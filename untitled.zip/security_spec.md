# FISM Security Specification (Payload-First Security TDD)

## 1. Data Invariants
1. **PII Split Isolation**: Public user profiles (`/users/{userId}`) contain zero PII (`email` is stored strictly in `/users/{userId}/private/{docId}` and readable only by `isOwner(userId)` or `isAdmin()`).
2. **Master Gate Relational Sync**: Subcollections `/posts/{postId}/comments/{commentId}` and `/posts/{postId}/sparks/{sparkId}` require the parent `/posts/{postId}` document to exist via `get()`/`exists()`.
3. **Identity Integrity**: Every created document (`Post`, `Comment`, `SparkReaction`, `SavedItem`, `Connection`, `EmberMessage`, `SmotherReport`) must have its author/owner UID field equal to `request.auth.uid`.
4. **Strict Keys & Partial Updates**: Every `isValid[Entity]` helper validates `data.keys().hasAll(...)` and `data.keys().hasOnly(...)` on create, and every `allow update` starts with `isValid[Entity](incoming())` and restricts mutated keys via `incoming().diff(existing()).affectedKeys().hasOnly(...)`.
5. **Temporal Integrity**: `createdAt == request.time` on create and `updatedAt == request.time` on update, with `createdAt == existing().createdAt` immutable.
6. **Secure List Queries**: No blanket `allow list: if isSignedIn();`. Every `allow list` restricts `resource.data` (e.g., `resource.data.visibility == 'public'` or `resource.data.authorId == request.auth.uid`).

## 2. The "Dirty Dozen" Payloads
1. **Identity Spoofing on Post**: `{ "authorId": "other_user_123", "caption": "Spoofed" }` -> `PERMISSION_DENIED`
2. **Shadow Field Injection on UserPublic**: `{ "uid": "u1", "username": "flame", "isAdmin": true }` -> `PERMISSION_DENIED`
3. **Self-Assigned Verification Badge**: `{ "uid": "u1", "username": "flame", "isVerified": true }` (non-admin create/update) -> `PERMISSION_DENIED`
4. **Unverified Email Write**: Authenticated user with `email_verified: false` attempting `create` on `/posts/p1` -> `PERMISSION_DENIED`
5. **PII Leak Attempt**: Authenticated user `u2` attempting `get` on `/users/u1/private/info` -> `PERMISSION_DENIED`
6. **ID Poisoning Attack**: Document ID exceeding 128 chars or containing special characters `../admin` -> `PERMISSION_DENIED`
7. **Unbounded Array / Denial of Wallet**: Post `hashtags` array with 25 items (`size() > 10`) -> `PERMISSION_DENIED`
8. **Value Poisoning on Update**: Updating `caption` on `/posts/p1` with a 50,000-character string or integer -> `PERMISSION_DENIED`
9. **Immutable Field Mutation**: Updating `authorId` or `createdAt` on `/posts/p1` -> `PERMISSION_DENIED`
10. **Forged Client Timestamp**: Creating a post where `createdAt != request.time` -> `PERMISSION_DENIED`
11. **Terminal State Bypass on Report**: Updating a `SmotherReport` after `status` is already `'resolved'` or `'dismissed'` by non-admin -> `PERMISSION_DENIED`
12. **Blanket List Scraping**: Listing `/messages` or `/notifications` without filtering `recipientId == request.auth.uid` or `senderId == request.auth.uid` -> `PERMISSION_DENIED`

## 3. Red Team Audit Summary
- **Shadow Update Test**: Passed (`hasOnly` enforced in both blueprint helpers and `affectedKeys()`).
- **Email Spoofing Test**: Passed (`request.auth.token.email_verified == true` required alongside email check).
- **PII Blanket Test**: Passed (`/users/{userId}/private/{docId}` restricted to owner or admin).
- **Query Trust Test**: Passed (all `allow list` rules check `resource.data`).
