/**
 * Firestore Security Rules Test Suite for FISM
 * Verifies that all Dirty Dozen payloads return PERMISSION_DENIED.
 */

export interface DirtyPayloadTestCase {
  id: number;
  name: string;
  collectionPath: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  authUid: string | null;
  emailVerified: boolean;
  payload?: Record<string, unknown>;
  expectedResult: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_TESTS: DirtyPayloadTestCase[] = [
  {
    id: 1,
    name: 'Identity Spoofing on Post',
    collectionPath: '/posts/post_1',
    operation: 'create',
    authUid: 'user_a',
    emailVerified: true,
    payload: { authorId: 'user_b', caption: 'Spoofed post' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Shadow Field Injection on UserPublic',
    collectionPath: '/users/user_a',
    operation: 'create',
    authUid: 'user_a',
    emailVerified: true,
    payload: { uid: 'user_a', username: 'flame', isAdmin: true },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Self-Assigned Verification Badge',
    collectionPath: '/users/user_a',
    operation: 'create',
    authUid: 'user_a',
    emailVerified: true,
    payload: { uid: 'user_a', username: 'flame', isVerified: true },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Unverified Email Write',
    collectionPath: '/posts/post_1',
    operation: 'create',
    authUid: 'user_a',
    emailVerified: false,
    payload: { authorId: 'user_a', caption: 'Unverified write' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'PII Leak Attempt on Private Info',
    collectionPath: '/users/user_a/private/info',
    operation: 'get',
    authUid: 'user_b',
    emailVerified: true,
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'ID Poisoning Attack',
    collectionPath: '/posts/invalid$id!with@spaces',
    operation: 'create',
    authUid: 'user_a',
    emailVerified: true,
    payload: { authorId: 'user_a', caption: 'Bad ID' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Unbounded Array Denial of Wallet',
    collectionPath: '/posts/post_1',
    operation: 'create',
    authUid: 'user_a',
    emailVerified: true,
    payload: {
      authorId: 'user_a',
      hashtags: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11'],
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Value Poisoning on Update',
    collectionPath: '/posts/post_1',
    operation: 'update',
    authUid: 'user_a',
    emailVerified: true,
    payload: { caption: 999999 },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Immutable Field Mutation',
    collectionPath: '/posts/post_1',
    operation: 'update',
    authUid: 'user_a',
    emailVerified: true,
    payload: { authorId: 'user_b' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Forged Client Timestamp',
    collectionPath: '/posts/post_1',
    operation: 'create',
    authUid: 'user_a',
    emailVerified: true,
    payload: { authorId: 'user_a', createdAt: '1999-01-01T00:00:00Z' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Terminal State Bypass on SmotherReport',
    collectionPath: '/reports/rep_1',
    operation: 'update',
    authUid: 'user_a',
    emailVerified: true,
    payload: { status: 'pending' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Blanket List Scraping on EmberMessage',
    collectionPath: '/messages',
    operation: 'list',
    authUid: 'user_c',
    emailVerified: true,
    expectedResult: 'PERMISSION_DENIED',
  },
];
