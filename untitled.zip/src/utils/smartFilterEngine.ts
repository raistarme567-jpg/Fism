import type { FismGameItem } from '../types';

export interface SegmentationResult {
  personDetected: boolean;
  coverageRatio: number;
  engine: 'mediapipe' | 'adaptive';
}

export interface ChromaKeyOptions {
  keyColorHex: string; // default '#00FF00'
  sensitivity: number; // 0..100
  smoothness: number; // 0..100
  spillSuppression?: number; // 0..100
  autoSampleCorner?: boolean;
}

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '').trim();
  if (/^[0-9A-Fa-f]{6}$/.test(clean)) {
    return [
      parseInt(clean.slice(0, 2), 16),
      parseInt(clean.slice(2, 4), 16),
      parseInt(clean.slice(4, 6), 16),
    ];
  }
  return [0, 255, 0];
}

function rgbToCbCr(r: number, g: number, b: number): [number, number] {
  const cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
  const cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
  return [cb, cr];
}

/**
 * Draw an image or video cover-fitted inside (w, h) preserving aspect ratio.
 */
export function drawCoverFitted(
  ctx: CanvasRenderingContext2D,
  source: CanvasImageSource,
  srcW: number,
  srcH: number,
  dstW: number,
  dstH: number,
  mirrorX = false,
): void {
  if (!srcW || !srcH || !dstW || !dstH) return;
  const srcRatio = srcW / srcH;
  const dstRatio = dstW / dstH;
  let drawW = dstW;
  let drawH = dstH;
  let offsetX = 0;
  let offsetY = 0;
  if (srcRatio > dstRatio) {
    drawH = dstH;
    drawW = dstH * srcRatio;
    offsetX = (dstW - drawW) / 2;
  } else {
    drawW = dstW;
    drawH = dstW / srcRatio;
    offsetY = (dstH - drawH) / 2;
  }
  ctx.save();
  if (mirrorX) {
    ctx.translate(dstW, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(source, offsetX, offsetY, drawW, drawH);
  ctx.restore();
}

/**
 * Fast, real-time YCbCr + Green-Dominance Chroma Keyer with edge feathering & spill suppression.
 * Preserves existing alpha transparency for PNG/WebM transparent overlays.
 */
export function applyChromaKeyToCanvas(
  source: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement,
  destCanvas: HTMLCanvasElement,
  opts: ChromaKeyOptions,
  maxProcWidth = 420,
): { ready: boolean; sampledHex?: string } {
  const rawW =
    source instanceof HTMLVideoElement
      ? source.videoWidth
      : source instanceof HTMLImageElement
        ? source.naturalWidth
        : source.width;
  const rawH =
    source instanceof HTMLVideoElement
      ? source.videoHeight
      : source instanceof HTMLImageElement
        ? source.naturalHeight
        : source.height;

  if (!rawW || !rawH) {
    return { ready: false };
  }

  const scale = rawW > maxProcWidth ? maxProcWidth / rawW : 1;
  const w = Math.max(2, Math.round(rawW * scale));
  const h = Math.max(2, Math.round(rawH * scale));

  if (destCanvas.width !== w || destCanvas.height !== h) {
    destCanvas.width = w;
    destCanvas.height = h;
  }

  const ctx = destCanvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return { ready: false };

  ctx.clearRect(0, 0, w, h);
  ctx.drawImage(source, 0, 0, w, h);

  // If sensitivity is 0, keep source intact (useful for already-transparent PNG/WebM assets)
  if (opts.sensitivity <= 0) {
    return { ready: true };
  }

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  let [kr, kg, kb] = hexToRgb(opts.keyColorHex || '#00FF00');
  let sampledHex: string | undefined;

  if (opts.autoSampleCorner) {
    // Sample top-left & top-right corners if non-transparent
    const idx1 = 0;
    const idx2 = (w - 1) * 4;
    if (data[idx1 + 3] > 200) {
      kr = data[idx1];
      kg = data[idx1 + 1];
      kb = data[idx1 + 2];
    } else if (data[idx2 + 3] > 200) {
      kr = data[idx2];
      kg = data[idx2 + 1];
      kb = data[idx2 + 2];
    }
    sampledHex = `#${[kr, kg, kb].map((c) => c.toString(16).padStart(2, '0')).join('').toUpperCase()}`;
  }

  const [keyCb, keyCr] = rgbToCbCr(kr, kg, kb);
  const isGreenKey = kg >= kr + 20 && kg >= kb + 20;

  // Map sensitivity (1..100) to chroma distance threshold (12..115)
  const tolA = 12 + (Math.min(100, Math.max(1, opts.sensitivity)) / 100) * 95;
  const feather = 6 + (Math.min(100, Math.max(0, opts.smoothness)) / 100) * 46;
  const tolB = tolA + feather;
  const spillAmount = (opts.spillSuppression ?? 70) / 100;

  for (let i = 0; i < data.length; i += 4) {
    const existingAlpha = data[i + 3];
    if (existingAlpha === 0) continue;

    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    const [cb, cr] = rgbToCbCr(r, g, b);
    const dist = Math.hypot(cb - keyCb, cr - keyCr);

    // Extra luminance guard for dark shadows vs vivid green
    const greenDominance = isGreenKey ? g - Math.max(r, b) : 999;

    if (dist < tolA && (!isGreenKey || greenDominance > 10)) {
      data[i + 3] = 0;
    } else if (dist < tolB && (!isGreenKey || greenDominance > 2)) {
      const t = (dist - tolA) / (tolB - tolA);
      data[i + 3] = Math.round(existingAlpha * Math.max(0, Math.min(1, t)));
      if (isGreenKey && spillAmount > 0) {
        const avgRB = (r + b) * 0.5;
        if (g > avgRB) {
          data[i + 1] = Math.round(g - (g - avgRB) * spillAmount * 0.85);
        }
      }
    } else if (isGreenKey && spillAmount > 0 && g > Math.max(r, b) + 12) {
      const avgRB = (r + b) * 0.5;
      data[i + 1] = Math.round(g - (g - avgRB) * spillAmount * 0.55);
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return { ready: true, sampledHex };
}

/**
 * Dual-Engine Real-Time Person Segmenter:
 *  1) Lazy MediaPipe ImageSegmenter (Selfie Segmenter) when WASM + TFLite are reachable.
 *  2) Adaptive real-time canvas background model + skin/motion foreground matte fallback
 *     so live compositing & "empty frame -> show uploaded photo cleanly" always work smoothly!
 */
export class SmartPersonSegmenter {
  private procW = 192;
  private procH = 256;
  private sampleCanvas: HTMLCanvasElement;
  private sampleCtx: CanvasRenderingContext2D;
  private maskCanvas: HTMLCanvasElement;
  private maskCtx: CanvasRenderingContext2D;
  private cutoutCanvas: HTMLCanvasElement;
  private cutoutCtx: CanvasRenderingContext2D;

  private bgModel: Float32Array | null = null;
  private prevGray: Uint8Array | null = null;
  private smoothedMask: Float32Array;
  private personActiveHysteresis = false;
  private lowFramesStreak = 0;

  // MediaPipe lazy state
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private mpSegmenter: any = null;
  private mpInitState: 'idle' | 'loading' | 'ready' | 'unavailable' = 'idle';
  private lastTimestampMs = 0;

  constructor() {
    this.sampleCanvas = document.createElement('canvas');
    this.sampleCanvas.width = this.procW;
    this.sampleCanvas.height = this.procH;
    this.sampleCtx = this.sampleCanvas.getContext('2d', { willReadFrequently: true })!;

    this.maskCanvas = document.createElement('canvas');
    this.maskCanvas.width = this.procW;
    this.maskCanvas.height = this.procH;
    this.maskCtx = this.maskCanvas.getContext('2d', { willReadFrequently: true })!;

    this.cutoutCanvas = document.createElement('canvas');
    this.cutoutCanvas.width = this.procW;
    this.cutoutCanvas.height = this.procH;
    this.cutoutCtx = this.cutoutCanvas.getContext('2d')!;

    this.smoothedMask = new Float32Array(this.procW * this.procH);
  }

  public initMediaPipeLazy(): void {
    if (this.mpInitState !== 'idle') return;
    this.mpInitState = 'loading';
    (async () => {
      try {
        const vision = await import('@mediapipe/tasks-vision');
        const fileset = await vision.FilesetResolver.forVisionTasks(
          'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.34/wasm',
        );
        const segmenter = await vision.ImageSegmenter.createFromOptions(fileset, {
          baseOptions: {
            modelAssetPath:
              'https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite',
            delegate: 'GPU',
          },
          runningMode: 'VIDEO',
          outputCategoryMask: false,
          outputConfidenceMasks: true,
        });
        this.mpSegmenter = segmenter;
        this.mpInitState = 'ready';
      } catch {
        this.mpInitState = 'unavailable';
      }
    })();
  }

  public calibrateEmptyBackground(video: HTMLVideoElement): boolean {
    if (!video || video.readyState < 2 || !video.videoWidth || !video.videoHeight) {
      return false;
    }
    drawCoverFitted(
      this.sampleCtx,
      video,
      video.videoWidth,
      video.videoHeight,
      this.procW,
      this.procH,
      true,
    );
    const frame = this.sampleCtx.getImageData(0, 0, this.procW, this.procH).data;
    if (!this.bgModel) {
      this.bgModel = new Float32Array(this.procW * this.procH * 3);
    }
    for (let i = 0, p = 0; i < frame.length; i += 4, p += 3) {
      this.bgModel[p] = frame[i];
      this.bgModel[p + 1] = frame[i + 1];
      this.bgModel[p + 2] = frame[i + 2];
    }
    this.smoothedMask.fill(0);
    this.personActiveHysteresis = false;
    return true;
  }

  public segmentAndComposite(
    outCtx: CanvasRenderingContext2D,
    outW: number,
    outH: number,
    video: HTMLVideoElement | null,
    backgroundImage: CanvasImageSource | null,
    bgW: number,
    bgH: number,
    sensitivity = 58,
    mirrorVideo = true,
  ): SegmentationResult {
    // 1. Always render uploaded background photo cleanly at 100% first
    outCtx.clearRect(0, 0, outW, outH);
    if (backgroundImage && bgW > 0 && bgH > 0) {
      drawCoverFitted(outCtx, backgroundImage, bgW, bgH, outW, outH, false);
    } else {
      const grad = outCtx.createLinearGradient(0, 0, 0, outH);
      grad.addColorStop(0, '#0F172A');
      grad.addColorStop(1, '#1E1B4B');
      outCtx.fillStyle = grad;
      outCtx.fillRect(0, 0, outW, outH);
    }

    if (!video || video.readyState < 2 || !video.videoWidth || !video.videoHeight) {
      return { personDetected: false, coverageRatio: 0, engine: 'adaptive' };
    }

    // Kick off lazy MediaPipe load in background
    if (this.mpInitState === 'idle') {
      this.initMediaPipeLazy();
    }

    // Draw mirrored webcam frame into small working buffer
    this.sampleCtx.clearRect(0, 0, this.procW, this.procH);
    drawCoverFitted(
      this.sampleCtx,
      video,
      video.videoWidth,
      video.videoHeight,
      this.procW,
      this.procH,
      mirrorVideo,
    );

    let coverageRatio = 0;
    let engine: 'mediapipe' | 'adaptive' = 'adaptive';

    // Try MediaPipe segmenter when ready
    if (this.mpInitState === 'ready' && this.mpSegmenter) {
      try {
        const now = performance.now();
        const ts = now > this.lastTimestampMs ? now : this.lastTimestampMs + 1;
        this.lastTimestampMs = ts;
        const mpResult = this.mpSegmenter.segmentForVideo(this.sampleCanvas, ts);
        const confMask = mpResult?.confidenceMasks?.[0];
        if (confMask) {
          const floatArr: Float32Array = confMask.getAsFloat32Array();
          const threshold = 0.72 - (Math.min(95, Math.max(10, sensitivity)) / 100) * 0.45;
          const total = this.procW * this.procH;
          let fgPixels = 0;
          const maskImg = this.maskCtx.createImageData(this.procW, this.procH);
          const mData = maskImg.data;
          for (let i = 0; i < total; i++) {
            const conf = floatArr[i] ?? 0;
            const soft = Math.max(0, Math.min(1, (conf - threshold) / 0.16));
            const alpha = Math.round(soft * 255);
            if (soft > 0.45) fgPixels++;
            const o = i * 4;
            mData[o] = 255;
            mData[o + 1] = 255;
            mData[o + 2] = 255;
            mData[o + 3] = alpha;
          }
          this.maskCtx.putImageData(maskImg, 0, 0);
          confMask.close?.();
          coverageRatio = fgPixels / total;
          engine = 'mediapipe';
        }
      } catch {
        // fallback cleanly below
      }
    }

    if (engine === 'adaptive') {
      coverageRatio = this.runAdaptiveSegmentation(sensitivity);
    }

    // Hysteresis prevents glitchy flickering when scene is empty vs person standing still
    if (coverageRatio >= 0.045) {
      this.personActiveHysteresis = true;
      this.lowFramesStreak = 0;
    } else if (coverageRatio < 0.024) {
      this.lowFramesStreak += 1;
      if (this.lowFramesStreak >= 4) {
        this.personActiveHysteresis = false;
      }
    }

    // If NO person detected in front of camera, return immediately so background photo stays 100% glitch-free!
    if (!this.personActiveHysteresis) {
      return { personDetected: false, coverageRatio, engine };
    }

    // Composite foreground cutout with light edge feathering onto output canvas
    this.cutoutCtx.clearRect(0, 0, this.procW, this.procH);
    this.cutoutCtx.save();
    this.cutoutCtx.filter = 'blur(1.4px)';
    this.cutoutCtx.drawImage(this.maskCanvas, 0, 0);
    this.cutoutCtx.restore();
    this.cutoutCtx.save();
    this.cutoutCtx.globalCompositeOperation = 'source-in';
    this.cutoutCtx.drawImage(this.sampleCanvas, 0, 0);
    this.cutoutCtx.restore();

    outCtx.save();
    outCtx.imageSmoothingEnabled = true;
    outCtx.imageSmoothingQuality = 'high';
    outCtx.drawImage(this.cutoutCanvas, 0, 0, outW, outH);
    outCtx.restore();

    return { personDetected: true, coverageRatio, engine };
  }

  private runAdaptiveSegmentation(sensitivity: number): number {
    const frame = this.sampleCtx.getImageData(0, 0, this.procW, this.procH).data;
    const total = this.procW * this.procH;

    if (!this.bgModel) {
      this.bgModel = new Float32Array(total * 3);
      for (let i = 0, p = 0; i < frame.length; i += 4, p += 3) {
        this.bgModel[p] = frame[i];
        this.bgModel[p + 1] = frame[i + 1];
        this.bgModel[p + 2] = frame[i + 2];
      }
    }
    if (!this.prevGray) {
      this.prevGray = new Uint8Array(total);
    }

    const diffThresh = 66 - (Math.min(95, Math.max(10, sensitivity)) / 100) * 40;
    const maskImg = this.maskCtx.createImageData(this.procW, this.procH);
    const mData = maskImg.data;
    let fgCount = 0;

    for (let idx = 0; idx < total; idx++) {
      const o = idx * 4;
      const p = idx * 3;
      const r = frame[o];
      const g = frame[o + 1];
      const b = frame[o + 2];

      const br = this.bgModel[p];
      const bg = this.bgModel[p + 1];
      const bb = this.bgModel[p + 2];

      // Chroma-green wall detection + background difference
      const greenExcess = g - Math.max(r, b);
      const isGreenWall = greenExcess > 24 && g > 75;

      const colorDist = Math.hypot(r - br, g - bg, b - bb);
      const gray = (r * 77 + g * 150 + b * 29) >> 8;
      const motion = Math.abs(gray - this.prevGray[idx]);
      this.prevGray[idx] = gray;

      // YCbCr skin-tone cue in human upper-torso center region boosts stillness retention
      const cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
      const cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
      const isSkinTone = cb >= 77 && cb <= 127 && cr >= 133 && cr <= 173 && r > 65;

      let rawFg = 0;
      if (!isGreenWall) {
        if (colorDist > diffThresh || motion > 24) {
          rawFg = Math.min(1, Math.max((colorDist - diffThresh * 0.72) / (diffThresh * 0.55), motion > 24 ? 0.9 : 0));
        } else if (isSkinTone && colorDist > diffThresh * 0.48) {
          rawFg = 0.85;
        }
      }

      // Temporal smoothing & slow background adaptation only for static non-foreground pixels
      const prevSmooth = this.smoothedMask[idx];
      const nextSmooth = rawFg > prevSmooth ? prevSmooth * 0.35 + rawFg * 0.65 : prevSmooth * 0.72 + rawFg * 0.28;
      this.smoothedMask[idx] = nextSmooth;

      if (nextSmooth < 0.15 && motion < 8) {
        this.bgModel[p] = br * 0.985 + r * 0.015;
        this.bgModel[p + 1] = bg * 0.985 + g * 0.015;
        this.bgModel[p + 2] = bb * 0.985 + b * 0.015;
      }

      if (nextSmooth > 0.45) fgCount++;
      mData[o] = 255;
      mData[o + 1] = 255;
      mData[o + 2] = 255;
      mData[o + 3] = Math.round(Math.max(0, Math.min(1, (nextSmooth - 0.28) / 0.45)) * 255);
    }

    this.maskCtx.putImageData(maskImg, 0, 0);
    return fgCount / total;
  }

  public dispose(): void {
    try {
      this.mpSegmenter?.close?.();
    } catch {
      // ignore
    }
    this.mpSegmenter = null;
  }
}

/**
 * Generates crisp built-in green-screen (#00FF00) overlay assets as data URLs so users
 * can immediately try Camera Filter drag/resize/rotate/chroma-removal even before uploading custom files.
 */
export function createBuiltInChromaElementDataUrl(
  preset: 'neon_wings' | 'flame_badge' | 'cyber_frame',
): string {
  const c = document.createElement('canvas');
  c.width = 480;
  c.height = 480;
  const ctx = c.getContext('2d')!;
  // Chroma Green backdrop (#00FF00)
  ctx.fillStyle = '#00FF00';
  ctx.fillRect(0, 0, 480, 480);

  if (preset === 'neon_wings') {
    ctx.strokeStyle = '#00F5D4';
    ctx.lineWidth = 10;
    ctx.shadowColor = '#38BDF8';
    ctx.shadowBlur = 18;
    // Left & Right Neon Cyber Wings
    for (const dir of [-1, 1]) {
      ctx.save();
      ctx.translate(240, 240);
      ctx.scale(dir, 1);
      ctx.beginPath();
      ctx.moveTo(22, -10);
      ctx.quadraticCurveTo(150, -140, 210, -70);
      ctx.quadraticCurveTo(175, 10, 120, 40);
      ctx.quadraticCurveTo(160, 75, 95, 115);
      ctx.quadraticCurveTo(45, 70, 22, 20);
      ctx.closePath();
      const grad = ctx.createLinearGradient(20, -120, 210, 110);
      grad.addColorStop(0, '#00F5D4');
      grad.addColorStop(1, '#EC4899');
      ctx.fillStyle = grad;
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  } else if (preset === 'flame_badge') {
    ctx.save();
    ctx.translate(240, 240);
    ctx.beginPath();
    ctx.arc(0, 0, 150, 0, Math.PI * 2);
    const g = ctx.createRadialGradient(0, -30, 20, 0, 0, 155);
    g.addColorStop(0, '#FFB300');
    g.addColorStop(0.65, '#FF5722');
    g.addColorStop(1, '#9A1A09');
    ctx.fillStyle = g;
    ctx.fill();
    ctx.lineWidth = 12;
    ctx.strokeStyle = '#FFFBEB';
    ctx.stroke();
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '900 54px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('FISM', 0, -6);
    ctx.font = '800 30px sans-serif';
    ctx.fillStyle = '#FDE047';
    ctx.fillText('LIVE PRO', 0, 42);
    ctx.restore();
  } else {
    ctx.strokeStyle = '#FF5722';
    ctx.lineWidth = 18;
    ctx.strokeRect(32, 32, 416, 416);
    ctx.strokeStyle = '#00F5D4';
    ctx.lineWidth = 6;
    ctx.strokeRect(52, 52, 376, 376);
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(110, 28, 260, 46);
    ctx.fillStyle = '#FFB300';
    ctx.font = '900 26px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('REC • CREATOR HUD', 240, 60);
  }
  return c.toDataURL('image/png');
}

/**
 * Interactive 2D Green-Screen Game Runtime:
 * Renders gameplay onto an offscreen canvas with a crisp #00FF00 chroma key background,
 * so chroma removal strips the green layer cleanly and lets the live camera feed shine behind!
 */
export class InteractiveGreenScreenGameRuntime {
  public canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  public engineType: FismGameItem['engineType'] = 'customAdmin2D';
  public gameTitle = 'Starfighter AR';
  public score = 0;
  public lives = 3;
  public isPaused = false;
  public gameOver = false;

  private playerX = 0.5;
  private playerY = 0.82;
  private runnerVelY = 0;
  private runnerOnGround = true;
  private ballX = 0.5;
  private ballY = 0.55;
  private ballVx = 0.36;
  private ballVy = -0.44;
  private snakeCells: Array<{ x: number; y: number }> = [
    { x: 10, y: 12 },
    { x: 9, y: 12 },
    { x: 8, y: 12 },
  ];
  private snakeDir: { x: number; y: number } = { x: 1, y: 0 };
  private snakeAccum = 0;
  private foodCell = { x: 14, y: 10 };

  private bullets: Array<{ x: number; y: number }> = [];
  private enemies: Array<{ x: number; y: number; speed: number; kind: 'orb' | 'coin' | 'boss'; r: number }> = [];
  private bricks: Array<{ x: number; y: number; w: number; h: number; alive: boolean; color: string }> = [];
  private spawnTimer = 0;
  private shootTimer = 0;
  private lastTick = 0;

  constructor(width = 360, height = 640) {
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    this.ctx = this.canvas.getContext('2d')!;
    this.reset(this.engineType, this.gameTitle);
  }

  public reset(engineType: FismGameItem['engineType'], title: string): void {
    this.engineType = engineType;
    this.gameTitle = title;
    this.score = 0;
    this.lives = 3;
    this.gameOver = false;
    this.isPaused = false;
    this.playerX = 0.5;
    this.playerY = engineType === 'flameRunner2D' ? 0.78 : 0.84;
    this.runnerVelY = 0;
    this.runnerOnGround = true;
    this.bullets = [];
    this.enemies = [];
    this.spawnTimer = 0;
    this.shootTimer = 0;
    this.ballX = 0.5;
    this.ballY = 0.62;
    this.ballVx = 0.36;
    this.ballVy = -0.45;
    this.snakeCells = [
      { x: 8, y: 14 },
      { x: 7, y: 14 },
      { x: 6, y: 14 },
    ];
    this.snakeDir = { x: 1, y: 0 };
    this.foodCell = { x: 12, y: 9 };

    this.bricks = [];
    if (engineType === 'brickBreaker2D') {
      const palette = ['#FF5722', '#FFB300', '#00F5D4', '#EC4899'];
      for (let row = 0; row < 4; row++) {
        for (let col = 0; col < 5; col++) {
          this.bricks.push({
            x: 0.08 + col * 0.172,
            y: 0.16 + row * 0.06,
            w: 0.15,
            h: 0.042,
            alive: true,
            color: palette[row % palette.length],
          });
        }
      }
    }
    this.lastTick = performance.now();
  }

  public handlePointer(normX: number, normY: number, isTap: boolean): void {
    if (this.gameOver && isTap) {
      this.reset(this.engineType, this.gameTitle);
      return;
    }
    const clampedX = Math.max(0.08, Math.min(0.92, normX));
    this.playerX = clampedX;

    if (this.engineType === 'flameRunner2D' && isTap && this.runnerOnGround) {
      this.runnerVelY = -0.95;
      this.runnerOnGround = false;
    } else if (
      (this.engineType === 'customAdmin2D' || this.engineType === 'redBallDefense2D') &&
      isTap
    ) {
      if (this.engineType === 'redBallDefense2D') {
        // Direct tap pop on orbs!
        for (let i = this.enemies.length - 1; i >= 0; i--) {
          const e = this.enemies[i];
          if (Math.hypot(e.x - normX, e.y - normY) < e.r + 0.08) {
            this.enemies.splice(i, 1);
            this.score += e.kind === 'coin' ? 25 : 15;
            return;
          }
        }
      }
      this.bullets.push({ x: this.playerX, y: this.playerY - 0.05 });
    } else if (this.engineType === 'cyberSnake2D' && isTap) {
      const head = this.snakeCells[0];
      const dx = normX - head.x / 18;
      const dy = normY - head.y / 32;
      if (Math.abs(dx) > Math.abs(dy)) {
        const nextX = dx > 0 ? 1 : -1;
        if (this.snakeDir.x !== -nextX) this.snakeDir = { x: nextX, y: 0 };
      } else {
        const nextY = dy > 0 ? 1 : -1;
        if (this.snakeDir.y !== -nextY) this.snakeDir = { x: 0, y: nextY };
      }
    }
  }

  public handleKey(key: string): void {
    if (key === 'ArrowLeft' || key === 'a') {
      this.playerX = Math.max(0.08, this.playerX - 0.07);
      if (this.engineType === 'cyberSnake2D' && this.snakeDir.x !== 1) this.snakeDir = { x: -1, y: 0 };
    } else if (key === 'ArrowRight' || key === 'd') {
      this.playerX = Math.min(0.92, this.playerX + 0.07);
      if (this.engineType === 'cyberSnake2D' && this.snakeDir.x !== -1) this.snakeDir = { x: 1, y: 0 };
    } else if (key === 'ArrowUp' || key === 'w' || key === ' ') {
      if (this.engineType === 'flameRunner2D' && this.runnerOnGround) {
        this.runnerVelY = -0.95;
        this.runnerOnGround = false;
      } else if (this.engineType === 'cyberSnake2D' && this.snakeDir.y !== 1) {
        this.snakeDir = { x: 0, y: -1 };
      } else {
        this.bullets.push({ x: this.playerX, y: this.playerY - 0.05 });
      }
    } else if (key === 'ArrowDown' || key === 's') {
      if (this.engineType === 'cyberSnake2D' && this.snakeDir.y !== -1) this.snakeDir = { x: 0, y: 1 };
    }
  }

  public stepAndRender(now: number): HTMLCanvasElement {
    const dt = Math.min(0.05, Math.max(0.008, (now - this.lastTick) / 1000));
    this.lastTick = now;

    const w = this.canvas.width;
    const h = this.canvas.height;
    const ctx = this.ctx;

    // Pure Chroma-Key Green Screen (#00FF00) background so chroma keyer exposes live camera behind!
    ctx.fillStyle = '#00FF00';
    ctx.fillRect(0, 0, w, h);

    if (!this.isPaused && !this.gameOver) {
      this.updatePhysics(dt);
    }

    this.drawGameEntities(ctx, w, h);
    return this.canvas;
  }

  private updatePhysics(dt: number): void {
    if (this.engineType === 'flameRunner2D') {
      this.runnerVelY += 2.3 * dt;
      this.playerY += this.runnerVelY * dt;
      if (this.playerY >= 0.78) {
        this.playerY = 0.78;
        this.runnerVelY = 0;
        this.runnerOnGround = true;
      }
      this.spawnTimer += dt;
      if (this.spawnTimer > 1.15) {
        this.spawnTimer = 0;
        this.enemies.push({
          x: 1.05,
          y: Math.random() > 0.45 ? 0.76 : 0.62,
          speed: 0.42,
          kind: Math.random() > 0.5 ? 'coin' : 'boss',
          r: 0.045,
        });
      }
      for (let i = this.enemies.length - 1; i >= 0; i--) {
        const e = this.enemies[i];
        e.x -= e.speed * dt;
        if (Math.hypot(e.x - this.playerX, e.y - this.playerY) < 0.075) {
          if (e.kind === 'coin') {
            this.score += 25;
          } else {
            this.lives -= 1;
            if (this.lives <= 0) this.gameOver = true;
          }
          this.enemies.splice(i, 1);
          continue;
        }
        if (e.x < -0.1) {
          if (e.kind !== 'coin') this.score += 5;
          this.enemies.splice(i, 1);
        }
      }
      return;
    }

    if (this.engineType === 'brickBreaker2D') {
      this.ballX += this.ballVx * dt;
      this.ballY += this.ballVy * dt;
      if (this.ballX < 0.04 || this.ballX > 0.96) this.ballVx *= -1;
      if (this.ballY < 0.12) this.ballVy = Math.abs(this.ballVy);
      if (
        this.ballY > 0.81 &&
        this.ballY < 0.86 &&
        Math.abs(this.ballX - this.playerX) < 0.13 &&
        this.ballVy > 0
      ) {
        this.ballVy = -Math.abs(this.ballVy);
        this.ballVx = (this.ballX - this.playerX) * 2.4;
      }
      for (const b of this.bricks) {
        if (!b.alive) continue;
        if (
          this.ballX >= b.x &&
          this.ballX <= b.x + b.w &&
          this.ballY >= b.y &&
          this.ballY <= b.y + b.h
        ) {
          b.alive = false;
          this.ballVy *= -1;
          this.score += 20;
          break;
        }
      }
      if (this.bricks.every((b) => !b.alive)) {
        this.bricks.forEach((b) => (b.alive = true));
        this.score += 100;
      }
      if (this.ballY > 0.98) {
        this.lives -= 1;
        this.ballX = 0.5;
        this.ballY = 0.6;
        this.ballVy = -0.45;
        if (this.lives <= 0) this.gameOver = true;
      }
      return;
    }

    if (this.engineType === 'cyberSnake2D') {
      this.snakeAccum += dt;
      if (this.snakeAccum >= 0.14) {
        this.snakeAccum = 0;
        const nextHead = {
          x: (this.snakeCells[0].x + this.snakeDir.x + 18) % 18,
          y: ((this.snakeCells[0].y + this.snakeDir.y - 3 + 26) % 26) + 3,
        };
        this.snakeCells.unshift(nextHead);
        if (nextHead.x === this.foodCell.x && nextHead.y === this.foodCell.y) {
          this.score += 30;
          this.foodCell = {
            x: 2 + Math.floor(Math.random() * 14),
            y: 4 + Math.floor(Math.random() * 20),
          };
        } else {
          this.snakeCells.pop();
        }
      }
      return;
    }

    // Starfighter (customAdmin2D) & Red Ball Defense (redBallDefense2D)
    this.shootTimer += dt;
    if (this.engineType === 'customAdmin2D' && this.shootTimer > 0.34) {
      this.shootTimer = 0;
      this.bullets.push({ x: this.playerX, y: this.playerY - 0.05 });
    }
    this.spawnTimer += dt;
    if (this.spawnTimer > 0.85) {
      this.spawnTimer = 0;
      const roll = Math.random();
      this.enemies.push({
        x: 0.12 + Math.random() * 0.76,
        y: 0.1,
        speed: 0.16 + Math.random() * 0.16,
        kind: roll > 0.65 ? 'coin' : roll > 0.2 ? 'orb' : 'boss',
        r: roll < 0.2 ? 0.055 : 0.04,
      });
    }

    for (let i = this.bullets.length - 1; i >= 0; i--) {
      this.bullets[i].y -= 0.75 * dt;
      if (this.bullets[i].y < 0.08) this.bullets.splice(i, 1);
    }

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      e.y += e.speed * dt;
      let hit = false;
      for (let j = this.bullets.length - 1; j >= 0; j--) {
        const b = this.bullets[j];
        if (Math.hypot(e.x - b.x, e.y - b.y) < e.r + 0.03) {
          this.bullets.splice(j, 1);
          this.enemies.splice(i, 1);
          this.score += e.kind === 'boss' ? 35 : 15;
          hit = true;
          break;
        }
      }
      if (hit) continue;

      if (Math.hypot(e.x - this.playerX, e.y - this.playerY) < 0.08) {
        if (e.kind === 'coin') {
          this.score += 30;
        } else {
          this.lives -= 1;
          if (this.lives <= 0) this.gameOver = true;
        }
        this.enemies.splice(i, 1);
        continue;
      }

      if (e.y > 0.94) {
        if (e.kind === 'boss') {
          this.lives -= 1;
          if (this.lives <= 0) this.gameOver = true;
        }
        this.enemies.splice(i, 1);
      }
    }
  }

  private drawGameEntities(ctx: CanvasRenderingContext2D, w: number, h: number): void {
    // Score HUD Pill (uses dark navy & orange — zero green pixels so chroma won't erase HUD)
    ctx.save();
    ctx.fillStyle = '#0F172A';
    ctx.strokeStyle = '#FF5722';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(14, 14, w - 28, 44, 14);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#FFB300';
    ctx.font = '900 14px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(`⚡ ${this.score} PTS`, 28, 41);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '800 12px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(this.gameTitle.slice(0, 18), w / 2, 41);

    ctx.fillStyle = '#F43F5E';
    ctx.textAlign = 'right';
    ctx.fillText('❤️'.repeat(Math.max(0, this.lives)) || '💀', w - 26, 41);
    ctx.restore();

    if (this.engineType === 'brickBreaker2D') {
      for (const b of this.bricks) {
        if (!b.alive) continue;
        ctx.fillStyle = b.color;
        ctx.strokeStyle = '#0F172A';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(b.x * w, b.y * h, b.w * w, b.h * h, 6);
        ctx.fill();
        ctx.stroke();
      }
      // Paddle
      ctx.fillStyle = '#FF5722';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect((this.playerX - 0.11) * w, 0.83 * h, 0.22 * w, 14, 7);
      ctx.fill();
      ctx.stroke();
      // Ball
      ctx.fillStyle = '#FDE047';
      ctx.beginPath();
      ctx.arc(this.ballX * w, this.ballY * h, 10, 0, Math.PI * 2);
      ctx.fill();
    } else if (this.engineType === 'cyberSnake2D') {
      const cellW = w / 18;
      const cellH = h / 32;
      // Food Orb
      ctx.fillStyle = '#FF2A85';
      ctx.beginPath();
      ctx.arc(
        (this.foodCell.x + 0.5) * cellW,
        (this.foodCell.y + 0.5) * cellH,
        cellW * 0.42,
        0,
        Math.PI * 2,
      );
      ctx.fill();
      // Snake Segments (Cyan & Orange so green-screen removal leaves snake crisp)
      this.snakeCells.forEach((cell, i) => {
        ctx.fillStyle = i === 0 ? '#FFB300' : '#00F5D4';
        ctx.strokeStyle = '#0F172A';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(cell.x * cellW + 1, cell.y * cellH + 1, cellW - 2, cellH - 2, 5);
        ctx.fill();
        ctx.stroke();
      });
    } else if (this.engineType === 'flameRunner2D') {
      // Track Rail
      ctx.strokeStyle = '#FF5722';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(16, 0.82 * h);
      ctx.lineTo(w - 16, 0.82 * h);
      ctx.stroke();

      // Runner Orb / Avatar
      ctx.fillStyle = '#FF5722';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(this.playerX * w, this.playerY * h, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '900 18px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🔥', this.playerX * w, this.playerY * h + 7);

      // Obstacles & Coins
      for (const e of this.enemies) {
        ctx.fillStyle = e.kind === 'coin' ? '#FFB300' : '#EF4444';
        ctx.strokeStyle = '#0F172A';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(e.x * w, e.y * h, e.r * w, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#FFFFFF';
        ctx.font = '800 14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(e.kind === 'coin' ? '★' : '▲', e.x * w, e.y * h + 5);
      }
    } else {
      // Starfighter / Red Ball Defense
      for (const b of this.bullets) {
        ctx.fillStyle = '#00F5D4';
        ctx.fillRect(b.x * w - 3, b.y * h - 10, 6, 18);
      }
      for (const e of this.enemies) {
        ctx.fillStyle =
          e.kind === 'coin' ? '#FFB300' : e.kind === 'boss' ? '#DC2626' : '#EC4899';
        ctx.strokeStyle = '#0F172A';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(e.x * w, e.y * h, e.r * w, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#FFFFFF';
        ctx.font = '800 14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(e.kind === 'coin' ? '★' : '👾', e.x * w, e.y * h + 5);
      }
      // Player Ship
      const px = this.playerX * w;
      const py = this.playerY * h;
      ctx.fillStyle = '#FF5722';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(px, py - 24);
      ctx.lineTo(px + 22, py + 18);
      ctx.lineTo(px, py + 10);
      ctx.lineTo(px - 22, py + 18);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    if (this.gameOver) {
      ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
      ctx.strokeStyle = '#FF5722';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(w * 0.14, h * 0.36, w * 0.72, 118, 18);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#FFB300';
      ctx.font = '900 22px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('GAME OVER', w / 2, h * 0.43);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '800 14px sans-serif';
      ctx.fillText(`Final Score: ${this.score} • Tap to Restart`, w / 2, h * 0.49);
    }
  }
}
