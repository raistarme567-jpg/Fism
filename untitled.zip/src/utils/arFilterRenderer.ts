import { FismArFilterAsset, FismPremiumProfileStyle } from '../types';

export const PREMIUM_USERNAME_FONTS: {
  id: FismPremiumProfileStyle['usernameFontId'];
  label: string;
  fontClass: string;
}[] = [
  { id: 'geometric', label: 'Display Geometric', fontClass: 'font-sans tracking-tight' },
  { id: 'editorial', label: 'Editorial Serif', fontClass: 'font-serif tracking-normal' },
  { id: 'mono', label: 'Technical Mono', fontClass: 'font-mono tracking-wider' },
  { id: 'condensed', label: 'Athletic Bold', fontClass: 'font-sans uppercase tracking-widest' },
];

export const PREMIUM_USERNAME_EFFECTS: {
  id: FismPremiumProfileStyle['usernameEffectId'];
  label: string;
}[] = [
  { id: 'classic', label: 'Clean Classic' },
  { id: 'flameGradient', label: 'Flame Gradient' },
  { id: 'goldShimmer', label: 'Gold Shimmer' },
  { id: 'royalOutline', label: 'Royal Glow' },
];

export const PREMIUM_COLOR_PRESETS = [
  { hex: '#FF5722', label: 'FISM Flame' },
  { hex: '#7C3AED', label: 'Royal Violet' },
  { hex: '#0EA5E9', label: 'Cyber Cyan' },
  { hex: '#10B981', label: 'Emerald Spark' },
  { hex: '#F59E0B', label: 'Solar Amber' },
  { hex: '#EC4899', label: 'Neon Rose' },
];

const DANGEROUS_MARKUP_REGEX =
  /<\s*\/?\s*(script|style|iframe|object|embed|svg|img|link|meta|body|html|div|span)\b|<|>|javascript:|data:text\/html|on\w+\s*=|style\s*=|@import|expression\s*\(/i;

const HEX_COLOR_REGEX = /^#[0-9A-Fa-f]{6}$/;

export function sanitizeAndValidateProfileStyle(
  input: Partial<FismPremiumProfileStyle> & { rawCustomInput?: string },
): {
  valid: boolean;
  error?: string;
  style?: FismPremiumProfileStyle;
} {
  if (input.rawCustomInput && DANGEROUS_MARKUP_REGEX.test(input.rawCustomInput)) {
    return {
      valid: false,
      error:
        'Security Block: HTML, <script>, <style>, or inline CSS injection tags are strictly prohibited!',
    };
  }

  const hex = String(input.themeColorHex || '#FF5722').trim();
  if (DANGEROUS_MARKUP_REGEX.test(hex) || !HEX_COLOR_REGEX.test(hex)) {
    return {
      valid: false,
      error:
        'Invalid Hex Color: Use a strict 6-digit hex code like #FF5722. Arbitrary CSS/HTML is rejected.',
    };
  }

  const allowedFonts: FismPremiumProfileStyle['usernameFontId'][] = [
    'geometric',
    'editorial',
    'mono',
    'condensed',
  ];
  const allowedEffects: FismPremiumProfileStyle['usernameEffectId'][] = [
    'classic',
    'flameGradient',
    'goldShimmer',
    'royalOutline',
  ];

  const fontId = allowedFonts.includes(
    input.usernameFontId as FismPremiumProfileStyle['usernameFontId'],
  )
    ? (input.usernameFontId as FismPremiumProfileStyle['usernameFontId'])
    : 'geometric';

  const effectId = allowedEffects.includes(
    input.usernameEffectId as FismPremiumProfileStyle['usernameEffectId'],
  )
    ? (input.usernameEffectId as FismPremiumProfileStyle['usernameEffectId'])
    : 'classic';

  return {
    valid: true,
    style: {
      themeColorHex: hex.toUpperCase(),
      customDarkAccent: Boolean(input.customDarkAccent),
      usernameFontId: fontId,
      usernameEffectId: effectId,
    },
  };
}

/**
 * Renders dynamic AR overlays (Cyberpunk Sunglasses, Neon Halo, Flame Crown, Laser Visor,
 * Cat Ears, Angel Wings, Spark HUD, Prism Glasses) aligned to the center/eye band of the camera frame.
 */
export function drawArFilterOverlay(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  filter: FismArFilterAsset | null | undefined,
  timeMs: number,
) {
  if (!filter) return;

  const cx = width * 0.5 + (filter.eyeOffsetX / 100) * (width * 0.25);
  const eyeY = height * 0.42 + (filter.eyeOffsetY / 100) * (height * 0.25);
  const s = Math.max(0.4, Math.min(2.4, filter.scale || 1)) * (Math.min(width, height) / 340);
  const primary = filter.primaryColor || '#00F5D4';
  const secondary = filter.secondaryColor || '#FF2A85';
  const glow = Math.max(0, Math.min(40, filter.glowIntensity ?? 18));
  const pulse = 0.88 + 0.12 * Math.sin(timeMs * 0.005);

  ctx.save();
  ctx.shadowColor = primary;
  ctx.shadowBlur = glow * pulse;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  switch (filter.overlayType) {
    case 'cyberpunk_sunglasses':
    case 'prism_glasses': {
      const lensW = 64 * s;
      const lensH = 34 * s;
      const gap = 14 * s;

      // Subtle futuristic scanline beam inside lenses
      const drawLens = (x: number, y: number, skew: number) => {
        ctx.beginPath();
        ctx.moveTo(x - lensW / 2, y - lensH / 2);
        ctx.lineTo(x + lensW / 2, y - lensH / 2 + skew);
        ctx.lineTo(x + lensW / 2 - 8 * s, y + lensH / 2);
        ctx.lineTo(x - lensW / 2 + 8 * s, y + lensH / 2 - skew * 0.5);
        ctx.closePath();

        const grad = ctx.createLinearGradient(x - lensW / 2, y - lensH / 2, x + lensW / 2, y + lensH / 2);
        grad.addColorStop(0, `${primary}B8`);
        grad.addColorStop(0.5, '#0F172ACC');
        grad.addColorStop(1, `${secondary}B8`);
        ctx.fillStyle = grad;
        ctx.fill();

        ctx.lineWidth = 3 * s;
        ctx.strokeStyle = primary;
        ctx.stroke();

        // Diagonal reflection gleam
        ctx.beginPath();
        ctx.strokeStyle = '#FFFFFFAA';
        ctx.lineWidth = 2 * s;
        const scanOffset = ((timeMs * 0.06) % lensW) - lensW * 0.4;
        ctx.moveTo(x + scanOffset - 6 * s, y - lensH * 0.35);
        ctx.lineTo(x + scanOffset + 6 * s, y + lensH * 0.35);
        ctx.stroke();
      };

      drawLens(cx - lensW / 2 - gap / 2, eyeY, 4 * s);
      drawLens(cx + lensW / 2 + gap / 2, eyeY, -4 * s);

      // Bridge & temple arms
      ctx.beginPath();
      ctx.strokeStyle = secondary;
      ctx.lineWidth = 3.5 * s;
      ctx.moveTo(cx - gap / 2, eyeY - 4 * s);
      ctx.lineTo(cx + gap / 2, eyeY - 4 * s);
      ctx.moveTo(cx - lensW - gap / 2, eyeY - 6 * s);
      ctx.lineTo(cx - lensW - gap / 2 - 22 * s, eyeY - 12 * s);
      ctx.moveTo(cx + lensW + gap / 2, eyeY - 6 * s);
      ctx.lineTo(cx + lensW + gap / 2 + 22 * s, eyeY - 12 * s);
      ctx.stroke();
      break;
    }

    case 'laser_visor': {
      const vw = 162 * s;
      const vh = 32 * s;
      const grad = ctx.createLinearGradient(cx - vw / 2, eyeY, cx + vw / 2, eyeY);
      grad.addColorStop(0, `${primary}DD`);
      grad.addColorStop(0.5, `${secondary}CC`);
      grad.addColorStop(1, `${primary}DD`);
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.roundRect(cx - vw / 2, eyeY - vh / 2, vw, vh, 12 * s);
      ctx.fill();
      ctx.lineWidth = 3 * s;
      ctx.strokeStyle = '#FFFFFFEE';
      ctx.stroke();

      // Animated scanner dot
      const sweepX = cx + Math.sin(timeMs * 0.006) * (vw * 0.4);
      ctx.beginPath();
      ctx.fillStyle = '#FFFFFF';
      ctx.arc(sweepX, eyeY, 5 * s, 0, Math.PI * 2);
      ctx.fill();
      break;
    }

    case 'neon_halo': {
      const crownY = eyeY - 82 * s;
      ctx.beginPath();
      ctx.ellipse(cx, crownY, 72 * s, 18 * s, 0, 0, Math.PI * 2);
      ctx.lineWidth = 6 * s;
      ctx.strokeStyle = primary;
      ctx.stroke();

      ctx.beginPath();
      ctx.ellipse(cx, crownY, 72 * s, 18 * s, 0, 0, Math.PI * 2);
      ctx.lineWidth = 2.5 * s;
      ctx.strokeStyle = '#FFFFFF';
      ctx.stroke();
      break;
    }

    case 'flame_crown': {
      const baseY = eyeY - 66 * s;
      const spikes = 5;
      const totalW = 128 * s;
      const startX = cx - totalW / 2;

      ctx.beginPath();
      ctx.moveTo(startX, baseY);
      for (let i = 0; i < spikes; i++) {
        const x1 = startX + (i + 0.5) * (totalW / spikes);
        const x2 = startX + (i + 1) * (totalW / spikes);
        const flicker = Math.sin(timeMs * 0.01 + i * 1.4) * 7 * s;
        const peakH = (i === 2 ? 56 : i === 1 || i === 3 ? 42 : 30) * s + flicker;
        ctx.lineTo(x1, baseY - peakH);
        ctx.lineTo(x2, baseY);
      }
      ctx.closePath();

      const grad = ctx.createLinearGradient(cx, baseY - 60 * s, cx, baseY);
      grad.addColorStop(0, secondary);
      grad.addColorStop(1, primary);
      ctx.fillStyle = grad;
      ctx.fill();
      ctx.lineWidth = 2.5 * s;
      ctx.strokeStyle = '#FFFFFFDD';
      ctx.stroke();
      break;
    }

    case 'cat_ears': {
      const topY = eyeY - 64 * s;
      const drawEar = (dir: -1 | 1) => {
        const ex = cx + dir * 56 * s;
        ctx.beginPath();
        ctx.moveTo(ex - 22 * s, topY + 12 * s);
        ctx.lineTo(ex + dir * 6 * s, topY - 40 * s);
        ctx.lineTo(ex + 22 * s, topY + 12 * s);
        ctx.closePath();
        ctx.fillStyle = `${primary}CC`;
        ctx.fill();
        ctx.lineWidth = 3 * s;
        ctx.strokeStyle = secondary;
        ctx.stroke();
      };
      drawEar(-1);
      drawEar(1);
      break;
    }

    case 'angel_wings': {
      const wingY = eyeY + 25 * s;
      const drawWing = (dir: -1 | 1) => {
        ctx.beginPath();
        ctx.moveTo(cx + dir * 64 * s, wingY);
        ctx.quadraticCurveTo(cx + dir * 135 * s, wingY - 68 * s, cx + dir * 145 * s, wingY + 10 * s);
        ctx.quadraticCurveTo(cx + dir * 110 * s, wingY + 46 * s, cx + dir * 64 * s, wingY + 18 * s);
        ctx.closePath();
        ctx.fillStyle = `${primary}66`;
        ctx.fill();
        ctx.lineWidth = 3 * s;
        ctx.strokeStyle = secondary;
        ctx.stroke();
      };
      drawWing(-1);
      drawWing(1);
      break;
    }

    case 'spark_hud':
    case 'custom_mask':
    default: {
      // Holographic HUD target reticle + AR badge around eyes
      const r = 74 * s;
      ctx.strokeStyle = primary;
      ctx.lineWidth = 2.5 * s;
      ctx.beginPath();
      ctx.arc(cx, eyeY, r, -0.6, 0.6);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, eyeY, r, Math.PI - 0.6, Math.PI + 0.6);
      ctx.stroke();

      ctx.strokeStyle = secondary;
      ctx.lineWidth = 2 * s;
      ctx.strokeRect(cx - 56 * s, eyeY - 22 * s, 112 * s, 44 * s);
      break;
    }
  }

  // Render crisp floating AR filter tag in corner if badgeText is present
  if (filter.badgeText) {
    ctx.shadowBlur = 8;
    ctx.font = `bold ${Math.max(10, Math.round(11 * s))}px sans-serif`;
    const label = `✦ ${filter.badgeText}`;
    const textW = ctx.measureText(label).width;
    const padX = 10;
    const boxW = textW + padX * 2;
    ctx.fillStyle = 'rgba(15, 23, 42, 0.72)';
    ctx.beginPath();
    ctx.roundRect(12, 12, boxW, 24, 999);
    ctx.fill();
    ctx.strokeStyle = primary;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText(label, 12 + padX, 28);
  }

  ctx.restore();
}
