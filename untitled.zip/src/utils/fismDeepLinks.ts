export const FISM_PUBLIC_APP_ORIGIN = 'https://flameintegrativesocialmedia.netlify.app';
export const FISM_ANDROID_PACKAGE = 'com.fism.flame.social';

export type FismDeepLinkTarget =
  | { kind: 'post'; id: string; query: Record<string, string>; rawUrl: string }
  | { kind: 'video'; id: string; query: Record<string, string>; rawUrl: string }
  | { kind: 'burst'; id: string; query: Record<string, string>; rawUrl: string }
  | { kind: 'user'; username: string; query: Record<string, string>; rawUrl: string }
  | { kind: 'item'; id: string; query: Record<string, string>; rawUrl: string }
  | { kind: 'live'; id: string; query: Record<string, string>; rawUrl: string }
  | { kind: 'install'; query: Record<string, string>; rawUrl: string }
  | { kind: 'home'; query: Record<string, string>; rawUrl: string };

export function buildFismShareUrl(
  kind: 'post' | 'video' | 'burst' | 'user' | 'item' | 'live' | 'install',
  idOrUsername?: string,
  extraParams?: Record<string, string | number | boolean | undefined>,
): string {
  const cleanId = idOrUsername ? encodeURIComponent(idOrUsername.replace(/^@/, '').trim()) : '';
  const path =
    kind === 'install'
      ? '/install'
      : cleanId
        ? `/${kind}/${cleanId}`
        : `/${kind}`;
  const url = new URL(`${FISM_PUBLIC_APP_ORIGIN}${path}`);
  if (extraParams) {
    Object.entries(extraParams).forEach(([k, v]) => {
      if (v !== undefined && v !== '') {
        url.searchParams.set(k, String(v));
      }
    });
  }
  return url.toString();
}

export function parseFismDeepLink(input: string): FismDeepLinkTarget | null {
  if (!input || typeof input !== 'string') return null;
  let parsed: URL;
  try {
    parsed = input.startsWith('http://') || input.startsWith('https://')
      ? new URL(input)
      : new URL(input.startsWith('/') ? `${FISM_PUBLIC_APP_ORIGIN}${input}` : `${FISM_PUBLIC_APP_ORIGIN}/${input}`);
  } catch {
    return null;
  }

  const query: Record<string, string> = {};
  parsed.searchParams.forEach((value, key) => {
    query[key] = value;
  });

  // Support both clean App Link paths (/post/123) and legacy hash links (/#post/123)
  let rawPath = parsed.pathname || '/';
  if ((rawPath === '/' || !rawPath) && parsed.hash) {
    const hashClean = parsed.hash.replace(/^#/, '');
    if (hashClean.includes('/')) {
      const [hashPath, hashQuery] = hashClean.split('?');
      rawPath = hashPath.startsWith('/') ? hashPath : `/${hashPath}`;
      if (hashQuery) {
        new URLSearchParams(hashQuery).forEach((v, k) => {
          query[k] = v;
        });
      }
    }
  }

  const segments = rawPath.split('/').filter(Boolean).map((s) => decodeURIComponent(s));
  const rawUrl = parsed.toString();

  if (segments.length === 0) {
    return Object.keys(query).length > 0 ? { kind: 'home', query, rawUrl } : null;
  }

  const head = segments[0].toLowerCase();
  const tail = segments[1] || '';

  if (head.startsWith('@') && head.length > 1) {
    return { kind: 'user', username: head.slice(1), query, rawUrl };
  }

  switch (head) {
    case 'post':
      return tail ? { kind: 'post', id: tail, query, rawUrl } : { kind: 'home', query, rawUrl };
    case 'video':
    case 'watch':
    case 'mainblast':
      return tail ? { kind: 'video', id: tail, query, rawUrl } : { kind: 'home', query, rawUrl };
    case 'burst':
    case 'short':
    case 'shorts':
    case 'quickburst':
      return tail ? { kind: 'burst', id: tail, query, rawUrl } : { kind: 'home', query, rawUrl };
    case 'user':
    case 'u':
    case 'profile':
      return tail
        ? { kind: 'user', username: tail.replace(/^@/, ''), query, rawUrl }
        : { kind: 'home', query, rawUrl };
    case 'item':
    case 'shop':
    case 'product':
      return tail ? { kind: 'item', id: tail, query, rawUrl } : { kind: 'home', query, rawUrl };
    case 'live':
    case 'onfire':
      return tail ? { kind: 'live', id: tail, query, rawUrl } : { kind: 'home', query, rawUrl };
    case 'install':
    case 'apk':
    case 'download':
      return { kind: 'install', query, rawUrl };
    default:
      return { kind: 'home', query, rawUrl };
  }
}

export async function shareFismLink(opts: {
  title: string;
  text: string;
  url: string;
  triggerToast?: (msg: string) => void;
}): Promise<'shared' | 'copied'> {
  try {
    await navigator.clipboard?.writeText(opts.url);
  } catch {
    // ignore clipboard block
  }

  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    try {
      await navigator.share({
        title: opts.title,
        text: opts.text,
        url: opts.url,
      });
      opts.triggerToast?.(`Shared App Link: ${opts.url}`);
      return 'shared';
    } catch {
      // User canceled native sheet or share restricted -> clipboard already copied
    }
  }

  opts.triggerToast?.(`Copied App Link: ${opts.url}`);
  return 'copied';
}
