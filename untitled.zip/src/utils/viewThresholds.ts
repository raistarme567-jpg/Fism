export type VideoLengthCategory = 'short' | 'medium' | 'long';

export interface DynamicViewThreshold {
  category: VideoLengthCategory;
  durationSeconds: number;
  requiredWatchSeconds: number;
  ruleLabel: string;
}

/**
 * Parses "MM:SS" or "HH:MM:SS" into total seconds.
 */
export function parseDurationToSeconds(
  durationStr?: string,
  fallbackPostType?: string,
): number {
  if (durationStr && typeof durationStr === 'string') {
    const clean = durationStr.trim();
    const parts = clean.split(':').map((n) => Number(n));
    if (parts.length === 2 && parts.every((n) => Number.isFinite(n) && n >= 0)) {
      return Math.max(1, Math.round(parts[0] * 60 + parts[1]));
    }
    if (parts.length === 3 && parts.every((n) => Number.isFinite(n) && n >= 0)) {
      return Math.max(1, Math.round(parts[0] * 3600 + parts[1] * 60 + parts[2]));
    }
  }
  return fallbackPostType === 'quickBurst' ? 15 : 180;
}

/**
 * Dynamic View Threshold Rules:
 * - Short Videos (<= 30s): minimum 5–7s (default 6s, capped by clip length if < 6s)
 * - Medium Videos (31s to < 10m / 1–3m+): minimum 20–30s (20s for <=60s, 25s for 1–3m+)
 * - Long Videos / Movies (>= 10m / 600s): minimum 2–3 min or 20% of duration (max(120, 20%))
 */
export function computeDynamicViewThreshold(durationSeconds: number): DynamicViewThreshold {
  const safeDur = Math.max(1, Math.round(Number(durationSeconds) || 0));

  if (safeDur <= 30) {
    const required = safeDur < 5 ? safeDur : 6;
    return {
      category: 'short',
      durationSeconds: safeDur,
      requiredWatchSeconds: required,
      ruleLabel: 'Short Video (<=30s): 5–7s watch required for valid view',
    };
  }

  if (safeDur < 600) {
    const required = safeDur <= 90 ? 20 : 25;
    return {
      category: 'medium',
      durationSeconds: safeDur,
      requiredWatchSeconds: required,
      ruleLabel: 'Medium Video (1–3m): 20–30s watch required for valid view',
    };
  }

  // Long Videos >= 10 minutes (600s): 2–3 min (120–180s) or 20% of total video length
  const twentyPercent = Math.round(safeDur * 0.2);
  const required = Math.max(120, twentyPercent);
  return {
    category: 'long',
    durationSeconds: safeDur,
    requiredWatchSeconds: required,
    ruleLabel: 'Long Video (10m+): 2–3 min or 20% watch required for valid view',
  };
}
