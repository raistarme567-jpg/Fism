import {
  FismAffiliateStoreConfig,
  FismPostItem,
  FismSmartAdItem,
  FismSmartAdPlacement,
  FismUserBehaviorProfile,
} from '../types';

const CATEGORY_KEYWORDS: Record<string, string[]> = {
  gaming: [
    'game',
    'gaming',
    'freefire',
    'free fire',
    'esports',
    'clutch',
    'streamer',
    'bgmi',
    'pubg',
    'arcade',
    'console',
    'headset',
    'fps',
    '2d',
    '3d',
  ],
  music: ['music', 'song', 'beat', 'phonk', 'rap', 'audio', 'synth', 'lofi', 'dj', 'track'],
  tech: ['tech', 'ai', 'code', 'app', 'vr', '3d', 'gadget', 'camera', 'mic', 'setup', 'gear'],
  shopping: ['shop', 'store', 'amazon', 'flipkart', 'meesho', 'buy', 'price', 'deal', 'product'],
  lifestyle: ['travel', 'nature', 'mountain', 'vlog', 'fitness', 'motivation', 'cinematic'],
  comedy: ['funny', 'meme', 'comedy', 'prank', 'laugh'],
};

export function extractPostCategories(post: Pick<FismPostItem, 'title' | 'caption' | 'hashtags' | 'audioTrack'>): string[] {
  const haystack = `${post.title || ''} ${post.caption || ''} ${(post.hashtags || []).join(' ')} ${post.audioTrack || ''}`.toLowerCase();
  const matched: string[] = [];

  for (const [category, words] of Object.entries(CATEGORY_KEYWORDS)) {
    if (words.some((w) => haystack.includes(w))) {
      matched.push(category);
    }
  }

  for (const tag of post.hashtags || []) {
    const clean = tag.replace(/^#/, '').toLowerCase().trim();
    if (clean && !matched.includes(clean)) {
      matched.push(clean);
    }
  }

  return matched.length > 0 ? matched : ['trending'];
}

export function computeUserAffinityScores(behavior: FismUserBehaviorProfile): Record<string, number> {
  const scores: Record<string, number> = {};

  for (const [cat, sec] of Object.entries(behavior.watchTimeByCategory || {})) {
    const key = cat.toLowerCase();
    scores[key] = (scores[key] || 0) + sec * 1.25;
  }

  for (const [tag, count] of Object.entries(behavior.likedTags || {})) {
    const key = tag.toLowerCase();
    scores[key] = (scores[key] || 0) + count * 18;
  }

  for (const [gameTag, count] of Object.entries(behavior.gameInterests || {})) {
    const key = gameTag.toLowerCase();
    scores[key] = (scores[key] || 0) + count * 22;
    scores['gaming'] = (scores['gaming'] || 0) + count * 20;
  }

  for (const searchTag of behavior.searchTags || []) {
    const key = searchTag.replace(/^#/, '').trim().toLowerCase();
    if (!key) continue;
    scores[key] = (scores[key] || 0) + 14;
    for (const [cat, words] of Object.entries(CATEGORY_KEYWORDS)) {
      if (words.some((w) => key.includes(w) || w.includes(key))) {
        scores[cat] = (scores[cat] || 0) + 15;
      }
    }
  }

  return scores;
}

export function getTopUserInterestCategories(
  behavior: FismUserBehaviorProfile,
  limitCount = 4,
): { category: string; score: number; percentage: number }[] {
  const scores = computeUserAffinityScores(behavior);
  const entries = Object.entries(scores)
    .filter(([, val]) => val > 0)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limitCount);

  if (entries.length === 0) {
    return [
      { category: 'gaming', score: 65, percentage: 65 },
      { category: 'tech', score: 45, percentage: 45 },
      { category: 'music', score: 35, percentage: 35 },
    ];
  }

  const maxScore = Math.max(1, entries[0][1]);
  return entries.map(([category, score]) => ({
    category,
    score: Math.round(score),
    percentage: Math.max(15, Math.min(100, Math.round((score / maxScore) * 100))),
  }));
}

export function scorePostForUser(
  post: FismPostItem,
  behavior: FismUserBehaviorProfile,
): { score: number; matchedCategory: string | null } {
  const affinity = computeUserAffinityScores(behavior);
  const categories = extractPostCategories(post);

  let affinityPoints = 0;
  let bestCategory: string | null = null;
  let bestCategoryScore = 0;

  for (const cat of categories) {
    const pts = affinity[cat] || 0;
    if (pts > bestCategoryScore) {
      bestCategoryScore = pts;
      bestCategory = cat;
    }
    affinityPoints += pts;
  }

  // Search text tag direct match boost
  const haystack = `${post.title} ${post.caption} ${post.hashtags.join(' ')}`.toLowerCase();
  for (const tag of behavior.searchTags || []) {
    const clean = tag.trim().toLowerCase();
    if (clean.length >= 2 && haystack.includes(clean)) {
      affinityPoints += 24;
      if (!bestCategory) bestCategory = clean;
    }
  }

  // Milestone Card Algorithm Boost (Year 3 Platinum AI Boost, Year 4 Gold, Year 5+ Red Card Top Priority)
  const milestoneBoost =
    post.algorithmBoostTier === 'red'
      ? 80
      : post.algorithmBoostTier === 'gold'
        ? 35
        : post.algorithmBoostTier === 'platinum'
          ? 24
          : 0;

  // Base engagement & freshness contribution
  const engagementScore =
    Math.log10(Math.max(10, post.viewsCount || 10)) * 5 +
    Math.log10(Math.max(2, post.sparkCount || 2)) * 4 +
    (post.isPremiumCreator ? 8 : 0) +
    milestoneBoost;

  return {
    score: affinityPoints + engagementScore,
    matchedCategory: bestCategory,
  };
}

export function rankPostsByFlameAlgorithm(
  posts: FismPostItem[],
  behavior: FismUserBehaviorProfile,
): FismPostItem[] {
  return [...posts].sort((a, b) => {
    const sa = scorePostForUser(a, behavior).score;
    const sb = scorePostForUser(b, behavior).score;
    return sb - sa;
  });
}

export function selectContextualAd(
  ads: FismSmartAdItem[],
  behavior: FismUserBehaviorProfile,
  placement: FismSmartAdPlacement,
  excludeIds: string[] = [],
): FismSmartAdItem | null {
  const activePool = ads.filter((ad) => ad.isActive && ad.placement === placement);
  if (activePool.length === 0) return null;

  const filteredPool = activePool.filter((ad) => !excludeIds.includes(ad.id));
  const candidates = filteredPool.length > 0 ? filteredPool : activePool;
  const affinity = computeUserAffinityScores(behavior);

  let bestAd = candidates[0];
  let bestScore = -1;

  for (const ad of candidates) {
    let score = ad.source === 'official' ? 5 : 4;
    const adHaystack = `${ad.title} ${ad.description} ${ad.categoryTags.join(' ')}`.toLowerCase();

    for (const tag of ad.categoryTags) {
      const clean = tag.toLowerCase().trim();
      score += (affinity[clean] || 0) * 2;
    }

    for (const [cat, pts] of Object.entries(affinity)) {
      if (adHaystack.includes(cat)) {
        score += pts * 1.4;
      }
    }

    if (score > bestScore) {
      bestScore = score;
      bestAd = ad;
    }
  }

  return bestAd;
}

export interface AutoCommentTriggerMatch {
  matchedKeyword: string;
  productTitle: string;
  productLinkUrl: string;
  storeName: string;
  replyText: string;
}

export function detectCommentAffiliateTrigger(
  commentText: string,
  post: FismPostItem,
  storeConfig?: FismAffiliateStoreConfig | null,
): AutoCommentTriggerMatch | null {
  const lowerComment = commentText.trim().toLowerCase();
  if (!lowerComment) return null;

  const explicitKeywords = (post.affiliateKeywords || [])
    .map((k) => k.trim().toLowerCase())
    .filter((k) => k.length >= 2);

  // Determine fallback store link if post already has shoppingLinkUrl or storeConfig is linked
  const fallbackStoreUrl =
    post.shoppingLinkUrl ||
    storeConfig?.amazonAffiliateUrl ||
    storeConfig?.flipkartAffiliateUrl ||
    storeConfig?.meeshoAffiliateUrl ||
    '';

  if (!fallbackStoreUrl && explicitKeywords.length === 0) {
    return null;
  }

  const defaultIntentKeywords = ['link', 'price', 'buy', 'kahan', 'khareed', 'order', 'store'];
  const keywordsToCheck =
    explicitKeywords.length > 0 ? explicitKeywords : defaultIntentKeywords;

  const matchedKeyword = keywordsToCheck.find((kw) => lowerComment.includes(kw));
  if (!matchedKeyword) return null;

  const resolvedUrl = fallbackStoreUrl || 'https://fism.shop/creator-affiliate';
  const resolvedTitle = post.shoppingProductTitle || `${post.title} — Featured Creator Gear`;
  const resolvedStore =
    post.shoppingStoreName ||
    (resolvedUrl.includes('amazon')
      ? 'Amazon Affiliate'
      : resolvedUrl.includes('flipkart')
        ? 'Flipkart Affiliate'
        : resolvedUrl.includes('meesho')
          ? 'Meesho Store'
          : 'FISM Verified Store');

  return {
    matchedKeyword,
    productTitle: resolvedTitle,
    productLinkUrl: resolvedUrl,
    storeName: resolvedStore,
    replyText: `🤖 Auto-Bot Reply for "${matchedKeyword}": Here is the direct product link for ${resolvedTitle} (${resolvedStore}) 👉 ${resolvedUrl}`,
  };
}
