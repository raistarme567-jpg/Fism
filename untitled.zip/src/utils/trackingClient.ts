export function detectFriendlyDeviceLabel(): string {
  if (typeof navigator === 'undefined') return 'Web Browser';
  const ua = navigator.userAgent || '';
  let device = 'Desktop / Web';
  if (/Android/i.test(ua)) {
    const m = /Android [^;]+;\s*([^;)]+)/i.exec(ua);
    device = m?.[1] ? `Android (${m[1].trim()})` : 'Android Mobile';
  } else if (/iPhone/i.test(ua)) {
    device = 'Apple iPhone (iOS)';
  } else if (/iPad/i.test(ua)) {
    device = 'Apple iPad';
  } else if (/Windows NT/i.test(ua)) {
    device = 'Windows PC';
  } else if (/Macintosh|Mac OS X/i.test(ua)) {
    device = 'Apple MacBook / Mac';
  } else if (/Linux/i.test(ua)) {
    device = 'Linux Workstation';
  }

  let browser = 'Browser';
  if (/Edg\//i.test(ua)) browser = 'Edge';
  else if (/Chrome\//i.test(ua)) browser = 'Chrome';
  else if (/Firefox\//i.test(ua)) browser = 'Firefox';
  else if (/Safari\//i.test(ua)) browser = 'Safari';

  const res =
    typeof window !== 'undefined' && window.screen
      ? ` ${window.screen.width}x${window.screen.height}`
      : '';
  return `${device} · ${browser}${res}`.slice(0, 120);
}

export type FismTrackingEventType =
  | 'session_ping'
  | 'watch'
  | 'like'
  | 'unlike'
  | 'comment'
  | 'save'
  | 'unsave'
  | 'download'
  | 'follow_sync';

export interface TrackEventPayload {
  userId: string;
  username?: string;
  displayName?: string;
  avatarUrl?: string;
  email?: string;
  phoneNumber?: string;
  eventType: FismTrackingEventType;
  postId?: string;
  videoTitle?: string;
  category?: string;
  watchSeconds?: number;
  durationSeconds?: number;
  commentText?: string;
  followersCount?: number;
  followingCount?: number;
  followersList?: string[];
  followingList?: string[];
  walletCoins?: number;
  spCoins?: number;
  milestoneTier?: string;
}

export async function reportUserTrackingEvent(payload: TrackEventPayload): Promise<void> {
  if (!payload.userId) return;
  try {
    await fetch('/api/tracking/event', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...payload,
        deviceName: detectFriendlyDeviceLabel(),
      }),
    });
  } catch {
    // Non-blocking telemetry delivery
  }
}

export async function downloadBrandedVideoWithWatermark(params: {
  postId: string;
  userId: string;
  username: string;
  displayName?: string;
  videoUrl?: string;
  thumbnailUrl?: string;
  title: string;
  authorUsername: string;
  isVertical?: boolean;
  durationSeconds?: number;
}): Promise<{ filename: string; watermarkLabel: string; engine: string; sizeBytes: number }> {
  const res = await fetch('/api/videos/download-branded', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...params,
      deviceName: detectFriendlyDeviceLabel(),
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => 'Download processing failed');
    throw new Error(errText || 'Failed to generate watermarked video');
  }

  const blob = await res.blob();
  const cd = res.headers.get('Content-Disposition') || '';
  const fnMatch = /filename="?([^";\n]+)"?/i.exec(cd);
  const filename = fnMatch?.[1] || `FISM_${params.postId}_branded.mp4`;
  const watermarkLabel = res.headers.get('X-Fism-Watermark-Label') || `FISM @${params.authorUsername}`;
  const engine = res.headers.get('X-Fism-Engine') || 'FFmpeg Burn-In';

  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = objectUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(objectUrl), 15000);

  return {
    filename,
    watermarkLabel,
    engine,
    sizeBytes: blob.size,
  };
}
