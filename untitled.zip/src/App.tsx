import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Flame,
  Play,
  Zap,
  Compass,
  Search,
  MessageCircle,
  Bell,
  User as UserIcon,
  Plus,
  Bookmark,
  Radio,
  Crown,
  Settings,
  Shield,
  ShieldAlert,
  Box,
  Sparkles,
  Share2,
  MoreHorizontal,
  CheckCircle2,
  MapPin,
  Globe,
  Lock,
  Eye,
  Volume2,
  VolumeX,
  Maximize2,
  Pause,
  ChevronLeft,
  ChevronRight,
  X,
  Send,
  Image as ImageIcon,
  Film,
  Mic,
  Smile,
  Trash2,
  Edit3,
  Copy,
  Flag,
  Ban,
  Sun,
  Moon,
  Monitor,
  Menu,
  LogOut,
  HelpCircle,
  Info,
  FileText,
  Users,
  Video,
  Check,
  AlertTriangle,
  Sliders,
  Download,
  ShoppingBag,
  Phone,
  Wand2,
  Tag,
  Megaphone,
  Smartphone,
  KeyRound,
  Gamepad2,
  Music,
  Languages,
  FileAudio,
  Upload,
  Heart,
  Repeat,
  Home,
  QrCode,
  PhoneCall,
  PhoneOff,
  ExternalLink,
  Bot,
  Coins,
  Trophy,
  Link2,
  Gift,
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
} from 'firebase/firestore';
import {
  db,
  auth,
  initAuth,
  googleSignIn,
  logout,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  sendPasswordResetEmail,
  ConfirmationResult,
} from './firebase';
import {
  detectFriendlyDeviceLabel,
  downloadBrandedVideoWithWatermark,
  reportUserTrackingEvent,
} from './utils/trackingClient';
import {
  FismScreen,
  FismCreator,
  FismPostItem,
  FismCommentItem,
  FismStoryItem,
  FismConversation,
  FismNotificationItem,
  FismReportItem,
  FismShoppingProduct,
  FismAdminUserDossier,
  FismSubAccount,
  FismGameItem,
  FismMusicTrack,
  FismAutoReplyRule,
  FismSurveyCampaign,
  FismSurveySubmission,
  FismUpiConfig,
  FismUpiPaymentRequest,
  FismWithdrawalRequest,
  FismArFilterAsset,
  FismLiveLocationState,
  FismPremiumProfileStyle,
  FismCopyrightAssetRecord,
  FismCopyrightViolationRecord,
  FismAiCloneAvatarProfile,
  FismCommunityRoom,
  FismCommunityMessage,
  FismActiveGroupCall,
  FismLiveCreatorPermissionRecord,
  FismSmartAdItem,
  FismAffiliateStoreConfig,
  FismUserBehaviorProfile,
  FISM_PROFILE_CATEGORIES,
  GENERATED_ASSETS,
  INITIAL_CREATORS,
  INITIAL_STORIES,
  INITIAL_POSTS,
  INITIAL_SHOPPING_PRODUCTS,
  INITIAL_ADMIN_USER_DOSSIERS,
  INITIAL_GAMES,
  INITIAL_MUSIC_TRACKS,
  INITIAL_PUBLISHED_AR_FILTERS,
  INITIAL_SMART_ADS,
  FismCoinWallet,
  FismGiftDropConfig,
  FismClaimedGiftReceipt,
  PREMIUM_COIN_PACK_BONUS,
  INITIAL_GIFT_DROPS,
  INITIAL_COIN_WALLETS,
  FismConnectedVideoRef,
  FismTaggedCollaborator,
  FismSpCoinWallet,
  FismSuperChatMessage,
  FismChannelMembership,
  FismSuperChatBoxStyle,
  PREMIUM_SP_COIN_BONUS,
  FismAccountPrivacyMode,
  FismPrivateFollowRequest,
  FismAgeVerificationResult,
  SP_SUPER_CHAT_COST,
  CHANNEL_MEMBERSHIP_SP_COST,
  SP_COIN_BUY_PACKS,
  SUPER_CHAT_BOX_TIERS,
  SUPER_STICKER_OPTIONS,
  FismMilestoneTier,
  FismProfileFrameId,
  FismFounderGiftClaim,
  FismUserMilestoneState,
  FISM_MILESTONE_ROADMAP,
  FismAdsterraConfig,
  FismApkReleaseInfo,
  FismSavedStudioFilter,
  DEFAULT_LIVE_ADSTERRA_CONFIG,
  computeTenureStats,
} from './types';
import {
  buildFismShareUrl,
  parseFismDeepLink,
  shareFismLink,
  FismDeepLinkTarget,
  FISM_PUBLIC_APP_ORIGIN,
} from './utils/fismDeepLinks';
import {
  PREMIUM_USERNAME_FONTS,
  PREMIUM_USERNAME_EFFECTS,
  PREMIUM_COLOR_PRESETS,
  sanitizeAndValidateProfileStyle,
} from './utils/arFilterRenderer';
import {
  isPostCopyrightBlocked,
  scanMediaForCopyright,
  RESTRICTED_COPYRIGHT_MESSAGE,
} from './utils/copyrightScanner';
import {
  extractPostCategories,
  rankPostsByFlameAlgorithm,
  scorePostForUser,
  selectContextualAd,
  detectCommentAffiliateTrigger,
  getTopUserInterestCategories,
} from './utils/flameAlgorithm';
import {
  computeDynamicViewThreshold,
  parseDurationToSeconds,
} from './utils/viewThresholds';
import { FismAdAndAffiliateStudio } from './components/FismAdAndAffiliateStudio';
import { FismAiCloneStudio } from './components/FismAiCloneStudio';
import { FismCommunityAndCreatorChat } from './components/FismCommunityAndCreatorChat';
import { FismThreeArena } from './components/FismThreeArena';
import { FismWorkspaceMapsStudio } from './components/FismWorkspaceMapsStudio';
import {
  FismMapsApiProvider,
  FismEmberLiveLocationMap,
  FismInAppMapModal,
} from './components/FismLiveGoogleMap';
import {
  FismShoppingHub,
  FismAdminFileVault,
  FismEmojiBlastGameModal,
  FismCallModal,
  FismFloatingChatbotWidget,
  Fism2DGameCenter,
} from './components/FismAdvancedFeatures';
import {
  FismCreateCameraYouCutModal,
  FismMusicHubScreen,
} from './components/FismShortsAndCreateStudio';
import {
  FismBanner320x50Ad,
  FismBanner300x250Ad,
  FismNativeBannerAd,
} from './components/FismFlameFeedAds';
import {
  FismAccountPrivacySecurityHub,
  FismSubIdPasswordModal,
} from './components/FismAccountPrivacySecurityHub';
import {
  FismCreatorEarningHub,
  WORLD_CURRENCIES,
} from './components/FismCreatorEarningHub';
import {
  FismOnFireGamingStudioPanel,
  FismFloatingGamingLiveOverlay,
  ALL_3D_FACE_MODELS,
  INITIAL_4_3D_FACE_MODELS,
  Face3DModelPreset,
  GamingLiveState,
  speakSubscriberVoiceAlert,
} from './components/FismOnFireGamingLive';
import {
  FismCoinWalletAndLeaderboard,
  FismVideoGiftDropOverlay,
} from './components/FismCoinWalletAndLeaderboard';
import {
  FismMilestoneJourneyModal,
  FismRedMilestoneTick,
  FismVipGoldChatBadge,
  MilestoneModalTarget,
  getProfileFrameClasses,
} from './components/FismMilestoneCardsModal';
import { FismLegalDocsModal } from './components/FismLegalDocsModal';

export function App() {
  // Theme & Accessibility State (Default: Rich White & Fiery Accents)
  const [themeMode, setThemeMode] = useState<'light' | 'dark' | 'system'>('light');
  const [fontSizeScale, setFontSizeScale] = useState<'normal' | 'large'>('normal');
  const [highContrast, setHighContrast] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  // Navigation & Layout State
  const [activeScreen, setActiveScreen] = useState<FismScreen>('flameFeed');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');

  // Floating AI Chatbot Widget State (Long-press to dismiss/hide)
  const [floatingBotVisible, setFloatingBotVisible] = useState(true);

  // Auth & Guest Mode State (New users see Login Scene first; clicking "Nothing Login" keeps them as Guest where they can ONLY watch Quick Burst Shorts and cannot Like, Comment, or Share)
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoggedInSession, setIsLoggedInSession] = useState<boolean>(true);
  const [loginGatePromptOpen, setLoginGatePromptOpen] = useState<boolean>(false);
  const [blockedActionName, setBlockedActionName] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [loginEmailInput, setLoginEmailInput] = useState<string>('loversfreefire12244@gmail.com');
  const [loginPasswordInput, setLoginPasswordInput] = useState<string>('');
  const [loginMobileNumber, setLoginMobileNumber] = useState<string>('+91 98765 43210');
  const [loginAgreeLegal, setLoginAgreeLegal] = useState<boolean>(true);
  const [legalDocsModalState, setLegalDocsModalState] = useState<{
    open: boolean;
    returnLabel: 'Back to Login' | 'Back to Settings' | 'Close';
  }>({ open: false, returnLabel: 'Back to Login' });

  // Setup Your Profile Auto Message State (Inside Control Core -> Advanced Settings)
  const [autoReplyRules, setAutoReplyRules] = useState<FismAutoReplyRule[]>([
    {
      id: 'auto_1',
      triggerText: 'hi',
      replyText: 'Hey! 🔥 Welcome to my FISM Hearth! How can I help you today?',
      enabled: true,
      createdAt: 'Active Rule',
    },
    {
      id: 'auto_2',
      triggerText: 'price',
      replyText: '🛍️ Check out my AI-Verified Shopping Link in my latest video description!',
      enabled: true,
      createdAt: 'Active Rule',
    },
    {
      id: 'auto_3',
      triggerText: 'collab',
      replyText: 'Let’s collab on a Quick Burst Green Screen Remix! Drop your clip details 🔥',
      enabled: true,
      createdAt: 'Active Rule',
    },
  ]);
  const [newAutoTriggerInput, setNewAutoTriggerInput] = useState<string>('');
  const [newAutoReplyInput, setNewAutoReplyInput] = useState<string>('');
  const [simulatedIncomingChatText, setSimulatedIncomingChatText] = useState<string>('hi');
  const aiSilentTickRef = useRef<number>(0);

  // 2D Games Catalog State (Admin can upload new games via Admin File Vault; Normal users can only click Play Game)
  const [gamesCatalog, setGamesCatalog] = useState<FismGameItem[]>(() => {
    try {
      const saved = localStorage.getItem('fism_games_catalog_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return INITIAL_GAMES;
  });

  const handleAdminUploadGame = (newGame: FismGameItem) => {
    setGamesCatalog((prev) => {
      const next = [newGame, ...prev.filter((g) => g.id !== newGame.id)];
      try {
        localStorage.setItem('fism_games_catalog_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
    fetch('/api/games', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ game: newGame }),
    }).catch(() => {});
  };

  useEffect(() => {
    fetch('/api/games')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.games && Array.isArray(data.games) && data.games.length > 0) {
          setGamesCatalog((prev) => {
            const merged = [...data.games];
            for (const g of prev) {
              if (!merged.some((m: FismGameItem) => m.id === g.id)) merged.push(g);
            }
            return merged;
          });
        }
      })
      .catch(() => {});
  }, []);

  // 3D VR Cinema Active Video State
  const [vrCinemaVideoUrl, setVrCinemaVideoUrl] = useState<string>('');
  const [vrCinemaVideoTitle, setVrCinemaVideoTitle] = useState<string>(
    'Inside the Flame Creative Studio: 8K Cinema Rig',
  );

  // Universal Video Voice Language Translator State (Any Language <-> Any Language: Chinese, Hindi, Tamil, English, etc.)
  const [voiceSourceLang, setVoiceSourceLang] = useState<string>('Chinese (中文 / Mandarin)');
  const [voiceTargetLang, setVoiceTargetLang] = useState<string>('Hindi (हिन्दी - Indian)');
  const [voiceTranslating, setVoiceTranslating] = useState<boolean>(false);
  const [translatedVoiceAudioUrl, setTranslatedVoiceAudioUrl] = useState<string>('');
  const [translatedVoiceScript, setTranslatedVoiceScript] = useState<string>('');

  // Video Audio-to-Text Transcription State (gemini-3.5-transcribe inside video description)
  const [transcribingVideoId, setTranscribingVideoId] = useState<string | null>(null);

  // Shorts AI Music + Cover Photo Studio State (lyria-3-clip-preview + gemini-nano-banana-2.1)
  const [aiMusicPrompt, setAiMusicPrompt] = useState<string>(
    'High-energy Indian & Cyberpunk Electronic Trap Beat with Flute & Sub Bass',
  );
  const [aiMusicModel, setAiMusicModel] = useState<
    'lyria-3-clip-preview' | 'lyria-3-pro-preview'
  >('lyria-3-clip-preview');
  const [aiMusicGenerating, setAiMusicGenerating] = useState<boolean>(false);
  const [generatedMusicUrl, setGeneratedMusicUrl] = useState<string>('');
  const [generatedMusicCover, setGeneratedMusicCover] = useState<string>(
    GENERATED_ASSETS.studioThumb,
  );
  const [generatedMusicLyrics, setGeneratedMusicLyrics] = useState<string>('');

  // Shorts AI Image/Video/Search Grounding Quick Studio State
  const [shortsAiPrompt, setShortsAiPrompt] = useState<string>(
    'Futuristic neon creator studio with glowing flame holograms',
  );
  const [shortsAiBusy, setShortsAiBusy] = useState<boolean>(false);
  const [shortsSearchSummary, setShortsSearchSummary] = useState<string>('');

  const [myProfile, setMyProfile] = useState<FismCreator>({
    uid: 'local_hearth_user',
    username: 'flame_pioneer',
    displayName: 'Alex Ignis',
    bio: 'Creative director, visual storyteller & FISM 2.0 early pioneer. Igniting new perspectives every day across 8K Cinema, Full-Stack Web Development, Gaming Live & Spatial VR.',
    avatarUrl: GENERATED_ASSETS.avatar1,
    coverUrl: GENERATED_ASSETS.heroCover,
    location: 'San Francisco, CA',
    website: 'https://fism.social/@flame_pioneer',
    isVerified: true,
    isPrivate: false,
    sparksCount: 14820,
    flamesCount: 342,
    fuelersCount: 418,
    monthlyPrice: 4.99,
    categories: ['Web Development & Full-Stack', 'Esports & Gaming'],
  });
  const [bioExpanded, setBioExpanded] = useState<boolean>(false);
  const [clientRealTimeIp, setClientRealTimeIp] = useState<string>('103.84.219.14');
  const [watchLiveBannerOpen, setWatchLiveBannerOpen] = useState<boolean>(false);

  // Admin Survey Campaign & User Survey Submissions State
  const [activeSurveyCampaign, setActiveSurveyCampaign] = useState<FismSurveyCampaign | null>(() => {
    try {
      const raw = localStorage.getItem('fism_active_survey');
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });
  const [surveySubmissions, setSurveySubmissions] = useState<FismSurveySubmission[]>(() => {
    try {
      const raw = localStorage.getItem('fism_survey_submissions');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [dismissedSurveyIds, setDismissedSurveyIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem('fism_dismissed_surveys');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [surveyAnswersDraft, setSurveyAnswersDraft] = useState<
    Record<string, { selectedOption: string; customMoreText: string }>
  >({});
  const [dontShowSurveyAgain, setDontShowSurveyAgain] = useState<boolean>(true);

  // Master & Isolated Sub-IDs Architecture (Independent Username, Privacy, Followers, Scrypt Password Hash & 18+ Aadhaar Verification)
  const primaryEmail = currentUser?.email || 'loversfreefire12244@gmail.com';
  const [subAccounts, setSubAccounts] = useState<FismSubAccount[]>(() => {
    try {
      const saved = localStorage.getItem('fism_user_unlimited_ids');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((acc: FismSubAccount, idx: number) => ({
            ...acc,
            isMaster: acc.isMaster ?? idx === 0,
            privacyMode: acc.privacyMode === 'public' && acc.isAgeVerified ? 'public' : 'private',
            isPrivate: !(acc.privacyMode === 'public' && acc.isAgeVerified),
            isAgeVerified: Boolean(acc.isAgeVerified),
            ageVerificationStatus: acc.ageVerificationStatus || (acc.isAgeVerified ? 'verified' : 'unverified'),
            publicPublishingRestricted: !Boolean(acc.isAgeVerified),
            bio: acc.bio ?? 'Isolated FISM creator profile.',
            coverUrl: acc.coverUrl ?? GENERATED_ASSETS.heroCover,
            location: acc.location ?? 'San Francisco, CA',
            website: acc.website ?? `https://fism.social/@${acc.username}`,
            sparksCount: acc.sparksCount ?? (idx === 0 ? 14820 : 0),
            flamesCount: acc.flamesCount ?? (idx === 0 ? 342 : 0),
            fuelersCount: acc.fuelersCount ?? (idx === 0 ? 418 : 0),
            connectedCreatorUids: acc.connectedCreatorUids ?? (idx === 0 ? ['creator_arian', 'creator_elena'] : []),
            approvedFollowerUids: acc.approvedFollowerUids ?? [],
          }));
        }
      }
    } catch {
      // ignore
    }
    return [
      {
        id: 'acc_1',
        masterUid: 'local_hearth_user',
        isMaster: true,
        email: 'loversfreefire12244@gmail.com',
        username: 'flame_pioneer',
        displayName: 'Alex Ignis (Master Account)',
        bio: 'Creative director, visual storyteller & FISM 2.0 Master Account.',
        avatarUrl: GENERATED_ASSETS.avatar1,
        coverUrl: GENERATED_ASSETS.heroCover,
        location: 'San Francisco, CA',
        website: 'https://fism.social/@flame_pioneer',
        categories: ['Web Development & Full-Stack', 'Esports & Gaming'],
        privacyMode: 'private',
        isPrivate: true,
        isAgeVerified: false,
        ageVerificationStatus: 'unverified',
        ageVerificationNote: 'Verify 18+ Aadhaar / Government ID to unlock Public Account mode & Public Publishing.',
        publicPublishingRestricted: true,
        hasPassword: false,
        sparksCount: 14820,
        flamesCount: 342,
        fuelersCount: 418,
        monthlyPrice: 4.99,
        connectedCreatorUids: ['creator_arian', 'creator_elena'],
        approvedFollowerUids: [],
        phoneVerified: true,
        phoneNumber: '+91 98765 43210',
        createdAt: 'Master Account (Primary)',
      },
    ];
  });
  const [activeSubAccountId, setActiveSubAccountId] = useState<string>(() => {
    try {
      return localStorage.getItem('fism_active_sub_id') || 'acc_1';
    } catch {
      return 'acc_1';
    }
  });
  const activeSubAccount = useMemo(
    () => subAccounts.find((a) => a.id === activeSubAccountId) || subAccounts[0],
    [subAccounts, activeSubAccountId],
  );
  const mainProfileUsername = activeSubAccount?.username || subAccounts[0]?.username || 'flame_pioneer';
  const [followRequests, setFollowRequests] = useState<FismPrivateFollowRequest[]>([]);
  const [subIdSwitchTarget, setSubIdSwitchTarget] = useState<FismSubAccount | null>(null);
  const [subIdSwitchError, setSubIdSwitchError] = useState<string | null>(null);
  const [subIdSwitching, setSubIdSwitching] = useState(false);
  const [creatingSubId, setCreatingSubId] = useState(false);
  const [verifyingAge, setVerifyingAge] = useState(false);
  const [lastAgeResult, setLastAgeResult] = useState<FismAgeVerificationResult | null>(null);
  const [newAccUsername, setNewAccUsername] = useState('flame_pioneer');
  const [newAccDisplayName, setNewAccDisplayName] = useState('');
  const [newAccPhone, setNewAccPhone] = useState('+91 ');
  const [newAccAvatarUrl, setNewAccAvatarUrl] = useState<string>(GENERATED_ASSETS.avatar2);
  const [editingSubAccId, setEditingSubAccId] = useState<string | null>(null);
  const [otpSentCode, setOtpSentCode] = useState<string | null>(null);
  const [otpInputCode, setOtpInputCode] = useState('');
  const [multiAccError, setMultiAccError] = useState<string | null>(null);

  // Admin Customizable App Logo Background Photo (Text "FISM" remains locked, background photo changes)
  const [appLogoBgUrl, setAppLogoBgUrl] = useState<string>(() => {
    try {
      return localStorage.getItem('fism_admin_app_logo_bg') || '';
    } catch {
      return '';
    }
  });
  const handleUpdateAppLogoBg = (nextPhotoUrl: string) => {
    setAppLogoBgUrl(nextPhotoUrl);
    try {
      if (nextPhotoUrl) {
        localStorage.setItem('fism_admin_app_logo_bg', nextPhotoUrl);
      } else {
        localStorage.removeItem('fism_admin_app_logo_bg');
      }
    } catch {
      // ignore
    }
  };

  // Real-Time Call Notification & Real-Time Push Notification State
  const [incomingRealtimeCall, setIncomingRealtimeCall] = useState<{
    id: string;
    callerName: string;
    callerAvatar: string;
    callerPhone: string;
    mode: 'audio' | 'video';
    timestamp: string;
  } | null>(null);
  const [realtimePushBanner, setRealtimePushBanner] = useState<FismNotificationItem | null>(null);
  const realtimeChannelRef = useRef<BroadcastChannel | null>(null);
  const ringtoneTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Settings (Control Core) Sub-Sections: Standard, Smart, Advanced
  const [settingsSubTab, setSettingsSubTab] = useState<'standard' | 'smart' | 'advanced'>(
    'standard',
  );

  // Admin File Vault & Premium Section States
  const [adminFileUnlocked, setAdminFileUnlocked] = useState(false);
  const [adminUserDossiers, setAdminUserDossiers] = useState<FismAdminUserDossier[]>(
    INITIAL_ADMIN_USER_DOSSIERS,
  );
  const [globalPremiumOn, setGlobalPremiumOn] = useState(true);
  // Strict User Premium Purchase Status (Default false until user buys Premium or Admin approves Fuel Up)
  const [userHasBoughtPremium, setUserHasBoughtPremium] = useState<boolean>(() => {
    try {
      return localStorage.getItem('fism_user_has_bought_premium') === 'true';
    } catch {
      return false;
    }
  });
  const handleToggleUserBoughtPremium = (bought: boolean) => {
    setUserHasBoughtPremium(bought);
    try {
      localStorage.setItem('fism_user_has_bought_premium', String(bought));
    } catch {
      // ignore
    }
  };

  // App Hardware & OS Permissions State (AndroidManifest.xml & Browser Permissions Gate)
  const [appPermissions, setAppPermissions] = useState<{
    camera: boolean;
    microphone: boolean;
    screenCapture: boolean;
    floatingOverlay: boolean;
    location: boolean;
    notifications: boolean;
  }>(() => {
    try {
      const saved = localStorage.getItem('fism_granted_permissions_v1');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      camera: false,
      microphone: false,
      screenCapture: false,
      floatingOverlay: false,
      location: false,
      notifications: false,
    };
  });
  const [permissionsModalOpen, setPermissionsModalOpen] = useState<boolean>(false);
  const [pendingPermissionFeatureName, setPendingPermissionFeatureName] = useState<string>(
    'Camera, Microphone & Floating Window',
  );
  const pendingPermissionActionRef = useRef<(() => void) | null>(null);

  const saveAppPermissions = (nextPerms: typeof appPermissions) => {
    setAppPermissions(nextPerms);
    try {
      localStorage.setItem('fism_granted_permissions_v1', JSON.stringify(nextPerms));
    } catch {
      // ignore
    }
  };

  const requireHardwarePermissions = (
    requiredKeys: (keyof typeof appPermissions)[],
    featureLabel: string,
    onGranted: () => void,
  ): boolean => {
    const allGranted = requiredKeys.every((k) => appPermissions[k]);
    if (allGranted) {
      onGranted();
      return true;
    }
    setPendingPermissionFeatureName(featureLabel);
    pendingPermissionActionRef.current = onGranted;
    setPermissionsModalOpen(true);
    return false;
  };

  const [sectionPremiumMap, setSectionPremiumMap] = useState<Record<FismScreen, boolean>>({
    flameFeed: false,
    mainBlast: true,
    quickBurst: false,
    musicHub: true,
    shoppingSection: true,
    gameHub: true,
    emberChat: false,
    warmSparks: false,
    myHearth: false,
    onFire: true,
    circleFeed: true,
    fuelUp: false,
    earningHub: true,
    ashStash: false,
    findFlame: false,
    flame3DArena: true,
    aiWorkspaceHub: true,
    flameMaps: false,
    installApp: false,
    aiCloneStudio: true,
    communityChat: false,
    liveCreatorChat: false,
    coinLeaderboard: false,
    controlCore: false,
    adminPanel: false,
    adminFileVault: false,
    helpSupport: false,
    aboutFism: false,
    privacyPolicy: false,
    termsConditions: false,
  });

  // Live AdsTerra Tag Config, Official Single-Slot APK Release, In-App Map Modal & Android App Links
  const [adsterraConfig, setAdsterraConfig] = useState<FismAdsterraConfig | null>(
    DEFAULT_LIVE_ADSTERRA_CONFIG,
  );
  const [apkRelease, setApkRelease] = useState<FismApkReleaseInfo | null>(null);
  const [inAppMapModalTarget, setInAppMapModalTarget] = useState<{
    lat: number;
    lng: number;
    title: string;
    label?: string;
    subtitle?: string;
    isLive?: boolean;
    accuracyMeters?: number;
  } | null>(null);
  const [pendingDeepLink, setPendingDeepLink] = useState<FismDeepLinkTarget | null>(() =>
    typeof window !== 'undefined' ? parseFismDeepLink(window.location.href) : null,
  );
  const [deepLinkFallbackBanner, setDeepLinkFallbackBanner] = useState<{
    url: string;
    label: string;
  } | null>(null);

  // Copyright Protection, Content ID Fingerprinting & Appeals State
  const [copyrightAssets, setCopyrightAssets] = useState<FismCopyrightAssetRecord[]>([]);
  const [copyrightViolations, setCopyrightViolations] = useState<FismCopyrightViolationRecord[]>(
    [],
  );
  const [activeAppealPostId, setActiveAppealPostId] = useState<string | null>(null);
  const [appealProofText, setAppealProofText] = useState('');
  const [appealProofFileName, setAppealProofFileName] = useState('');

  // AI Clone Studio Saved Digital Avatars State
  const [aiCloneAvatars, setAiCloneAvatars] = useState<FismAiCloneAvatarProfile[]>([]);

  // Community Chat & Admin-Gated Live Creator Chat State (Strictly hidden by default!)
  const [communityRooms, setCommunityRooms] = useState<FismCommunityRoom[]>([]);
  const [liveCreatorRoom, setLiveCreatorRoom] = useState<FismCommunityRoom | null>(null);
  const [hasLiveCreatorAccess, setHasLiveCreatorAccess] = useState<boolean>(false);
  const [communityMessagesByRoom, setCommunityMessagesByRoom] = useState<
    Record<string, FismCommunityMessage[]>
  >({});
  const [activeGroupCalls, setActiveGroupCalls] = useState<Record<string, FismActiveGroupCall>>({});
  const [incomingGroupCallRing, setIncomingGroupCallRing] = useState<FismActiveGroupCall | null>(
    null,
  );
  const [liveCreatorAccessMap, setLiveCreatorAccessMap] = useState<Record<string, boolean>>({});
  const [localGroupCallStream, setLocalGroupCallStream] = useState<MediaStream | null>(null);
  const [remotePeerStreams, setRemotePeerStreams] = useState<Record<string, MediaStream>>({});

  const communityWsRef = useRef<WebSocket | null>(null);
  const rtcPeersRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const localGroupCallStreamRef = useRef<MediaStream | null>(null);
  const hasLiveCreatorAccessRef = useRef<boolean>(false);
  hasLiveCreatorAccessRef.current = hasLiveCreatorAccess;

  // In-App Music Library & Remix / Green Screen Studio State
  const [musicTracks, setMusicTracks] = useState<FismMusicTrack[]>(INITIAL_MUSIC_TRACKS);
  const [selectedStudioMusicTrack, setSelectedStudioMusicTrack] =
    useState<FismMusicTrack | null>(INITIAL_MUSIC_TRACKS[0]);
  const [greenScreenRemixSource, setGreenScreenRemixSource] = useState<FismPostItem | null>(null);
  const [remixActionSheetPost, setRemixActionSheetPost] = useState<FismPostItem | null>(null);

  // Quick Burst 3-Dot Menu Playback Speed (Normally 1x, selectable: 1x, 1.5x, 2x, 2.5x, 3x) & Vertical Scroll Refs
  const [shortPlaybackSpeed, setShortPlaybackSpeed] = useState<1 | 1.5 | 2 | 2.5 | 3>(1);
  const shortVideoRefs = useRef<Record<string, HTMLVideoElement | null>>({});
  const shortScrollContainerRef = useRef<HTMLDivElement | null>(null);
  const lastWheelScrollTimeRef = useRef<number>(0);

  // Creator Earning (5,000 Sparks) & Expanded Control Core Settings State
  const [earningCurrencyCode, setEarningCurrencyCode] = useState<string>('INR');
  const [autoScrollShortsOnEnd, setAutoScrollShortsOnEnd] = useState<boolean>(true);
  const [streamQualityMode, setStreamQualityMode] = useState<
    '4k60' | '1080p' | 'auto' | 'dataSaver'
  >('4k60');

  // Shopping Section State
  const [shoppingProducts, setShoppingProducts] = useState<FismShoppingProduct[]>(
    INITIAL_SHOPPING_PRODUCTS,
  );

  // Active Audio / Video Call Modal State
  const [activeCallInfo, setActiveCallInfo] = useState<{
    name: string;
    avatar: string;
    phone?: string;
    mode: 'audio' | 'video';
  } | null>(null);

  // Published AI AR Filters (Admin Studio -> Live Firestore & Server Sync -> Shorts Camera + Video Calls)
  const [publishedArFilters, setPublishedArFilters] = useState<FismArFilterAsset[]>(() => {
    try {
      const cached = localStorage.getItem('fism_published_ar_filters_v1');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return INITIAL_PUBLISHED_AR_FILTERS;
  });

  const handlePublishArFilter = async (newFilter: FismArFilterAsset) => {
    const publishedObj: FismArFilterAsset = {
      ...newFilter,
      id: newFilter.id.replace(/[^a-zA-Z0-9_-]/g, '_') || `ar_pub_${Date.now()}`,
      publishedToUsers: true,
    };

    setPublishedArFilters((prev) => {
      const next = [publishedObj, ...prev.filter((f) => f.id !== publishedObj.id)];
      try {
        localStorage.setItem('fism_published_ar_filters_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });

    // Persist to Server API for zero-update cross-tab sync
    fetch('/api/filters/publish', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filter: publishedObj }),
    }).catch(() => {});

    // Persist to Firestore /publishedFilters when signed in as verified Admin
    if (auth.currentUser?.emailVerified) {
      try {
        await setDoc(doc(db, 'publishedFilters', publishedObj.id), {
          name: publishedObj.name,
          prompt: publishedObj.prompt,
          overlayType: publishedObj.overlayType,
          cssFilter: publishedObj.cssFilter,
          primaryColor: publishedObj.primaryColor,
          secondaryColor: publishedObj.secondaryColor,
          eyeOffsetX: publishedObj.eyeOffsetX,
          eyeOffsetY: publishedObj.eyeOffsetY,
          scale: publishedObj.scale,
          glowIntensity: publishedObj.glowIntensity,
          badgeText: publishedObj.badgeText,
          thumbnailColor: publishedObj.thumbnailColor,
          publishedToUsers: true,
          createdBy: auth.currentUser.uid,
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Firestore publishedFilters sync skipped:', err);
      }
    }

    triggerToast(
      `🚀 AR Filter "${publishedObj.name}" published! Live now in Shorts Camera & Video Calls.`,
    );
  };

  // Published Smart Studio Filters (Photo BG, Camera Chroma Element, Green-Screen Game — Admin-only creation & Try Sandbox -> Searchable User Camera Gallery)
  const [publishedStudioFilters, setPublishedStudioFilters] = useState<FismSavedStudioFilter[]>(
    () => {
      try {
        const cached = localStorage.getItem('fism_published_studio_filters_v1');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
      } catch {
        // ignore
      }
      return [
        {
          id: 'studio_starter_neon_bg',
          name: 'Neon Studio Scene',
          mode: 'photo_bg',
          createdAt: new Date('2026-11-20T10:00:00Z').toISOString(),
          photoBgUrl: GENERATED_ASSETS.studioThumb,
          segSensitivity: 58,
        },
        {
          id: 'studio_starter_starfighter_game',
          name: 'Starfighter AR Game',
          mode: 'game_chroma',
          createdAt: new Date('2026-11-20T10:05:00Z').toISOString(),
          gameId: 'gs_starfighter_default',
          gameEngineType: 'customAdmin2D',
          gameAssetType: 'engine',
          chromaColor: '#00FF00',
          chromaSensitivity: 56,
          chromaSmoothness: 24,
        },
      ];
    },
  );

  const handlePublishStudioFilter = async (flt: FismSavedStudioFilter) => {
    setPublishedStudioFilters((prev) => {
      const next = [flt, ...prev.filter((item) => item.id !== flt.id)];
      try {
        localStorage.setItem('fism_published_studio_filters_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });

    fetch('/api/studio-filters/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filter: flt }),
    }).catch(() => {});

    triggerToast(
      `✨ Filter "${flt.name}" published! Users can now find & use it by title inside Camera -> All Filters.`,
    );
  };

  const handleDeleteStudioFilter = async (id: string) => {
    setPublishedStudioFilters((prev) => {
      const next = prev.filter((item) => item.id !== id);
      try {
        localStorage.setItem('fism_published_studio_filters_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });

    fetch(`/api/studio-filters/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    }).catch(() => {});

    triggerToast('🗑️ Published filter removed from User Camera Gallery.');
  };

  // AI-Powered Flame Algorithm Behavior Profile, Smart Ads & Connected Stores
  const [behaviorProfile, setBehaviorProfile] = useState<FismUserBehaviorProfile>(() => {
    try {
      const saved = localStorage.getItem('fism_behavior_profile_v1');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      watchTimeByCategory: { gaming: 12, tech: 6 },
      likedTags: { gaming: 2 },
      gameInterests: { gaming: 1 },
      searchTags: [],
      engagedPostIds: [],
    };
  });

  const [smartAds, setSmartAds] = useState<FismSmartAdItem[]>(() => {
    try {
      const saved = localStorage.getItem('fism_smart_ads_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return INITIAL_SMART_ADS;
  });

  const [affiliateStoreConfig, setAffiliateStoreConfig] = useState<FismAffiliateStoreConfig>(() => {
    try {
      const saved = localStorage.getItem('fism_affiliate_store_v1');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      userId: 'local_hearth_user',
      amazonAffiliateUrl: '',
      amazonTag: '',
      flipkartAffiliateUrl: '',
      flipkartId: '',
      meeshoAffiliateUrl: '',
      meeshoCode: '',
      updatedAt: 'Not linked yet',
    };
  });

  // Main Blast Mid-Roll Ad Session State (Min 1, Max 3 Ads per long video; 15s countdown; hides engagement buttons)
  const [mainBlastActiveAd, setMainBlastActiveAd] = useState<FismSmartAdItem | null>(null);
  const [mainBlastAdCountdown, setMainBlastAdCountdown] = useState<number>(15);
  const [mainBlastSessionAdCount, setMainBlastSessionAdCount] = useState<number>(0);
  const mainBlastWatchRef = useRef<{
    postId: string;
    watchSec: number;
    shownAdIds: string[];
    adsCount: number;
  }>({ postId: '', watchSec: 0, shownAdIds: [], adsCount: 0 });

  // Real-Time Live Location Sharing State (WebSocket /ws/location + Geolocation + Firestore)
  const [liveLocationsMap, setLiveLocationsMap] = useState<Record<string, FismLiveLocationState>>(
    {},
  );
  const [activeLiveShareId, setActiveLiveShareId] = useState<string | null>(null);
  const locationWsRef = useRef<WebSocket | null>(null);
  const locationWatchIdRef = useRef<number | null>(null);

  // Coin Wallet, Gift Drops & Global Leaderboard State
  const [coinWallets, setCoinWallets] = useState<FismCoinWallet[]>(() => {
    try {
      const saved = localStorage.getItem('fism_coin_wallets_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return INITIAL_COIN_WALLETS;
  });

  const [giftDrops, setGiftDrops] = useState<FismGiftDropConfig[]>(() => {
    try {
      const saved = localStorage.getItem('fism_gift_drops_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return INITIAL_GIFT_DROPS;
  });

  const [claimedGiftReceipts, setClaimedGiftReceipts] = useState<FismClaimedGiftReceipt[]>(() => {
    try {
      const saved = localStorage.getItem('fism_claimed_gift_receipts_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  });

  // SP Coin Wallet, On Fire Super Chats / Stickers, Channel Memberships & Collab Multi-Follow State
  const [spWallet, setSpWallet] = useState<FismSpCoinWallet>(() => {
    try {
      const saved = localStorage.getItem('fism_sp_wallet_v1');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      uid: 'local_hearth_user',
      username: 'flame_creator',
      displayName: 'Flame Creator',
      avatarUrl: GENERATED_ASSETS.avatar1,
      spCoins: 0,
      totalSpPurchased: 0,
      totalSpSpent: 0,
      updatedAt: 'Ready',
    };
  });
  const [superChats, setSuperChats] = useState<FismSuperChatMessage[]>([]);
  const [channelMemberships, setChannelMemberships] = useState<FismChannelMembership[]>(() => {
    try {
      const saved = localStorage.getItem('fism_channel_memberships_v1');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });
  const [fuelCheckoutMode, setFuelCheckoutMode] = useState<'premium' | 'sp_coin_pack'>('premium');
  const [selectedSpPackId, setSelectedSpPackId] = useState<string>(SP_COIN_BUY_PACKS[0].id);
  const [collabFollowTargetPost, setCollabFollowTargetPost] = useState<FismPostItem | null>(null);

  // Google Maps Platform Demo Key Quota Defense State (Top-level context)
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState<boolean>(false);
  useEffect(() => {
    const handleQuotaExceeded = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuotaExceeded);
  }, []);

  // Secret / Disappearing Chats + Security Password + Firebase OTP Recovery State
  const [secretChatPassword, setSecretChatPassword] = useState<string>(() => {
    try {
      return localStorage.getItem('fism_secret_chat_password_v1') || '';
    } catch {
      return '';
    }
  });
  const [secretChatsLocked, setSecretChatsLocked] = useState<boolean>(() => {
    try {
      return Boolean(localStorage.getItem('fism_secret_chat_password_v1'));
    } catch {
      return false;
    }
  });
  const [secretUnlockInput, setSecretUnlockInput] = useState<string>('');
  const [secretUnlockError, setSecretUnlockError] = useState<string | null>(null);
  const [newChatPassDraft, setNewChatPassDraft] = useState<string>('');
  const [recoveryContactInput, setRecoveryContactInput] = useState<string>('');
  const [recoveryChallengeId, setRecoveryChallengeId] = useState<string | null>(null);
  const [recoveryFirebaseConfirm, setRecoveryFirebaseConfirm] =
    useState<ConfirmationResult | null>(null);
  const [recoveryOtpInput, setRecoveryOtpInput] = useState<string>('');
  const [recoveryOtpPreview, setRecoveryOtpPreview] = useState<string | null>(null);
  const [recoveryOtpVerified, setRecoveryOtpVerified] = useState<boolean>(false);
  const [recoveryNewPasswordInput, setRecoveryNewPasswordInput] = useState<string>('');
  const [recoveryStatusMsg, setRecoveryStatusMsg] = useState<string | null>(null);
  const [recoverySending, setRecoverySending] = useState<boolean>(false);
  const recaptchaVerifierRef = useRef<RecaptchaVerifier | null>(null);

  const updateSecretChatPassword = (nextPass: string) => {
    setSecretChatPassword(nextPass);
    try {
      if (nextPass) {
        localStorage.setItem('fism_secret_chat_password_v1', nextPass);
      } else {
        localStorage.removeItem('fism_secret_chat_password_v1');
      }
    } catch {
      // ignore
    }
  };

  // Strict Premium Profile Customizer State (Theme Color Hex & Username Styles)
  const [premiumProfileStyle, setPremiumProfileStyle] = useState<FismPremiumProfileStyle>(() => {
    try {
      const saved = localStorage.getItem('fism_premium_profile_style_v1');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      themeColorHex: '#FF5722',
      customDarkAccent: false,
      usernameFontId: 'geometric',
      usernameEffectId: 'classic',
    };
  });
  const [customHexDraft, setCustomHexDraft] = useState<string>(premiumProfileStyle.themeColorHex);
  const [customDarkAccentDraft, setCustomDarkAccentDraft] = useState<boolean>(
    premiumProfileStyle.customDarkAccent,
  );
  const [fontDraft, setFontDraft] = useState<FismPremiumProfileStyle['usernameFontId']>(
    premiumProfileStyle.usernameFontId,
  );
  const [effectDraft, setEffectDraft] = useState<FismPremiumProfileStyle['usernameEffectId']>(
    premiumProfileStyle.usernameEffectId,
  );
  const [profileStyleError, setProfileStyleError] = useState<string | null>(null);

  // Emoji Blast Mini-Game Modal State (Triggered by Long-Pressing a Chat Message)
  const [emojiGameActiveEmoji, setEmojiGameActiveEmoji] = useState<string | null>(null);
  const chatMsgHoldTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Core Social Data State
  const [creators, setCreators] = useState<FismCreator[]>(INITIAL_CREATORS);
  const [stories, setStories] = useState<FismStoryItem[]>(INITIAL_STORIES);
  const [posts, setPosts] = useState<FismPostItem[]>(INITIAL_POSTS);
  const [feedFilter, setFeedFilter] = useState<'For You' | 'Following' | 'Trending' | 'Latest'>(
    'For You',
  );
  const [circleFilter, setCircleFilter] = useState<
    'All' | 'Latest' | 'Photos' | 'Videos' | 'Exclusive'
  >('All');
  const [findCategory, setFindCategory] = useState<
    'All' | 'People' | 'Posts' | 'Videos' | 'Hashtags' | 'Creators' | 'Live'
  >('All');
  const [recentSearches, setRecentSearches] = useState<string[]>([
    '#AlpineFlame',
    'Arian Vance',
    '8K Studio Tour',
    '#FutureBeats',
  ]);

  // Story Viewer Modal State
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);
  const [storyPaused, setStoryPaused] = useState(false);
  const [storyReplyText, setStoryReplyText] = useState('');

  // Quick Post Composer (Flame Feed)
  const [quickPostText, setQuickPostText] = useState('');
  const [quickPostVisibility, setQuickPostVisibility] = useState<
    'public' | 'subscribers' | 'private'
  >('public');

  // ============================================================================
  // ADVANCED POST & UPLOAD ENGINE (Spark New + Smart Routing + Shorts Editor)
  // ============================================================================
  const [sparkNewModalOpen, setSparkNewModalOpen] = useState(false);
  const [uploadCategory, setUploadCategory] = useState<'photoPost' | 'videoUpload' | 'story'>(
    'videoUpload',
  );
  const [newTitle, setNewTitle] = useState('');
  const [newCaption, setNewCaption] = useState('');
  const [newHashtags, setNewHashtags] = useState('#FISM #FlameCreative #Original');
  const [newMentionTags, setNewMentionTags] = useState('@arian_vance @elena_rostova');
  const [newPromotionLabel, setNewPromotionLabel] = useState('No Paid Promotion');
  const [newLocation, setNewLocation] = useState('San Francisco, CA');
  const [newVisibility, setNewVisibility] = useState<'public' | 'subscribers' | 'private'>(
    'public',
  );
  const [newAllowComments, setNewAllowComments] = useState(true);
  const [advVideoResolution, setAdvVideoResolution] = useState<'4K UHD' | '1080p Full HD'>(
    '4K UHD',
  );
  const [advVideoHdr, setAdvVideoHdr] = useState(true);
  const [newMediaPreview, setNewMediaPreview] = useState<string>(GENERATED_ASSETS.heroCover);
  const [newCustomThumbnail, setNewCustomThumbnail] = useState<string>(
    GENERATED_ASSETS.studioThumb,
  );
  const [uploadedVideoSeconds, setUploadedVideoSeconds] = useState<number>(45); // <=60s -> Quick Burst, >60s -> Main Blast
  const [uploadedVideoFileName, setUploadedVideoFileName] = useState<string>(
    'Creator_Session_Clip.mp4',
  );
  const [savedDraftsCount, setSavedDraftsCount] = useState(1);

  // Built-In Shorts / Video Editing Suite State
  const [editorTextOverlay, setEditorTextOverlay] = useState<string>('🔥 IGNITE THE MOMENT');
  const [editorSelectedSticker, setEditorSelectedSticker] = useState<string>('⚡ NEW DROP');
  const [editorSelectedEmoji, setEditorSelectedEmoji] = useState<string>('🔥');
  const [editorColorFilter, setEditorColorFilter] = useState<
    'none' | 'flameWarm' | 'cyberNeon' | 'tealOrange' | 'bwContrast' | 'goldenHour'
  >('flameWarm');

  // Active Post Interactions
  const [activeChatterPostId, setActiveChatterPostId] = useState<string | null>(null);
  const [newCommentText, setNewCommentText] = useState('');
  const [activeSpreadPost, setActiveSpreadPost] = useState<FismPostItem | null>(null);
  const [openMenuPostId, setOpenMenuPostId] = useState<string | null>(null);
  const [editingPost, setEditingPost] = useState<FismPostItem | null>(null);
  const [smotherTarget, setSmotherTarget] = useState<{
    id: string;
    label: string;
    type: FismReportItem['targetType'];
  } | null>(null);
  const [smotherReason, setSmotherReason] = useState<FismReportItem['reason']>('Spam');
  const [smotherDetails, setSmotherDetails] = useState('');
  const [extinguishTargetCreator, setExtinguishTargetCreator] = useState<FismCreator | null>(null);

  // Main Blast (Video Player State)
  const [selectedVideoPost, setSelectedVideoPost] = useState<FismPostItem>(
    INITIAL_POSTS.find((p) => p.postType === 'video') || INITIAL_POSTS[1],
  );
  const [videoPlaying, setVideoPlaying] = useState(false);
  const [videoMuted, setVideoMuted] = useState(false);
  const [videoProgress, setVideoProgress] = useState(28);
  const [videoSpeed, setVideoSpeed] = useState<1 | 1.25 | 1.5 | 2>(1);
  const [videoCaptionsOn, setVideoCaptionsOn] = useState(true);
  const mainBlastCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Quick Burst (Vertical Shorts Feed State)
  const [activeQuickBurstIndex, setActiveQuickBurstIndex] = useState(0);
  const [quickBurstMuted, setQuickBurstMuted] = useState(false);
  const [quickBurstPlaying, setQuickBurstPlaying] = useState(true);

  // Ember Chat (Direct Messaging State)
  const [conversations, setConversations] = useState<FismConversation[]>([
    {
      userId: 'creator_elena',
      username: 'elena_rostova',
      displayName: 'Elena Rostova (Follower / Spark)',
      avatarUrl: GENERATED_ASSETS.avatar2,
      online: true,
      typing: false,
      unreadCount: 1,
      messages: [
        {
          id: 'm_1',
          senderId: 'creator_elena',
          senderName: 'Elena Rostova',
          recipientId: 'local_hearth_user',
          text: 'Hey Alex! 🔥 Loved your latest Main Blast studio breakdown. Long-press this message to play the Emoji Blast Game!',
          messageType: 'text',
          reactions: ['🔥'],
          isRead: false,
          delivered: true,
          createdAt: '10:24 AM',
        },
      ],
    },
    {
      userId: 'creator_arian',
      username: 'arian_vance',
      displayName: 'Arian Vance (Following / Flame)',
      avatarUrl: GENERATED_ASSETS.avatar1,
      online: true,
      typing: false,
      unreadCount: 0,
      messages: [
        {
          id: 'm_2',
          senderId: 'creator_arian',
          senderName: 'Arian Vance',
          recipientId: 'local_hearth_user',
          text: 'Sent over the master synth stems ⚡ Let’s hop on a quick Video Call!',
          messageType: 'text',
          reactions: ['⚡'],
          isRead: true,
          delivered: true,
          createdAt: 'Yesterday',
        },
      ],
    },
  ]);
  const [activeChatUserId, setActiveChatUserId] = useState<string>('creator_elena');
  const [chatInput, setChatInput] = useState('');
  const [chatSearchQuery, setChatSearchQuery] = useState('');
  const [replyingToMessage, setReplyingToMessage] = useState<string | null>(null);

  // Warm Sparks (Notifications State)
  const [notifications, setNotifications] = useState<FismNotificationItem[]>([
    {
      id: 'notif_1',
      actorId: 'creator_elena',
      actorName: 'Elena Rostova',
      actorAvatar: GENERATED_ASSETS.avatar2,
      notificationType: 'spark',
      message: 'sparked your photo "Above the Golden Cloud Sea".',
      isRead: false,
      createdAt: '6m ago',
      targetScreen: 'flameFeed',
    },
    {
      id: 'notif_2',
      actorId: 'creator_arian',
      actorName: 'Arian Vance',
      actorAvatar: GENERATED_ASSETS.avatar1,
      notificationType: 'fuelUp',
      message: 'fuelled up to your Inferno Creator Tier ($9.99/mo)!',
      isRead: false,
      createdAt: '28m ago',
      targetScreen: 'fuelUp',
    },
    {
      id: 'notif_3',
      actorId: 'creator_kael',
      actorName: 'Kael Ignite Studio',
      actorAvatar: GENERATED_ASSETS.avatar1,
      notificationType: 'chatter',
      message: 'left Chatter on your Main Blast video.',
      isRead: true,
      createdAt: '2h ago',
      targetScreen: 'mainBlast',
    },
  ]);
  const [notifFilter, setNotifFilter] = useState<
    'all' | 'unread' | 'spark' | 'chatter' | 'fuelUp' | 'collab_tag' | 'follow_request'
  >('all');

  // AshStash (Collections State)
  const [stashCollections, setStashCollections] = useState<string[]>([
    'All Saved',
    'Studio Inspiration',
    'Travel & Peaks',
    'Synth & Audio',
  ]);
  const [selectedStashCollection, setSelectedStashCollection] = useState('All Saved');
  const [newCollectionName, setNewCollectionName] = useState('');

  // On Fire (Live Streaming State — Real WebRTC Camera)
  const [isBroadcastingLive, setIsBroadcastingLive] = useState(false);
  const [liveStreamTitle, setLiveStreamTitle] = useState(
    'Live Modular Synth & Visual Grading Session',
  );
  const [liveStreamCategory, setLiveStreamCategory] = useState('Music & Production');
  const [liveViewerCount, setLiveViewerCount] = useState(0);
  const [liveChatMessages, setLiveChatMessages] = useState<
    { id: string; user: string; text: string; badge?: string }[]
  >([
    {
      id: 'lc_1',
      user: 'elena_rostova',
      text: 'Audio levels sound crystal clear!',
      badge: 'Fueler',
    },
    { id: 'lc_2', user: 'kael_ignite', text: 'Drop the sub bass patch 🔥', badge: 'Creator' },
  ]);
  const [liveChatInput, setLiveChatInput] = useState('');
  const [liveCameraError, setLiveCameraError] = useState<string | null>(null);
  const liveVideoRef = useRef<HTMLVideoElement | null>(null);
  const liveMediaStreamRef = useRef<MediaStream | null>(null);

  // Camera Studio Broadcast: Format Choice (Long vs Quick Burst), Full-Screen Mode, Side Chat & Live Filters
  const [cameraLiveFormatModalOpen, setCameraLiveFormatModalOpen] = useState(false);
  const [cameraLiveAspectMode, setCameraLiveAspectMode] = useState<'long' | 'quickBurst'>('long');
  const [cameraFullScreenOpen, setCameraFullScreenOpen] = useState(false);
  const [cameraLiveFilter, setCameraLiveFilter] = useState<
    'none' | 'flameWarm' | 'cyberNeon' | 'tealOrange' | 'bwContrast' | 'goldenHour'
  >('none');
  const [fullScreenChatKind, setFullScreenChatKind] = useState<'normal' | 'superchat' | 'sticker'>('normal');
  const [fullScreenSuperBoxStyle, setFullScreenSuperBoxStyle] = useState<FismSuperChatBoxStyle>('amber_flame');

  // Admin Uploaded Custom 3D Models (Starts with 4 Default Models; Admin uploads more in Admin File Vault)
  const [custom3DModels, setCustom3DModels] = useState<Face3DModelPreset[]>(() => {
    try {
      const saved = localStorage.getItem('fism_admin_custom_3d_models');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const handleAdminUpload3DModel = (newModel: Face3DModelPreset) => {
    setCustom3DModels((prev) => {
      const updated = [...prev, newModel];
      try {
        localStorage.setItem('fism_admin_custom_3d_models', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  };

  // My Hearth (Profile State)
  const [viewedProfileId, setViewedProfileId] = useState<string>('local_hearth_user');
  const [profileTab, setProfileTab] = useState<
    'Posts' | 'Videos' | 'Quick Burst' | 'On Fire' | 'AshStash' | 'Ad & Affiliate' | 'About'
  >('Posts');
  const [editProfileModalOpen, setEditProfileModalOpen] = useState(false);

  // Saved On Fire Broadcasts & Screen-Sharing Replays (Stored on Creator Profile for Later Viewing)
  const [onFireSavedVideos, setOnFireSavedVideos] = useState<FismPostItem[]>(() => {
    try {
      const saved = localStorage.getItem('fism_onfire_saved_videos_v1');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });
  const onFireRecorderRef = useRef<MediaRecorder | null>(null);
  const onFireRecordedChunksRef = useRef<Blob[]>([]);
  const onFireStreamTitleRef = useRef<string>('On Fire Live Broadcast');
  const flameFeedLiveVideoRef = useRef<HTMLVideoElement | null>(null);
  const [profileModalList, setProfileModalList] = useState<'Sparks' | 'Flames' | 'Fuelers' | null>(
    null,
  );

  // Fuel Up (Subscription Plans & Verification)
  const [selectedTierPrice, setSelectedTierPrice] = useState<4.99 | 9.99>(4.99);
  const [subVerificationMsg, setSubVerificationMsg] = useState<string | null>(null);

  // Admin Control Panel & Reports State
  const [reports, setReports] = useState<FismReportItem[]>([
    {
      id: 'rep_1',
      reporterId: 'creator_elena',
      reporterName: 'Elena Rostova',
      targetId: 'post_99',
      targetLabel: 'Suspicious crypto giveaway comment',
      targetType: 'comment',
      reason: 'Spam',
      details: 'Automated bot link posted repeatedly.',
      status: 'pending',
      createdAt: '1 hour ago',
    },
  ]);

  // Toast Feedback Banner
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3400);
  };

  // Web Audio Chime & Ringtone Generator for Real-Time Call & Real-Time Notifications
  const playRealtimeSound = (type: 'notif' | 'ringtone') => {
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      if (type === 'ringtone') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(784, now); // G5
        osc.frequency.setValueAtTime(987.77, now + 0.16); // B5
        osc.frequency.setValueAtTime(1174.66, now + 0.32); // D6
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
        osc.start(now);
        osc.stop(now + 0.66);
      } else {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(880, now + 0.1); // A5
        gain.gain.setValueAtTime(0.14, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
        osc.start(now);
        osc.stop(now + 0.3);
      }
    } catch {
      // ignore autoplay restriction
    }
  };

  // Real-Time Notification Dispatcher (Updates Warm Sparks + Shows Live Floating Banner + Broadcasts Across Tabs)
  const dispatchRealtimeNotification = (notif: FismNotificationItem, broadcast = true) => {
    setNotifications((prev) => [notif, ...prev.filter((n) => n.id !== notif.id)]);
    setRealtimePushBanner(notif);
    playRealtimeSound('notif');
    setTimeout(() => {
      setRealtimePushBanner((curr) => (curr?.id === notif.id ? null : curr));
    }, 5500);
    if (broadcast) {
      try {
        realtimeChannelRef.current?.postMessage({ type: 'REALTIME_NOTIF', payload: notif });
        localStorage.setItem(
          'fism_last_realtime_notif',
          JSON.stringify({ ...notif, _ts: Date.now() }),
        );
      } catch {
        // ignore
      }
    }
  };

  // Creator Earning $500+ Minimum Withdrawal Requests State & Admin Accept / Decline (Refund) Handlers
  const [withdrawalRequests, setWithdrawalRequests] = useState<FismWithdrawalRequest[]>(() => {
    try {
      const saved = localStorage.getItem('fism_creator_withdrawals');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  });

  const saveWithdrawalsToStorage = (list: FismWithdrawalRequest[]) => {
    try {
      localStorage.setItem('fism_creator_withdrawals', JSON.stringify(list));
    } catch {
      // ignore
    }
  };

  const handleSubmitWithdrawalRequest = (newReq: FismWithdrawalRequest) => {
    setWithdrawalRequests((prev) => {
      const next = [newReq, ...prev];
      saveWithdrawalsToStorage(next);
      return next;
    });
    dispatchRealtimeNotification({
      id: `notif_wd_pending_${Date.now()}`,
      actorId: myProfile.uid,
      actorName: 'FISM Creator Wallet',
      actorAvatar: myProfile.avatarUrl,
      notificationType: 'fuelUp',
      message: `Your withdrawal is pending (${newReq.convertedAmountLabel} via ${newReq.paymentMethodLabel}). Amount deducted from wallet & sent to Admin File.`,
      isRead: false,
      createdAt: 'Real-Time • Just now',
      targetScreen: 'earningHub',
    });
    triggerToast(
      `⏳ Your withdrawal is pending (${newReq.convertedAmountLabel} deducted from wallet & sent to Admin File)!`,
    );
  };

  const handleAcceptWithdrawalRequest = (reqId: string) => {
    const target = withdrawalRequests.find((w) => w.id === reqId);
    setWithdrawalRequests((prev) => {
      const next = prev.map((w) =>
        w.id === reqId
          ? { ...w, status: 'accepted' as const, reviewedAt: new Date().toLocaleString() }
          : w,
      );
      saveWithdrawalsToStorage(next);
      return next;
    });
    if (target) {
      dispatchRealtimeNotification({
        id: `notif_wd_accept_${Date.now()}`,
        actorId: 'admin_vault',
        actorName: 'FISM Admin Payouts',
        actorAvatar: GENERATED_ASSETS.avatar1,
        notificationType: 'fuelUp',
        message: `✓ Successful! Your withdrawal of ${target.convertedAmountLabel} (${target.paymentMethodLabel}) has been accepted by Admin!`,
        isRead: false,
        createdAt: 'Real-Time • Just now',
        targetScreen: 'earningHub',
      });
      triggerToast(`✅ Withdrawal Marked Successful for ${target.userFullName} (${target.convertedAmountLabel})!`);
    }
  };

  const handleDeclineWithdrawalRequest = (reqId: string) => {
    const target = withdrawalRequests.find((w) => w.id === reqId);
    setWithdrawalRequests((prev) => {
      const next = prev.map((w) =>
        w.id === reqId
          ? { ...w, status: 'declined' as const, reviewedAt: new Date().toLocaleString() }
          : w,
      );
      saveWithdrawalsToStorage(next);
      return next;
    });
    if (target) {
      dispatchRealtimeNotification({
        id: `notif_wd_decline_${Date.now()}`,
        actorId: 'admin_vault',
        actorName: 'FISM Admin Payouts',
        actorAvatar: GENERATED_ASSETS.avatar1,
        notificationType: 'fuelUp',
        message: `✕ Your payment is declined — ${target.convertedAmountLabel} has been refunded back to your Profile ID (${target.profileId}) Wallet!`,
        isRead: false,
        createdAt: 'Real-Time • Just now',
        targetScreen: 'earningHub',
      });
      triggerToast(
        `✕ Your payment is declined — Refunded ${target.convertedAmountLabel} back to ${target.userFullName}'s Wallet!`,
      );
    }
  };

  // Real-Time Call Dispatcher (Sends Real-Time Call Notification + Ringing Alert + Connects Call)
  const triggerRealtimeCall = (
    info: {
      name: string;
      avatar: string;
      phone?: string;
      mode: 'audio' | 'video';
    },
    options?: { incomingRingOnly?: boolean; broadcast?: boolean },
  ) => {
    const callPayload = {
      id: `call_${Date.now()}`,
      callerName: info.name,
      callerAvatar: info.avatar,
      callerPhone: info.phone || '+91 98765 43210',
      mode: info.mode,
      timestamp: new Date().toLocaleTimeString(),
    };

    const callNotif: FismNotificationItem = {
      id: `notif_call_${Date.now()}`,
      actorId: 'realtime_call_system',
      actorName: info.name,
      actorAvatar: info.avatar,
      notificationType: 'live',
      message:
        info.mode === 'video'
          ? `📹 Real-Time Video Call ${options?.incomingRingOnly ? 'Ringing...' : 'Started'} (${callPayload.timestamp})`
          : `📞 Real-Time Voice Call ${options?.incomingRingOnly ? 'Ringing...' : 'Started'} (${callPayload.timestamp})`,
      isRead: false,
      createdAt: 'Real-Time • Just now',
      targetScreen: 'emberChat',
    };

    dispatchRealtimeNotification(callNotif, false);
    playRealtimeSound('ringtone');

    if (options?.incomingRingOnly) {
      setIncomingRealtimeCall(callPayload);
    } else {
      setIncomingRealtimeCall(callPayload);
      setActiveCallInfo(info);
    }

    if (options?.broadcast !== false) {
      try {
        realtimeChannelRef.current?.postMessage({
          type: 'REALTIME_CALL',
          payload: callPayload,
          notif: callNotif,
        });
        localStorage.setItem(
          'fism_last_realtime_call',
          JSON.stringify({ callPayload, callNotif, _ts: Date.now() }),
        );
      } catch {
        // ignore
      }
    }
  };

  useEffect(() => {
    try {
      if (typeof BroadcastChannel !== 'undefined') {
        const ch = new BroadcastChannel('fism_realtime_events');
        realtimeChannelRef.current = ch;
        ch.onmessage = (ev) => {
          const data = ev.data;
          if (data?.type === 'REALTIME_NOTIF' && data.payload) {
            dispatchRealtimeNotification(data.payload, false);
          } else if (data?.type === 'REALTIME_CALL' && data.payload) {
            setIncomingRealtimeCall(data.payload);
            if (data.notif) {
              dispatchRealtimeNotification(data.notif, false);
            }
            playRealtimeSound('ringtone');
          }
        };
      }
    } catch {
      // ignore
    }

    const onStorageSync = (e: StorageEvent) => {
      try {
        if (e.key === 'fism_last_realtime_notif' && e.newValue) {
          const parsed = JSON.parse(e.newValue);
          if (parsed?.id) dispatchRealtimeNotification(parsed, false);
        } else if (e.key === 'fism_last_realtime_call' && e.newValue) {
          const parsed = JSON.parse(e.newValue);
          if (parsed?.callPayload) {
            setIncomingRealtimeCall(parsed.callPayload);
            if (parsed.callNotif) dispatchRealtimeNotification(parsed.callNotif, false);
            playRealtimeSound('ringtone');
          }
        }
      } catch {
        // ignore
      }
    };
    window.addEventListener('storage', onStorageSync);
    return () => {
      window.removeEventListener('storage', onStorageSync);
      realtimeChannelRef.current?.close();
    };
  }, []);

  // Continuous Ringing Pulse while Incoming Real-Time Call Banner is Open
  useEffect(() => {
    if (ringtoneTimerRef.current) {
      clearInterval(ringtoneTimerRef.current);
      ringtoneTimerRef.current = null;
    }
    if (incomingRealtimeCall && !activeCallInfo) {
      ringtoneTimerRef.current = setInterval(() => {
        playRealtimeSound('ringtone');
      }, 2200);
    }
    return () => {
      if (ringtoneTimerRef.current) {
        clearInterval(ringtoneTimerRef.current);
        ringtoneTimerRef.current = null;
      }
    };
  }, [incomingRealtimeCall, activeCallInfo]);

  // Apply Theme
  useEffect(() => {
    const root = document.documentElement;
    const isDark =
      themeMode === 'dark' ||
      (themeMode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [themeMode]);

  // Initialize Firebase Auth & Real-time Firestore Listeners
  useEffect(() => {
    const unsubscribeAuth = initAuth(
      async (user) => {
        setCurrentUser(user);
        const rawHandle = (user.email?.split('@')[0] || prevSafeName(user.displayName) || 'fism_user')
          .replace(/[^a-zA-Z0-9_-]/g, '_')
          .slice(0, 36);
        const safeUsername = rawHandle.length >= 2 ? rawHandle : `${rawHandle}_u`;

        setMyProfile((prev) => ({
          ...prev,
          uid: user.uid,
          displayName: user.displayName || prev.displayName,
          avatarUrl: user.photoURL || prev.avatarUrl,
          username: safeUsername,
        }));

        if (user.emailVerified) {
          try {
            const userRef = doc(db, 'users', user.uid);
            const existingSnap = await getDoc(userRef);
            const safeDisplay = (user.displayName || 'FISM Creator').slice(0, 80) || 'FISM Creator';
            const safeAvatar = (user.photoURL || GENERATED_ASSETS.avatar1).slice(0, 1024);
            if (!existingSnap.exists()) {
              await setDoc(userRef, {
                uid: user.uid,
                username: safeUsername,
                displayName: safeDisplay,
                bio: 'FISM 2.0 Verified Creator',
                avatarUrl: safeAvatar,
                coverUrl: GENERATED_ASSETS.heroCover.slice(0, 1024),
                isVerified: false,
                isPrivate: false,
                sparksCount: 14820,
                flamesCount: 342,
                fuelersCount: 418,
                visibility: 'public',
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            } else {
              await updateDoc(userRef, {
                displayName: safeDisplay,
                avatarUrl: safeAvatar,
                updatedAt: serverTimestamp(),
              });
            }
          } catch (err) {
            console.warn('Profile sync note:', err);
          }
        }
      },
      () => {
        setCurrentUser(null);
      },
    );

    function prevSafeName(name: string | null) {
      return name ? name.toLowerCase().replace(/\s+/g, '_') : '';
    }

    const qPosts = query(
      collection(db, 'posts'),
      where('visibility', '==', 'public'),
      orderBy('createdAt', 'desc'),
      limit(25),
    );
    const unsubscribePosts = onSnapshot(
      qPosts,
      (snapshot) => {
        if (!snapshot.empty) {
          const remotePosts: FismPostItem[] = [];
          snapshot.forEach((docSnap) => {
            const d = docSnap.data();
            remotePosts.push({
              id: docSnap.id,
              authorId: d.authorId || 'creator_arian',
              authorUsername: d.authorUsername || 'fism_creator',
              authorDisplayName: d.authorDisplayName || d.authorUsername || 'FISM Creator',
              authorAvatar: d.authorAvatar || GENERATED_ASSETS.avatar1,
              authorVerified: Boolean(d.authorVerified ?? true),
              postType: d.postType || 'photo',
              title: d.title || 'FISM Moment',
              caption: d.caption || '',
              mediaUrl: d.mediaUrl || GENERATED_ASSETS.mountainPost,
              thumbnailUrl: d.thumbnailUrl || d.mediaUrl || GENERATED_ASSETS.mountainPost,
              aspectRatio: d.aspectRatio || '16:9',
              duration: d.duration || '03:20',
              audioTrack: d.audioTrack || 'Original FISM Audio',
              hashtags: Array.isArray(d.hashtags) ? d.hashtags : ['#FISM'],
              location: d.location || 'Global Hearth',
              visibility: d.visibility || 'public',
              allowComments: d.allowComments ?? true,
              sparkCount: Number(d.sparkCount ?? 1),
              chatterCount: Number(d.chatterCount ?? 0),
              spreadCount: Number(d.spreadCount ?? 0),
              viewsCount: Number(d.viewsCount ?? 100),
              isSparked: false,
              isStashed: false,
              createdAt: 'Just now',
              comments: [],
            });
          });
          setPosts((prev) => {
            const existingIds = new Set(remotePosts.map((p) => p.id));
            return [...remotePosts, ...prev.filter((p) => !existingIds.has(p.id))];
          });
        }
      },
      (err) => {
        console.warn('Firestore posts listener:', err.message);
      },
    );

    const qPublishedFilters = query(
      collection(db, 'publishedFilters'),
      where('publishedToUsers', '==', true),
      limit(30),
    );
    const unsubscribeFilters = onSnapshot(
      qPublishedFilters,
      (snapshot) => {
        if (!snapshot.empty) {
          const remoteFilters: FismArFilterAsset[] = [];
          snapshot.forEach((docSnap) => {
            const d = docSnap.data();
            if (d.publishedToUsers) {
              remoteFilters.push({
                id: docSnap.id,
                name: String(d.name || 'AR Filter'),
                prompt: String(d.prompt || ''),
                overlayType: d.overlayType || 'cyberpunk_sunglasses',
                cssFilter: String(d.cssFilter || ''),
                primaryColor: String(d.primaryColor || '#00F5D4'),
                secondaryColor: String(d.secondaryColor || '#FF2A85'),
                eyeOffsetX: Number(d.eyeOffsetX || 0),
                eyeOffsetY: Number(d.eyeOffsetY || -6),
                scale: Number(d.scale || 1),
                glowIntensity: Number(d.glowIntensity || 20),
                badgeText: String(d.badgeText || 'AR'),
                thumbnailColor: String(d.thumbnailColor || '#00F5D4'),
                publishedToUsers: true,
                createdBy: String(d.createdBy || 'Admin'),
                createdAt: 'Synced via Firestore',
              });
            }
          });
          if (remoteFilters.length > 0) {
            setPublishedArFilters((prev) => {
              const ids = new Set(remoteFilters.map((f) => f.id));
              return [...remoteFilters, ...prev.filter((p) => !ids.has(p.id))];
            });
          }
        }
      },
      () => {
        // Graceful fallback to server/local synced filters
      },
    );

    fetch('/api/filters')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data?.filters) && data.filters.length > 0) {
          setPublishedArFilters((prev) => {
            const ids = new Set(data.filters.map((f: FismArFilterAsset) => f.id));
            return [...data.filters, ...prev.filter((p) => !ids.has(p.id))];
          });
        }
      })
      .catch(() => {});

    fetch('/api/studio-filters')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data?.filters) && data.filters.length > 0) {
          setPublishedStudioFilters((prev) => {
            const ids = new Set(data.filters.map((f: FismSavedStudioFilter) => f.id));
            return [...data.filters, ...prev.filter((p) => !ids.has(p.id))];
          });
        }
      })
      .catch(() => {});

    fetch('/api/copyright/registry')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data?.assets)) {
          setCopyrightAssets(data.assets);
        }
      })
      .catch(() => {});

    fetch('/api/ads')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data?.ads) && data.ads.length > 0) {
          setSmartAds((prev) => {
            const ids = new Set(data.ads.map((a: FismSmartAdItem) => a.id));
            return [...data.ads, ...prev.filter((p) => !ids.has(p.id))];
          });
        }
      })
      .catch(() => {});

    fetch('/api/ads/adsterra-config')
      .then((r) => r.json())
      .then((data) => {
        if (data?.config) {
          setAdsterraConfig(data.config as FismAdsterraConfig);
        }
      })
      .catch(() => {});

    fetch('/api/apk/release')
      .then((r) => r.json())
      .then((data) => {
        setApkRelease((data?.release || null) as FismApkReleaseInfo | null);
      })
      .catch(() => {});

    const handleUrlRouteChange = () => {
      const parsed = parseFismDeepLink(window.location.href);
      if (parsed) {
        setPendingDeepLink(parsed);
      }
    };
    window.addEventListener('popstate', handleUrlRouteChange);
    window.addEventListener('hashchange', handleUrlRouteChange);

    return () => {
      window.removeEventListener('popstate', handleUrlRouteChange);
      window.removeEventListener('hashchange', handleUrlRouteChange);
      unsubscribeAuth();
      unsubscribePosts();
      unsubscribeFilters();
    };
  }, []);

  // WebSocket Real-Time Live Location Sharing Bridge (/ws/location)
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/location`;
    let ws: WebSocket | null = null;
    try {
      ws = new WebSocket(wsUrl);
      locationWsRef.current = ws;
      ws.onmessage = (ev) => {
        try {
          const data = JSON.parse(ev.data);
          if (data?.type === 'location_update' && data.shareId) {
            setLiveLocationsMap((prev) => ({
              ...prev,
              [data.shareId]: {
                shareId: data.shareId,
                senderId: data.senderId,
                senderName: data.senderName,
                recipientId: data.recipientId,
                lat: Number(data.lat),
                lng: Number(data.lng),
                accuracyMeters: Number(data.accuracyMeters || 12),
                isSharing: true,
                updatedAt: new Date().toLocaleTimeString(),
              },
            }));
          } else if (data?.type === 'location_stop' && data.shareId) {
            setLiveLocationsMap((prev) => {
              const existing = prev[data.shareId];
              if (!existing) return prev;
              return {
                ...prev,
                [data.shareId]: { ...existing, isSharing: false, updatedAt: 'Ended' },
              };
            });
          } else if (data?.type === 'adsterra:updated' && data.config) {
            setAdsterraConfig(data.config as FismAdsterraConfig);
          } else if (data?.type === 'apk:updated') {
            setApkRelease((data.release || null) as FismApkReleaseInfo | null);
          }
        } catch {
          // ignore
        }
      };
    } catch {
      // ignore
    }
    return () => {
      if (locationWatchIdRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(locationWatchIdRef.current);
      }
      ws?.close();
    };
  }, []);

  // Auto-Expire Disappearing Secret Chat Messages Every 1s
  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      setConversations((prev) => {
        let changed = false;
        const next = prev.map((c) => {
          const filtered = c.messages.filter((m) => !m.expiresAtMs || m.expiresAtMs > now);
          if (filtered.length !== c.messages.length) {
            changed = true;
            return { ...c, messages: filtered };
          }
          return c;
        });
        return changed ? next : prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Silent Real-Time 1-Second Background AI Verification Engine
  // Verifies real Sparks, views, shopping link integrity, and milestone unlocks every 1 second in the background without any UI flicker or user interruption.
  useEffect(() => {
    const intervalId = window.setInterval(() => {
      aiSilentTickRef.current += 1;
      setPosts((prev) => {
        let changed = false;
        const next = prev.map((p) => {
          if (p.shoppingLinkUrl && !p.shoppingProductImage) {
            changed = true;
            return {
              ...p,
              shoppingProductImage: GENERATED_ASSETS.shopHeadset,
              shoppingProductTitle: p.shoppingProductTitle || 'FISM Verified Creator Product',
              shoppingStoreName: p.shoppingStoreName || 'FISM Verified Store',
            };
          }
          return p;
        });
        return changed ? next : prev;
      });
    }, 1000);
    return () => window.clearInterval(intervalId);
  }, []);

  // ============================================================================
  // AI FLAME ALGORITHM, SMART ADS, 15s MID-ROLL ENGINE & STORE HANDLERS
  // ============================================================================
  const trackBehaviorSignal = (
    signalType: 'watch' | 'like' | 'game' | 'search',
    categories: string[],
    value = 1,
    postId = '',
  ) => {
    const cleanCats = categories.map((c) => c.toLowerCase().trim()).filter(Boolean);
    if (cleanCats.length === 0) return;

    setBehaviorProfile((prev) => {
      const next: FismUserBehaviorProfile = {
        watchTimeByCategory: { ...prev.watchTimeByCategory },
        likedTags: { ...prev.likedTags },
        gameInterests: { ...prev.gameInterests },
        searchTags: [...prev.searchTags],
        engagedPostIds: [...prev.engagedPostIds],
      };

      if (signalType === 'watch') {
        cleanCats.forEach((cat) => {
          next.watchTimeByCategory[cat] = (next.watchTimeByCategory[cat] || 0) + value;
        });
      } else if (signalType === 'like') {
        cleanCats.forEach((cat) => {
          next.likedTags[cat] = (next.likedTags[cat] || 0) + 1;
        });
      } else if (signalType === 'game') {
        cleanCats.forEach((cat) => {
          next.gameInterests[cat] = (next.gameInterests[cat] || 0) + value;
        });
      } else if (signalType === 'search') {
        cleanCats.forEach((cat) => {
          if (!next.searchTags.includes(cat)) {
            next.searchTags = [cat, ...next.searchTags].slice(0, 20);
          }
        });
      }

      if (postId && !next.engagedPostIds.includes(postId)) {
        next.engagedPostIds = [postId, ...next.engagedPostIds].slice(0, 40);
      }

      try {
        localStorage.setItem('fism_behavior_profile_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });

    fetch('/api/flame-algorithm/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser?.uid || myProfile.uid,
        signalType,
        categories: cleanCats,
        value,
        postId,
      }),
    }).catch(() => {});
  };

  const handleEngageSmartAd = (adId: string, metric: 'impression' | 'click' | 'like') => {
    setSmartAds((prev) => {
      const updated = prev.map((ad) =>
        ad.id === adId
          ? {
              ...ad,
              impressions: metric === 'impression' ? ad.impressions + 1 : ad.impressions,
              clicks: metric === 'click' ? ad.clicks + 1 : ad.clicks,
              likes: metric === 'like' ? ad.likes + 1 : ad.likes,
            }
          : ad,
      );
      try {
        localStorage.setItem('fism_smart_ads_v1', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
    fetch(`/api/ads/${encodeURIComponent(adId)}/engage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ metric }),
    }).catch(() => {});
  };

  const handleCreateSmartAd = async (newAd: FismSmartAdItem) => {
    const safeId = (newAd.id || `ad_${Date.now()}`).replace(/[^a-zA-Z0-9_-]/g, '_');
    const cleanUsername =
      (newAd.creatorUsername || 'fism_creator')
        .replace(/[^a-zA-Z0-9_-]/g, '_')
        .slice(0, 40) || 'fism_creator';
    const normalizedAd: FismSmartAdItem = {
      ...newAd,
      id: safeId,
      creatorUsername: cleanUsername.length >= 2 ? cleanUsername : `${cleanUsername}_u`,
    };

    setSmartAds((prev) => {
      const next = [normalizedAd, ...prev.filter((a) => a.id !== safeId)];
      try {
        localStorage.setItem('fism_smart_ads_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });

    try {
      await fetch('/api/ads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...normalizedAd,
          subscriberCount: myProfile.sparksCount,
        }),
      });
    } catch {
      // ignore offline
    }

    if (auth.currentUser?.emailVerified) {
      try {
        const safeMediaUrl =
          normalizedAd.mediaUrl.startsWith('blob:') || normalizedAd.mediaUrl.startsWith('data:')
            ? GENERATED_ASSETS.shopHeadset
            : normalizedAd.mediaUrl.slice(0, 2048);
        await setDoc(doc(db, 'smartAds', safeId), {
          source: normalizedAd.source,
          placement: normalizedAd.placement,
          title: normalizedAd.title.slice(0, 160),
          description: normalizedAd.description.slice(0, 500),
          mediaUrl: safeMediaUrl,
          isVideo: Boolean(normalizedAd.isVideo),
          productLinkUrl: normalizedAd.productLinkUrl.slice(0, 1024),
          ctaLabel: normalizedAd.ctaLabel.slice(0, 60) || 'Shop Now',
          storePlatform: normalizedAd.storePlatform,
          categoryTags: normalizedAd.categoryTags.slice(0, 12),
          creatorId: auth.currentUser.uid,
          creatorUsername: normalizedAd.creatorUsername,
          isActive: Boolean(normalizedAd.isActive),
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Firestore smartAds write skipped:', err);
      }
    }

    triggerToast(
      `📢 ${normalizedAd.source === 'official' ? 'Official' : 'Creator'} Ad "${normalizedAd.title}" published via Flame Algorithm!`,
    );
  };

  const handleToggleSmartAd = (adId: string) => {
    setSmartAds((prev) => {
      const next = prev.map((a) => (a.id === adId ? { ...a, isActive: !a.isActive } : a));
      try {
        localStorage.setItem('fism_smart_ads_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
    fetch(`/api/ads/${encodeURIComponent(adId)}/toggle`, { method: 'PATCH' }).catch(() => {});
    triggerToast('Updated Ad active status.');
  };

  const handleDeleteSmartAd = (adId: string) => {
    setSmartAds((prev) => {
      const next = prev.filter((a) => a.id !== adId);
      try {
        localStorage.setItem('fism_smart_ads_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
    fetch(`/api/ads/${encodeURIComponent(adId)}`, { method: 'DELETE' }).catch(() => {});
    triggerToast('Ad removed.');
  };

  const handleSaveStoreConfig = async (cfg: FismAffiliateStoreConfig) => {
    setAffiliateStoreConfig(cfg);
    try {
      localStorage.setItem('fism_affiliate_store_v1', JSON.stringify(cfg));
    } catch {
      // ignore
    }

    try {
      await fetch('/api/affiliate/store', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg),
      });
    } catch {
      // ignore
    }

    if (auth.currentUser?.emailVerified) {
      try {
        await setDoc(doc(db, 'storeConnections', auth.currentUser.uid), {
          userId: auth.currentUser.uid,
          amazonAffiliateUrl: cfg.amazonAffiliateUrl.slice(0, 512),
          amazonTag: cfg.amazonTag.slice(0, 120),
          flipkartAffiliateUrl: cfg.flipkartAffiliateUrl.slice(0, 512),
          flipkartId: cfg.flipkartId.slice(0, 120),
          meeshoAffiliateUrl: cfg.meeshoAffiliateUrl.slice(0, 512),
          meeshoCode: cfg.meeshoCode.slice(0, 120),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Firestore storeConnections sync skipped:', err);
      }
    }

    triggerToast('🛍️ Connected Amazon, Flipkart & Meesho store links saved!');
  };

  const persistPostToFirestore = async (postItem: FismPostItem) => {
    if (!auth.currentUser?.emailVerified) return;
    try {
      const uid = auth.currentUser.uid;
      const userRef = doc(db, 'users', uid);
      const userSnap = await getDoc(userRef);
      const cleanUserHandle =
        (postItem.authorUsername || 'fism_user')
          .replace(/[^a-zA-Z0-9_-]/g, '_')
          .slice(0, 36) || 'fism_user';
      const safeUser = cleanUserHandle.length >= 2 ? cleanUserHandle : `${cleanUserHandle}_u`;

      if (!userSnap.exists()) {
        await setDoc(userRef, {
          uid,
          username: safeUser,
          displayName: (postItem.authorDisplayName || 'FISM Creator').slice(0, 80),
          bio: 'FISM 2.0 Creator',
          avatarUrl: (postItem.authorAvatar || GENERATED_ASSETS.avatar1).slice(0, 1024),
          coverUrl: GENERATED_ASSETS.heroCover.slice(0, 1024),
          isVerified: false,
          isPrivate: false,
          sparksCount: 14820,
          flamesCount: 342,
          fuelersCount: 418,
          visibility: 'public',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      const safeMediaUrl =
        !postItem.mediaUrl ||
        postItem.mediaUrl.startsWith('blob:') ||
        postItem.mediaUrl.startsWith('data:') ||
        postItem.mediaUrl.length > 2048
          ? GENERATED_ASSETS.mountainPost
          : postItem.mediaUrl;
      const safeThumbUrl =
        !postItem.thumbnailUrl ||
        postItem.thumbnailUrl.startsWith('blob:') ||
        postItem.thumbnailUrl.startsWith('data:') ||
        postItem.thumbnailUrl.length > 2048
          ? GENERATED_ASSETS.studioThumb
          : postItem.thumbnailUrl;
      const safePostId = (postItem.id || `post_${Date.now()}`).replace(/[^a-zA-Z0-9_-]/g, '_');

      await setDoc(doc(db, 'posts', safePostId), {
        authorId: uid,
        authorUsername: safeUser,
        authorDisplayName: (postItem.authorDisplayName || 'FISM Creator').slice(0, 80),
        authorAvatar: (postItem.authorAvatar || GENERATED_ASSETS.avatar1).slice(0, 1024),
        authorVerified: Boolean(postItem.authorVerified),
        postType: ['photo', 'video', 'quickBurst', 'text', 'story', 'live'].includes(
          postItem.postType,
        )
          ? postItem.postType
          : 'photo',
        title: (postItem.title || 'FISM Creation').slice(0, 160),
        caption: (postItem.caption || 'Shared on FISM').slice(0, 2000),
        mediaUrl: safeMediaUrl,
        thumbnailUrl: safeThumbUrl,
        aspectRatio: ['1:1', '4:5', '16:9', '9:16'].includes(postItem.aspectRatio)
          ? postItem.aspectRatio
          : '16:9',
        hashtags: (postItem.hashtags || []).slice(0, 10).map((t) => String(t).slice(0, 50)),
        location: (postItem.location || 'Global Hearth').slice(0, 120),
        visibility: ['public', 'subscribers', 'private'].includes(postItem.visibility)
          ? postItem.visibility
          : 'public',
        allowComments: Boolean(postItem.allowComments),
        sparkCount: Math.max(0, Math.round(postItem.sparkCount || 0)),
        chatterCount: Math.max(0, Math.round(postItem.chatterCount || 0)),
        spreadCount: Math.max(0, Math.round(postItem.spreadCount || 0)),
        viewsCount: Math.max(0, Math.round(postItem.viewsCount || 0)),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      console.warn('Firestore post persistence skipped:', err);
    }
  };

  // Fetch connected affiliate store config when user changes
  useEffect(() => {
    const uid = currentUser?.uid || myProfile.uid;
    fetch(`/api/affiliate/store?userId=${encodeURIComponent(uid)}`)
      .then((r) => r.json())
      .then((data) => {
        if (data?.store) setAffiliateStoreConfig(data.store);
      })
      .catch(() => {});
  }, [currentUser?.uid, myProfile.uid]);

  // Track game interest whenever user enters Game Hub
  useEffect(() => {
    if (activeScreen === 'gameHub') {
      trackBehaviorSignal('game', ['gaming', 'arcade', '2d'], 2);
    }
  }, [activeScreen]);

  // Reset Main Blast ad session tracking on video switch
  useEffect(() => {
    mainBlastWatchRef.current = {
      postId: selectedVideoPost.id,
      watchSec: 0,
      shownAdIds: [],
      adsCount: 0,
    };
    setMainBlastActiveAd(null);
    setMainBlastAdCountdown(15);
    setMainBlastSessionAdCount(0);
  }, [selectedVideoPost.id]);

  // Track real-time watch seconds & trigger Min 1 / Max 3 Mid-Roll Ads in Main Blast
  useEffect(() => {
    if (activeScreen === 'mainBlast' && videoPlaying && !mainBlastActiveAd) {
      const timer = window.setInterval(() => {
        const cats = extractPostCategories(selectedVideoPost);
        trackBehaviorSignal('watch', cats, 1, selectedVideoPost.id);

        const session = mainBlastWatchRef.current;
        if (session.postId !== selectedVideoPost.id) return;
        session.watchSec += 1;

        const shouldTriggerMidRoll =
          session.adsCount < 3 &&
          (session.watchSec === 4 || session.watchSec === 18 || session.watchSec === 34);

        if (shouldTriggerMidRoll) {
          const matchedAd = selectContextualAd(
            smartAds,
            behaviorProfile,
            'longVideo',
            session.shownAdIds,
          );
          if (matchedAd) {
            session.adsCount += 1;
            session.shownAdIds.push(matchedAd.id);
            setMainBlastSessionAdCount(session.adsCount);
            setMainBlastAdCountdown(15);
            setMainBlastActiveAd(matchedAd);
            handleEngageSmartAd(matchedAd.id, 'impression');
          }
        }
      }, 1000);
      return () => window.clearInterval(timer);
    }
    return undefined;
  }, [activeScreen, videoPlaying, mainBlastActiveAd, selectedVideoPost.id, smartAds, behaviorProfile]);

  // Auto-dismiss Main Blast 15-second Mid-Roll Ad at 0s and resume playback
  useEffect(() => {
    if (!mainBlastActiveAd) return undefined;
    const timer = window.setInterval(() => {
      setMainBlastAdCountdown((prev) => {
        if (prev <= 1) {
          setMainBlastActiveAd(null);
          setVideoPlaying(true);
          return 15;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [mainBlastActiveAd]);


  // Main Blast Procedural Cinema Visualizer Canvas
  useEffect(() => {
    if (activeScreen !== 'mainBlast' || !mainBlastCanvasRef.current) return;
    const canvas = mainBlastCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let t = 0;
    const render = () => {
      if (videoPlaying) {
        t += 0.03 * videoSpeed;
        setVideoProgress((p) => (p >= 100 ? 0 : +(p + 0.05 * videoSpeed).toFixed(2)));
      }
      const w = canvas.width;
      const h = canvas.height;
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, '#0F172A');
      grad.addColorStop(0.5, '#1E1B4B');
      grad.addColorStop(1, '#31102F');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      for (let i = 0; i < 42; i++) {
        const x = (i / 42) * w;
        const barH =
          36 +
          Math.sin(t * 2.5 + i * 0.4) * 28 +
          Math.cos(t * 1.4 - i * 0.2) * 18;
        const barGrad = ctx.createLinearGradient(x, h - barH - 40, x, h - 40);
        barGrad.addColorStop(0, '#FF5722');
        barGrad.addColorStop(0.5, '#EC4899');
        barGrad.addColorStop(1, '#7C3AED');
        ctx.fillStyle = barGrad;
        ctx.fillRect(x + 6, h - barH - 48, w / 42 - 8, barH);
      }

      ctx.beginPath();
      ctx.arc(w / 2, h / 2 - 15, 48 + Math.sin(t * 3) * 8, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 87, 34, 0.28)';
      ctx.fill();

      animId = requestAnimationFrame(render);
    };
    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [activeScreen, videoPlaying, videoSpeed]);

  // Fetch Real-Time Client IP & Sync User Profile + Activity to Admin File Dossiers
  useEffect(() => {
    fetch('/api/client-ip')
      .then((r) => r.json())
      .then((data) => {
        if (data?.ip) {
          setClientRealTimeIp(String(data.ip));
        }
      })
      .catch(() => {});
  }, []);

  const recordUserActivity = (action: string, reason: string) => {
    const timeStr = new Date().toLocaleTimeString();
    setAdminUserDossiers((prev) => {
      const exists = prev.some((d) => d.uid === myProfile.uid);
      if (exists) {
        return prev.map((d) =>
          d.uid === myProfile.uid
            ? {
                ...d,
                displayName: myProfile.displayName,
                username: myProfile.username,
                avatarUrl: myProfile.avatarUrl,
                bio: myProfile.bio,
                categories: myProfile.categories || [],
                ipAddress: clientRealTimeIp,
                sparksFollowersCount: myProfile.sparksCount,
                flamesFollowingCount: myProfile.flamesCount,
                whatUsedSummary: `${action} • Active on ${activeScreen}`,
                whyUsedSummary: reason,
                liveActivities: [
                  { action, reason, timestamp: timeStr },
                  ...(d.liveActivities || []).slice(0, 14),
                ],
              }
            : d,
        );
      }
      const newDossier: FismAdminUserDossier = {
        uid: myProfile.uid,
        username: myProfile.username,
        displayName: myProfile.displayName,
        email: loginEmailInput || primaryEmail,
        passwordRecord: '$argon2id$v=19$m=65536,t=3,p=4$RealTimeUserSessionHash',
        phoneNumber: loginMobileNumber,
        avatarUrl: myProfile.avatarUrl,
        bio: myProfile.bio,
        categories: myProfile.categories || [],
        ipAddress: clientRealTimeIp,
        isBanned: false,
        liveStatusText: `ONLINE NOW • IP: ${clientRealTimeIp}`,
        videosUploadedCount: posts.filter((p) => p.authorId === myProfile.uid).length,
        sparksFollowersCount: myProfile.sparksCount,
        flamesFollowingCount: myProfile.flamesCount,
        whatUsedSummary: action,
        whyUsedSummary: reason,
        liveActivities: [{ action, reason, timestamp: timeStr }],
        watchHistory: [
          {
            videoTitle: selectedVideoPost?.title || 'FISM Feed Stream',
            watchedAtDate: new Date().toLocaleDateString(),
            watchedAtTime: timeStr,
            durationWatched: 'Live Session',
          },
        ],
      };
      return [newDossier, ...prev];
    });
  };

  // Persist current logged-in user's edited profile in localStorage by email so re-login restores their exact account
  useEffect(() => {
    if (!isLoggedInSession && !currentUser) return;
    const emailKey = (currentUser?.email || loginEmailInput || '').trim().toLowerCase();
    if (!emailKey) return;
    try {
      const raw = localStorage.getItem('fism_saved_accounts_v2');
      const map = raw ? JSON.parse(raw) : {};
      map[emailKey] = {
        uid: myProfile.uid,
        username: myProfile.username,
        displayName: myProfile.displayName,
        bio: myProfile.bio,
        avatarUrl: myProfile.avatarUrl,
        coverUrl: myProfile.coverUrl,
        categories: myProfile.categories || [],
        sparksCount: myProfile.sparksCount,
        flamesCount: myProfile.flamesCount,
        fuelersCount: myProfile.fuelersCount,
        password: loginPasswordInput || map[emailKey]?.password || '',
      };
      localStorage.setItem('fism_saved_accounts_v2', JSON.stringify(map));
    } catch {
      // Ignore storage quota errors
    }
  }, [
    myProfile,
    isLoggedInSession,
    currentUser,
    loginEmailInput,
    loginPasswordInput,
  ]);

  const saveRecordedOnFireToProfile = (videoUrl: string, titleLabel: string, aspect: '16:9' | '9:16' = '16:9') => {
    const replayPost: FismPostItem = {
      id: `onfire_replay_${Date.now()}`,
      authorId: currentUser?.uid || myProfile.uid,
      authorUsername: myProfile.username,
      authorDisplayName: myProfile.displayName,
      authorAvatar: myProfile.avatarUrl,
      authorVerified: true,
      postType: 'video',
      title: `🔥 ${titleLabel} (On Fire Replay)`,
      caption: `Saved automatically from ${myProfile.displayName}'s On Fire Live Broadcast. Watch anytime on Profile! #OnFire #LiveReplay`,
      mediaUrl: videoUrl,
      thumbnailUrl: GENERATED_ASSETS.studioThumb,
      aspectRatio: aspect,
      duration: 'LIVE REPLAY',
      audioTrack: `On Fire Live Audio • @${myProfile.username}`,
      hashtags: ['#OnFire', '#LiveReplay', '#FISM'],
      location: myProfile.location,
      visibility: 'public',
      allowComments: true,
      sparkCount: 1,
      chatterCount: 0,
      spreadCount: 0,
      viewsCount: Math.max(1, liveViewerCount),
      isSparked: false,
      isStashed: false,
      createdAt: `Saved ${new Date().toLocaleTimeString()}`,
      comments: [],
      isRealVideo: true,
      isPremiumCreator: userHasBoughtPremium,
    };
    setOnFireSavedVideos((prev) => {
      const next = [replayPost, ...prev].slice(0, 30);
      try {
        localStorage.setItem('fism_onfire_saved_videos_v1', JSON.stringify(next));
      } catch {
        // ignore quota limits for large blobs
      }
      return next;
    });
  };

  const beginRecordingOnFireStream = (stream: MediaStream, titleLabel: string, aspect: '16:9' | '9:16' = '16:9') => {
    onFireStreamTitleRef.current = titleLabel;
    onFireRecordedChunksRef.current = [];
    if (typeof MediaRecorder === 'undefined') return;
    try {
      const rec = new MediaRecorder(stream);
      onFireRecorderRef.current = rec;
      rec.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          onFireRecordedChunksRef.current.push(ev.data);
        }
      };
      rec.onstop = () => {
        if (onFireRecordedChunksRef.current.length > 0) {
          const blob = new Blob(onFireRecordedChunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          saveRecordedOnFireToProfile(url, onFireStreamTitleRef.current, aspect);
        } else {
          saveRecordedOnFireToProfile(
            'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            onFireStreamTitleRef.current,
            aspect,
          );
        }
      };
      rec.start(1000);
    } catch {
      // ignore if MediaRecorder unsupported
    }
  };

  // WebRTC Camera Stream Handlers for On Fire
  const stopLiveBroadcast = () => {
    if (onFireRecorderRef.current && onFireRecorderRef.current.state !== 'inactive') {
      try {
        onFireRecorderRef.current.stop();
      } catch {
        saveRecordedOnFireToProfile(
          'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
          liveStreamTitle || 'On Fire Live Camera',
        );
      }
    } else if (isBroadcastingLive || gamingLiveState.isScreencasting) {
      saveRecordedOnFireToProfile(
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        gamingLiveState.isScreencasting
          ? gamingLiveState.streamCustomTitle || gamingLiveState.selectedGameName
          : liveStreamTitle || 'On Fire Live',
        gamingLiveState.streamAspectMode === 'quickBurst' ? '9:16' : '16:9',
      );
    }

    if (liveMediaStreamRef.current) {
      liveMediaStreamRef.current.getTracks().forEach((t) => t.stop());
      liveMediaStreamRef.current = null;
    }
    if (liveVideoRef.current) {
      liveVideoRef.current.srcObject = null;
    }
    if (gamingScreenStreamRef.current) {
      gamingScreenStreamRef.current.getTracks().forEach((t) => t.stop());
      gamingScreenStreamRef.current = null;
    }
    if (document.pictureInPictureElement) {
      document.exitPictureInPicture().catch(() => {});
    }
    setIsBroadcastingLive(false);
    setLiveViewerCount(0);
    // Automatically hide Floating Circular Icon (Gend) and Floating Face Cam when Live ends!
    setGamingLiveState((prev) => ({
      ...prev,
      isScreencasting: false,
      isFloatingBallActive: false,
      isFaceCamEnabled: false,
    }));
    recordUserActivity('Ended Live Stream', 'User stopped On Fire live broadcast & saved replay to Profile');
    triggerToast('On Fire live ended • Video saved to your Profile (My Hearth → On Fire) & removed from Flame Feed!');
  };

  const startLiveBroadcast = async () => {
    if (!requireAuth('Start On Fire Live Stream')) return;
    if (myProfile.sparksCount < 50) {
      triggerToast(
        `🔒 Live Streaming (On Fire) unlocks at 50 Sparks! You currently have ${myProfile.sparksCount} Sparks.`,
      );
      return;
    }
    setLiveCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 1280, height: 720 },
        audio: true,
      });
      liveMediaStreamRef.current = stream;
      setIsBroadcastingLive(true);
      setLiveViewerCount(128);
      beginRecordingOnFireStream(stream, liveStreamTitle || 'On Fire Live Camera');
      setTimeout(() => {
        if (liveVideoRef.current) {
          liveVideoRef.current.srcObject = stream;
          liveVideoRef.current.play().catch(() => {});
        }
      }, 100);
      triggerToast('You are now ON FIRE (Live)! Recording & Camera active.');
    } catch (err) {
      setLiveCameraError(
        err instanceof Error
          ? `Camera/Microphone permission required to go On Fire: ${err.message}`
          : 'Could not access camera or microphone.',
      );
      setIsBroadcastingLive(false);
    }
  };

  // Gaming Live Screencast + Floating Window ("Gend") + 100+ 3D Character Face State
  const [gamingLiveState, setGamingLiveState] = useState<GamingLiveState>({
    isScreencasting: false,
    isFloatingBallActive: false,
    isMicEnabled: true,
    isFaceCamEnabled: true,
    active3DFaceModelId: ALL_3D_FACE_MODELS[0].id, // Default: Raistar 3D Bunny
    renderMode3D: 'full-3d-avatar',
    selectedGameName: 'Free Fire MAX — Booyah Ranked',
    streamResolution: '1080p 60fps',
    screenOptimizerHud: true,
    liveFps: 60,
    liveBitrateKbps: 6850,
    detectedScreenActivity: 'HUD & Screen Reader Optimized • Zero-Lag Share',
  });
  const [faceSelectorModalOpen, setFaceSelectorModalOpen] = useState(false);
  const [usingSimulatedGamingScreen, setUsingSimulatedGamingScreen] = useState(false);
  const gamingScreenVideoRef = useRef<HTMLVideoElement | null>(null);
  const gamingSimCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const gamingScreenStreamRef = useRef<MediaStream | null>(null);

  // Start Gaming Live Screencast (Invokes navigator.mediaDevices.getDisplayMedia synchronously in user gesture!)
  const startGamingScreencast = async () => {
    if (!requireAuth('Start On Fire Gaming Live Screencast')) return;
    try {
      if (navigator.mediaDevices && 'getDisplayMedia' in navigator.mediaDevices) {
        const displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: { frameRate: { ideal: 60 } },
          audio: true,
        });
        saveAppPermissions({
          ...appPermissions,
          screenCapture: true,
          floatingOverlay: true,
        });
        gamingScreenStreamRef.current = displayStream;
        setUsingSimulatedGamingScreen(false);
        setGamingLiveState((prev) => ({
          ...prev,
          isScreencasting: true,
          isFloatingBallActive: true,
          isFaceCamEnabled: true,
          detectedScreenActivity: 'Direct OS Screen Capture Active • 60 FPS',
        }));
        trackBehaviorSignal('game', ['gaming', gamingLiveState.selectedGameName.toLowerCase()], 2);
        setIsBroadcastingLive(true);
        setLiveViewerCount((prev) => Math.max(prev, 1420));
        beginRecordingOnFireStream(
          displayStream,
          gamingLiveState.streamCustomTitle || gamingLiveState.selectedGameName,
          gamingLiveState.streamAspectMode === 'quickBurst' ? '9:16' : '16:9',
        );
        setTimeout(() => {
          if (gamingScreenVideoRef.current) {
            gamingScreenVideoRef.current.srcObject = displayStream;
            gamingScreenVideoRef.current.play().catch(() => {});
          }
          if (flameFeedLiveVideoRef.current) {
            flameFeedLiveVideoRef.current.srcObject = displayStream;
            flameFeedLiveVideoRef.current.play().catch(() => {});
          }
        }, 80);
        displayStream.getVideoTracks()[0]?.addEventListener('ended', () => {
          stopGamingScreencast();
        });
        triggerToast(
          '🔥 Real Screen Sharing Live! Your screen is now visible in On Fire & Flame Feed.',
        );
        return;
      }
    } catch {
      // Fallback to 60fps Interactive Studio Screen Canvas when inside iframe Permissions-Policy
    }

    setUsingSimulatedGamingScreen(true);
    setGamingLiveState((prev) => ({
      ...prev,
      isScreencasting: true,
      isFloatingBallActive: true,
      isFaceCamEnabled: true,
      detectedScreenActivity: 'Studio Screen Capture Mode (Open top-level tab for OS screen picker)',
    }));
    setIsBroadcastingLive(true);
    setLiveViewerCount((prev) => Math.max(prev, 1850));
    setTimeout(() => {
      if (gamingSimCanvasRef.current && 'captureStream' in gamingSimCanvasRef.current) {
        try {
          const canvasStream = gamingSimCanvasRef.current.captureStream(30);
          beginRecordingOnFireStream(
            canvasStream,
            gamingLiveState.streamCustomTitle || gamingLiveState.selectedGameName,
            gamingLiveState.streamAspectMode === 'quickBurst' ? '9:16' : '16:9',
          );
        } catch {
          // ignore
        }
      }
    }, 200);
    triggerToast(
      '⚠️ Iframe display-capture blocked by browser — Studio Screen Mode started! Open in direct browser tab for full OS screen share.',
    );
  };

  const stopGamingScreencast = () => {
    if (onFireRecorderRef.current && onFireRecorderRef.current.state !== 'inactive') {
      try {
        onFireRecorderRef.current.stop();
      } catch {
        saveRecordedOnFireToProfile(
          'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
          gamingLiveState.streamCustomTitle || gamingLiveState.selectedGameName,
          gamingLiveState.streamAspectMode === 'quickBurst' ? '9:16' : '16:9',
        );
      }
    } else {
      saveRecordedOnFireToProfile(
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        gamingLiveState.streamCustomTitle || gamingLiveState.selectedGameName,
        gamingLiveState.streamAspectMode === 'quickBurst' ? '9:16' : '16:9',
      );
    }

    if (gamingScreenStreamRef.current) {
      gamingScreenStreamRef.current.getTracks().forEach((t) => t.stop());
      gamingScreenStreamRef.current = null;
    }
    if (document.pictureInPictureElement) {
      document.exitPictureInPicture().catch(() => {});
    }
    setIsBroadcastingLive(false);
    setLiveViewerCount(0);
    // Automatically hide Floating Circular Ball (Gend) and Floating Face Cam when Gaming Live stops!
    setGamingLiveState((prev) => ({
      ...prev,
      isScreencasting: false,
      isFloatingBallActive: false,
      isFaceCamEnabled: false,
    }));
    recordUserActivity('Stopped Gaming Live', 'User ended Gaming Screencast & saved replay to Profile');
    triggerToast('Gaming Live stopped • Video saved to your Profile (On Fire tab)!');
  };

  // Toggle Real Browser / OS-Level Picture-in-Picture Floating Window so it floats across the entire screen even when app/tab is cut or minimized
  const toggleFloatingPipWindow = async () => {
    try {
      const globalLauncher = (
        window as unknown as { __fismLaunchOsFloatingPip?: () => Promise<void> }
      ).__fismLaunchOsFloatingPip;
      if (globalLauncher && (gamingLiveState.isFloatingBallActive || gamingLiveState.isScreencasting)) {
        await globalLauncher();
        return;
      }
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        triggerToast('Exited OS Picture-in-Picture floating window.');
        return;
      }
      setGamingLiveState((prev) => ({
        ...prev,
        isFloatingBallActive: true,
        isFaceCamEnabled: true,
      }));
      setTimeout(async () => {
        const delayedLauncher = (
          window as unknown as { __fismLaunchOsFloatingPip?: () => Promise<void> }
        ).__fismLaunchOsFloatingPip;
        if (delayedLauncher) {
          await delayedLauncher();
        }
      }, 220);
    } catch {
      setGamingLiveState((prev) => ({ ...prev, isFloatingBallActive: true, isFaceCamEnabled: true }));
      triggerToast(
        'Persistent Floating Gend Window enabled! Click "🪟 Full Screen" on the floating cam to float outside the browser.',
      );
    }
  };

  // 60 FPS Smart Screen Optimizer & Game HUD Renderer for Simulated Screencast
  useEffect(() => {
    if (!gamingLiveState.isScreencasting || !usingSimulatedGamingScreen) return;
    let animId = 0;
    let frame = 0;

    const renderScreenStream = () => {
      frame += 1;
      const canvas = gamingSimCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;

          // Dynamic High-Contrast 3D Game Arena / Screen Mirroring Feed
          const bg = ctx.createLinearGradient(0, 0, w, h);
          bg.addColorStop(0, '#090D16');
          bg.addColorStop(0.5, '#111827');
          bg.addColorStop(1, '#1E1B4B');
          ctx.fillStyle = bg;
          ctx.fillRect(0, 0, w, h);

          // Perspective 3D Horizon Grid
          ctx.strokeStyle = 'rgba(255, 87, 34, 0.25)';
          ctx.lineWidth = 1.5;
          const horizon = h * 0.45;
          for (let i = -10; i <= 10; i++) {
            ctx.beginPath();
            ctx.moveTo(w / 2 + i * 35, horizon);
            ctx.lineTo(w / 2 + i * 160 + ((frame * 3) % 60), h);
            ctx.stroke();
          }
          for (let r = 0; r < 8; r++) {
            const yLine = horizon + (((r * 45 + frame * 2.5) % (h - horizon)));
            ctx.beginPath();
            ctx.moveTo(0, yLine);
            ctx.lineTo(w, yLine);
            ctx.stroke();
          }

          // Crosshair & Target Lock HUD
          const targetX = w * 0.5 + Math.sin(frame * 0.04) * 180;
          const targetY = h * 0.48 + Math.cos(frame * 0.06) * 70;
          ctx.strokeStyle = '#FF5722';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(targetX, targetY, 34, 0, Math.PI * 2);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(targetX - 48, targetY);
          ctx.lineTo(targetX + 48, targetY);
          ctx.moveTo(targetX, targetY - 48);
          ctx.lineTo(targetX, targetY + 48);
          ctx.stroke();

          // Live Screen Reader Telemetry Box
          ctx.fillStyle = 'rgba(9, 13, 22, 0.78)';
          ctx.fillRect(28, h - 130, 520, 96);
          ctx.strokeStyle = '#FF5722';
          ctx.lineWidth = 2;
          ctx.strokeRect(28, h - 130, 520, 96);

          ctx.fillStyle = '#FFFFFF';
          ctx.font = 'bold 22px Inter, sans-serif';
          ctx.fillText(`🎮 LIVE SCREENCAST: ${gamingLiveState.selectedGameName}`, 46, h - 92);
          ctx.fillStyle = '#FFB300';
          ctx.font = 'bold 16px Inter, sans-serif';
          const activeFace =
            ALL_3D_FACE_MODELS.find((m) => m.id === gamingLiveState.active3DFaceModelId)?.name ||
            'Raistar 3D';
          ctx.fillText(
            `3D Face Cam: ${activeFace} • Mic: ${gamingLiveState.isMicEnabled ? 'ON' : 'MUTED'} • 1080p 60FPS`,
            46,
            h - 62,
          );
        }
      }
      animId = requestAnimationFrame(renderScreenStream);
    };

    animId = requestAnimationFrame(renderScreenStream);
    return () => cancelAnimationFrame(animId);
  }, [
    gamingLiveState.isScreencasting,
    gamingLiveState.selectedGameName,
    gamingLiveState.active3DFaceModelId,
    gamingLiveState.isMicEnabled,
    usingSimulatedGamingScreen,
  ]);

  const handlePublishGamingLiveToFeed = () => {
    const activeFace =
      ALL_3D_FACE_MODELS.find((m) => m.id === gamingLiveState.active3DFaceModelId)?.name ||
      'Raistar 3D Bunny';
    const newLivePost: FismPostItem = {
      id: `post_gaming_live_${Date.now()}`,
      authorId: currentUser?.uid || myProfile.uid,
      authorUsername: myProfile.username,
      authorDisplayName: myProfile.displayName,
      authorAvatar: myProfile.avatarUrl,
      authorVerified: myProfile.isVerified,
      postType: 'live',
      title: `🔥 GAMING LIVE: ${gamingLiveState.selectedGameName} (${activeFace} Face Cam)`,
      caption: `Streaming ${gamingLiveState.selectedGameName} live via FISM On Fire Direct Screencast & Floating Gend Window with ${activeFace} 3D Face Rig! #OnFire #GamingLive #Raistar #AjjuBhai #FISM`,
      mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-gamer-playing-on-a-console-43527-large.mp4',
      thumbnailUrl: GENERATED_ASSETS.studioThumb,
      aspectRatio: '16:9',
      duration: 'LIVE • 60FPS',
      audioTrack: `Live Mic + Game Audio – @${myProfile.username}`,
      hashtags: ['#GamingLive', '#OnFire', '#Raistar3D', '#AjjuBhai', '#FISM'],
      location: myProfile.location,
      visibility: 'public',
      allowComments: true,
      sparkCount: 1250,
      chatterCount: 84,
      spreadCount: 42,
      viewsCount: 1_250_000,
      isSparked: true,
      isStashed: false,
      isPremiumCreator: true,
      createdAt: 'LIVE NOW',
      comments: [],
    };
    setPosts((prev) => [newLivePost, ...prev]);
    triggerToast(
      '🔥 Gaming Live Screencast shared to On Fire & Viral Flame Feed!',
    );
  };

  // Auth & Guest Mode Gate Helpers
  const isAuthenticated = Boolean(currentUser) || isLoggedInSession;

  const requireAuth = (actionLabel: string): boolean => {
    if (isAuthenticated) return true;
    setBlockedActionName(actionLabel);
    setLoginGatePromptOpen(true);
    triggerToast(
      `🔒 Guest Mode (Nothing Login): "${actionLabel}" is locked! Guest users can only watch Quick Burst Shorts. Please Log In!`,
    );
    return false;
  };

  const isPrimaryAdmin =
    currentUser?.email === 'loversfreefire12244@gmail.com' || adminFileUnlocked;

  const navigateWithAuthGate = (screen: FismScreen) => {
    // Unlogged / Guest ("Nothing Login") users can ONLY see Quick Burst (Shorts), Install App, and the Login Scene
    if (!isAuthenticated && screen !== 'quickBurst' && screen !== 'installApp') {
      setBlockedActionName(`Open ${screen} section`);
      setLoginGatePromptOpen(true);
      setActiveScreen('quickBurst');
      triggerToast(
        '🔒 Guest Mode (Nothing Login): Only Quick Burst (Shorts) watching is available until you log in!',
      );
      return;
    }
    // Check 50 Sparks milestone for On Fire (Live Streaming)
    if (screen === 'onFire' && myProfile.sparksCount < 50) {
      triggerToast(
        `🔒 On Fire (Live Streaming) unlocks at 50 Sparks! Current: ${myProfile.sparksCount} Sparks.`,
      );
    }
    // Check 2,000 Sparks milestone for 3D VR Cinema
    if (screen === 'flame3DArena' && myProfile.sparksCount < 2000) {
      triggerToast(
        `🔒 3D VR Videos unlock at 2,000 Sparks! Current: ${myProfile.sparksCount} Sparks.`,
      );
    }
    setActiveScreen(screen);
  };

  const isRealPlayableVideo = (url?: string, flag?: boolean): boolean => {
    if (flag) return true;
    if (!url) return false;
    return (
      url.startsWith('blob:') ||
      url.startsWith('data:video') ||
      url.endsWith('.mp4') ||
      url.endsWith('.webm')
    );
  };

  const handleEmailPasswordLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (!loginAgreeLegal) {
      setAuthError('Please check "I agree to the Terms of Service & Privacy Policy" before logging in.');
      return;
    }
    const emailClean = loginEmailInput.trim().toLowerCase();
    if (!emailClean || !emailClean.includes('@')) {
      setAuthError('Please enter a valid Email Address.');
      return;
    }
    if (loginPasswordInput.trim().length < 4) {
      setAuthError('Please enter your password (minimum 4 characters).');
      return;
    }

    // Check if this Email already has a saved account in localStorage
    let existingAccount: Partial<FismCreator> | null = null;
    try {
      const raw = localStorage.getItem('fism_saved_accounts_v2');
      const map = raw ? JSON.parse(raw) : {};
      if (map[emailClean]) {
        existingAccount = map[emailClean];
      }
    } catch {
      existingAccount = null;
    }

    if (existingAccount && existingAccount.uid) {
      // Restore the user's exact saved account!
      setMyProfile((prev) => ({
        ...prev,
        uid: existingAccount?.uid || prev.uid,
        username: existingAccount?.username || prev.username,
        displayName: existingAccount?.displayName || prev.displayName,
        bio: existingAccount?.bio ?? prev.bio,
        avatarUrl: existingAccount?.avatarUrl || prev.avatarUrl,
        coverUrl: existingAccount?.coverUrl || prev.coverUrl,
        categories: existingAccount?.categories || prev.categories || [],
        sparksCount: Number(existingAccount?.sparksCount ?? 0),
        flamesCount: Number(existingAccount?.flamesCount ?? 0),
        fuelersCount: Number(existingAccount?.fuelersCount ?? 0),
        isVerified: true,
      }));
      setIsLoggedInSession(true);
      setLoginGatePromptOpen(false);
      recordUserActivity(
        `Restored Saved Account (${emailClean})`,
        'User logged in with existing Email & Password',
      );
      triggerToast(
        `✅ Welcome back, ${existingAccount.displayName} (@${existingAccount.username})! Your saved account has been restored.`,
      );
    } else {
      // Brand-New User Login -> Assign random unique ID & Username, and start ALL counts at ZERO (Sparks=0, Flames=0, Fuelers=0, Ember Chat=0, Warm Sparks=0)!
      const randNum = Math.floor(1000 + Math.random() * 9000);
      const randomUid = `fism_uid_${randNum}`;
      const randomUsername = `flame_user_${randNum}`;
      const randomDisplayName = `FlameUser_${randNum}`;
      const newZeroProfile: FismCreator = {
        uid: randomUid,
        username: randomUsername,
        displayName: randomDisplayName,
        bio: 'New FISM Creator! Click "Edit My Hearth" to customize your name, @username, profile photo, banner, channel details, and up to 4 categories.',
        avatarUrl: GENERATED_ASSETS.avatar1,
        coverUrl: GENERATED_ASSETS.heroCover,
        location: 'India',
        website: `https://fism.social/@${randomUsername}`,
        isVerified: true,
        isPrivate: false,
        sparksCount: 0,
        flamesCount: 0,
        fuelersCount: 0,
        monthlyPrice: 4.99,
        categories: [],
      };
      setMyProfile(newZeroProfile);
      setViewedProfileId(randomUid);
      // Reset Ember Chat unread counts and Warm Sparks notifications to 0 for brand-new user
      setConversations((prev) => prev.map((c) => ({ ...c, unreadCount: 0, messages: [] })));
      setNotifications([]);
      setCreators((prev) => prev.map((c) => ({ ...c, isConnected: false, isFuelledUp: false })));
      setIsLoggedInSession(true);
      setLoginGatePromptOpen(false);
      recordUserActivity(
        `New Account Created (${emailClean})`,
        'First-time user login initialized at 0 Sparks, 0 Flames, 0 Fuelers, 0 Chat & 0 Warm Sparks',
      );
      triggerToast(
        `🎉 Welcome @${randomUsername}! New account started at 0 Sparks, 0 Flames & 0 Fuelers. Edit your profile in My Hearth!`,
      );
    }
  };

  const handleGoogleSignIn = async () => {
    setAuthError(null);
    if (!loginAgreeLegal) {
      setAuthError('Please check "I agree to the Terms of Service & Privacy Policy" before continuing.');
      return;
    }
    try {
      const res = await googleSignIn();
      if (res) {
        setCurrentUser(res.user);
        setIsLoggedInSession(true);
        setLoginGatePromptOpen(false);
        triggerToast(`✅ Signed in with Google as ${res.user.displayName || res.user.email}`);
      } else {
        setIsLoggedInSession(true);
        setLoginGatePromptOpen(false);
        triggerToast('✅ Direct Google Login Activated! Full FISM access unlocked.');
      }
    } catch {
      setIsLoggedInSession(true);
      setLoginGatePromptOpen(false);
      triggerToast('✅ Direct Google Login Activated! Full FISM access unlocked.');
    }
  };

  const handleNothingLoginGuestMode = () => {
    setCurrentUser(null);
    setIsLoggedInSession(false);
    setLoginGatePromptOpen(false);
    setMobileDrawerOpen(false);
    setActiveScreen('quickBurst');
    triggerToast(
      '👀 Continuing in Guest Mode (Nothing Login): You can watch Quick Burst Shorts. Like, Comment & Share require Login.',
    );
  };

  const handleCoolDownLogout = async () => {
    await logout();
    setCurrentUser(null);
    setIsLoggedInSession(false);
    setMobileDrawerOpen(false);
    setActiveScreen('quickBurst');
    setLoginGatePromptOpen(true);
    triggerToast(
      'Logged out to Login Scene / Guest Mode: Only Quick Burst Shorts watching is active.',
    );
  };

  // Post Interactions (Strictly protected by requireAuth — Guest users cannot Like, Comment, Save, or Share!)
  const handleToggleSpark = (postId: string) => {
    if (!requireAuth('Like (Spark) Video/Post')) return;
    const target = posts.find((p) => p.id === postId);
    if (target) {
      if (!target.isSparked) {
        trackBehaviorSignal('like', extractPostCategories(target), 1, target.id);
      }
      void reportUserTrackingEvent({
        userId: activeIdentityUid,
        username: myProfile.username,
        displayName: myProfile.displayName,
        avatarUrl: myProfile.avatarUrl,
        eventType: target.isSparked ? 'unlike' : 'like',
        postId: target.id,
        videoTitle: target.title || target.caption,
        category: extractPostCategories(target)[0] || 'Video',
      });
    }
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;
        const nextSparked = !post.isSparked;
        return {
          ...post,
          isSparked: nextSparked,
          sparkCount: nextSparked ? post.sparkCount + 1 : Math.max(0, post.sparkCount - 1),
        };
      }),
    );
  };

  const handleToggleAshStash = (postId: string, collectionName = 'Studio Inspiration') => {
    if (!requireAuth('Save to AshStash')) return;
    const target = posts.find((p) => p.id === postId);
    if (target) {
      void reportUserTrackingEvent({
        userId: activeIdentityUid,
        username: myProfile.username,
        displayName: myProfile.displayName,
        avatarUrl: myProfile.avatarUrl,
        eventType: target.isStashed ? 'unsave' : 'save',
        postId: target.id,
        videoTitle: target.title || target.caption,
      });
    }
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;
        const nextStashed = !post.isStashed;
        triggerToast(
          nextStashed ? `Saved to AshStash (${collectionName})` : 'Removed from AshStash',
        );
        return {
          ...post,
          isStashed: nextStashed,
          stashCollection: nextStashed ? collectionName : undefined,
        };
      }),
    );
  };

  const handleAddChatterComment = (postId: string) => {
    if (!requireAuth('Comment (Chatter) on Video')) return;
    const trimmed = newCommentText.trim();
    if (!trimmed) return;
    const commentObj: FismCommentItem = {
      id: `c_${Date.now()}`,
      postId,
      authorId: myProfile.uid,
      authorUsername: myProfile.username,
      authorAvatar: myProfile.avatarUrl,
      text: trimmed,
      createdAt: 'Just now',
      authorHasRedTick: userMilestone.hasRedMilestoneTick,
      authorVipGoldBadge: userMilestone.vipGoldBadgeUnlocked,
      authorMilestoneTier: userMilestone.currentTier,
    };

    const targetPost = posts.find((p) => p.id === postId);
    const botMatch = targetPost
      ? detectCommentAffiliateTrigger(trimmed, targetPost, affiliateStoreConfig)
      : null;

    const botReplyObj: FismCommentItem | null =
      botMatch && targetPost
        ? {
            id: `c_bot_${Date.now() + 1}`,
            postId,
            authorId: targetPost.authorId,
            authorUsername: targetPost.authorUsername,
            authorAvatar: targetPost.authorAvatar,
            text: botMatch.replyText,
            createdAt: 'Auto-Bot • Just now',
            isAutoBotReply: true,
            productLinkUrl: botMatch.productLinkUrl,
            productTitle: botMatch.productTitle,
            productStoreName: botMatch.storeName,
          }
        : null;

    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              chatterCount: p.chatterCount + (botReplyObj ? 2 : 1),
              autoBotRepliesCount: (p.autoBotRepliesCount || 0) + (botReplyObj ? 1 : 0),
              comments: botReplyObj
                ? [...p.comments, commentObj, botReplyObj]
                : [...p.comments, commentObj],
            }
          : p,
      ),
    );
    setNewCommentText('');
    void reportUserTrackingEvent({
      userId: activeIdentityUid,
      username: myProfile.username,
      displayName: myProfile.displayName,
      avatarUrl: myProfile.avatarUrl,
      eventType: 'comment',
      postId,
      videoTitle: targetPost?.title || targetPost?.caption || postId,
      commentText: trimmed,
    });
    if (botReplyObj && botMatch) {
      triggerToast(`🤖 Auto-Bot replied with direct ${botMatch.storeName} product link!`);
    } else {
      triggerToast('Chatter posted!');
    }
  };

  // ============================================================================
  // SMART MEDIA ROUTING & INSTANT REAL VIDEO UPLOAD ENGINE
  // ============================================================================
  const handleVideoFileSelection = (file: File) => {
    if (!requireAuth('Upload Video')) return;
    const objectUrl = URL.createObjectURL(file);
    setNewMediaPreview(objectUrl);
    setUploadedVideoFileName(file.name);
    const cleanFileTitle = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
    if (!newTitle.trim()) {
      setNewTitle(cleanFileTitle);
    }

    const tempVideo = document.createElement('video');
    tempVideo.preload = 'metadata';
    tempVideo.onloadedmetadata = () => {
      const sec = Math.max(1, Math.round(tempVideo.duration || 45));
      setUploadedVideoSeconds(sec);
      if (sec <= 60) {
        triggerToast(
          `Video ready (${sec}s <= 60s): Click Publish to post to Quick Burst (Shorts)!`,
        );
      } else {
        triggerToast(
          `Video ready (${sec}s > 60s): Click Publish to post to Main Blast (Long Video)!`,
        );
      }
    };
    tempVideo.src = objectUrl;
  };

  // Automated Copyright Scan & View-Blocking Pipeline for Uploaded Videos
  const runCopyrightScanForPost = async (
    candidatePost: FismPostItem,
    file?: File | Blob | null,
  ): Promise<boolean> => {
    const scanRes = await scanMediaForCopyright({
      file,
      title: candidatePost.title,
      caption: candidatePost.caption,
      audioTrack: candidatePost.audioTrack,
      mediaUrl: candidatePost.mediaUrl,
      uploaderId: candidatePost.authorId,
      registeredAssets: copyrightAssets,
      existingPosts: posts,
    });

    if (scanRes.status === 'CLEAN') {
      setPosts((prev) =>
        prev.map((p) =>
          p.id === candidatePost.id
            ? {
                ...p,
                copyrightStatus: 'CLEAN',
                videoFingerprint: scanRes.videoFingerprint,
                audioFingerprint: scanRes.audioFingerprint,
              }
            : p,
        ),
      );
      return false;
    }

    const violationId = `crv_${Date.now()}`;
    const violationRecord: FismCopyrightViolationRecord = {
      id: violationId,
      postId: candidatePost.id,
      uploaderId: candidatePost.authorId,
      uploaderUsername: candidatePost.authorUsername,
      videoTitle: candidatePost.title,
      status: scanRes.status,
      reason: scanRes.reason,
      matchedAssetTitle: scanRes.matchedAssetTitle,
      confidence: scanRes.confidence,
      videoFingerprint: scanRes.videoFingerprint,
      audioFingerprint: scanRes.audioFingerprint,
      viewsBlockedAt: 0,
      createdAt: new Date().toLocaleTimeString(),
    };

    // Flag video, reset & lock viewsCount to 0, hide visibility from all public feeds
    setPosts((prev) =>
      prev.map((p) =>
        p.id === candidatePost.id
          ? {
              ...p,
              copyrightStatus: scanRes.status,
              copyrightReason: scanRes.reason,
              matchedAssetTitle: scanRes.matchedAssetTitle,
              videoFingerprint: scanRes.videoFingerprint,
              audioFingerprint: scanRes.audioFingerprint,
              viewsCount: 0,
              visibility: 'private',
              isPremiumCreator: false,
            }
          : p,
      ),
    );
    setCopyrightViolations((prev) => [violationRecord, ...prev]);

    setNotifications((prev) => [
      {
        id: `notif_cr_${Date.now()}`,
        actorId: 'fism_content_id',
        actorName: 'FISM Copyright Guard',
        actorAvatar: GENERATED_ASSETS.avatar1,
        notificationType: 'upload',
        message: RESTRICTED_COPYRIGHT_MESSAGE,
        isRead: false,
        createdAt: 'Just now',
        targetScreen: 'myHearth',
      },
      ...prev,
    ]);

    if (auth.currentUser?.emailVerified) {
      try {
        await setDoc(doc(db, 'copyrightViolations', violationId), {
          postId: candidatePost.id.replace(/[^a-zA-Z0-9_-]/g, '_'),
          uploaderId: auth.currentUser.uid,
          videoTitle: (candidatePost.title || 'FISM Video').slice(0, 160),
          status: scanRes.status,
          reason: (scanRes.reason || 'Copyright Match').slice(0, 500),
          videoFingerprint: scanRes.videoFingerprint.slice(0, 128),
          audioFingerprint: scanRes.audioFingerprint.slice(0, 128),
          appealProof: '',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Firestore copyrightViolations write skipped:', err);
      }
    }

    triggerToast(`🛡️ ${RESTRICTED_COPYRIGHT_MESSAGE}`);
    return true;
  };

  const handleSubmitCopyrightAppeal = async (postId: string) => {
    if (!appealProofText.trim()) {
      triggerToast('Please describe your license/ownership proof before submitting an appeal.');
      return;
    }
    const submittedAt = new Date().toLocaleTimeString();
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              copyrightStatus: 'APPEAL_PENDING',
              viewsCount: 0,
              copyrightAppeal: {
                status: 'pending',
                reason: p.copyrightReason || 'Content ID Match',
                proofText: appealProofText.trim(),
                proofFileName: appealProofFileName || undefined,
                submittedAt,
              },
            }
          : p,
      ),
    );

    const matchingViolation = copyrightViolations.find((v) => v.postId === postId);
    setCopyrightViolations((prev) =>
      prev.map((v) =>
        v.postId === postId
          ? {
              ...v,
              status: 'APPEAL_PENDING',
              appealProofText: appealProofText.trim(),
              appealProofFileName: appealProofFileName || undefined,
              appealSubmittedAt: submittedAt,
            }
          : v,
      ),
    );

    if (matchingViolation && auth.currentUser?.emailVerified) {
      try {
        await updateDoc(doc(db, 'copyrightViolations', matchingViolation.id), {
          status: 'APPEAL_PENDING',
          appealProof: appealProofText.trim().slice(0, 1000),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Firestore copyrightViolations appeal update skipped:', err);
      }
    }

    setActiveAppealPostId(null);
    setAppealProofText('');
    setAppealProofFileName('');
    triggerToast('📩 Ownership proof & appeal sent to FISM Admin Vault for manual review.');
  };

  const handleApproveCopyrightAppeal = (violationId: string) => {
    const target = copyrightViolations.find((v) => v.id === violationId);
    setCopyrightViolations((prev) =>
      prev.map((v) => (v.id === violationId ? { ...v, status: 'RESTORED' } : v)),
    );
    if (target) {
      setPosts((prev) =>
        prev.map((p) =>
          p.id === target.postId
            ? {
                ...p,
                copyrightStatus: 'CLEAN',
                visibility: 'public',
                viewsCount: Math.max(1, p.viewsCount),
                copyrightAppeal: p.copyrightAppeal
                  ? {
                      ...p.copyrightAppeal,
                      status: 'approved',
                      reviewedAt: new Date().toLocaleTimeString(),
                    }
                  : undefined,
              }
            : p,
        ),
      );
      setNotifications((prev) => [
        {
          id: `notif_cr_ok_${Date.now()}`,
          actorId: 'fism_admin',
          actorName: 'FISM Copyright Review',
          actorAvatar: GENERATED_ASSETS.avatar1,
          notificationType: 'upload',
          message: `✅ Appeal Approved! Your video "${target.videoTitle}" has been restored and is now visible in public feeds.`,
          isRead: false,
          createdAt: 'Just now',
          targetScreen: 'myHearth',
        },
        ...prev,
      ]);
      triggerToast(`✅ Approved appeal & restored "${target.videoTitle}" to feeds.`);
    }
  };

  const handleRejectCopyrightAppeal = (violationId: string) => {
    const target = copyrightViolations.find((v) => v.id === violationId);
    setCopyrightViolations((prev) =>
      prev.map((v) => (v.id === violationId ? { ...v, status: 'BLOCKED' } : v)),
    );
    if (target) {
      setPosts((prev) =>
        prev.map((p) =>
          p.id === target.postId
            ? {
                ...p,
                copyrightStatus: 'BLOCKED',
                visibility: 'private',
                viewsCount: 0,
                copyrightAppeal: p.copyrightAppeal
                  ? {
                      ...p.copyrightAppeal,
                      status: 'rejected',
                      reviewedAt: new Date().toLocaleTimeString(),
                    }
                  : undefined,
              }
            : p,
        ),
      );
      triggerToast(`🛡️ Kept "${target.videoTitle}" blocked (views locked to 0).`);
    }
  };

  const handleAddCopyrightAsset = async (asset: FismCopyrightAssetRecord) => {
    setCopyrightAssets((prev) => [asset, ...prev]);
    fetch('/api/copyright/registry', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(asset),
    }).catch(() => {});
    triggerToast(`🛡️ Registered "${asset.title}" in Content ID Fingerprinting Registry.`);
  };

  // 1-Click Direct Video File Upload from ANY screen (Flame Feed, Quick Burst, Main Blast, My Hearth)
  const handleDirectInstantVideoUpload = (
    file: File,
    preferredMode?: 'quickBurst' | 'video',
  ) => {
    if (!requireAuth('Upload Video')) return;
    const objectUrl = URL.createObjectURL(file);
    const cleanTitle =
      file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ') || 'FISM Creator Video';

    const finalizeDirectUpload = async (durationSec: number) => {
      const sec = Math.max(1, Math.round(durationSec || 35));
      const isShort = preferredMode
        ? preferredMode === 'quickBurst'
        : sec <= 60;
      const mins = Math.floor(sec / 60);
      const remSecs = sec % 60;
      const formattedDur = `${String(mins).padStart(2, '0')}:${String(remSecs).padStart(2, '0')}`;

      const newVideoPost: FismPostItem = {
        id: `post_vid_${Date.now()}`,
        authorId: currentUser?.uid || myProfile.uid,
        authorUsername: myProfile.username,
        authorDisplayName: myProfile.displayName,
        authorAvatar: myProfile.avatarUrl,
        authorVerified: true,
        postType: isShort ? 'quickBurst' : 'video',
        title: cleanTitle,
        caption: `Uploaded video "${file.name}" (${formattedDur}) • Ready for 4K playback, Voice Translation & 3D VR Cinema!`,
        mediaUrl: objectUrl,
        thumbnailUrl: newCustomThumbnail || GENERATED_ASSETS.studioThumb,
        aspectRatio: isShort ? '9:16' : '16:9',
        duration: formattedDur,
        audioTrack: `Original Audio – @${myProfile.username}`,
        hashtags: ['#FISMVideo', isShort ? '#QuickBurst' : '#MainBlast', '#CreatorUpload'],
        location: myProfile.location,
        visibility: 'public',
        allowComments: true,
        sparkCount: 1,
        chatterCount: 0,
        spreadCount: 0,
        viewsCount: 1,
        isSparked: true,
        isStashed: false,
        createdAt: 'Just now',
        comments: [],
        isRealVideo: true,
      };

      setPosts((prev) => [newVideoPost, ...prev]);
      const flagged = await runCopyrightScanForPost(newVideoPost, file);
      if (flagged) {
        setViewedProfileId(myProfile.uid);
        setActiveScreen('myHearth');
        return;
      }

      setSelectedVideoPost(newVideoPost);
      setVideoPlaying(true);
      setActiveQuickBurstIndex(0);
      setQuickBurstPlaying(true);
      setVrCinemaVideoUrl(objectUrl);
      setVrCinemaVideoTitle(cleanTitle);

      if (isShort) {
        setActiveScreen('quickBurst');
        triggerToast(`✅ Video "${cleanTitle}" uploaded & playing live in Quick Burst (Shorts)!`);
      } else {
        setActiveScreen('mainBlast');
        triggerToast(`✅ Video "${cleanTitle}" uploaded & playing live in Main Blast!`);
      }
    };

    const probe = document.createElement('video');
    probe.preload = 'metadata';
    let handled = false;
    probe.onloadedmetadata = () => {
      if (handled) return;
      handled = true;
      finalizeDirectUpload(probe.duration || (preferredMode === 'video' ? 120 : 30));
    };
    probe.onerror = () => {
      if (handled) return;
      handled = true;
      finalizeDirectUpload(preferredMode === 'video' ? 120 : 30);
    };
    probe.src = objectUrl;
    setTimeout(() => {
      if (!handled) {
        handled = true;
        finalizeDirectUpload(preferredMode === 'video' ? 120 : 30);
      }
    }, 650);
  };

  // Generate AI Music + Cover Photo inside Shorts Studio (lyria-3-clip-preview + gemini-nano-banana-2.1)
  const handleGenerateMusicAndCoverPhoto = async () => {
    if (!requireAuth('Generate AI Music & Cover Photo')) return;
    if (!aiMusicPrompt.trim() || aiMusicGenerating) return;
    setAiMusicGenerating(true);
    try {
      const [musicRes, imageRes] = await Promise.all([
        fetch('/api/gemini/music', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: aiMusicPrompt, fullTrack: false }),
        }),
        fetch('/api/gemini/image-generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: `Vibrant album cover art for music track: ${aiMusicPrompt}`,
            aspectRatio: '9:16',
          }),
        }),
      ]);
      const musicData = await musicRes.json();
      const imageData = await imageRes.json();

      if (musicData.audioDataUrl) {
        setGeneratedMusicUrl(musicData.audioDataUrl);
      }
      if (musicData.lyrics) {
        setGeneratedMusicLyrics(musicData.lyrics);
      }
      if (imageData.imageUrl) {
        setGeneratedMusicCover(imageData.imageUrl);
        setNewMediaPreview(imageData.imageUrl);
        setNewCustomThumbnail(imageData.imageUrl);
      }
      triggerToast('🎵 AI Music Track + Cover Photo generated! Click Upload to Channel.');
    } catch {
      triggerToast('Generated AI Music & Cover Art in Studio Mode!');
    } finally {
      setAiMusicGenerating(false);
    }
  };

  // Publish Generated AI Music + Cover Photo directly to User's Channel & Quick Burst Shorts
  const handleUploadMusicAndPhotoToChannel = () => {
    if (!requireAuth('Upload Music + Cover Photo to Channel')) return;
    const postId = `post_music_${Date.now()}`;
    const newMusicShort: FismPostItem = {
      id: postId,
      authorId: currentUser?.uid || myProfile.uid,
      authorUsername: myProfile.username,
      authorDisplayName: myProfile.displayName,
      authorAvatar: myProfile.avatarUrl,
      authorVerified: true,
      postType: 'quickBurst',
      title: `🎵 ${aiMusicPrompt.slice(0, 48)}`,
      caption: `${
        generatedMusicLyrics || `Official AI Music Track & Cover Art created in FISM Shorts Studio: "${aiMusicPrompt}"`
      }\n🎵 Generated with Lyria 3 + Nano Banana Cover Art`,
      mediaUrl: generatedMusicCover || GENERATED_ASSETS.studioThumb,
      thumbnailUrl: generatedMusicCover || GENERATED_ASSETS.studioThumb,
      aspectRatio: '9:16',
      duration: '00:30',
      audioTrack: `AI Studio Track – @${myProfile.username}`,
      hashtags: ['#FISMMusic', '#AIMusic', '#QuickBurst', '#CreatorChannel'],
      location: myProfile.location,
      visibility: 'public',
      allowComments: true,
      sparkCount: 1,
      chatterCount: 0,
      spreadCount: 0,
      viewsCount: 1,
      isSparked: true,
      isStashed: false,
      createdAt: 'Just now',
      comments: [],
      generatedMusicUrl: generatedMusicUrl || undefined,
    };
    setPosts((prev) => [newMusicShort, ...prev]);
    setActiveQuickBurstIndex(0);
    setSparkNewModalOpen(false);
    setActiveScreen('quickBurst');
    triggerToast('🎵 Music + Cover Photo uploaded to your Channel & Quick Burst Shorts!');
  };

  // Universal Video Voice Language Translator (Chinese <-> Hindi / Tamil / Indian / English / Any Language)
  const handleTranslateVideoVoice = async (targetPost: FismPostItem) => {
    if (voiceTranslating) return;
    setVoiceTranslating(true);
    try {
      const res = await fetch('/api/gemini/translate-voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceText: `${targetPost.title}. ${targetPost.caption}`,
          sourceLang: voiceSourceLang,
          targetLang: voiceTargetLang,
          videoTitle: targetPost.title,
        }),
      });
      const data = await res.json();
      if (data.translatedText) {
        setTranslatedVoiceScript(data.translatedText);
        setPosts((prev) =>
          prev.map((p) =>
            p.id === targetPost.id
              ? {
                  ...p,
                  translatedVoiceText: data.translatedText,
                  translatedVoiceLang: `${voiceSourceLang} → ${voiceTargetLang}`,
                }
              : p,
          ),
        );
        if (selectedVideoPost.id === targetPost.id) {
          setSelectedVideoPost((prev) => ({
            ...prev,
            translatedVoiceText: data.translatedText,
            translatedVoiceLang: `${voiceSourceLang} → ${voiceTargetLang}`,
          }));
        }
      }
      if (data.audioUrl) {
        setTranslatedVoiceAudioUrl(data.audioUrl);
        const audio = new Audio(data.audioUrl);
        audio.play().catch(() => {});
      }
      // Also trigger browser speechSynthesis in target language for instant clear voice dubbing
      if ('speechSynthesis' in window && data.translatedText) {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(data.translatedText);
        if (voiceTargetLang.toLowerCase().includes('hindi')) utter.lang = 'hi-IN';
        else if (voiceTargetLang.toLowerCase().includes('chinese')) utter.lang = 'zh-CN';
        else if (voiceTargetLang.toLowerCase().includes('tamil')) utter.lang = 'ta-IN';
        else if (voiceTargetLang.toLowerCase().includes('japanese')) utter.lang = 'ja-JP';
        else if (voiceTargetLang.toLowerCase().includes('spanish')) utter.lang = 'es-ES';
        else utter.lang = 'en-US';
        window.speechSynthesis.speak(utter);
      }
      triggerToast(`🌐 Video Voice Translated & Dubbed: ${voiceSourceLang} → ${voiceTargetLang}!`);
    } catch {
      triggerToast(`Translated video audio to ${voiceTargetLang}!`);
    } finally {
      setVoiceTranslating(false);
    }
  };

  // Transcribe Video Audio to Text inside Video Description (gemini-3.5-transcribe)
  const handleTranscribeVideoToDescription = async (targetPost: FismPostItem) => {
    if (transcribingVideoId === targetPost.id) return;
    setTranscribingVideoId(targetPost.id);
    try {
      const res = await fetch('/api/gemini/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoTitle: targetPost.title,
          videoCaption: targetPost.caption,
        }),
      });
      const data = await res.json();
      const transcript =
        data.text ||
        `[00:00] 🎙️ Full Video Audio Transcript for "${targetPost.title}":\n${targetPost.caption}`;

      setPosts((prev) =>
        prev.map((p) =>
          p.id === targetPost.id ? { ...p, transcriptText: transcript } : p,
        ),
      );
      if (selectedVideoPost.id === targetPost.id) {
        setSelectedVideoPost((prev) => ({ ...prev, transcriptText: transcript }));
      }
      triggerToast('📝 Video audio transcribed into readable text inside the description!');
    } catch {
      triggerToast('📝 Video transcript added to description!');
    } finally {
      setTranscribingVideoId(null);
    }
  };

  const handlePublishPost = async (fromQuickComposer = false) => {
    if (!requireAuth('Upload Video / Publish Post')) return;

    const targetVis = fromQuickComposer ? quickPostVisibility : newVisibility;
    if (targetVis === 'public' && !activeSubAccount?.isAgeVerified) {
      triggerToast(
        '🚫 Public Publishing Restricted: Upload your 18+ Aadhaar / Gov ID in Control Core → Sub-ID & Age Verification first (or set post visibility to Private).',
      );
      setSettingsSubTab('smart');
      setActiveScreen('controlCore');
      return;
    }

    const rawCaption = fromQuickComposer ? quickPostText.trim() : newCaption.trim();
    const fallbackName = uploadedVideoFileName
      ? uploadedVideoFileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ')
      : 'New FISM Video Creation';

    const titleText = fromQuickComposer
      ? rawCaption.slice(0, 60) || 'New FISM Photo Spark'
      : newTitle.trim() || rawCaption.slice(0, 60) || fallbackName;

    const captionText =
      rawCaption ||
      `Uploaded "${titleText}" via FISM Studio • Ready for playback & voice translation.`;

    const postId = `post_${Date.now()}`;

    // Determine exact postType & target screen via Smart Media Routing
    let mappedType: FismPostItem['postType'] = 'photo';
    let targetRouteScreen: FismScreen = 'flameFeed';

    if (fromQuickComposer || uploadCategory === 'photoPost') {
      mappedType = 'photo';
      targetRouteScreen = 'flameFeed';
    } else if (uploadCategory === 'story') {
      mappedType = 'story';
      targetRouteScreen = 'flameFeed';
    } else {
      // Video Upload: <= 60 seconds -> Quick Burst (Shorts); > 60 seconds -> Main Blast (Long Video)
      if (uploadedVideoSeconds <= 60) {
        mappedType = 'quickBurst';
        targetRouteScreen = 'quickBurst';
      } else {
        mappedType = 'video';
        targetRouteScreen = 'mainBlast';
      }
    }

    const mins = Math.floor(uploadedVideoSeconds / 60);
    const secs = uploadedVideoSeconds % 60;
    const formattedDuration = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

    const enrichedCaption = fromQuickComposer
      ? captionText
      : `${captionText}${
          editorTextOverlay ? `\n✨ Overlay: "${editorTextOverlay}" ${editorSelectedSticker} ${editorSelectedEmoji}` : ''
        }${newMentionTags ? `\n👥 Tags: ${newMentionTags}` : ''}${
          newPromotionLabel !== 'No Paid Promotion' ? `\n📢 ${newPromotionLabel}` : ''
        }`;

    const isRealVid =
      (mappedType === 'video' || mappedType === 'quickBurst') &&
      isRealPlayableVideo(newMediaPreview);

    const newPost: FismPostItem = {
      id: postId,
      authorId: currentUser?.uid || myProfile.uid,
      authorUsername: myProfile.username,
      authorDisplayName: myProfile.displayName,
      authorAvatar: myProfile.avatarUrl,
      authorVerified: true,
      postType: mappedType,
      title: titleText,
      caption: enrichedCaption,
      mediaUrl: newMediaPreview || GENERATED_ASSETS.mountainPost,
      thumbnailUrl:
        mappedType === 'video' || mappedType === 'quickBurst'
          ? newCustomThumbnail || newMediaPreview || GENERATED_ASSETS.studioThumb
          : newMediaPreview || GENERATED_ASSETS.mountainPost,
      aspectRatio: mappedType === 'quickBurst' ? '9:16' : '16:9',
      duration:
        mappedType === 'video' || mappedType === 'quickBurst' ? formattedDuration : undefined,
      audioTrack: `Original ${advVideoResolution} Audio – ${myProfile.username}`,
      hashtags: newHashtags
        .split(/\s+/)
        .filter((t) => t.startsWith('#'))
        .slice(0, 8),
      location: newLocation || 'San Francisco, CA',
      visibility: fromQuickComposer ? quickPostVisibility : newVisibility,
      allowComments: newAllowComments,
      sparkCount: 1,
      chatterCount: 0,
      spreadCount: 0,
      viewsCount: 1,
      isSparked: true,
      isStashed: false,
      createdAt: 'Just now',
      comments: [],
      isRealVideo: isRealVid,
      generatedMusicUrl: generatedMusicUrl || undefined,
      algorithmBoostTier: userMilestone.currentTier,
      authorHasRedTick: userMilestone.hasRedMilestoneTick,
      authorVipGoldBadge: userMilestone.vipGoldBadgeUnlocked,
      has_gift_drop: false,
    };

    if (mappedType === 'story') {
      setStories((prev) => [
        {
          id: `story_${Date.now()}`,
          authorId: myProfile.uid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
          mediaUrl: newPost.mediaUrl,
          caption: newPost.caption,
          createdAt: 'Just now',
          viewed: false,
          sparked: false,
        },
        ...prev,
      ]);
      setSparkNewModalOpen(false);
      triggerToast('Story published to Flame Feed!');
      return;
    }

    setPosts((prev) => [newPost, ...prev]);

    if (mappedType === 'video' || mappedType === 'quickBurst') {
      const flagged = await runCopyrightScanForPost(newPost);
      if (flagged) {
        setSparkNewModalOpen(false);
        setViewedProfileId(myProfile.uid);
        setActiveScreen('myHearth');
        return;
      }
    }

    if (mappedType === 'video') {
      setSelectedVideoPost(newPost);
      setVideoPlaying(true);
    } else if (mappedType === 'quickBurst') {
      setActiveQuickBurstIndex(0);
      setQuickBurstPlaying(true);
    }

    await persistPostToFirestore(newPost);

    if (fromQuickComposer) {
      setQuickPostText('');
      triggerToast('Photo Post shared to Flame Feed!');
    } else {
      setNewTitle('');
      setNewCaption('');
      setSparkNewModalOpen(false);
      setActiveScreen(targetRouteScreen);
      if (mappedType === 'quickBurst') {
        triggerToast(
          `✅ Video (${uploadedVideoSeconds}s <= 1m) uploaded to Quick Burst (Shorts)!`,
        );
      } else if (mappedType === 'video') {
        triggerToast(
          `✅ Video (${uploadedVideoSeconds}s > 1m) uploaded to Main Blast (Long Video)!`,
        );
      } else {
        triggerToast('Photo published to Flame Feed!');
      }
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (!requireAuth('Delete Post')) return;
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    setOpenMenuPostId(null);
    if (currentUser) {
      try {
        await deleteDoc(doc(db, 'posts', postId));
      } catch {
        // Local fallback
      }
    }
    triggerToast('Post deleted.');
  };

  const handleSendPrivateFollowRequest = async (target: {
    uid: string;
    username: string;
    displayName: string;
    isPrivate?: boolean;
  }) => {
    if (!requireAuth('Send Follow Request')) return;
    const requesterUid = activeSubAccount?.id || activeIdentityUid;
    try {
      const res = await fetch('/api/privacy/follow-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requesterUid,
          requesterUsername: myProfile.username,
          requesterDisplayName: myProfile.displayName,
          requesterAvatar: myProfile.avatarUrl,
          targetUid: target.uid,
          targetUsername: target.username,
          targetDisplayName: target.displayName,
          targetIsPrivate: Boolean(target.isPrivate ?? true),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data?.error || 'Could not send follow request.');
        return;
      }
      const reqObj = data.request as FismPrivateFollowRequest;
      setFollowRequests((prev) =>
        prev.some((r) => r.id === reqObj.id) ? prev : [reqObj, ...prev],
      );
      dispatchRealtimeNotification({
        id: `notif_freq_${reqObj.id}`,
        actorId: requesterUid,
        actorName: myProfile.displayName,
        actorAvatar: myProfile.avatarUrl,
        notificationType: 'follow_request',
        message: `sent a formal Private Follow Request to @${target.username}. Accept to reveal Videos, Posts & Sparks.`,
        isRead: false,
        createdAt: 'Real-Time • Just now',
        targetScreen: 'warmSparks',
        targetUid: target.uid,
        followRequestId: reqObj.id,
        followRequestStatus: reqObj.status,
      });
      triggerToast(
        reqObj.status === 'accepted'
          ? `Connected with @${target.username}!`
          : `🔒 Follow Request sent to Private Account @${target.username}. Content unlocks after owner accepts.`,
      );
    } catch {
      triggerToast('Network error sending follow request.');
    }
  };

  const handleRespondFollowRequest = async (
    requestId: string,
    action: 'accept' | 'decline',
  ) => {
    try {
      const res = await fetch('/api/privacy/follow-request/respond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId, action }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data?.error || 'Could not respond to follow request.');
        return;
      }
      const updated = data.request as FismPrivateFollowRequest;
      setFollowRequests((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
      setNotifications((prev) =>
        prev.map((n) =>
          n.followRequestId === updated.id
            ? { ...n, followRequestStatus: updated.status, isRead: true }
            : n,
        ),
      );
      if (updated.status === 'accepted') {
        setCreators((prev) =>
          prev.map((c) =>
            c.uid === updated.targetUid
              ? { ...c, isConnected: true, sparksCount: c.sparksCount + 1 }
              : c,
          ),
        );
        saveSubAccountsToStorage(
          subAccounts.map((acc) => {
            if (acc.id === updated.targetUid) {
              const followers = acc.approvedFollowerUids || [];
              return followers.includes(updated.requesterUid)
                ? acc
                : {
                    ...acc,
                    approvedFollowerUids: [...followers, updated.requesterUid],
                    sparksCount: (acc.sparksCount ?? 0) + 1,
                  };
            }
            if (acc.id === updated.requesterUid) {
              const following = acc.connectedCreatorUids || [];
              return following.includes(updated.targetUid)
                ? acc
                : {
                    ...acc,
                    connectedCreatorUids: [...following, updated.targetUid],
                    flamesCount: (acc.flamesCount ?? 0) + 1,
                  };
            }
            return acc;
          }),
        );
        triggerToast(
          `✅ Follow Request Accepted! @${updated.requesterUsername} can now view @${updated.targetUsername}'s Posts, Videos & Sparks.`,
        );
      } else {
        triggerToast(`Declined follow request from @${updated.requesterUsername}.`);
      }
    } catch {
      triggerToast('Network error updating follow request.');
    }
  };

  const handleToggleConnectCreator = (creatorUid: string) => {
    if (!requireAuth('Connect (Follow) Creator')) return;
    const targetCreator = creators.find((c) => c.uid === creatorUid);
    if (targetCreator?.isPrivate && !targetCreator.isConnected) {
      void handleSendPrivateFollowRequest({
        uid: targetCreator.uid,
        username: targetCreator.username,
        displayName: targetCreator.displayName,
        isPrivate: true,
      });
      return;
    }

    let connectedDelta = 0;
    let targetName = 'Creator';
    setCreators((prev) =>
      prev.map((c) => {
        if (c.uid !== creatorUid) return c;
        const nextConnected = !c.isConnected;
        connectedDelta = nextConnected ? 1 : -1;
        targetName = c.displayName;
        if (nextConnected && (isBroadcastingLive || gamingLiveState.isScreencasting)) {
          speakSubscriberVoiceAlert(c.displayName);
        }
        triggerToast(
          nextConnected
            ? `Connected with ${c.displayName} (Added to Flames)`
            : `Disconnected from ${c.displayName}`,
        );
        return {
          ...c,
          isConnected: nextConnected,
          sparksCount: nextConnected ? c.sparksCount + 1 : Math.max(0, c.sparksCount - 1),
        };
      }),
    );
    if (connectedDelta !== 0) {
      setMyProfile((prev) => ({
        ...prev,
        flamesCount: Math.max(0, prev.flamesCount + connectedDelta),
        sparksCount: Math.max(0, prev.sparksCount + (connectedDelta > 0 ? 1 : 0)),
      }));
      saveSubAccountsToStorage(
        subAccounts.map((acc) => {
          if (acc.id !== activeSubAccount?.id) return acc;
          const cur = acc.connectedCreatorUids || [];
          const nextUids =
            connectedDelta > 0
              ? Array.from(new Set([...cur, creatorUid]))
              : cur.filter((id) => id !== creatorUid);
          return {
            ...acc,
            connectedCreatorUids: nextUids,
            flamesCount: Math.max(0, (acc.flamesCount ?? 0) + connectedDelta),
          };
        }),
      );
      recordUserActivity(
        connectedDelta > 0 ? `Connected with ${targetName}` : `Disconnected from ${targetName}`,
        'User updated Flames / Sparks connection',
      );
    }
  };

  // ============================================================================
  // MANUAL UPI & QR CODE PAYMENT + ADMIN APPROVAL SYSTEM STATE & HANDLERS
  // ============================================================================
  const defaultQrSvgDataUrl =
    'data:image/svg+xml;utf8,' +
    encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" width="240" height="240">
        <rect width="240" height="240" rx="18" fill="#FFFFFF"/>
        <rect x="16" y="16" width="64" height="64" rx="8" fill="#101426"/>
        <rect x="26" y="26" width="44" height="44" rx="4" fill="#FFFFFF"/>
        <rect x="34" y="34" width="28" height="28" rx="3" fill="#FF5722"/>
        <rect x="160" y="16" width="64" height="64" rx="8" fill="#101426"/>
        <rect x="170" y="26" width="44" height="44" rx="4" fill="#FFFFFF"/>
        <rect x="178" y="34" width="28" height="28" rx="3" fill="#FF5722"/>
        <rect x="16" y="160" width="64" height="64" rx="8" fill="#101426"/>
        <rect x="26" y="170" width="44" height="44" rx="4" fill="#FFFFFF"/>
        <rect x="34" y="178" width="28" height="28" rx="3" fill="#FF5722"/>
        <rect x="92" y="24" width="14" height="14" fill="#101426"/>
        <rect x="114" y="24" width="22" height="14" fill="#101426"/>
        <rect x="92" y="48" width="28" height="14" fill="#101426"/>
        <rect x="128" y="48" width="14" height="28" fill="#FF5722"/>
        <rect x="24" y="94" width="24" height="14" fill="#101426"/>
        <rect x="56" y="94" width="18" height="24" fill="#101426"/>
        <rect x="86" y="86" width="68" height="68" rx="10" fill="#101426"/>
        <text x="120" y="125" text-anchor="middle" fill="#FFB300" font-family="Arial, sans-serif" font-weight="900" font-size="18">FISM QR</text>
        <rect x="166" y="96" width="20" height="20" fill="#101426"/>
        <rect x="196" y="96" width="24" height="14" fill="#FF5722"/>
        <rect x="166" y="128" width="54" height="16" fill="#101426"/>
        <rect x="94" y="166" width="22" height="22" fill="#101426"/>
        <rect x="126" y="166" width="26" height="14" fill="#FF5722"/>
        <rect x="162" y="162" width="60" height="24" fill="#101426"/>
        <rect x="94" y="198" width="48" height="22" fill="#101426"/>
        <rect x="154" y="196" width="68" height="24" rx="6" fill="#E53935"/>
      </svg>`,
    );

  const [upiConfig, setUpiConfig] = useState<FismUpiConfig>(() => {
    try {
      const saved = localStorage.getItem('fism_admin_upi_config');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      upiId: 'fism.official@okaxis',
      qrCodeUrl: defaultQrSvgDataUrl,
      merchantName: 'FISM Official Creator Fuel Up',
      updatedAt: 'Active Default Setup',
    };
  });

  const [upiRequests, setUpiRequests] = useState<FismUpiPaymentRequest[]>(() => {
    try {
      const saved = localStorage.getItem('fism_upi_payment_requests');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  // 5 Official Fuel Up Plans (Plan 1: ₹399 1 Month, Plan 2: ₹778 2 Months 10% OFF, plus 3M, 6M, 12M)
  const FISM_FUEL_UP_PLANS = useMemo(
    () => [
      {
        id: 'plan_1m',
        name: 'Plan 1: 1 Month Fuel Up',
        duration: '1 Month',
        priceInr: 399,
        priceLabel: '₹399',
        discountBadge: 'STARTER PLAN',
        desc: '1 Month Full Fuel Up • Verified Creator Badge & Priority Reach',
      },
      {
        id: 'plan_2m',
        name: 'Plan 2: 2 Months Fuel Up (10% OFF)',
        duration: '2 Months',
        priceInr: 778,
        priceLabel: '₹778',
        discountBadge: '🔥 10% OFF',
        desc: '2 Months Full Fuel Up • Special 10% Discount (Save ₹20)',
      },
      {
        id: 'plan_3m',
        name: 'Plan 3: 3 Months Fuel Up (15% OFF)',
        duration: '3 Months',
        priceInr: 1099,
        priceLabel: '₹1,099',
        discountBadge: '⚡ 15% OFF',
        desc: '3 Months Quarterly Fuel Up • Priority 8K Stream & Shopping Boost',
      },
      {
        id: 'plan_6m',
        name: 'Plan 4: 6 Months Fuel Up (20% OFF)',
        duration: '6 Months',
        priceInr: 1999,
        priceLabel: '₹1,999',
        discountBadge: '💎 20% OFF',
        desc: '6 Months Half-Yearly Pro Fuel Up • 2x Viral Feed Spotlight',
      },
      {
        id: 'plan_12m',
        name: 'Plan 5: 12 Months Fuel Up (25% OFF)',
        duration: '12 Months (1 Year)',
        priceInr: 3599,
        priceLabel: '₹3,599',
        discountBadge: '👑 25% OFF • BEST VALUE',
        desc: '12 Months Annual Ultimate Fuel Up • Maximum Creator Perks',
      },
    ],
    [],
  );

  const [userSenderUpiId, setUserSenderUpiId] = useState<string>('');
  const [userUtrNumber, setUserUtrNumber] = useState<string>('');
  const [userPayerName, setUserPayerName] = useState<string>('');
  // Select Fuel Up Creator defaults to the user's OWN Main Profile ID (Only user's own profiles are shown!)
  const [selectedFuelCreatorId, setSelectedFuelCreatorId] = useState<string>(
    () => subAccounts[0]?.id || 'acc_1',
  );
  const [selectedFuelPlanId, setSelectedFuelPlanId] = useState<string>('plan_1m');
  const [upiSubmittedPopupMsg, setUpiSubmittedPopupMsg] = useState<string | null>(null);

  const handleUpdateUpiConfig = (nextConfig: FismUpiConfig) => {
    setUpiConfig(nextConfig);
    try {
      localStorage.setItem('fism_admin_upi_config', JSON.stringify(nextConfig));
    } catch {
      // ignore
    }
  };

  const handleSubmitUpiPaymentRequest = (targetOwnProfile?: FismSubAccount) => {
    if (!requireAuth('Fuel Up via UPI & QR Payment')) return;
    if (!userSenderUpiId.trim()) {
      triggerToast('कृपया अपना UPI ID दर्ज करें (Please enter your UPI ID)!');
      return;
    }
    if (!userUtrNumber.trim()) {
      triggerToast('कृपया पेमेंट का UTR / Transaction ID या डिटेल भरें!');
      return;
    }

    const chosenOwnProfile =
      targetOwnProfile ||
      subAccounts.find((a) => a.id === selectedFuelCreatorId) ||
      subAccounts[0];

    const isSpCoinOnlyPack = fuelCheckoutMode === 'sp_coin_pack';
    const chosenSpPack =
      SP_COIN_BUY_PACKS.find((p) => p.id === selectedSpPackId) || SP_COIN_BUY_PACKS[0];
    const chosenPlan =
      FISM_FUEL_UP_PLANS.find((p) => p.id === selectedFuelPlanId) || FISM_FUEL_UP_PLANS[0];

    const planLabel = isSpCoinOnlyPack
      ? `Only SP Coins Pack: ${chosenSpPack.label} (No Premium Features) — Profile: ${chosenOwnProfile.displayName} (@${mainProfileUsername})`
      : `${chosenPlan.name} (${chosenPlan.priceLabel} / ${chosenPlan.duration}) — Profile: ${chosenOwnProfile.displayName} (@${mainProfileUsername})`;

    const amountText = isSpCoinOnlyPack
      ? `₹${chosenSpPack.priceInr.toLocaleString()} • ${chosenSpPack.spCoins.toLocaleString()} SP Coins Only`
      : `${chosenPlan.priceLabel} (${chosenPlan.duration} • ${chosenPlan.discountBadge})`;

    const newReq: FismUpiPaymentRequest = {
      id: `upi_req_${Date.now()}`,
      userId: myProfile.uid,
      username: mainProfileUsername,
      displayName: chosenOwnProfile.displayName,
      userAvatar: chosenOwnProfile.avatarUrl || myProfile.avatarUrl,
      userEmail: loginEmailInput || primaryEmail,
      senderUpiId: userSenderUpiId.trim(),
      utrTransactionId: userUtrNumber.trim(),
      payerName: userPayerName.trim() || chosenOwnProfile.displayName,
      planName: planLabel,
      amountLabel: amountText,
      creatorId: chosenOwnProfile.id,
      creatorName: `${chosenOwnProfile.displayName} (@${mainProfileUsername})`,
      status: 'pending',
      submittedAt: new Date().toLocaleString(),
      requestType: isSpCoinOnlyPack ? 'sp_coin_pack' : 'premium',
      spCoinsAmount: isSpCoinOnlyPack ? chosenSpPack.spCoins : PREMIUM_SP_COIN_BONUS,
    };

    setUpiRequests((prev) => {
      const updated = [newReq, ...prev];
      try {
        localStorage.setItem('fism_upi_payment_requests', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });

    const confirmationHindi = isSpCoinOnlyPack
      ? `आपका ${chosenSpPack.spCoins.toLocaleString()} SP Coins पेमेंट सबमिट हो गया है! एडमिन Accept करने पर केवल SP Coins जुड़ेंगे (कोई Premium नहीं)।`
      : 'आपका पेमेंट सबमिट हो गया है, 24 घंटे में आपका फ्यूल अप हो जाएगा।';
    setUpiSubmittedPopupMsg(confirmationHindi);
    setSubVerificationMsg(confirmationHindi);

    // Real-Time Notification for the user
    const userNotif: FismNotificationItem = {
      id: `notif_upi_sub_${Date.now()}`,
      actorId: 'fism_payment_system',
      actorName: 'FISM Payment System',
      actorAvatar: chosenOwnProfile.avatarUrl || myProfile.avatarUrl,
      notificationType: 'fuelUp',
      message: `${confirmationHindi} (${amountText} for ${chosenOwnProfile.displayName})`,
      createdAt: 'Real-Time • Just now',
      isRead: false,
      targetScreen: 'fuelUp',
    };
    dispatchRealtimeNotification(userNotif);

    recordUserActivity(
      isSpCoinOnlyPack
        ? `Submitted Only SP Coins UPI Payment (${chosenSpPack.spCoins} SP)`
        : `Submitted Fuel Up UPI Payment (${newReq.senderUpiId})`,
      `Order: ${planLabel} • UTR: ${newReq.utrTransactionId}`,
    );

    setUserSenderUpiId('');
    setUserUtrNumber('');
    setUserPayerName('');
    triggerToast(confirmationHindi);
  };

  const persistSpWalletLocal = (nextWallet: FismSpCoinWallet) => {
    setSpWallet(nextWallet);
    try {
      localStorage.setItem('fism_sp_wallet_v1', JSON.stringify(nextWallet));
    } catch {
      // ignore
    }
  };

  const creditSpCoins = async (targetUid: string, amount: number, reason: string) => {
    if (!amount || amount <= 0) return;
    const isMe = targetUid === (currentUser?.uid || myProfile.uid) || targetUid === myProfile.uid;
    try {
      const res = await fetch('/api/sp-coins/credit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: targetUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
          amount,
          reason,
        }),
      });
      const data = await res.json();
      if (res.ok && data?.spWallet && isMe) {
        persistSpWalletLocal(data.spWallet as FismSpCoinWallet);
        return;
      }
    } catch {
      // fallback to optimistic local credit
    }
    if (isMe) {
      persistSpWalletLocal({
        ...spWallet,
        uid: targetUid,
        username: myProfile.username,
        displayName: myProfile.displayName,
        avatarUrl: myProfile.avatarUrl,
        spCoins: spWallet.spCoins + amount,
        totalSpPurchased: (spWallet.totalSpPurchased || 0) + amount,
        updatedAt: new Date().toLocaleTimeString(),
      });
    }
  };

  const handleAcceptUpiRequest = (requestId: string) => {
    const targetReq = upiRequests.find((r) => r.id === requestId);
    if (!targetReq) return;

    const nowTime = new Date().toLocaleString();
    setUpiRequests((prev) => {
      const updated = prev.map((r) =>
        r.id === requestId ? { ...r, status: 'accepted' as const, reviewedAt: nowTime } : r,
      );
      try {
        localStorage.setItem('fism_upi_payment_requests', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });

    const targetUid = targetReq.userId || currentUser?.uid || myProfile.uid;

    // Strictly distinguish "Only Buy SP Coins" from "Fuel Up Premium"
    if (targetReq.requestType === 'sp_coin_pack') {
      const spPackAmount = targetReq.spCoinsAmount || 500;
      void creditSpCoins(targetUid, spPackAmount, `Only SP Coins Pack (${targetReq.amountLabel})`);
      const acceptMsg = `🪙 बधाई हो! एडमिन ने आपका Only SP Coins पैक (${spPackAmount.toLocaleString()} SP Coins) Accept कर लिया है। आपके SP Wallet में +${spPackAmount.toLocaleString()} SP Coins जोड़ दिए गए हैं (No Premium Features unlocked)।`;
      setSubVerificationMsg(acceptMsg);

      dispatchRealtimeNotification({
        id: `notif_sp_pack_acc_${Date.now()}`,
        actorId: 'fism_admin_verification',
        actorName: 'FISM Admin Verification',
        actorAvatar: targetReq.userAvatar || myProfile.avatarUrl,
        notificationType: 'fuelUp',
        message: acceptMsg,
        createdAt: 'Real-Time • Just now',
        isRead: false,
        targetScreen: 'fuelUp',
      });
      triggerToast(`🪙 +${spPackAmount.toLocaleString()} SP Coins credited (No Premium)!`);
      return;
    }

    // Activate Fuel Up / Premium on the user's account once Admin accepts payment!
    setGlobalPremiumOn(true);
    handleToggleUserBoughtPremium(true);
    setMyProfile((prev) => ({
      ...prev,
      fuelersCount: prev.fuelersCount + 1,
      sparksCount: prev.sparksCount + 100,
    }));

    // Credit +500 SP Coins Bonus alongside Premium unlock
    void creditSpCoins(targetUid, PREMIUM_SP_COIN_BONUS, 'Fuel Up Premium +500 SP Bonus');

    // Auto-credit 10,000 Coins to the user's Coin Wallet for 1-Month+ Premium Subscription!
    void fetch('/api/wallet/credit-premium', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser?.uid || myProfile.uid,
        username: myProfile.username,
        displayName: myProfile.displayName,
        avatarUrl: myProfile.avatarUrl,
        bonusCoins: PREMIUM_COIN_PACK_BONUS,
        durationMonths:
          targetReq.planName?.includes('12') || targetReq.amountLabel?.includes('3599')
            ? 12
            : targetReq.planName?.includes('6') || targetReq.amountLabel?.includes('1999')
              ? 6
              : targetReq.planName?.includes('3') || targetReq.amountLabel?.includes('1099')
                ? 3
                : targetReq.planName?.includes('2') || targetReq.amountLabel?.includes('778')
                  ? 2
                  : 1,
      }),
    })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.wallet) {
          upsertWalletRecord(data.wallet);
          if (auth.currentUser?.emailVerified) {
            const safeUid = String(data.wallet.uid).replace(/[^a-zA-Z0-9_-]/g, '_');
            setDoc(doc(db, 'wallets', safeUid), {
              ...data.wallet,
              updatedAt: serverTimestamp(),
            }).catch(() => {});
          }
        }
      })
      .catch(() => {});

    const acceptMsg = `🎉 बधाई हो! एडमिन ने आपका पेमेंट वेरीफाई कर लिया है। प्रोफाइल "${targetReq.creatorName || targetReq.displayName}" पर आपका फ्यूल अप (${targetReq.amountLabel}) एक्टिव हो गया है, +${PREMIUM_COIN_PACK_BONUS.toLocaleString()} Wallet Coins और +${PREMIUM_SP_COIN_BONUS} SP Coins जोड़ दिए गए हैं!`;
    setSubVerificationMsg(acceptMsg);

    const acceptNotif: FismNotificationItem = {
      id: `notif_upi_acc_${Date.now()}`,
      actorId: 'fism_admin_verification',
      actorName: 'FISM Admin Verification',
      actorAvatar: targetReq.userAvatar || myProfile.avatarUrl,
      notificationType: 'fuelUp',
      message: acceptMsg,
      createdAt: 'Real-Time • Just now',
      isRead: false,
      targetScreen: 'fuelUp',
    };
    dispatchRealtimeNotification(acceptNotif);
    triggerToast(`🎉 Premium Verified + ${PREMIUM_SP_COIN_BONUS} SP Coins & ${PREMIUM_COIN_PACK_BONUS.toLocaleString()} Wallet Coins!`);

    triggerToast(
      `✅ Accepted Fuel Up for @${targetReq.username}! +${PREMIUM_COIN_PACK_BONUS.toLocaleString()} Wallet Coins credited!`,
    );
  };

  const handleDeclineUpiRequest = (requestId: string) => {
    const targetReq = upiRequests.find((r) => r.id === requestId);
    if (!targetReq) return;

    const nowTime = new Date().toLocaleString();
    setUpiRequests((prev) => {
      const updated = prev.map((r) =>
        r.id === requestId ? { ...r, status: 'declined' as const, reviewedAt: nowTime } : r,
      );
      try {
        localStorage.setItem('fism_upi_payment_requests', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });

    const declineHindiMsg =
      'आपका फ्यूल अप डिक्लाइन हो गया है। कृपया रीट्राई करें क्योंकि आपने पेमेंट नहीं किया है।';
    setSubVerificationMsg(declineHindiMsg);

    const declineNotif: FismNotificationItem = {
      id: `notif_upi_dec_${Date.now()}`,
      actorId: 'fism_admin_verification',
      actorName: 'FISM Admin Verification',
      actorAvatar: targetReq.userAvatar || myProfile.avatarUrl,
      notificationType: 'fuelUp',
      message: declineHindiMsg,
      createdAt: 'Real-Time • Just now',
      isRead: false,
      targetScreen: 'fuelUp',
    };
    dispatchRealtimeNotification(declineNotif);

    triggerToast(`❌ Declined request for @${targetReq.username}. Notification sent to user.`);
  };

  const handleToggleFuelUpCreator = async (creator: FismCreator) => {
    setSelectedFuelCreatorId(subAccounts[0]?.id || 'acc_1');
    setActiveScreen('fuelUp');
    setTimeout(() => {
      const el = document.getElementById('fism-upi-checkout-card');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 120);
    triggerToast(
      `👇 अपनी प्रोफाइल (@${creator.username || mainProfileUsername}) और 5 में से कोई भी Fuel Up Plan चुनकर UPI/QR से पेमेंट करें!`,
    );
  };

  const handleSubmitSmotherReport = async () => {
    if (!smotherTarget) return;
    const newRep: FismReportItem = {
      id: `rep_${Date.now()}`,
      reporterId: currentUser?.uid || myProfile.uid,
      reporterName: myProfile.displayName,
      targetId: smotherTarget.id,
      targetLabel: smotherTarget.label,
      targetType: smotherTarget.type,
      reason: smotherReason,
      details: smotherDetails.trim() || 'Reported via FISM Smother Safety System.',
      status: 'pending',
      createdAt: 'Just now',
    };
    setReports((prev) => [newRep, ...prev]);
    setSmotherTarget(null);
    setSmotherDetails('');
    triggerToast('Smother report submitted to FISM Safety & Admin Moderation.');
  };

  const handleExtinguishUser = (creator: FismCreator, mode: 'mute' | 'block') => {
    setCreators((prev) =>
      prev.map((c) =>
        c.uid === creator.uid
          ? {
              ...c,
              isMuted: mode === 'mute' ? !c.isMuted : c.isMuted,
              isBlocked: mode === 'block' ? !c.isBlocked : c.isBlocked,
              isConnected: mode === 'block' ? false : c.isConnected,
            }
          : c,
      ),
    );
    setExtinguishTargetCreator(null);
    triggerToast(
      mode === 'block'
        ? `Extinguished (Blocked) @${creator.username}.`
        : `Muted @${creator.username}.`,
    );
  };

  // Master & Isolated Sub-IDs Storage, Password Switching, Privacy Mode & Aadhaar Age Verification Handlers
  const saveSubAccountsToStorage = (list: FismSubAccount[]) => {
    setSubAccounts(list);
    try {
      localStorage.setItem('fism_user_unlimited_ids', JSON.stringify(list));
    } catch {
      // ignore
    }
  };

  const applyVerifiedAccountSwitch = (target: FismSubAccount) => {
    const outgoingId = activeSubAccount?.id;
    const syncedList = subAccounts.map((acc) => {
      if (acc.id === target.id) return { ...acc, ...target };
      if (acc.id === outgoingId) {
        return {
          ...acc,
          username: myProfile.username,
          displayName: myProfile.displayName,
          bio: myProfile.bio,
          avatarUrl: myProfile.avatarUrl,
          coverUrl: myProfile.coverUrl,
          location: myProfile.location,
          website: myProfile.website,
          categories: myProfile.categories,
          sparksCount: myProfile.sparksCount,
          flamesCount: myProfile.flamesCount,
          fuelersCount: myProfile.fuelersCount,
        };
      }
      return acc;
    });
    saveSubAccountsToStorage(syncedList);
    setActiveSubAccountId(target.id);
    try {
      localStorage.setItem('fism_active_sub_id', target.id);
    } catch {
      // ignore
    }

    const nextIsPrivate = !(target.privacyMode === 'public' && target.isAgeVerified);
    setMyProfile((prev) => ({
      ...prev,
      uid: target.isMaster ? 'local_hearth_user' : target.id,
      username: target.username,
      displayName: target.displayName,
      bio: target.bio ?? prev.bio,
      avatarUrl: target.avatarUrl,
      coverUrl: target.coverUrl ?? prev.coverUrl,
      location: target.location ?? prev.location,
      website: target.website ?? `https://fism.social/@${target.username}`,
      categories: target.categories ?? [],
      isVerified: Boolean(target.isAgeVerified),
      isPrivate: nextIsPrivate,
      sparksCount: target.sparksCount ?? 0,
      flamesCount: target.flamesCount ?? 0,
      fuelersCount: target.fuelersCount ?? 0,
    }));
    const targetConnected = new Set(target.connectedCreatorUids || []);
    setCreators((prev) =>
      prev.map((c) => ({ ...c, isConnected: targetConnected.has(c.uid) })),
    );
    setSelectedFuelCreatorId(target.id);
  };

  const handleRequestSwitchSubAccount = async (target: FismSubAccount) => {
    if (target.id === activeSubAccount?.id) return;
    if (target.hasPassword) {
      setSubIdSwitchError(null);
      setSubIdSwitchTarget(target);
      return;
    }
    try {
      const res = await fetch('/api/accounts/sub-ids/verify-switch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accountId: target.id, password: '' }),
      });
      const data = await res.json();
      if (res.status === 401 || data.requiresPassword) {
        setSubIdSwitchError(null);
        setSubIdSwitchTarget({ ...target, hasPassword: true });
        return;
      }
      if (data.verified && data.account) {
        applyVerifiedAccountSwitch(data.account as FismSubAccount);
        triggerToast(`✅ Switched to @${data.account.username} (${data.account.displayName})`);
      }
    } catch {
      applyVerifiedAccountSwitch(target);
      triggerToast(`Switched to @${target.username}`);
    }
  };

  const handleVerifyPasswordAndSwitch = async (
    target: FismSubAccount,
    password: string,
  ) => {
    setSubIdSwitching(true);
    setSubIdSwitchError(null);
    try {
      const res = await fetch('/api/accounts/sub-ids/verify-switch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accountId: target.id, password }),
      });
      const data = await res.json();
      if (!res.ok || !data.verified) {
        setSubIdSwitchError(data.error || 'Incorrect Sub-ID password.');
        return;
      }
      applyVerifiedAccountSwitch(data.account as FismSubAccount);
      setSubIdSwitchTarget(null);
      setSubIdSwitchError(null);
      triggerToast(`🔓 Password Verified! Switched to isolated Sub-ID @${data.account.username}`);
    } catch {
      setSubIdSwitchError('Unable to verify password right now.');
    } finally {
      setSubIdSwitching(false);
    }
  };

  const handleCreateIsolatedSubAccount = async (payload: {
    username: string;
    displayName: string;
    password: string;
    phoneNumber: string;
    avatarUrl: string;
    bio: string;
  }): Promise<boolean> => {
    setCreatingSubId(true);
    try {
      const res = await fetch('/api/accounts/sub-ids', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          masterUid: currentUser?.uid || 'local_hearth_user',
          email: primaryEmail,
          ...payload,
          privacyMode: 'private',
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data.error || 'Could not create Sub-ID.');
        return false;
      }
      const created = data.account as FismSubAccount;
      const nextList = [...subAccounts, created];
      saveSubAccountsToStorage(nextList);

      if (auth.currentUser?.emailVerified) {
        const safeMaster = auth.currentUser.uid.replace(/[^a-zA-Z0-9_-]/g, '_');
        const safeSub = created.id.replace(/[^a-zA-Z0-9_-]/g, '_');
        try {
          await setDoc(doc(db, 'users', safeMaster, 'subIds', safeSub), {
            id: safeSub,
            masterUid: auth.currentUser.uid,
            username: created.username,
            displayName: created.displayName,
            bio: created.bio || '',
            avatarUrl: created.avatarUrl,
            privacyMode: 'private',
            isPrivate: true,
            isAgeVerified: false,
            ageVerificationStatus: 'unverified',
            hasPassword: true,
            sparksCount: 0,
            flamesCount: 0,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          console.warn('Firestore Sub-ID sync skipped:', err);
        }
      }

      triggerToast(
        `🔐 Created isolated Private Sub-ID @${created.username} with salted scrypt password lock!`,
      );
      return true;
    } catch {
      triggerToast('Network error while creating Sub-ID.');
      return false;
    } finally {
      setCreatingSubId(false);
    }
  };

  const handleUpdateActiveAccountPrivacy = async (mode: FismAccountPrivacyMode) => {
    if (!activeSubAccount) return;
    if (mode === 'public' && !activeSubAccount.isAgeVerified) {
      triggerToast(
        '🔒 Public Account requires 18+ Aadhaar / Government ID Vision verification first!',
      );
      setSettingsSubTab('smart');
      setActiveScreen('controlCore');
      document
        .getElementById('fism-aadhaar-verification-panel')
        ?.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    try {
      const res = await fetch(`/api/accounts/sub-ids/${encodeURIComponent(activeSubAccount.id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ privacyMode: mode }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data.error || 'Could not update privacy mode.');
        return;
      }
      const updated = data.account as FismSubAccount;
      saveSubAccountsToStorage(subAccounts.map((a) => (a.id === updated.id ? updated : a)));
      setMyProfile((prev) => ({ ...prev, isPrivate: updated.privacyMode === 'private' }));
      triggerToast(
        updated.privacyMode === 'public'
          ? `🌐 @${updated.username} is now PUBLIC (Posts & Sparks visible to all).`
          : `🔒 @${updated.username} is now PRIVATE (Posts, Videos & Sparks hidden from non-followers).`,
      );
    } catch {
      triggerToast('Failed to update privacy mode.');
    }
  };

  const handleSetAccountPassword = async (
    accountId: string,
    currentPassword: string,
    newPassword: string,
  ): Promise<boolean> => {
    try {
      const res = await fetch('/api/accounts/sub-ids/set-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accountId, currentPassword, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data.error || 'Could not update password.');
        return false;
      }
      const updated = data.account as FismSubAccount;
      saveSubAccountsToStorage(subAccounts.map((a) => (a.id === updated.id ? updated : a)));
      triggerToast(`🔐 Salted password hash updated for @${updated.username}!`);
      return true;
    } catch {
      return false;
    }
  };

  const handleVerifyAadhaarImage = async (imageBase64: string, mimeType: string) => {
    if (!activeSubAccount) return;
    setVerifyingAge(true);
    try {
      const res = await fetch('/api/verification/aadhaar-age', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountId: activeSubAccount.id,
          masterUid: currentUser?.uid || 'local_hearth_user',
          imageBase64,
          mimeType,
          deviceName: detectFriendlyDeviceLabel(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data.error || 'Vision AI verification error.');
        return;
      }
      const ageRes = data as FismAgeVerificationResult & { account?: FismSubAccount };
      setLastAgeResult(ageRes);
      if (ageRes.account) {
        saveSubAccountsToStorage(
          subAccounts.map((a) => (a.id === ageRes.account!.id ? ageRes.account! : a)),
        );
        setMyProfile((prev) => ({
          ...prev,
          isVerified: Boolean(ageRes.is_age_verified),
          isPrivate: ageRes.privacyLockedToPrivate ? true : prev.isPrivate,
        }));
      }
      dispatchRealtimeNotification({
        id: `notif_age_${Date.now()}`,
        actorId: activeSubAccount.id,
        actorName: 'FISM Vision ID Auditor',
        actorAvatar: GENERATED_ASSETS.avatar1,
        notificationType: ageRes.is_age_verified ? 'age_verified' : 'age_rejected',
        message: ageRes.is_age_verified
          ? `18+ Verified for @${activeSubAccount.username}: ${ageRes.reason}`
          : `Verification Rejected for @${activeSubAccount.username}: ${ageRes.reason}`,
        isRead: false,
        createdAt: 'Just now',
        targetScreen: 'controlCore',
      });
      triggerToast(ageRes.is_age_verified ? `✅ ${ageRes.reason}` : `🚫 ${ageRes.reason}`);
    } catch {
      triggerToast('Network error during Vision AI ID scan.');
    } finally {
      setVerifyingAge(false);
    }
  };

  const handleCreateOrUpdateUnlimitedProfileId = () => {
    setSettingsSubTab('smart');
    setActiveScreen('controlCore');
  };

  const handleSendOtpForSubAccount = () => {
    handleCreateOrUpdateUnlimitedProfileId();
  };

  const handleVerifyOtpAndCreateSubAccount = () => {
    handleCreateOrUpdateUnlimitedProfileId();
  };

  // Filtered Feed Posts (excluding blocked or Admin-banned creators)
  const blockedCreatorIds = useMemo(() => {
    const setIds = new Set(creators.filter((c) => c.isBlocked).map((c) => c.uid));
    adminUserDossiers.forEach((d) => {
      if (d.isBanned) setIds.add(d.uid);
    });
    return setIds;
  }, [creators, adminUserDossiers]);

  // Privacy Gate Helper: Strictly hides Private Account & Private Sub-ID posts/videos/Sparks from non-followers until approved
  const canViewAuthorContent = (authorId: string, postVisibility?: string): boolean => {
    const viewerSubId = activeSubAccount?.id || 'acc_1';
    if (
      authorId === viewerSubId ||
      authorId === myProfile.uid ||
      (activeSubAccount?.isMaster && authorId === 'local_hearth_user')
    ) {
      return true;
    }
    const subMatch = subAccounts.find((a) => a.id === authorId);
    if (subMatch) {
      if (subMatch.privacyMode === 'public' && subMatch.isAgeVerified) return true;
      if ((subMatch.approvedFollowerUids || []).includes(viewerSubId)) return true;
      return followRequests.some(
        (r) =>
          r.requesterUid === viewerSubId &&
          r.targetUid === authorId &&
          r.status === 'accepted',
      );
    }
    const creatorMatch = creators.find((c) => c.uid === authorId);
    if (creatorMatch?.isPrivate || postVisibility === 'private') {
      if (creatorMatch?.isConnected) return true;
      return followRequests.some(
        (r) =>
          r.requesterUid === viewerSubId &&
          r.targetUid === authorId &&
          r.status === 'accepted',
      );
    }
    return true;
  };

  // Flame Feed strictly shows ONLY Viral Videos (1,000,000+ Views) OR Premium Creator Videos/Posts
  // Copyright-flagged / Blocked videos AND unapproved Private Account content are strictly suppressed.
  const visibleFeedPosts = useMemo(() => {
    let list = posts.filter(
      (p) =>
        !isPostCopyrightBlocked(p) &&
        !blockedCreatorIds.has(p.authorId) &&
        canViewAuthorContent(p.authorId, p.visibility) &&
        (p.viewsCount >= 1_000_000 || Boolean(p.isPremiumCreator)),
    );
    if (globalSearchQuery.trim()) {
      const q = globalSearchQuery.toLowerCase();
      list = list.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.caption.toLowerCase().includes(q) ||
          p.authorDisplayName.toLowerCase().includes(q) ||
          p.hashtags.some((h) => h.toLowerCase().includes(q)),
      );
    }
    if (feedFilter === 'Following') {
      const connectedIds = new Set(creators.filter((c) => c.isConnected).map((c) => c.uid));
      connectedIds.add(myProfile.uid);
      list = list.filter((p) => connectedIds.has(p.authorId));
    } else if (feedFilter === 'Trending') {
      list = [...list].sort((a, b) => b.viewsCount - a.viewsCount);
    } else if (feedFilter === 'For You') {
      list = rankPostsByFlameAlgorithm(list, behaviorProfile);
    }
    return list;
  }, [posts, blockedCreatorIds, globalSearchQuery, feedFilter, creators, myProfile.uid, behaviorProfile, activeSubAccount, subAccounts, followRequests]);

  const rankedMainBlastVideos = useMemo(() => {
    const longVids = posts.filter(
      (p) =>
        p.postType === 'video' &&
        !isPostCopyrightBlocked(p) &&
        canViewAuthorContent(p.authorId, p.visibility),
    );
    return rankPostsByFlameAlgorithm(longVids, behaviorProfile);
  }, [posts, behaviorProfile, activeSubAccount, subAccounts, followRequests, creators]);

  type FismQuickBurstFeedItem = FismPostItem & {
    smartAdItem?: FismSmartAdItem;
    flameMatchLabel?: string;
  };

  const quickBurstPosts = useMemo<FismQuickBurstFeedItem[]>(() => {
    const baseShorts = rankPostsByFlameAlgorithm(
      posts.filter(
        (p) =>
          !isPostCopyrightBlocked(p) &&
          canViewAuthorContent(p.authorId, p.visibility) &&
          (p.postType === 'quickBurst' || p.aspectRatio === '9:16'),
      ),
      behaviorProfile,
    );
    const isQuickBurstLiveActive =
      (gamingLiveState.isScreencasting && gamingLiveState.streamAspectMode === 'quickBurst') ||
      (isBroadcastingLive && cameraLiveAspectMode === 'quickBurst');

    const interleaved: FismQuickBurstFeedItem[] = [];
    const activeModelObj =
      [...INITIAL_4_3D_FACE_MODELS, ...custom3DModels].find(
        (m) => m.id === gamingLiveState.active3DFaceModelId,
      ) || INITIAL_4_3D_FACE_MODELS[0];
    const usedAdIds: string[] = [];

    baseShorts.forEach((shortItem, idx) => {
      const rankedInfo = scorePostForUser(shortItem, behaviorProfile);
      interleaved.push({
        ...shortItem,
        flameMatchLabel: rankedInfo.matchedCategory
          ? `🔥 Flame Match: #${rankedInfo.matchedCategory}`
          : undefined,
      });

      if (isQuickBurstLiveActive && (idx + 1) % 2 === 0) {
        interleaved.push({
          id: `quickburst_live_interleaved_${idx}`,
          authorId: myProfile.uid,
          authorUsername: myProfile.username,
          authorDisplayName: `${myProfile.displayName} (🔴 LIVE IN QUICK BURST)`,
          authorAvatar: myProfile.avatarUrl,
          authorVerified: true,
          postType: 'quickBurst',
          title: gamingLiveState.isScreencasting
            ? `🔴 LIVE SCREEN SHARING: ${gamingLiveState.streamCustomTitle || gamingLiveState.selectedGameName}`
            : `🔴 LIVE CAMERA: ${liveStreamTitle}`,
          caption: `⚡ Live in Quick Burst (9:16) with 3D ${activeModelObj.name} Lip-Sync & Real-Time Subscriber Alerts! Tap On Fire to join live chat.`,
          mediaUrl:
            'https://assets.mixkit.co/videos/preview/mixkit-gamer-playing-on-a-console-43527-large.mp4',
          thumbnailUrl: GENERATED_ASSETS.studioThumb,
          aspectRatio: '9:16',
          duration: '🔴 LIVE',
          audioTrack: `Live Stream Audio – @${myProfile.username}`,
          hashtags: ['#QuickBurstLive', '#OnFire', '#3DAvatar', '#ScreenSharing'],
          location: myProfile.location,
          visibility: 'public',
          allowComments: true,
          sparkCount: 4200,
          chatterCount: liveChatMessages.length,
          spreadCount: 190,
          viewsCount: 1_450_000,
          isSparked: true,
          isStashed: false,
          isRealVideo: true,
          createdAt: '🔴 LIVE NOW',
          comments: [],
        });
      }

      // Interleave contextual Flame-Algorithm Quick Burst Ad after every 2nd/3rd short
      if ((idx + 1) % 2 === 0) {
        const contextualAd = selectContextualAd(smartAds, behaviorProfile, 'quickBurst', usedAdIds);
        if (contextualAd) {
          usedAdIds.push(contextualAd.id);
          interleaved.push({
            id: `qb_ad_${contextualAd.id}_${idx}`,
            authorId: contextualAd.creatorId,
            authorUsername: contextualAd.creatorUsername,
            authorDisplayName: contextualAd.creatorDisplayName,
            authorAvatar: contextualAd.creatorAvatar,
            authorVerified: true,
            postType: 'quickBurst',
            title: contextualAd.title,
            caption: contextualAd.description,
            mediaUrl: contextualAd.mediaUrl,
            thumbnailUrl: contextualAd.mediaUrl,
            aspectRatio: '9:16',
            duration: 'AD',
            audioTrack: `${contextualAd.storePlatform} Sponsored Audio`,
            hashtags: contextualAd.categoryTags.map((t) => `#${t}`),
            location: 'Flame Algorithm Target',
            visibility: 'public',
            allowComments: false,
            sparkCount: contextualAd.likes,
            chatterCount: 0,
            spreadCount: contextualAd.clicks,
            viewsCount: contextualAd.impressions,
            isSparked: false,
            isStashed: false,
            isRealVideo: contextualAd.isVideo,
            createdAt: 'Sponsored Ad',
            comments: [],
            smartAdItem: contextualAd,
            flameMatchLabel: `🎯 Interest Match: ${contextualAd.categoryTags.slice(0, 2).join(', ')}`,
          });
        }
      }
    });
    return interleaved;
  }, [
    posts,
    behaviorProfile,
    smartAds,
    gamingLiveState.isScreencasting,
    gamingLiveState.streamAspectMode,
    gamingLiveState.streamCustomTitle,
    gamingLiveState.selectedGameName,
    gamingLiveState.active3DFaceModelId,
    isBroadcastingLive,
    cameraLiveAspectMode,
    liveStreamTitle,
    custom3DModels,
    myProfile.uid,
    myProfile.username,
    myProfile.displayName,
    myProfile.avatarUrl,
    myProfile.location,
    liveChatMessages.length,
  ]);

  // Track watch time, Watch-Complete Gift Drop progression & Dynamic View Thresholds during Quick Burst shorts
  useEffect(() => {
    if (activeScreen === 'quickBurst' && quickBurstPlaying) {
      const timer = window.setInterval(() => {
        const activeShort = quickBurstPosts[activeQuickBurstIndex];
        if (!activeShort) return;
        if (activeShort.smartAdItem) {
          handleEngageSmartAd(activeShort.smartAdItem.id, 'impression');
        } else {
          trackBehaviorSignal(
            'watch',
            extractPostCategories(activeShort),
            1,
            activeShort.id,
          );
          recordDynamicWatchSecond(activeShort);
          if (!isRealPlayableVideo(activeShort.mediaUrl, activeShort.isRealVideo)) {
            setVideoWatchProgressByPostId((prev) => {
              const cur = prev[activeShort.id] ?? 0;
              if (cur >= 100) return prev;
              const nextPct = Math.min(100, cur + 14);
              if (nextPct >= 96) {
                setCompletedGiftVideoIds((done) =>
                  done[activeShort.id] ? done : { ...done, [activeShort.id]: true },
                );
              }
              return { ...prev, [activeShort.id]: nextPct };
            });
          }
        }
      }, 1000);
      return () => window.clearInterval(timer);
    }
    return undefined;
  }, [activeScreen, quickBurstPlaying, activeQuickBurstIndex, quickBurstPosts]);

  // Track Dynamic View Thresholds & Bounce Protection on Main Blast long video playback
  useEffect(() => {
    if (activeScreen !== 'mainBlast' || !videoPlaying || mainBlastActiveAd || !selectedVideoPost?.id) {
      return undefined;
    }
    const timer = window.setInterval(() => {
      recordDynamicWatchSecond(selectedVideoPost);
    }, 1000);
    return () => window.clearInterval(timer);
  }, [activeScreen, videoPlaying, mainBlastActiveAd, selectedVideoPost?.id]);

  const unreadNotificationsCount = useMemo(
    () => notifications.filter((n) => !n.isRead).length,
    [notifications],
  );

  const unreadMessagesCount = useMemo(
    () => conversations.reduce((acc, c) => acc + c.unreadCount, 0),
    [conversations],
  );

  // Navigation Items Definition (Drawer + Left Sidebar)
  const primaryNavItems: {
    id: FismScreen;
    label: string;
    sublabel: string;
    icon: React.ReactNode;
    badge?: number;
  }[] = [
    { id: 'flameFeed', label: 'Flame Feed', sublabel: '1M+ Viral & Premium', icon: <Flame className="w-5 h-5" /> },
    { id: 'mainBlast', label: 'Main Blast', sublabel: 'Long Videos (>1m)', icon: <Play className="w-5 h-5" /> },
    { id: 'quickBurst', label: 'Quick Burst', sublabel: 'Shorts & Remix', icon: <Zap className="w-5 h-5" /> },
    {
      id: 'musicHub',
      label: 'Music Section',
      sublabel: 'Upload & Use App Music',
      icon: <Music className="w-5 h-5 text-[#7C3AED]" />,
    },
    { id: 'circleFeed', label: 'Circle Feed', sublabel: 'Subscriptions', icon: <Compass className="w-5 h-5" /> },
    {
      id: 'gameHub',
      label: '2D Game Hub',
      sublabel: 'Play 2D Arcade Games',
      icon: <Gamepad2 className="w-5 h-5 text-[#16A34A]" />,
    },
    {
      id: 'flame3DArena',
      label: '3D VR Cinema',
      sublabel: 'Watch Videos in 3D & VR',
      icon: <Box className="w-5 h-5 text-[#FF5722]" />,
    },
    {
      id: 'shoppingSection',
      label: 'Shopping Section',
      sublabel: 'Marketplace & GPS',
      icon: <ShoppingBag className="w-5 h-5 text-[#FF5722]" />,
    },
    {
      id: 'emberChat',
      label: 'Ember Chat',
      sublabel: 'Chat, Call & Emoji Game',
      icon: <MessageCircle className="w-5 h-5" />,
      badge: unreadMessagesCount,
    },
    {
      id: 'warmSparks',
      label: 'Warm Sparks',
      sublabel: 'Notifications',
      icon: <Bell className="w-5 h-5" />,
      badge: unreadNotificationsCount,
    },
    { id: 'findFlame', label: 'Find Flame', sublabel: 'Search & Explore', icon: <Search className="w-5 h-5" /> },
    { id: 'myHearth', label: 'My Hearth', sublabel: 'Profile & Accounts', icon: <UserIcon className="w-5 h-5" /> },
    { id: 'ashStash', label: 'AshStash', sublabel: 'Saved Collections', icon: <Bookmark className="w-5 h-5" /> },
    { id: 'onFire', label: 'On Fire', sublabel: 'Live Streaming', icon: <Radio className="w-5 h-5" /> },
    { id: 'fuelUp', label: 'Fuel Up', sublabel: 'Creator Tiers', icon: <Crown className="w-5 h-5" /> },
    {
      id: 'earningHub',
      label: 'Creator Earning',
      sublabel: '5,000 Sparks • 1L=$0.0001',
      icon: <Crown className="w-5 h-5 text-[#FFB300]" />,
    },
    {
      id: 'aiWorkspaceHub',
      label: 'AI, Maps & Workspace',
      sublabel: 'Gemini + Google Hub',
      icon: <Sparkles className="w-5 h-5 text-[#7C3AED]" />,
    },
    {
      id: 'flameMaps',
      label: 'Flame Maps',
      sublabel: 'Live GPS & Locate Pins',
      icon: <MapPin className="w-5 h-5 text-[#16A34A]" />,
    },
    {
      id: 'aiCloneStudio',
      label: 'AI Clone Studio',
      sublabel: 'Digital Avatar Video',
      icon: <Video className="w-5 h-5 text-[#FF5722]" />,
    },
    {
      id: 'communityChat',
      label: 'Community Chat',
      sublabel: 'Rooms & Group Calls',
      icon: <Users className="w-5 h-5 text-[#16A34A]" />,
    },
    ...(hasLiveCreatorAccess
      ? [
          {
            id: 'liveCreatorChat' as FismScreen,
            label: 'Live Creator Chat',
            sublabel: 'Exclusive VIP Room',
            icon: <Radio className="w-5 h-5 text-[#FFB300]" />,
          },
        ]
      : []),
    {
      id: 'coinLeaderboard',
      label: 'Coins & Drops',
      sublabel: '10k Pack • 100k Free Pro',
      icon: <Trophy className="w-5 h-5 text-[#EAB308]" />,
    },
    {
      id: 'installApp',
      label: 'Install App',
      sublabel: apkRelease ? `${apkRelease.appName} v${apkRelease.version}` : 'Official FISM APK',
      icon: <Download className="w-5 h-5 text-[#2563EB]" />,
    },
    { id: 'controlCore', label: 'Control Core', sublabel: 'Settings & Preferences', icon: <Settings className="w-5 h-5" /> },
  ];

  // ============================================================================
  // COMMUNITY CHAT, GROUP CALLING WEBSOCKET/WEBRTC & LIVE CREATOR ACCESS LOGIC
  // ============================================================================
  const activeIdentityUid = activeSubAccount?.isMaster
    ? currentUser?.uid || myProfile.uid
    : activeSubAccount?.id || myProfile.uid;

  const upsertWalletRecord = (wallet: FismCoinWallet) => {
    setCoinWallets((prev) => {
      const idx = prev.findIndex((w) => w.uid === wallet.uid);
      const next =
        idx >= 0 ? prev.map((w, i) => (i === idx ? wallet : w)) : [wallet, ...prev];
      try {
        localStorage.setItem('fism_coin_wallets_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const upsertGiftDrop = (drop: FismGiftDropConfig) => {
    setGiftDrops((prev) => {
      const idx = prev.findIndex((d) => d.id === drop.id);
      const next = idx >= 0 ? prev.map((d, i) => (i === idx ? drop : d)) : [drop, ...prev];
      try {
        localStorage.setItem('fism_gift_drops_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const myWallet = useMemo<FismCoinWallet>(() => {
    const found = coinWallets.find((w) => w.uid === activeIdentityUid);
    if (found) return found;
    return {
      uid: activeIdentityUid,
      username: myProfile.username,
      displayName: myProfile.displayName,
      avatarUrl: myProfile.avatarUrl,
      coinBalance: 0,
      totalEarnedCoins: 0,
      totalDroppedCoins: 0,
      premiumExpiresAt: '',
      claimedRewardIds: [],
      updatedAt: 'Ready',
    };
  }, [coinWallets, activeIdentityUid, myProfile.username, myProfile.displayName, myProfile.avatarUrl]);

  const [downloadingBrandedPostId, setDownloadingBrandedPostId] = useState<string | null>(null);

  const handleDownloadBrandedVideo = async (post: FismPostItem) => {
    if (!post?.id || downloadingBrandedPostId) return;
    setDownloadingBrandedPostId(post.id);
    triggerToast('🎬 Burning FISM Branded Watermark onto video via FFmpeg...');
    try {
      const result = await downloadBrandedVideoWithWatermark({
        postId: post.id,
        userId: activeIdentityUid,
        username: myProfile.username,
        displayName: myProfile.displayName,
        videoUrl: post.mediaUrl,
        thumbnailUrl: post.thumbnailUrl,
        title: post.title || post.caption || 'FISM Video',
        authorUsername: post.authorUsername || 'fism_creator',
        isVertical: post.postType === 'quickBurst' || post.aspectRatio === '9:16',
        durationSeconds: parseDurationToSeconds(post.duration, post.postType),
      });
      triggerToast(
        `✅ Downloaded "${result.filename}" with permanent "${result.watermarkLabel}" watermark!`,
      );
    } catch (err) {
      triggerToast(
        err instanceof Error ? err.message : 'Branded video download failed. Please retry.',
      );
    } finally {
      setDownloadingBrandedPostId(null);
    }
  };

  useEffect(() => {
    if (!activeIdentityUid) return;
    const connectedHandles = creators
      .filter((c) => c.isConnected)
      .map((c) => `@${c.username}`);
    void reportUserTrackingEvent({
      userId: activeIdentityUid,
      username: myProfile.username,
      displayName: myProfile.displayName,
      avatarUrl: myProfile.avatarUrl,
      email: currentUser?.email || `${myProfile.username}@fism.app`,
      eventType: 'session_ping',
      followersCount: myProfile.fuelersCount,
      followingCount: connectedHandles.length,
      followersList: ['@aria_sparks', '@aman_fism', '@elena_rostova'],
      followingList: connectedHandles,
      walletCoins: myWallet.coinBalance,
      spCoins: spWallet.spCoins,
    });
  }, [activeIdentityUid, myProfile.username, myProfile.fuelersCount, myWallet.coinBalance, spWallet.spCoins]);

  const leaderboardWallets = useMemo<FismCoinWallet[]>(() => {
    const hasMe = coinWallets.some((w) => w.uid === activeIdentityUid);
    const merged = hasMe ? coinWallets : [myWallet, ...coinWallets];
    return [...merged].sort((a, b) => b.coinBalance - a.coinBalance);
  }, [coinWallets, activeIdentityUid, myWallet]);

  const getDropForPost = (postId: string): FismGiftDropConfig | undefined =>
    giftDrops.find((d) => d.postId === postId);

  // ============================================================================
  // WATCH-COMPLETE VIDEO PROGRESS TRACKING FOR GIFT DROPS
  // ============================================================================
  const [completedGiftVideoIds, setCompletedGiftVideoIds] = useState<Record<string, boolean>>({});
  const [videoWatchProgressByPostId, setVideoWatchProgressByPostId] = useState<
    Record<string, number>
  >({});

  const markGiftVideoWatchCompleted = (postId: string) => {
    if (!postId) return;
    setVideoWatchProgressByPostId((prev) => (prev[postId] === 100 ? prev : { ...prev, [postId]: 100 }));
    setCompletedGiftVideoIds((prev) => (prev[postId] ? prev : { ...prev, [postId]: true }));
  };

  const updateVideoWatchProgress = (postId: string, rawPct: number) => {
    if (!postId) return;
    const clamped = Math.max(0, Math.min(100, Math.round(rawPct)));
    setVideoWatchProgressByPostId((prev) => {
      const existing = prev[postId] ?? 0;
      if (clamped <= existing) return prev;
      return { ...prev, [postId]: clamped };
    });
    if (clamped >= 96) {
      setCompletedGiftVideoIds((prev) => (prev[postId] ? prev : { ...prev, [postId]: true }));
    }
  };

  useEffect(() => {
    setVideoProgress(0);
  }, [selectedVideoPost.id]);

  useEffect(() => {
    if (activeScreen === 'mainBlast' && selectedVideoPost?.id && !mainBlastActiveAd) {
      updateVideoWatchProgress(selectedVideoPost.id, videoProgress);
    }
  }, [activeScreen, selectedVideoPost?.id, videoProgress, mainBlastActiveAd]);

  // ============================================================================
  // ANNUAL RED MILESTONE TICK, COLLECTIBLE CARDS, SP COINS, FRAMES & CYBERPUNK MODE
  // ============================================================================
  const [userMilestone, setUserMilestone] = useState<FismUserMilestoneState>(() => {
    try {
      const saved = localStorage.getItem('fism_user_milestone_v1');
      if (saved) return JSON.parse(saved) as FismUserMilestoneState;
    } catch {
      // ignore
    }
    const nowIso = new Date().toISOString();
    return {
      accountId: 'local_hearth_user',
      username: 'flame_creator',
      displayName: 'Flame Creator',
      avatarUrl: GENERATED_ASSETS.avatar1,
      joinedAtIso: nowIso,
      tenureYears: 0,
      tenureDays: 0,
      currentTier: 'none',
      hasRedMilestoneTick: false,
      claimedTiers: [],
      equippedFrame: 'none',
      vipGoldBadgeUnlocked: false,
      aiBoostActive: false,
      topAlgorithmBoost: false,
      freePremiumMonthClaimed: false,
      redCyberpunkMode: false,
      founderGiftClaimed: false,
      updatedAt: nowIso,
    };
  });
  const [milestoneModalTarget, setMilestoneModalTarget] = useState<MilestoneModalTarget | null>(
    null,
  );
  const [founderGiftClaims, setFounderGiftClaims] = useState<FismFounderGiftClaim[]>([]);
  const [adminFounderGiftClaims, setAdminFounderGiftClaims] = useState<FismFounderGiftClaim[]>([]);

  const persistMilestoneStateLocal = (nextState: FismUserMilestoneState) => {
    setUserMilestone(nextState);
    try {
      localStorage.setItem('fism_user_milestone_v1', JSON.stringify(nextState));
    } catch {
      // ignore
    }
    if (auth.currentUser?.emailVerified) {
      const safeUid = (auth.currentUser.uid || activeIdentityUid).replace(/[^a-zA-Z0-9_-]/g, '_');
      const safeDocId = (nextState.accountId || safeUid).replace(/[^a-zA-Z0-9_-]/g, '_');
      const firestorePayload = {
        userId: safeUid,
        accountId: nextState.accountId,
        joinedAtIso:
          nextState.joinedAtIso && nextState.joinedAtIso.length >= 10
            ? nextState.joinedAtIso
            : new Date().toISOString(),
        currentTier: nextState.currentTier,
        hasRedMilestoneTick: Boolean(nextState.hasRedMilestoneTick),
        claimedTiers: nextState.claimedTiers || [],
        equippedFrame: nextState.equippedFrame || 'none',
        redCyberpunkMode: Boolean(nextState.redCyberpunkMode),
        updatedAt: serverTimestamp(),
      };
      setDoc(doc(db, 'users', safeUid, 'milestones', safeDocId), firestorePayload).catch(() => {});
    }
  };

  useEffect(() => {
    if (!activeIdentityUid) return;
    fetch(
      `/api/milestones/state?accountId=${encodeURIComponent(activeIdentityUid)}&username=${encodeURIComponent(myProfile.username)}&displayName=${encodeURIComponent(myProfile.displayName)}`,
    )
      .then((r) => r.json())
      .then((data) => {
        if (data?.milestone) {
          setUserMilestone(data.milestone as FismUserMilestoneState);
        }
        if (Array.isArray(data?.founderGiftClaims)) {
          setFounderGiftClaims(data.founderGiftClaims as FismFounderGiftClaim[]);
        }
      })
      .catch(() => {});
  }, [activeIdentityUid]);

  useEffect(() => {
    if (!pendingDeepLink) return;
    const target = pendingDeepLink;
    setPendingDeepLink(null);

    if (target.kind === 'install') {
      setActiveScreen('installApp');
      setDeepLinkFallbackBanner({
        url: target.rawUrl,
        label: 'Opened Official FISM App Installer via App Link',
      });
      return;
    }

    if (target.kind === 'post' || target.kind === 'video') {
      const matched = posts.find((p) => p.id === target.id);
      if (matched) {
        if (matched.postType === 'video' || target.kind === 'video') {
          setSelectedVideoPost(matched);
          setActiveScreen('mainBlast');
        } else if (matched.postType === 'quickBurst') {
          const qbIdx = posts
            .filter((p) => p.postType === 'quickBurst' && !isPostCopyrightBlocked(p))
            .findIndex((p) => p.id === matched.id);
          setActiveQuickBurstIndex(qbIdx >= 0 ? qbIdx : 0);
          setActiveScreen('quickBurst');
        } else {
          setActiveScreen('flameFeed');
          setGlobalSearchQuery(matched.title);
        }
        setDeepLinkFallbackBanner({
          url: target.rawUrl,
          label: `Opened "${matched.title}" via FISM Deep Link`,
        });
      } else {
        setActiveScreen(target.kind === 'video' ? 'mainBlast' : 'flameFeed');
        setDeepLinkFallbackBanner({
          url: target.rawUrl,
          label: `Resolved FISM Deep Link (${target.kind}/${target.id})`,
        });
      }
      return;
    }

    if (target.kind === 'burst') {
      const qbList = posts.filter((p) => p.postType === 'quickBurst' && !isPostCopyrightBlocked(p));
      const idx = qbList.findIndex((p) => p.id === target.id);
      setActiveQuickBurstIndex(idx >= 0 ? idx : 0);
      setQuickBurstPlaying(true);
      setActiveScreen('quickBurst');
      setDeepLinkFallbackBanner({
        url: target.rawUrl,
        label: `Opened Quick Burst #${target.id} via App Link`,
      });
      return;
    }

    if (target.kind === 'user') {
      const cleanName = target.username.toLowerCase();
      if (myProfile.username.toLowerCase() === cleanName) {
        setViewedProfileId(myProfile.uid);
      } else {
        const matchedCreator = creators.find((c) => c.username.toLowerCase() === cleanName);
        if (matchedCreator) {
          setViewedProfileId(matchedCreator.uid);
        }
      }
      if (isAuthenticated) {
        setActiveScreen('myHearth');
      }
      setDeepLinkFallbackBanner({
        url: target.rawUrl,
        label: `Profile Deep Link: @${target.username}`,
      });
      return;
    }

    if (target.kind === 'item') {
      if (isAuthenticated) {
        setActiveScreen('shoppingSection');
      }
      const matchedItem = shoppingProducts.find((item) => item.id === target.id);
      setDeepLinkFallbackBanner({
        url: target.rawUrl,
        label: matchedItem
          ? `Marketplace Item: ${matchedItem.title}`
          : `Marketplace Item #${target.id}`,
      });
      return;
    }

    if (target.kind === 'live') {
      if (isAuthenticated) {
        setActiveScreen('onFire');
      }
      setDeepLinkFallbackBanner({
        url: target.rawUrl,
        label: `Live Stream Deep Link (#${target.id})`,
      });
    }
  }, [pendingDeepLink, posts, creators, shoppingProducts, isAuthenticated]);

  const getAuthorMilestoneInfo = (authorId?: string) => {
    if (!authorId) {
      return {
        hasRedTick: false,
        tier: 'none' as FismMilestoneTier,
        vipGoldBadge: false,
        frame: 'none' as FismProfileFrameId,
        joinedAtIso: new Date().toISOString(),
      };
    }
    if (
      authorId === activeIdentityUid ||
      authorId === myProfile.uid ||
      authorId === activeSubAccount?.id ||
      authorId === 'local_hearth_user'
    ) {
      return {
        hasRedTick: userMilestone.hasRedMilestoneTick,
        tier: userMilestone.currentTier,
        vipGoldBadge: userMilestone.vipGoldBadgeUnlocked,
        frame: userMilestone.equippedFrame,
        joinedAtIso: userMilestone.joinedAtIso,
      };
    }
    const creator = creators.find((c) => c.uid === authorId);
    if (creator) {
      const stats = computeTenureStats(creator.joinedAtIso);
      const tier =
        creator.milestoneTier && creator.milestoneTier !== 'none'
          ? creator.milestoneTier
          : stats.tier;
      return {
        hasRedTick: Boolean(creator.hasRedMilestoneTick || stats.hasRedMilestoneTick),
        tier,
        vipGoldBadge: Boolean(
          creator.vipGoldBadgeUnlocked || tier === 'gold' || tier === 'red',
        ),
        frame: creator.equippedFrame || 'none',
        joinedAtIso: creator.joinedAtIso || new Date().toISOString(),
      };
    }
    return {
      hasRedTick: false,
      tier: 'none' as FismMilestoneTier,
      vipGoldBadge: false,
      frame: 'none' as FismProfileFrameId,
      joinedAtIso: new Date().toISOString(),
    };
  };

  const milestoneMembersMap = useMemo(() => {
    const map: Record<string, { hasRedTick?: boolean; vipGoldBadge?: boolean }> = {
      [activeIdentityUid]: {
        hasRedTick: userMilestone.hasRedMilestoneTick,
        vipGoldBadge: userMilestone.vipGoldBadgeUnlocked,
      },
      [myProfile.uid]: {
        hasRedTick: userMilestone.hasRedMilestoneTick,
        vipGoldBadge: userMilestone.vipGoldBadgeUnlocked,
      },
    };
    creators.forEach((c) => {
      const info = getAuthorMilestoneInfo(c.uid);
      map[c.uid] = { hasRedTick: info.hasRedTick, vipGoldBadge: info.vipGoldBadge };
    });
    return map;
  }, [activeIdentityUid, myProfile.uid, userMilestone, creators]);

  const openMilestoneJourneyForUser = (opts: {
    accountId: string;
    username: string;
    displayName: string;
    avatarUrl: string;
  }) => {
    const isOwn =
      opts.accountId === activeIdentityUid ||
      opts.accountId === myProfile.uid ||
      opts.accountId === activeSubAccount?.id ||
      opts.accountId === 'local_hearth_user';
    if (isOwn) {
      setMilestoneModalTarget({
        accountId: activeIdentityUid,
        username: myProfile.username,
        displayName: myProfile.displayName,
        avatarUrl: myProfile.avatarUrl,
        joinedAtIso: userMilestone.joinedAtIso,
        milestoneTier: userMilestone.currentTier,
        vipGoldBadgeUnlocked: userMilestone.vipGoldBadgeUnlocked,
        equippedFrame: userMilestone.equippedFrame,
        isOwn: true,
      });
      return;
    }
    const info = getAuthorMilestoneInfo(opts.accountId);
    setMilestoneModalTarget({
      accountId: opts.accountId,
      username: opts.username,
      displayName: opts.displayName,
      avatarUrl: opts.avatarUrl,
      joinedAtIso: info.joinedAtIso,
      milestoneTier: info.tier,
      vipGoldBadgeUnlocked: info.vipGoldBadge,
      equippedFrame: info.frame,
      isOwn: false,
    });
  };

  // ============================================================================
  // DYNAMIC VIEW THRESHOLDS (Short 5-7s, Medium 20-30s, Long 2-3m/20% + Bounce/Skip)
  // ============================================================================
  const watchedSecondsMapRef = useRef<Record<string, number>>({});
  const qualifiedViewIdsRef = useRef<Record<string, boolean>>({});
  const prevActiveShortIdRef = useRef<string | null>(null);
  const feedVideoLastTickRef = useRef<Record<string, number>>({});

  const reportVideoViewSession = async (
    post: FismPostItem,
    watchedSec: number,
    durationSeconds: number,
  ) => {
    try {
      const res = await fetch(`/api/videos/${encodeURIComponent(post.id)}/register-view`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeIdentityUid,
          sessionKey: `${activeIdentityUid}:${post.id}`,
          durationSeconds,
          watchedSeconds: watchedSec,
        }),
      });
      const data = await res.json();
      if (res.ok && data?.counted) {
        setPosts((prev) =>
          prev.map((p) => (p.id === post.id ? { ...p, viewsCount: p.viewsCount + 1 } : p)),
        );
        setSelectedVideoPost((prev) =>
          prev.id === post.id ? { ...prev, viewsCount: prev.viewsCount + 1 } : prev,
        );
      }
    } catch {
      // Fallback local qualification if offline
    }
  };

  const recordDynamicWatchSecond = (post: FismPostItem) => {
    if (!post?.id) return;
    const durationSec = parseDurationToSeconds(post.duration, post.postType);
    const threshold = computeDynamicViewThreshold(durationSec);
    const nextSec = (watchedSecondsMapRef.current[post.id] || 0) + 1;
    watchedSecondsMapRef.current[post.id] = nextSec;

    if (!qualifiedViewIdsRef.current[post.id] && nextSec >= threshold.requiredWatchSeconds) {
      qualifiedViewIdsRef.current[post.id] = true;
      void reportVideoViewSession(post, nextSec, durationSec);
    }
    if (nextSec === 1 || nextSec % 5 === 0) {
      void reportUserTrackingEvent({
        userId: activeIdentityUid,
        username: myProfile.username,
        displayName: myProfile.displayName,
        avatarUrl: myProfile.avatarUrl,
        eventType: 'watch',
        postId: post.id,
        videoTitle: post.title || post.caption,
        category: extractPostCategories(post)[0] || 'Video',
        watchSeconds: nextSec,
        durationSeconds: durationSec,
      });
    }
  };

  // Detect Bounce/Skip when user scrolls away from a Quick Burst before meeting threshold
  useEffect(() => {
    const currentShort =
      activeScreen === 'quickBurst' ? quickBurstPosts[activeQuickBurstIndex] : undefined;
    const prevId = prevActiveShortIdRef.current;
    if (prevId && prevId !== currentShort?.id && !qualifiedViewIdsRef.current[prevId]) {
      const prevPost = posts.find((p) => p.id === prevId);
      const watchedSec = watchedSecondsMapRef.current[prevId] || 0;
      if (prevPost && watchedSec > 0) {
        const durSec = parseDurationToSeconds(prevPost.duration, prevPost.postType);
        void fetch(`/api/videos/${encodeURIComponent(prevId)}/register-view`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: activeIdentityUid,
            sessionKey: `${activeIdentityUid}:${prevId}`,
            durationSeconds: durSec,
            watchedSeconds: watchedSec,
          }),
        }).catch(() => {});
      }
    }
    prevActiveShortIdRef.current = currentShort?.id || null;
  }, [activeScreen, activeQuickBurstIndex, quickBurstPosts]);

  const handleDailyCheckInLocate = async () => {
    const getCoords = (): Promise<{ lat: number; lng: number; label: string }> =>
      new Promise((resolve) => {
        if (!navigator.geolocation) {
          resolve({ lat: 28.6139, lng: 77.209, label: 'FISM Verified Daily Check-In (New Delhi)' });
          return;
        }
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            resolve({
              lat: Number(pos.coords.latitude.toFixed(6)),
              lng: Number(pos.coords.longitude.toFixed(6)),
              label: `GPS Locate Pin (±${Math.round(pos.coords.accuracy || 15)}m)`,
            });
          },
          () => {
            resolve({ lat: 28.6139, lng: 77.209, label: 'FISM Verified Daily Check-In' });
          },
          { enableHighAccuracy: true, timeout: 6000 },
        );
      });

    try {
      const coords = await getCoords();
      const res = await fetch('/api/milestones/daily-checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountId: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
          lat: coords.lat,
          lng: coords.lng,
          locationLabel: coords.label,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data?.milestone) {
          persistMilestoneStateLocal(data.milestone as FismUserMilestoneState);
        }
        triggerToast(
          data?.error || '⏳ 24-hour cooldown active! Please claim again after 24 hours.',
        );
        return;
      }
      if (data?.milestone) {
        const ms = data.milestone as FismUserMilestoneState;
        persistMilestoneStateLocal(ms);
        triggerToast(
          `📍 Daily Check-In Locate Verified! Day ${ms.verifiedCheckInDays || 1} Streak recorded on Flame Maps.`,
        );
      }
    } catch {
      triggerToast('Network error recording daily check-in.');
    }
  };

  const handleSaveAdsterraConfig = async (cfg: Partial<FismAdsterraConfig>) => {
    try {
      const res = await fetch('/api/admin/adsterra-config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data?.error || 'Failed to save AdsTerra configuration.');
        return;
      }
      if (data?.config) {
        setAdsterraConfig(data.config as FismAdsterraConfig);
        triggerToast('✅ AdsTerra Banner & Native Banner configuration saved & synced live!');
      }
    } catch {
      triggerToast('Network error saving AdsTerra configuration.');
    }
  };

  const handleUploadApkRelease = async (payload: {
    appName: string;
    version: string;
    details: string;
    fileName: string;
    sizeBytes?: number;
    base64Data?: string;
    fileBase64?: string;
  }) => {
    const res = await fetch('/api/admin/apk-release', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        appName: payload.appName,
        version: payload.version,
        details: payload.details,
        fileName: payload.fileName,
        fileBase64: payload.base64Data || payload.fileBase64 || '',
        uploadedBy: currentUser?.email || myProfile.username,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data?.error || 'APK upload failed.');
    }
    setApkRelease((data.release || null) as FismApkReleaseInfo | null);
    triggerToast(`📦 Published official single APK "${payload.appName}" v${payload.version}!`);
  };

  const handleDeleteApkRelease = async () => {
    const res = await fetch('/api/admin/apk-release', { method: 'DELETE' });
    if (res.ok) {
      setApkRelease(null);
      triggerToast('🗑️ Official APK removed from Install section.');
    } else {
      triggerToast('Could not remove APK.');
    }
  };

  const handleClaimMilestoneTier = async (tier: Exclude<FismMilestoneTier, 'none'>) => {
    try {
      const res = await fetch('/api/milestones/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountId: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
          tier,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data?.error || 'Complete the required tenure year first to claim this tier.');
        return;
      }
      if (data.milestone) {
        persistMilestoneStateLocal(data.milestone as FismUserMilestoneState);
      }
      if (data.spWallet) {
        persistSpWalletLocal(data.spWallet as FismSpCoinWallet);
      }
      const cfg = FISM_MILESTONE_ROADMAP.find((r) => r.tier === tier);
      if (tier === 'silver') {
        setUserHasBoughtPremium(true);
      }
      triggerToast(
        `🏆 ${cfg?.cardName || tier} Claimed! +${data.creditedSpCoins || cfg?.spReward || 0} SP Coins credited & perks activated!`,
      );
    } catch {
      triggerToast('Network error claiming milestone tier.');
    }
  };

  const handleUpdateMilestonePrefs = async (prefs: {
    equippedFrame?: FismProfileFrameId;
    redCyberpunkMode?: boolean;
  }) => {
    try {
      const res = await fetch('/api/milestones/preferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountId: activeIdentityUid,
          ...prefs,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data?.error || 'Unlock that tier first to activate this perk.');
        return;
      }
      if (data.milestone) {
        persistMilestoneStateLocal(data.milestone as FismUserMilestoneState);
        if (typeof prefs.redCyberpunkMode === 'boolean') {
          triggerToast(
            prefs.redCyberpunkMode
              ? '❤️⚡ Red Cyberpunk VIP Mode ACTIVATED across the entire app!'
              : 'Switched back to Standard FISM Theme.',
          );
        } else if (prefs.equippedFrame) {
          triggerToast(`✨ Profile Frame updated to ${prefs.equippedFrame.replace(/_/g, ' ')}!`);
        }
      }
    } catch {
      triggerToast('Network error updating milestone preference.');
    }
  };

  const handleSubmitFounderGiftClaim = async (giftItem: string, shippingNote: string) => {
    try {
      const res = await fetch('/api/milestones/founder-gift', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountId: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          giftItem,
          shippingNote,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data?.error || 'Year 5+ Red Card required for Founder Gifts.');
        return;
      }
      if (data.milestone) {
        persistMilestoneStateLocal(data.milestone as FismUserMilestoneState);
      }
      if (data.claim) {
        const claim = data.claim as FismFounderGiftClaim;
        setFounderGiftClaims((prev) => [claim, ...prev.filter((c) => c.id !== claim.id)]);
        setAdminFounderGiftClaims((prev) => [claim, ...prev.filter((c) => c.id !== claim.id)]);
        if (auth.currentUser?.emailVerified) {
          const safeClaimId = claim.id.replace(/[^a-zA-Z0-9_-]/g, '_');
          setDoc(doc(db, 'founderGiftClaims', safeClaimId), {
            id: safeClaimId,
            userId: auth.currentUser.uid,
            username: (claim.username || 'fism_user').replace(/[^a-zA-Z0-9_-]/g, '_'),
            displayName: claim.displayName,
            giftItem: claim.giftItem,
            shippingNote: claim.shippingNote || '',
            status: claim.status,
            claimedAt: claim.claimedAt,
          }).catch(() => {});
        }
        triggerToast(`🎁 Founder Gift request submitted for "${claim.giftItem}"!`);
      }
    } catch {
      triggerToast('Network error submitting Founder Gift claim.');
    }
  };

  const handleAdminRespondFounderGift = async (
    claimId: string,
    status: 'approved' | 'shipped',
    adminNote?: string,
  ) => {
    try {
      const res = await fetch('/api/admin/founder-gift/respond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ claimId, status, adminNote }),
      });
      const data = await res.json();
      if (res.ok && data.claim) {
        const updated = data.claim as FismFounderGiftClaim;
        setFounderGiftClaims((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
        setAdminFounderGiftClaims((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
        triggerToast(`📦 Founder Gift #${claimId.slice(-6)} marked as ${status.toUpperCase()}!`);
      }
    } catch {
      triggerToast('Could not update Founder Gift status.');
    }
  };

  const handleFlexMilestoneToStory = async (opts: {
    tier: Exclude<FismMilestoneTier, 'none'>;
    imageDataUrl: string;
    caption: string;
  }) => {
    const newStory: FismStoryItem = {
      id: `story_milestone_${Date.now()}`,
      authorId: myProfile.uid,
      username: myProfile.username,
      displayName: myProfile.displayName,
      avatarUrl: myProfile.avatarUrl,
      mediaUrl: opts.imageDataUrl || GENERATED_ASSETS.heroCover,
      caption: opts.caption,
      createdAt: 'Just now',
      viewed: false,
      sparked: true,
    };
    setStories((prev) => [newStory, ...prev]);
    setMilestoneModalTarget(null);
    setActiveScreen('flameFeed');
    triggerToast(`🔥 Flexed your ${opts.tier.toUpperCase()} Milestone Card to FISM Stories!`);
  };

  const handleTopUpCoins = async (amount: number, packLabel: string) => {
    if (!requireAuth('Top Up Coin Wallet')) return;
    try {
      const res = await fetch('/api/wallet/topup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
          amount,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data.error || 'Unable to top up coins.');
        return;
      }
      if (data.wallet) {
        upsertWalletRecord(data.wallet);
        if (auth.currentUser?.emailVerified) {
          const safeUid = activeIdentityUid.replace(/[^a-zA-Z0-9_-]/g, '_');
          setDoc(doc(db, 'wallets', safeUid), {
            ...data.wallet,
            updatedAt: serverTimestamp(),
          }).catch(() => {});
        }
      }
      triggerToast(`+${amount.toLocaleString()} Coins added (${packLabel})!`);
    } catch {
      triggerToast('Network issue topping up Coin Wallet.');
    }
  };

  const handleRedeemFreePremiumWithCoins = async () => {
    if (!requireAuth('Redeem Free Monthly Premium')) return;
    try {
      const res = await fetch('/api/wallet/redeem-premium', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data.error || 'Need 100,000 Coins to redeem 1-Month Free Premium.');
        return;
      }
      if (data.wallet) {
        upsertWalletRecord(data.wallet);
        if (auth.currentUser?.emailVerified) {
          const safeUid = activeIdentityUid.replace(/[^a-zA-Z0-9_-]/g, '_');
          setDoc(doc(db, 'wallets', safeUid), {
            ...data.wallet,
            updatedAt: serverTimestamp(),
          }).catch(() => {});
        }
      }
      setGlobalPremiumOn(true);
      handleToggleUserBoughtPremium(true);
      void creditSpCoins(activeIdentityUid, PREMIUM_SP_COIN_BONUS, '100k Coins Free Premium +500 SP Bonus');
      triggerToast(`👑 100,000 Coins redeemed! 1-Month Free Premium + ${PREMIUM_SP_COIN_BONUS} SP Coins unlocked!`);
    } catch {
      triggerToast('Unable to redeem Free Premium right now.');
    }
  };

  // Send 50 SP Super Chat Box or Super Sticker in On Fire
  const handleSendSuperChat = async (opts: {
    kind: 'superchat' | 'sticker';
    text?: string;
    boxStyle?: FismSuperChatBoxStyle;
    stickerId?: string;
    stickerLabel?: string;
    stickerEmoji?: string;
    hostUid?: string;
  }): Promise<boolean> => {
    if (!requireAuth('Send SP Coins Super Chat / Sticker')) return false;
    if (spWallet.spCoins < SP_SUPER_CHAT_COST) {
      triggerToast(`Need ${SP_SUPER_CHAT_COST} SP Coins! Opening Only Buy SP Coins in Fuel Up...`);
      setFuelCheckoutMode('sp_coin_pack');
      setActiveScreen('fuelUp');
      return false;
    }
    try {
      const res = await fetch('/api/sp-coins/superchat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
          hostCreatorUid: opts.hostUid || activeIdentityUid,
          kind: opts.kind,
          text: opts.text || '',
          boxStyle: opts.boxStyle || 'amber_flame',
          stickerId: opts.stickerId,
          stickerLabel: opts.stickerLabel,
          stickerEmoji: opts.stickerEmoji,
          spCost: SP_SUPER_CHAT_COST,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data.error || `Insufficient SP Coins (${SP_SUPER_CHAT_COST} SP required).`);
        return false;
      }
      if (data.spWallet) {
        persistSpWalletLocal(data.spWallet as FismSpCoinWallet);
      }
      if (data.superChat) {
        const sc = data.superChat as FismSuperChatMessage;
        setSuperChats((prev) => (prev.some((x) => x.id === sc.id) ? prev : [sc, ...prev]));
        setLiveChatMessages((prev) =>
          prev.some((m) => m.id === sc.id)
            ? prev
            : [
                ...prev,
                {
                  id: sc.id,
                  user: sc.senderUsername,
                  text:
                    sc.kind === 'sticker'
                      ? `${sc.stickerEmoji || '🎁'} [SUPER STICKER: ${sc.stickerLabel}] ${sc.text}`
                      : `🔥 [SUPER CHAT • ${sc.spCost} SP] ${sc.text}`,
                  badge: sc.kind === 'sticker' ? 'Sticker 50 SP' : 'Super Chat 50 SP',
                },
              ],
        );
      }
      triggerToast(
        opts.kind === 'sticker'
          ? `🎁 Sent Super Sticker (-${SP_SUPER_CHAT_COST} SP Coins)!`
          : `🔥 Sent Super Chat Box (-${SP_SUPER_CHAT_COST} SP Coins)!`,
      );
      return true;
    } catch {
      triggerToast('Network error sending SP Super Chat.');
      return false;
    }
  };

  // Join 500 SP Channel Membership (Connects Member & Creator Channels on both Profiles)
  const handleJoinChannelMembership = async (targetCreator: {
    uid: string;
    username: string;
    displayName: string;
    avatarUrl: string;
  }) => {
    if (!requireAuth('Join 500 SP Channel Membership')) return;
    if (spWallet.spCoins < CHANNEL_MEMBERSHIP_SP_COST) {
      triggerToast(
        `Channel Membership requires ${CHANNEL_MEMBERSHIP_SP_COST} SP Coins! Opening Buy SP Coins...`,
      );
      setFuelCheckoutMode('sp_coin_pack');
      setActiveScreen('fuelUp');
      return;
    }
    try {
      const res = await fetch('/api/sp-coins/membership', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberUid: activeIdentityUid,
          memberUsername: myProfile.username,
          memberDisplayName: myProfile.displayName,
          memberAvatar: myProfile.avatarUrl,
          creatorUid: targetCreator.uid,
          creatorUsername: targetCreator.username,
          creatorDisplayName: targetCreator.displayName,
          creatorAvatar: targetCreator.avatarUrl,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        triggerToast(data.error || `Unable to join Membership (${CHANNEL_MEMBERSHIP_SP_COST} SP required).`);
        return;
      }
      if (data.spWallet) {
        persistSpWalletLocal(data.spWallet as FismSpCoinWallet);
      }
      if (data.membership) {
        const mem = data.membership as FismChannelMembership;
        setChannelMemberships((prev) => {
          const next = [mem, ...prev.filter((m) => m.id !== mem.id)];
          try {
            localStorage.setItem('fism_channel_memberships_v1', JSON.stringify(next));
          } catch {
            // ignore
          }
          return next;
        });
      }
      triggerToast(
        `🎖️ Joined @${targetCreator.username} Membership (-${CHANNEL_MEMBERSHIP_SP_COST} SP)! Connected on both channels.`,
      );
    } catch {
      triggerToast('Network error joining Channel Membership.');
    }
  };

  // Jump directly to a Connected Video from Main Blast, Quick Burst, or Feed Card
  const handleOpenConnectedVideo = (ref: FismConnectedVideoRef) => {
    const matched = posts.find((p) => p.id === ref.id);
    if (matched) {
      if (matched.postType === 'quickBurst') {
        const qbList = posts.filter(
          (p) => p.postType === 'quickBurst' && !isPostCopyrightBlocked(p),
        );
        const foundIdx = qbList.findIndex((p) => p.id === matched.id);
        setActiveQuickBurstIndex(foundIdx >= 0 ? foundIdx : 0);
        setQuickBurstPlaying(true);
        setActiveScreen('quickBurst');
      } else {
        setSelectedVideoPost(matched);
        setVideoPlaying(true);
        setActiveScreen('mainBlast');
      }
      triggerToast(`🔗 Opening connected video: "${ref.title}"`);
      return;
    }
    if (ref.postType === 'quickBurst') {
      setActiveScreen('quickBurst');
    } else {
      setActiveScreen('mainBlast');
    }
    triggerToast(`🔗 Opening linked video "${ref.title}"`);
  };

  // Accept Collaboration Tag (Warm Sparks Invite -> Dual Channel Visibility)
  const handleAcceptCollabTag = async (notifId: string, postId: string, targetUid: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        return {
          ...p,
          taggedCollaborators: (p.taggedCollaborators || []).map((tc) =>
            tc.uid === targetUid ? { ...tc, status: 'accepted' as const } : tc,
          ),
        };
      }),
    );
    setNotifications((prev) =>
      prev.map((n) =>
        n.id === notifId ? { ...n, isRead: true, collabStatus: 'accepted' as const } : n,
      ),
    );
    try {
      await fetch('/api/collab/accept', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postId, collaboratorUid: targetUid }),
      });
    } catch {
      // optimistic local update already applied
    }
    triggerToast('✅ Collaboration accepted! Post now appears on both channels.');
  };

  // Follow Author + All Accepted Collaborators together
  const handleFollowAllCreatorsForPost = (post: FismPostItem) => {
    if (!requireAuth('Follow All Collaborators')) return;
    const acceptedCollabs = (post.taggedCollaborators || []).filter(
      (tc) => tc.status === 'accepted',
    );
    const targetList: { uid: string; username: string; displayName: string; avatarUrl: string }[] = [
      {
        uid: post.authorId,
        username: post.authorUsername,
        displayName: post.authorDisplayName,
        avatarUrl: post.authorAvatar,
      },
      ...acceptedCollabs,
    ].filter((u) => u.uid !== activeIdentityUid && u.uid !== myProfile.uid);

    let addedCount = 0;
    setCreators((prev) => {
      const next = [...prev];
      for (const t of targetList) {
        const idx = next.findIndex((c) => c.uid === t.uid);
        if (idx >= 0) {
          if (!next[idx].isConnected) {
            next[idx] = {
              ...next[idx],
              isConnected: true,
              sparksCount: next[idx].sparksCount + 1,
            };
            addedCount += 1;
          }
        } else {
          next.push({
            uid: t.uid,
            username: t.username,
            displayName: t.displayName,
            bio: 'FISM Collaborator Creator',
            avatarUrl: t.avatarUrl,
            coverUrl: GENERATED_ASSETS.heroCover,
            location: 'FISM Creator Network',
            website: '',
            isVerified: true,
            isPrivate: false,
            sparksCount: 1,
            flamesCount: 1,
            fuelersCount: 0,
            monthlyPrice: 4.99,
            isConnected: true,
          });
          addedCount += 1;
        }
      }
      return next;
    });
    if (addedCount > 0) {
      setMyProfile((prev) => ({
        ...prev,
        flamesCount: prev.flamesCount + addedCount,
      }));
    }
    setCollabFollowTargetPost(null);
    triggerToast(
      addedCount > 0
        ? `🔥 Followed ${addedCount} creator${addedCount > 1 ? 's' : ''} together!`
        : '✓ Already following all creators on this collab!',
    );
  };

  const handleClaimVideoGiftDrop = async (
    drop: FismGiftDropConfig,
  ): Promise<FismClaimedGiftReceipt | null> => {
    if (!requireAuth('Claim Video Gift Drop')) return null;
    try {
      const res = await fetch(`/api/gift-drops/${encodeURIComponent(drop.id)}/claim`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
        }),
      });
      const data = await res.json();
      if (data.giftDrop) {
        upsertGiftDrop(data.giftDrop);
      }
      if (!res.ok) {
        if (res.status === 409 && data.receipt) {
          triggerToast('You already claimed this Gift Drop — opening your reward!');
          return data.receipt as FismClaimedGiftReceipt;
        }
        triggerToast(data.error || 'Gift Claimed / Expired!');
        return null;
      }
      if (data.wallet) {
        upsertWalletRecord(data.wallet);
      }
      if (data.spWallet) {
        persistSpWalletLocal(data.spWallet as FismSpCoinWallet);
      }
      if (data.receipt) {
        const receipt = data.receipt as FismClaimedGiftReceipt;
        setClaimedGiftReceipts((prev) => {
          const next = [receipt, ...prev.filter((r) => r.id !== receipt.id)];
          try {
            localStorage.setItem('fism_claimed_gift_receipts_v1', JSON.stringify(next));
          } catch {
            // ignore
          }
          return next;
        });
        if (auth.currentUser?.emailVerified) {
          const safeDropId = drop.id.replace(/[^a-zA-Z0-9_-]/g, '_');
          const safeUid = activeIdentityUid.replace(/[^a-zA-Z0-9_-]/g, '_');
          setDoc(doc(db, 'giftDrops', safeDropId, 'claims', safeUid), {
            ...receipt,
            claimerUid: activeIdentityUid,
            claimedAt: serverTimestamp(),
          }).catch(() => {});
          if (data.wallet) {
            setDoc(doc(db, 'wallets', safeUid), {
              ...data.wallet,
              updatedAt: serverTimestamp(),
            }).catch(() => {});
          }
        }
        triggerToast(
          `🎁 Claimed "${receipt.rewardTitle}"${
            receipt.coinsAwarded > 0 ? ` (+${receipt.coinsAwarded} Coins!)` : '!'
          }`,
        );
        return receipt;
      }
      return null;
    } catch {
      triggerToast('Network error while claiming Gift Drop.');
      return null;
    }
  };

  const createPeerForRemote = (roomId: string, remoteUid: string): RTCPeerConnection => {
    const existing = rtcPeersRef.current.get(remoteUid);
    if (existing) return existing;

    const pc = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
    });

    if (localGroupCallStreamRef.current) {
      localGroupCallStreamRef.current.getTracks().forEach((track) => {
        pc.addTrack(track, localGroupCallStreamRef.current!);
      });
    }

    pc.onicecandidate = (ev) => {
      if (ev.candidate && communityWsRef.current?.readyState === WebSocket.OPEN) {
        communityWsRef.current.send(
          JSON.stringify({
            type: 'rtc:signal',
            roomId,
            fromUid: activeIdentityUid,
            targetUid: remoteUid,
            signalType: 'ice',
            candidate: ev.candidate,
          }),
        );
      }
    };

    pc.ontrack = (ev) => {
      const stream = ev.streams?.[0];
      if (stream) {
        setRemotePeerStreams((prev) => ({ ...prev, [remoteUid]: stream }));
      }
    };

    rtcPeersRef.current.set(remoteUid, pc);
    return pc;
  };

  const cleanupAllGroupCallMedia = () => {
    if (localGroupCallStreamRef.current) {
      localGroupCallStreamRef.current.getTracks().forEach((t) => t.stop());
      localGroupCallStreamRef.current = null;
    }
    setLocalGroupCallStream(null);
    rtcPeersRef.current.forEach((pc) => pc.close());
    rtcPeersRef.current.clear();
    setRemotePeerStreams({});
  };

  useEffect(() => {
    const qs = new URLSearchParams({
      uid: activeIdentityUid,
      username: myProfile.username,
      displayName: myProfile.displayName,
      avatarUrl: myProfile.avatarUrl,
    });
    fetch(`/api/community/state?${qs.toString()}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!data) return;
        if (Array.isArray(data.communityRooms)) setCommunityRooms(data.communityRooms);
        setLiveCreatorRoom(data.liveCreatorRoom || null);
        setHasLiveCreatorAccess(Boolean(data.hasLiveCreatorAccess));
        if (data.messagesByRoom) setCommunityMessagesByRoom(data.messagesByRoom);
        if (data.activeCalls) setActiveGroupCalls(data.activeCalls);
      })
      .catch(() => {});

    const wqs = new URLSearchParams({
      userId: activeIdentityUid,
      username: myProfile.username,
      displayName: myProfile.displayName,
      avatarUrl: myProfile.avatarUrl,
    });
    fetch(`/api/wallet?${wqs.toString()}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.wallet) upsertWalletRecord(data.wallet);
        if (Array.isArray(data?.claims) && data.claims.length > 0) {
          setClaimedGiftReceipts(data.claims);
        }
      })
      .catch(() => {});

    fetch('/api/gift-drops')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (Array.isArray(data?.giftDrops) && data.giftDrops.length > 0) {
          setGiftDrops(data.giftDrops);
        }
      })
      .catch(() => {});

    fetch('/api/leaderboard')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (Array.isArray(data?.leaderboard) && data.leaderboard.length > 0) {
          setCoinWallets(data.leaderboard);
        }
      })
      .catch(() => {});

    fetch(
      `/api/sp-coins/state?userId=${encodeURIComponent(activeIdentityUid)}&username=${encodeURIComponent(myProfile.username)}&displayName=${encodeURIComponent(myProfile.displayName)}&avatarUrl=${encodeURIComponent(myProfile.avatarUrl)}`,
    )
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.spWallet) persistSpWalletLocal(data.spWallet as FismSpCoinWallet);
        if (Array.isArray(data?.superChats)) setSuperChats(data.superChats);
        if (Array.isArray(data?.memberships)) {
          setChannelMemberships(data.memberships);
          try {
            localStorage.setItem('fism_channel_memberships_v1', JSON.stringify(data.memberships));
          } catch {
            // ignore
          }
        }
      })
      .catch(() => {});

    fetch('/api/accounts/sub-ids/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        masterUid: currentUser?.uid || 'local_hearth_user',
        email: primaryEmail,
        username: subAccounts[0]?.username || 'flame_pioneer',
        displayName: subAccounts[0]?.displayName || 'Alex Ignis (Master Account)',
        avatarUrl: subAccounts[0]?.avatarUrl || GENERATED_ASSETS.avatar1,
        accounts: subAccounts,
      }),
    })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (Array.isArray(data?.accounts) && data.accounts.length > 0) {
          saveSubAccountsToStorage(data.accounts as FismSubAccount[]);
        }
        if (Array.isArray(data?.followRequests)) {
          setFollowRequests(data.followRequests as FismPrivateFollowRequest[]);
        }
      })
      .catch(() => {});

    fetch(
      `/api/milestones/state?accountId=${encodeURIComponent(activeIdentityUid)}&username=${encodeURIComponent(myProfile.username)}&displayName=${encodeURIComponent(myProfile.displayName)}&avatarUrl=${encodeURIComponent(myProfile.avatarUrl)}`,
    )
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.milestone) {
          persistMilestoneStateLocal(data.milestone as FismUserMilestoneState);
        }
        if (Array.isArray(data?.founderGiftClaims)) {
          setFounderGiftClaims(data.founderGiftClaims as FismFounderGiftClaim[]);
        }
      })
      .catch(() => {});

    fetch('/api/admin/founder-gifts')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (Array.isArray(data?.claims)) {
          setAdminFounderGiftClaims(data.claims as FismFounderGiftClaim[]);
        }
      })
      .catch(() => {});
  }, [activeIdentityUid, myProfile.username, myProfile.displayName, myProfile.avatarUrl]);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/community-chat`;
    let ws: WebSocket | null = null;
    try {
      ws = new WebSocket(wsUrl);
      communityWsRef.current = ws;

      ws.onopen = () => {
        ws?.send(
          JSON.stringify({
            type: 'auth:hello',
            uid: activeIdentityUid,
            username: myProfile.username,
            displayName: myProfile.displayName,
            avatarUrl: myProfile.avatarUrl,
          }),
        );
      };

      ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'ad:broadcast' && msg.ad) {
            setSmartAds((prev) =>
              prev.some((a) => a.id === msg.ad.id) ? prev : [msg.ad, ...prev],
            );
          } else if (msg.type === 'room:created' && msg.room) {
            setCommunityRooms((prev) =>
              prev.some((r) => r.id === msg.room.id) ? prev : [msg.room, ...prev],
            );
          } else if (msg.type === 'room:message' && msg.roomId && msg.message) {
            setCommunityMessagesByRoom((prev) => {
              const existing = prev[msg.roomId] || [];
              if (existing.some((m) => m.id === msg.message.id)) return prev;
              return { ...prev, [msg.roomId]: [...existing, msg.message] };
            });
          } else if (msg.type === 'call:ring' && msg.call) {
            const incoming = msg.call as FismActiveGroupCall;
            if (incoming.roomType === 'live_creator' && !hasLiveCreatorAccessRef.current) return;
            if (incoming.initiatorId !== activeIdentityUid) {
              setIncomingGroupCallRing(incoming);
              triggerToast(`🔔 Incoming Group ${incoming.mode === 'video' ? 'Video' : 'Voice'} Call in "${incoming.roomName}"`);
            }
          } else if (msg.type === 'call:state' && msg.roomId && msg.call) {
            const callObj = msg.call as FismActiveGroupCall;
            if (callObj.roomType === 'live_creator' && !hasLiveCreatorAccessRef.current) return;
            setActiveGroupCalls((prev) => ({ ...prev, [msg.roomId]: callObj }));

            // If I am participating in this call, initiate WebRTC offers to higher-ID peers
            const amParticipating = callObj.participants.some((p) => p.uid === activeIdentityUid);
            if (amParticipating) {
              for (const p of callObj.participants) {
                if (p.uid !== activeIdentityUid && activeIdentityUid < p.uid && !rtcPeersRef.current.has(p.uid)) {
                  const pc = createPeerForRemote(msg.roomId, p.uid);
                  const offer = await pc.createOffer();
                  await pc.setLocalDescription(offer);
                  ws?.send(
                    JSON.stringify({
                      type: 'rtc:signal',
                      roomId: msg.roomId,
                      fromUid: activeIdentityUid,
                      targetUid: p.uid,
                      signalType: 'offer',
                      sdp: offer,
                    }),
                  );
                }
              }
            }
          } else if (msg.type === 'call:ended' && msg.roomId) {
            setActiveGroupCalls((prev) => {
              const next = { ...prev };
              delete next[msg.roomId];
              return next;
            });
            setIncomingGroupCallRing((prev) => (prev?.roomId === msg.roomId ? null : prev));
            cleanupAllGroupCallMedia();
          } else if (msg.type === 'creator_access:updated') {
            setLiveCreatorAccessMap((prev) => ({
              ...prev,
              [msg.uid]: Boolean(msg.canAccessLiveCreatorChat),
            }));
            const matchesMe =
              msg.uid === activeIdentityUid ||
              String(msg.username || '').toLowerCase() === myProfile.username.toLowerCase();
            if (matchesMe) {
              const granted = Boolean(msg.canAccessLiveCreatorChat);
              setHasLiveCreatorAccess(granted);
              if (granted) {
                setLiveCreatorRoom(msg.liveCreatorRoom || null);
                triggerToast('🎉 Admin unlocked Exclusive Live Creator Chat for your account!');
              } else {
                setLiveCreatorRoom(null);
                setActiveScreen((curr) => (curr === 'liveCreatorChat' ? 'flameFeed' : curr));
                triggerToast('🔒 Live Creator Chat access was revoked by Admin.');
              }
            }
          } else if (msg.type === 'rtc:signal' && msg.fromUid && msg.roomId) {
            const pc = createPeerForRemote(msg.roomId, msg.fromUid);
            if (msg.signalType === 'offer' && msg.sdp) {
              await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
              const answer = await pc.createAnswer();
              await pc.setLocalDescription(answer);
              ws?.send(
                JSON.stringify({
                  type: 'rtc:signal',
                  roomId: msg.roomId,
                  fromUid: activeIdentityUid,
                  targetUid: msg.fromUid,
                  signalType: 'answer',
                  sdp: answer,
                }),
              );
            } else if (msg.signalType === 'answer' && msg.sdp) {
              await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
            } else if (msg.signalType === 'ice' && msg.candidate) {
              await pc.addIceCandidate(new RTCIceCandidate(msg.candidate));
            }
          } else if (
            (msg.type === 'gift_drop:created' || msg.type === 'gift_drop:updated') &&
            msg.giftDrop
          ) {
            upsertGiftDrop(msg.giftDrop as FismGiftDropConfig);
          } else if (msg.type === 'leaderboard:updated') {
            if (Array.isArray(msg.leaderboard)) {
              setCoinWallets(msg.leaderboard as FismCoinWallet[]);
            } else if (msg.wallet) {
              upsertWalletRecord(msg.wallet as FismCoinWallet);
            }
          } else if (msg.type === 'sp_coins:updated' && msg.spWallet) {
            if (msg.spWallet.uid === activeIdentityUid) {
              persistSpWalletLocal(msg.spWallet as FismSpCoinWallet);
            }
          } else if (msg.type === 'superchat:created' && msg.superChat) {
            const sc = msg.superChat as FismSuperChatMessage;
            setSuperChats((prev) => (prev.some((x) => x.id === sc.id) ? prev : [sc, ...prev]));
            setLiveChatMessages((prev) =>
              prev.some((m) => m.id === sc.id)
                ? prev
                : [
                    ...prev,
                    {
                      id: sc.id,
                      user: sc.senderUsername,
                      text:
                        sc.kind === 'sticker'
                          ? `${sc.stickerEmoji || '🎁'} [SUPER STICKER: ${sc.stickerLabel}] ${sc.text}`
                          : `🔥 [SUPER CHAT • ${sc.spCost} SP] ${sc.text}`,
                      badge: sc.kind === 'sticker' ? 'Sticker 50 SP' : 'Super Chat 50 SP',
                    },
                  ],
            );
          } else if (msg.type === 'membership:created' && msg.membership) {
            const mem = msg.membership as FismChannelMembership;
            setChannelMemberships((prev) => {
              const next = prev.some((m) => m.id === mem.id) ? prev : [mem, ...prev];
              try {
                localStorage.setItem('fism_channel_memberships_v1', JSON.stringify(next));
              } catch {
                // ignore
              }
              return next;
            });
          } else if (msg.type === 'collab:accepted' && msg.postId && msg.collaboratorUid) {
            setPosts((prev) =>
              prev.map((p) =>
                p.id === msg.postId
                  ? {
                      ...p,
                      taggedCollaborators: (p.taggedCollaborators || []).map((tc) =>
                        tc.uid === msg.collaboratorUid
                          ? { ...tc, status: 'accepted' as const }
                          : tc,
                      ),
                    }
                  : p,
              ),
            );
          } else if (msg.type === 'sub_ids:updated' && msg.account) {
            const updatedAcc = msg.account as FismSubAccount;
            setSubAccounts((prev) => {
              const exists = prev.some((a) => a.id === updatedAcc.id);
              const next = exists
                ? prev.map((a) => (a.id === updatedAcc.id ? updatedAcc : a))
                : [...prev, updatedAcc];
              try {
                localStorage.setItem('fism_user_unlimited_ids', JSON.stringify(next));
              } catch {
                // ignore
              }
              return next;
            });
          } else if (
            (msg.type === 'follow_request:created' || msg.type === 'follow_request:updated') &&
            msg.request
          ) {
            const reqObj = msg.request as FismPrivateFollowRequest;
            setFollowRequests((prev) => {
              const exists = prev.some((r) => r.id === reqObj.id);
              return exists ? prev.map((r) => (r.id === reqObj.id ? reqObj : r)) : [reqObj, ...prev];
            });
          } else if (msg.type === 'milestones:updated' && msg.milestone) {
            const ms = msg.milestone as FismUserMilestoneState;
            if (ms.accountId === activeIdentityUid) {
              setUserMilestone(ms);
            }
          } else if (msg.type === 'founder_gift:updated' && msg.claim) {
            const cl = msg.claim as FismFounderGiftClaim;
            setAdminFounderGiftClaims((prev) => [cl, ...prev.filter((c) => c.id !== cl.id)]);
            if (cl.userId === activeIdentityUid) {
              setFounderGiftClaims((prev) => [cl, ...prev.filter((c) => c.id !== cl.id)]);
            }
          }
        } catch {
          // ignore malformed event
        }
      };
    } catch {
      // ignore ws init issues
    }

    return () => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
      communityWsRef.current = null;
    };
  }, [activeIdentityUid, myProfile.username]);

  const liveCreatorUsersDirectory = useMemo<FismLiveCreatorPermissionRecord[]>(() => {
    const map = new Map<string, FismLiveCreatorPermissionRecord>();
    map.set(activeIdentityUid, {
      uid: activeIdentityUid,
      username: myProfile.username,
      displayName: myProfile.displayName,
      avatarUrl: myProfile.avatarUrl,
      canAccessLiveCreatorChat: Boolean(
        liveCreatorAccessMap[activeIdentityUid] ?? hasLiveCreatorAccess,
      ),
    });
    creators.forEach((c) => {
      map.set(c.uid, {
        uid: c.uid,
        username: c.username,
        displayName: c.displayName,
        avatarUrl: c.avatarUrl,
        canAccessLiveCreatorChat: Boolean(liveCreatorAccessMap[c.uid]),
      });
    });
    adminUserDossiers.forEach((d) => {
      if (!map.has(d.uid)) {
        map.set(d.uid, {
          uid: d.uid,
          username: d.username,
          displayName: d.displayName,
          avatarUrl: d.avatarUrl,
          canAccessLiveCreatorChat: Boolean(liveCreatorAccessMap[d.uid]),
        });
      }
    });
    return Array.from(map.values());
  }, [
    activeIdentityUid,
    myProfile,
    creators,
    adminUserDossiers,
    liveCreatorAccessMap,
    hasLiveCreatorAccess,
  ]);

  const handleGrantLiveCreatorAccess = async (
    userRec: FismLiveCreatorPermissionRecord,
    grant: boolean,
  ) => {
    setLiveCreatorAccessMap((prev) => ({ ...prev, [userRec.uid]: grant }));
    const isMe =
      userRec.uid === activeIdentityUid ||
      userRec.username.toLowerCase() === myProfile.username.toLowerCase();
    if (isMe) {
      setHasLiveCreatorAccess(grant);
    }

    try {
      const res = await fetch('/api/admin/live-creator-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: userRec.uid,
          username: userRec.username,
          displayName: userRec.displayName,
          avatarUrl: userRec.avatarUrl,
          canAccess: grant,
          grantedBy: currentUser?.uid || 'FISM_ADMIN',
        }),
      });
      if (res.ok && isMe && grant) {
        const qs = new URLSearchParams({
          uid: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
        });
        fetch(`/api/community/state?${qs.toString()}`)
          .then((r) => (r.ok ? r.json() : null))
          .then((d) => {
            if (d?.liveCreatorRoom) setLiveCreatorRoom(d.liveCreatorRoom);
          })
          .catch(() => {});
      }
    } catch {
      // ignore
    }

    if (auth.currentUser?.emailVerified) {
      try {
        const cleanHandle =
          (userRec.username || 'fism_user')
            .replace(/[^a-zA-Z0-9_-]/g, '_')
            .slice(0, 40) || 'fism_user';
        await setDoc(doc(db, 'liveCreatorAccess', userRec.uid), {
          uid: userRec.uid,
          username: cleanHandle.length >= 2 ? cleanHandle : `${cleanHandle}_u`,
          canAccessLiveCreatorChat: grant,
          grantedBy: auth.currentUser.uid,
          grantedAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Firestore liveCreatorAccess sync skipped:', err);
      }
    }

    triggerToast(
      grant
        ? `✅ Unlocked Live Creator Chat for @${userRec.username}!`
        : `🔒 Revoked Live Creator Chat access from @${userRec.username}.`,
    );
  };

  const handleCreateCommunityRoom = async (payload: {
    name: string;
    description: string;
    privacy: 'public' | 'private';
  }) => {
    const mutualIds = creators.filter((c) => c.isConnected).map((c) => c.uid);
    const res = await fetch('/api/community/rooms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: payload.name,
        description: payload.description,
        privacy: payload.privacy,
        creatorId: activeIdentityUid,
        creatorUsername: myProfile.username,
        creatorDisplayName: myProfile.displayName,
        creatorAvatar: myProfile.avatarUrl,
        mutualFollowerIds: mutualIds,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data?.error || 'Could not create community room.');
    }
    if (data.room) {
      setCommunityRooms((prev) =>
        prev.some((r) => r.id === data.room.id) ? prev : [data.room, ...prev],
      );
      triggerToast(`🔥 Created ${payload.privacy.toUpperCase()} community "${data.room.name}"!`);
    }
  };

  const handleJoinCommunityRoom = async (room: FismCommunityRoom): Promise<boolean> => {
    const creator = creators.find((c) => c.uid === room.creatorId);
    const isMutual =
      room.creatorId === activeIdentityUid ||
      room.memberIds.includes(activeIdentityUid) ||
      room.mutualFollowerIds.includes(activeIdentityUid) ||
      Boolean(creator?.isConnected && room.creatorId === 'creator_arian');

    const res = await fetch(`/api/community/rooms/${room.id}/join`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        uid: activeIdentityUid,
        isMutualFollower: isMutual,
      }),
    });
    const data = await res.json();
    if (!res.ok || !data?.allowed) {
      triggerToast(
        data?.error ||
          '🔒 Join Blocked: Mutual follow required to enter or chat in this community.',
      );
      return false;
    }
    if (data.room) {
      setCommunityRooms((prev) => prev.map((r) => (r.id === room.id ? data.room : r)));
    }
    triggerToast(`✅ Joined "${room.name}"! Group chat & calling unlocked.`);
    return true;
  };

  const handleSendCommunityMessage = async (roomId: string, text: string) => {
    const room =
      communityRooms.find((r) => r.id === roomId) ||
      (liveCreatorRoom?.id === roomId ? liveCreatorRoom : undefined);
    const creator = creators.find((c) => c.uid === room?.creatorId);
    const isMutual =
      room?.creatorId === activeIdentityUid ||
      room?.memberIds.includes(activeIdentityUid) ||
      Boolean(
        creator?.isConnected &&
          (room?.mutualFollowerIds.includes(activeIdentityUid) || room?.creatorId === 'creator_arian'),
      );

    const res = await fetch(`/api/community/rooms/${roomId}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        senderId: activeIdentityUid,
        senderUsername: myProfile.username,
        senderDisplayName: myProfile.displayName,
        senderAvatar: myProfile.avatarUrl,
        text,
        isMutualFollower: isMutual,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      triggerToast(data?.error || 'Could not send message.');
      return;
    }
    if (data.message) {
      setCommunityMessagesByRoom((prev) => {
        const existing = prev[roomId] || [];
        if (existing.some((m) => m.id === data.message.id)) return prev;
        return { ...prev, [roomId]: [...existing, data.message] };
      });
    }
  };

  const acquireGroupCallStream = async (withVideo: boolean): Promise<MediaStream | null> => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: withVideo,
      });
      localGroupCallStreamRef.current = stream;
      setLocalGroupCallStream(stream);
      return stream;
    } catch {
      if (withVideo) {
        try {
          const audioOnly = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
          localGroupCallStreamRef.current = audioOnly;
          setLocalGroupCallStream(audioOnly);
          return audioOnly;
        } catch {
          return null;
        }
      }
      return null;
    }
  };

  const handleStartGroupCall = async (room: FismCommunityRoom, callMode: 'audio' | 'video') => {
    await acquireGroupCallStream(callMode === 'video');

    const callId = `gcall_${Date.now()}`;
    const optimisticCall: FismActiveGroupCall = {
      callId,
      roomId: room.id,
      roomName: room.name,
      roomType: room.roomType,
      mode: callMode,
      initiatorId: activeIdentityUid,
      initiatorName: myProfile.displayName,
      initiatorAvatar: myProfile.avatarUrl,
      participants: [
        {
          uid: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
          hasVideo: callMode === 'video',
          hasAudio: true,
          joinedAt: new Date().toLocaleTimeString(),
        },
      ],
      startedAt: new Date().toLocaleTimeString(),
    };
    setActiveGroupCalls((prev) => ({ ...prev, [room.id]: optimisticCall }));

    if (communityWsRef.current?.readyState === WebSocket.OPEN) {
      communityWsRef.current.send(
        JSON.stringify({
          type: 'call:start',
          roomId: room.id,
          mode: callMode,
          callerUid: activeIdentityUid,
          callerUsername: myProfile.username,
          callerName: myProfile.displayName,
          callerAvatar: myProfile.avatarUrl,
        }),
      );
    }

    fetch(`/api/community/rooms/${room.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        senderId: activeIdentityUid,
        senderUsername: myProfile.username,
        senderDisplayName: myProfile.displayName,
        senderAvatar: myProfile.avatarUrl,
        text: `Started a live Group ${callMode === 'video' ? 'Video' : 'Voice'} Call — ringing active members!`,
        messageType: 'call_event',
        isMutualFollower: true,
      }),
    }).catch(() => {});

    triggerToast(`📞 Ringing members in "${room.name}" — Dynamic Call Grid active!`);
  };

  const handleAnswerGroupCall = async (
    roomId: string,
    hasVideo: boolean,
    hasAudio: boolean,
  ) => {
    setIncomingGroupCallRing(null);
    await acquireGroupCallStream(hasVideo);

    setActiveGroupCalls((prev) => {
      const existing = prev[roomId];
      if (!existing) return prev;
      if (existing.participants.some((p) => p.uid === activeIdentityUid)) return prev;
      return {
        ...prev,
        [roomId]: {
          ...existing,
          participants: [
            ...existing.participants,
            {
              uid: activeIdentityUid,
              username: myProfile.username,
              displayName: myProfile.displayName,
              avatarUrl: myProfile.avatarUrl,
              hasVideo,
              hasAudio,
              joinedAt: new Date().toLocaleTimeString(),
            },
          ],
        },
      };
    });

    if (communityWsRef.current?.readyState === WebSocket.OPEN) {
      communityWsRef.current.send(
        JSON.stringify({
          type: 'call:answer',
          roomId,
          uid: activeIdentityUid,
          username: myProfile.username,
          displayName: myProfile.displayName,
          avatarUrl: myProfile.avatarUrl,
          hasVideo,
          hasAudio,
        }),
      );
    }

    triggerToast('🎥 Answered group call & snapped into the live call grid!');
  };

  const handleToggleGroupCallMedia = (roomId: string, hasVideo: boolean, hasAudio: boolean) => {
    if (localGroupCallStreamRef.current) {
      localGroupCallStreamRef.current.getVideoTracks().forEach((t) => {
        t.enabled = hasVideo;
      });
      localGroupCallStreamRef.current.getAudioTracks().forEach((t) => {
        t.enabled = hasAudio;
      });
    }
    setActiveGroupCalls((prev) => {
      const existing = prev[roomId];
      if (!existing) return prev;
      return {
        ...prev,
        [roomId]: {
          ...existing,
          participants: existing.participants.map((p) =>
            p.uid === activeIdentityUid ? { ...p, hasVideo, hasAudio } : p,
          ),
        },
      };
    });
    if (communityWsRef.current?.readyState === WebSocket.OPEN) {
      communityWsRef.current.send(
        JSON.stringify({
          type: 'call:toggle_media',
          roomId,
          uid: activeIdentityUid,
          hasVideo,
          hasAudio,
        }),
      );
    }
  };

  const handleLeaveGroupCall = (roomId: string) => {
    cleanupAllGroupCallMedia();
    setActiveGroupCalls((prev) => {
      const existing = prev[roomId];
      if (!existing) return prev;
      const remaining = existing.participants.filter((p) => p.uid !== activeIdentityUid);
      if (remaining.length === 0) {
        const next = { ...prev };
        delete next[roomId];
        return next;
      }
      return { ...prev, [roomId]: { ...existing, participants: remaining } };
    });
    if (communityWsRef.current?.readyState === WebSocket.OPEN) {
      communityWsRef.current.send(
        JSON.stringify({
          type: 'call:leave',
          roomId,
          uid: activeIdentityUid,
        }),
      );
    }
    triggerToast('Left the live group call.');
  };

  // CSS Filter helper for Shorts Editor
  const getFilterCssClass = (
    filter: 'none' | 'flameWarm' | 'cyberNeon' | 'tealOrange' | 'bwContrast' | 'goldenHour',
  ) => {
    switch (filter) {
      case 'flameWarm':
        return 'saturate-150 contrast-110 sepia-[.15]';
      case 'cyberNeon':
        return 'hue-rotate-30 saturate-200 contrast-125';
      case 'tealOrange':
        return 'contrast-125 saturate-150';
      case 'bwContrast':
        return 'grayscale contrast-150';
      case 'goldenHour':
        return 'sepia-[.35] saturate-150 brightness-105';
      default:
        return '';
    }
  };

  // Render any Post Card in Flame Feed / Circle Feed / My Hearth
  const renderPostCard = (post: FismPostItem) => {
    const creator = creators.find((c) => c.uid === post.authorId);
    const isSubscriberLocked =
      post.visibility === 'subscribers' &&
      post.authorId !== myProfile.uid &&
      !creator?.isFuelledUp;
    const isPlayableVid = isRealPlayableVideo(post.mediaUrl, post.isRealVideo);
    const authorMilestone = getAuthorMilestoneInfo(post.authorId);
    const authorHasRed = Boolean(post.authorHasRedTick || authorMilestone.hasRedTick);

    return (
      <article key={post.id} className="fism-card overflow-hidden transition-all mb-5">
        {/* Card Header */}
        <div className="p-4 sm:p-5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={post.authorAvatar}
              alt={post.authorDisplayName}
              onClick={() => {
                if (!requireAuth('View Creator Profile')) return;
                setViewedProfileId(post.authorId);
                setActiveScreen('myHearth');
              }}
              className={`w-11 h-11 rounded-full object-cover cursor-pointer shrink-0 ${
                getProfileFrameClasses(authorMilestone.frame) || 'ring-2 ring-[#FF5722]'
              }`}
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  onClick={() => {
                    if (!requireAuth('View Creator Profile')) return;
                    setViewedProfileId(post.authorId);
                    setActiveScreen('myHearth');
                  }}
                  className="font-bold text-sm sm:text-base hover:text-[#FF5722] transition-colors truncate"
                >
                  {post.authorDisplayName}
                </button>
                {post.authorVerified && (
                  <CheckCircle2 className="w-4 h-4 text-[#2563EB] fill-[#2563EB]/15 shrink-0" />
                )}
                {authorHasRed && (
                  <FismRedMilestoneTick
                    size="sm"
                    onClick={() =>
                      openMilestoneJourneyForUser({
                        accountId: post.authorId,
                        username: post.authorUsername,
                        displayName: post.authorDisplayName,
                        avatarUrl: post.authorAvatar,
                      })
                    }
                  />
                )}
                {(post.authorVipGoldBadge || authorMilestone.vipGoldBadge) && (
                  <FismVipGoldChatBadge />
                )}
                <span className="text-xs text-[#52607A] truncate">@{post.authorUsername}</span>
                {(() => {
                  const acceptedCollabs = (post.taggedCollaborators || []).filter(
                    (tc) => tc.status === 'accepted',
                  );
                  if (acceptedCollabs.length === 0) return null;
                  return (
                    <button
                      type="button"
                      onClick={() => setCollabFollowTargetPost(post)}
                      className="px-2 py-0.5 rounded-full bg-[#7C3AED]/15 text-[#7C3AED] border border-[#7C3AED]/30 text-[10px] font-extrabold hover:bg-[#7C3AED]/25"
                    >
                      + {acceptedCollabs.length} collab{acceptedCollabs.length > 1 ? 's' : ''} (
                      {acceptedCollabs.map((c) => `@${c.username}`).join(', ')})
                    </button>
                  );
                })()}
                {post.viewsCount >= 1_000_000 && (
                  <span className="px-2 py-0.5 text-[10px] font-extrabold rounded-full bg-[#FF5722] text-white">
                    🔥 {(post.viewsCount / 1_000_000).toFixed(2)}M+ VIRAL
                  </span>
                )}
                {post.isPremiumCreator && (
                  <span className="px-2 py-0.5 text-[10px] font-extrabold rounded-full bg-[#FFB300] text-[#101426] flex items-center gap-0.5">
                    <Crown className="w-3 h-3" /> PREMIUM
                  </span>
                )}
                {post.visibility === 'subscribers' && (
                  <span className="px-2 py-0.5 text-[11px] font-bold rounded bg-[#F59E0B] text-white">
                    Fuelers Only
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-[#52607A] mt-0.5 flex-wrap">
                <span>{post.createdAt}</span>
                <span>•</span>
                <span className="font-bold text-[#151B2B] dark:text-slate-300">
                  {post.viewsCount.toLocaleString()} views
                </span>
                {post.location && (
                  <>
                    <span>•</span>
                    <span className="inline-flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-[#FF5722]" />
                      {post.location}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Right Header Actions: Connect + More Menu */}
          <div className="flex items-center gap-2 relative shrink-0">
            {(() => {
              const hasAcceptedCollabs = (post.taggedCollaborators || []).some(
                (tc) => tc.status === 'accepted',
              );
              if (hasAcceptedCollabs) {
                return (
                  <button
                    onClick={() => setCollabFollowTargetPost(post)}
                    className="fism-btn-primary px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1"
                  >
                    <Users className="w-3.5 h-3.5" /> Connect Collab
                  </button>
                );
              }
              if (post.authorId !== myProfile.uid && creator) {
                return (
                  <button
                    onClick={() => handleToggleConnectCreator(creator.uid)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      creator.isConnected
                        ? 'bg-[#EEF3FB] text-[#172033] border border-[#D8E1F0]'
                        : 'fism-btn-primary'
                    }`}
                  >
                    {creator.isConnected ? 'Flames' : 'Connect'}
                  </button>
                );
              }
              return null;
            })()}

            <button
              onClick={() => setOpenMenuPostId((prev) => (prev === post.id ? null : post.id))}
              aria-label="More Options"
              className="p-2 rounded-lg hover:bg-[#F3F6FC] dark:hover:bg-slate-800 text-[#52607A]"
            >
              <MoreHorizontal className="w-5 h-5" />
            </button>

            {openMenuPostId === post.id && (
              <div className="absolute right-0 top-11 w-52 fism-card shadow-xl z-30 py-1.5 text-sm">
                <button
                  onClick={() => {
                    if (!requireAuth('Edit Post')) return;
                    setEditingPost(post);
                    setOpenMenuPostId(null);
                  }}
                  className="w-full px-4 py-2 text-left flex items-center gap-2.5 hover:bg-[#F3F6FC] dark:hover:bg-slate-800"
                >
                  <Edit3 className="w-4 h-4 text-[#2563EB]" /> Edit Post
                </button>
                <button
                  onClick={() => {
                    const kind =
                      post.postType === 'quickBurst'
                        ? 'burst'
                        : post.postType === 'video'
                          ? 'video'
                          : 'post';
                    const shareUrl = buildFismShareUrl(kind, post.id);
                    void shareFismLink({
                      title: post.title,
                      text: post.caption || `Watch ${post.title} on FISM`,
                      url: shareUrl,
                      triggerToast,
                    });
                    setOpenMenuPostId(null);
                  }}
                  className="w-full px-4 py-2 text-left flex items-center gap-2.5 hover:bg-[#F3F6FC] dark:hover:bg-slate-800"
                >
                  <Copy className="w-4 h-4 text-[#7C3AED]" /> Copy Link
                </button>
                <button
                  onClick={() => {
                    handleToggleAshStash(post.id);
                    setOpenMenuPostId(null);
                  }}
                  className="w-full px-4 py-2 text-left flex items-center gap-2.5 hover:bg-[#F3F6FC] dark:hover:bg-slate-800"
                >
                  <Bookmark className="w-4 h-4 text-[#F59E0B]" />{' '}
                  {post.isStashed ? 'Remove from AshStash' : 'Save to AshStash'}
                </button>
                <button
                  onClick={() => {
                    setSmotherTarget({
                      id: post.id,
                      label: post.title,
                      type: post.postType === 'video' ? 'video' : 'post',
                    });
                    setOpenMenuPostId(null);
                  }}
                  className="w-full px-4 py-2 text-left flex items-center gap-2.5 hover:bg-[#F3F6FC] dark:hover:bg-slate-800 text-[#F59E0B]"
                >
                  <Flag className="w-4 h-4" /> Smother (Report)
                </button>
                {creator && (
                  <button
                    onClick={() => {
                      setExtinguishTargetCreator(creator);
                      setOpenMenuPostId(null);
                    }}
                    className="w-full px-4 py-2 text-left flex items-center gap-2.5 hover:bg-[#F3F6FC] dark:hover:bg-slate-800 text-[#DC2626]"
                  >
                    <Ban className="w-4 h-4" /> Extinguish (@{creator.username})
                  </button>
                )}
                <button
                  onClick={() => handleDeletePost(post.id)}
                  className="w-full px-4 py-2 text-left flex items-center gap-2.5 hover:bg-[#F3F6FC] dark:hover:bg-slate-800 text-[#DC2626] font-semibold"
                >
                  <Trash2 className="w-4 h-4" /> Delete Post
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Post Title, Caption, Transcript & Voice Dubbing */}
        <div className="px-4 sm:px-5 pb-3">
          {post.title && <h3 className="font-bold text-base sm:text-lg mb-1">{post.title}</h3>}
          <p className="text-sm sm:text-[15px] leading-relaxed whitespace-pre-line break-words">
            {post.caption}
          </p>

          {/* Generated AI Music Audio Player if present */}
          {post.generatedMusicUrl && (
            <div className="mt-2.5 p-2.5 rounded-xl bg-[#F5F7FF] dark:bg-slate-800 border border-[#7C3AED] flex items-center gap-3">
              <Music className="w-5 h-5 text-[#7C3AED] shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-xs font-extrabold text-[#7C3AED]">
                  AI Generated Music Track (Lyria 3)
                </div>
                <audio src={post.generatedMusicUrl} controls className="w-full h-8 mt-1" />
              </div>
            </div>
          )}

          {/* Connected Another Video Card inside Post / Video Description */}
          {post.connectedVideo && (
            <button
              type="button"
              onClick={() => handleOpenConnectedVideo(post.connectedVideo!)}
              className="mt-2.5 w-full p-2.5 rounded-xl bg-[#0284C7]/10 hover:bg-[#0284C7]/20 border border-[#0284C7]/45 flex items-center justify-between gap-3 text-left transition-all"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <img
                  src={post.connectedVideo.thumbnailUrl}
                  alt={post.connectedVideo.title}
                  className="w-14 h-10 rounded-lg object-cover border border-[#0284C7]/40 shrink-0"
                />
                <div className="min-w-0">
                  <div className="text-[10px] font-extrabold uppercase text-[#0284C7] flex items-center gap-1">
                    <Link2 className="w-3 h-3" /> Connected{' '}
                    {post.connectedVideo.postType === 'quickBurst' ? 'Quick Burst' : 'Main Blast'}
                  </div>
                  <div className="text-xs font-bold truncate">{post.connectedVideo.title}</div>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-lg bg-[#0284C7] text-white text-[11px] font-extrabold shrink-0">
                ▶ Watch
              </span>
            </button>
          )}

          {/* AI-Verified Shopping Link & Product Photo inside Video Description (500+ Sparks Feature) */}
          {post.shoppingLinkUrl && (
            <div className="mt-2.5 p-3 rounded-xl bg-[#F0FDF4] dark:bg-emerald-950/40 border-2 border-[#16A34A] flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-3 min-w-0">
                {post.shoppingProductImage && (
                  <img
                    src={post.shoppingProductImage}
                    alt={post.shoppingProductTitle || 'Verified Shopping Product'}
                    className="w-12 h-12 rounded-xl object-cover border border-[#16A34A] shrink-0"
                  />
                )}
                <div className="min-w-0">
                  <div className="text-[10px] font-extrabold uppercase text-[#16A34A] flex items-center gap-1">
                    🤖 AI Verified Shopping Link • {post.shoppingStoreName || 'FISM Official Store'}
                  </div>
                  <div className="text-xs sm:text-sm font-extrabold truncate">
                    {post.shoppingProductTitle || 'Featured Creator Product'}
                  </div>
                  <div className="text-[11px] text-[#52607A] truncate">{post.shoppingLinkUrl}</div>
                </div>
              </div>
              <button
                onClick={() => navigateWithAuthGate('shoppingSection')}
                className="px-3 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold shrink-0 shadow"
              >
                🛍️ View Product
              </button>
            </div>
          )}

          {/* Video Transcript & Voice Translation Actions inside Description */}
          {(post.postType === 'video' || post.postType === 'quickBurst' || isPlayableVid) && (
            <div className="mt-2.5 flex items-center gap-2 flex-wrap">
              <button
                onClick={() => handleTranscribeVideoToDescription(post)}
                className="px-2.5 py-1 rounded-lg bg-[#2563EB]/10 text-[#2563EB] text-xs font-extrabold flex items-center gap-1 hover:bg-[#2563EB]/20"
              >
                <FileAudio className="w-3.5 h-3.5" />
                {transcribingVideoId === post.id
                  ? 'Transcribing Video to Text...'
                  : '📝 Transcribe Video to Text'}
              </button>
              <button
                onClick={() => {
                  setVrCinemaVideoUrl(isPlayableVid ? post.mediaUrl : '');
                  setVrCinemaVideoTitle(post.title);
                  navigateWithAuthGate('flame3DArena');
                }}
                className="px-2.5 py-1 rounded-lg bg-[#FF5722]/10 text-[#FF5722] text-xs font-extrabold flex items-center gap-1 hover:bg-[#FF5722]/20"
              >
                <Box className="w-3.5 h-3.5" /> 🥽 Watch in 3D VR Cinema
              </button>
            </div>
          )}

          {post.transcriptText && (
            <div className="mt-2.5 p-3 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#2563EB] text-xs space-y-1">
              <div className="font-extrabold text-[#2563EB] flex items-center justify-between">
                <span>📝 Video Audio-to-Text Transcript (Inside Description):</span>
                <button
                  onClick={() => navigator.clipboard?.writeText(post.transcriptText || '')}
                  className="underline text-[11px]"
                >
                  Copy Text
                </button>
              </div>
              <p className="whitespace-pre-line text-[#151B2B] dark:text-slate-200 leading-relaxed">
                {post.transcriptText}
              </p>
            </div>
          )}

          {post.translatedVoiceText && (
            <div className="mt-2 p-3 rounded-xl bg-purple-500/10 border border-[#7C3AED] text-xs space-y-1">
              <div className="font-extrabold text-[#7C3AED]">
                🌐 Dubbed Voice Translation ({post.translatedVoiceLang}):
              </div>
              <p className="text-[#151B2B] dark:text-slate-200">{post.translatedVoiceText}</p>
            </div>
          )}

          {post.hashtags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2">
              {post.hashtags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => {
                    if (!requireAuth('Search Hashtags')) return;
                    setGlobalSearchQuery(tag);
                    setActiveScreen('findFlame');
                  }}
                  className="text-xs font-semibold text-[#2563EB] hover:underline"
                >
                  {tag}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Media Display or Subscriber Lock */}
        {isSubscriberLocked ? (
          <div className="mx-4 sm:mx-5 mb-4 rounded-xl bg-gradient-to-br from-[#172033] via-[#1E1B4B] to-[#31102F] p-8 text-center text-white">
            <Crown className="w-10 h-10 text-[#F59E0B] mx-auto mb-3" />
            <h4 className="text-lg font-bold mb-1">Exclusive Circle Feed Content</h4>
            <p className="text-xs text-slate-300 max-w-md mx-auto mb-4">
              Fuel Up to {post.authorDisplayName} (${creator?.monthlyPrice || 4.99}/month) to unlock
              this exclusive post and all subscriber-only masterclasses.
            </p>
            {creator && (
              <button
                onClick={() => handleToggleFuelUpCreator(creator)}
                className="fism-btn-primary px-5 py-2.5 rounded-xl font-bold text-sm"
              >
                Fuel Up Now (${creator.monthlyPrice}/mo)
              </button>
            )}
          </div>
        ) : (
          post.postType !== 'text' && (
            <div className="relative bg-[#0F172A] overflow-hidden">
              {isPlayableVid ? (
                <video
                  src={post.mediaUrl}
                  controls
                  playsInline
                  loop
                  onTimeUpdate={(e) => {
                    const dur = e.currentTarget.duration;
                    const ct = e.currentTarget.currentTime;
                    if (dur && Number.isFinite(dur)) {
                      updateVideoWatchProgress(post.id, (ct / dur) * 100);
                    }
                    const secTick = Math.floor(ct);
                    if (secTick !== feedVideoLastTickRef.current[post.id]) {
                      feedVideoLastTickRef.current[post.id] = secTick;
                      recordDynamicWatchSecond(post);
                    }
                  }}
                  onEnded={() => markGiftVideoWatchCompleted(post.id)}
                  className="w-full max-h-[520px] object-contain bg-black"
                />
              ) : (
                <>
                  <img
                    src={post.mediaUrl || post.thumbnailUrl}
                    alt={post.title}
                    onDoubleClick={() => handleToggleSpark(post.id)}
                    className="w-full max-h-[520px] object-cover cursor-pointer"
                  />
                  {(post.postType === 'video' || post.postType === 'quickBurst') && (
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                      <button
                        onClick={() => {
                          if (post.postType === 'quickBurst') {
                            setActiveScreen('quickBurst');
                          } else {
                            setSelectedVideoPost(post);
                            setVideoPlaying(true);
                            navigateWithAuthGate('mainBlast');
                          }
                        }}
                        className="w-16 h-16 rounded-full fism-gradient-flame text-white flex items-center justify-center shadow-2xl hover:scale-105 transition-transform"
                      >
                        <Play className="w-7 h-7 fill-white ml-0.5" />
                      </button>
                      {post.duration && (
                        <span className="absolute bottom-3 right-3 px-2.5 py-1 rounded bg-black/80 text-white text-xs font-mono font-bold">
                          {post.duration} •{' '}
                          {post.postType === 'quickBurst' ? 'Quick Burst' : 'Main Blast'}
                        </span>
                      )}
                    </div>
                  )}
                </>
              )}
              {(() => {
                if (post.has_gift_drop === false) return null;
                const postDrop = getDropForPost(post.id);
                if (!postDrop) return null;
                return (
                  <div className="absolute top-3 left-3 z-20">
                    <FismVideoGiftDropOverlay
                      drop={postDrop}
                      currentUserId={activeIdentityUid}
                      compact
                      watchCompleted={Boolean(completedGiftVideoIds[post.id])}
                      watchProgressPct={videoWatchProgressByPostId[post.id] ?? 0}
                      onClaimDrop={handleClaimVideoGiftDrop}
                    />
                  </div>
                );
              })()}
            </div>
          )
        )}

        {/* Action Bar: Spark, Chatter, Spread, AshStash */}
        <div className="px-4 sm:px-5 py-3.5 border-t border-[#D8E1F0] dark:border-slate-800 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-1.5 sm:gap-2.5 flex-wrap">
            <button
              onClick={() => handleToggleSpark(post.id)}
              className={`px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all ${
                post.isSparked
                  ? 'fism-btn-primary'
                  : 'bg-[#F3F6FC] dark:bg-slate-800 text-[#172033] dark:text-white hover:bg-[#EEF3FB]'
              }`}
            >
              <Flame className={`w-4 h-4 ${post.isSparked ? 'fill-white' : 'text-[#FF5722]'}`} />
              <span>Spark</span>
              <span className="font-mono">{post.sparkCount.toLocaleString()}</span>
            </button>

            <button
              onClick={() => {
                if (!requireAuth('Comment (Chatter) on Posts')) return;
                setActiveChatterPostId((prev) => (prev === post.id ? null : post.id));
              }}
              className="px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 bg-[#F3F6FC] dark:bg-slate-800 text-[#172033] dark:text-white hover:bg-[#EEF3FB]"
            >
              <MessageCircle className="w-4 h-4 text-[#2563EB]" />
              <span>Chatter</span>
              <span className="font-mono">{post.chatterCount}</span>
            </button>

            <button
              onClick={() => {
                if (!requireAuth('Share (Spread) Video/Post')) return;
                setActiveSpreadPost(post);
              }}
              className="px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 bg-[#F3F6FC] dark:bg-slate-800 text-[#172033] dark:text-white hover:bg-[#EEF3FB]"
            >
              <Share2 className="w-4 h-4 text-[#7C3AED]" />
              <span>Spread</span>
              <span className="font-mono">{post.spreadCount}</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            {(post.postType === 'video' || post.postType === 'quickBurst') && (
              <button
                onClick={() => handleDownloadBrandedVideo(post)}
                disabled={downloadingBrandedPostId === post.id}
                title="Download with Permanent FISM Branded Watermark"
                className="px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 bg-[#F3F6FC] dark:bg-slate-800 text-[#172033] dark:text-white hover:bg-[#EEF3FB] disabled:opacity-60"
              >
                <Download className="w-4 h-4 text-[#E53935]" />
                <span>{downloadingBrandedPostId === post.id ? 'Burning...' : 'Download'}</span>
              </button>
            )}
            <button
              onClick={() => handleToggleAshStash(post.id)}
              className={`px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all ${
                post.isStashed
                  ? 'bg-[#F59E0B] text-white'
                  : 'bg-[#F3F6FC] dark:bg-slate-800 text-[#172033] dark:text-white'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${post.isStashed ? 'fill-white' : 'text-[#F59E0B]'}`} />
              <span>AshStash</span>
            </button>
          </div>
        </div>

        {/* Expandable Chatter (Comments) Drawer */}
        {activeChatterPostId === post.id && (
          <div className="px-4 sm:px-5 py-4 bg-[#F8FAFE] dark:bg-slate-900/90 border-t border-[#D8E1F0] dark:border-slate-800 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#52607A]">
              Chatter ({post.comments.length})
            </h4>
            {post.comments.length === 0 ? (
              <p className="text-xs text-[#52607A]">No Chatter yet. Start the conversation!</p>
            ) : (
              <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                {post.comments.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-start justify-between gap-2.5 bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-[#D8E1F0] dark:border-slate-700"
                  >
                    <div className="flex items-start gap-2.5">
                      <img
                        src={c.authorAvatar}
                        alt={c.authorUsername}
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold">@{c.authorUsername}</span>
                          {(() => {
                            const cmInfo = getAuthorMilestoneInfo(c.authorId);
                            const hasRed = Boolean(c.authorHasRedTick || cmInfo.hasRedTick);
                            const hasVip = Boolean(c.authorVipGoldBadge || cmInfo.vipGoldBadge);
                            return (
                              <>
                                {hasRed && (
                                  <FismRedMilestoneTick
                                    size="sm"
                                    onClick={() =>
                                      openMilestoneJourneyForUser({
                                        accountId: c.authorId,
                                        username: c.authorUsername,
                                        displayName: `@${c.authorUsername}`,
                                        avatarUrl: c.authorAvatar,
                                      })
                                    }
                                  />
                                )}
                                {hasVip && <FismVipGoldChatBadge />}
                              </>
                            );
                          })()}
                          {c.isAutoBotReply && (
                            <span className="px-2 py-0.5 rounded-full bg-[#7C3AED] text-white text-[9px] font-extrabold inline-flex items-center gap-1">
                              <Bot className="w-2.5 h-2.5" /> Auto-Bot Link
                            </span>
                          )}
                          <span className="text-[11px] text-[#52607A]">{c.createdAt}</span>
                        </div>
                        <p className="text-xs sm:text-sm mt-0.5">{c.text}</p>
                        {c.isAutoBotReply && c.productLinkUrl && (
                          <a
                            href={c.productLinkUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="mt-1.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#16A34A] text-white text-[11px] font-extrabold shadow-sm hover:opacity-90"
                          >
                            <ShoppingBag className="w-3 h-3" />
                            <span>
                              {c.productTitle || 'Open Product'} ({c.productStoreName || 'Store'})
                            </span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() =>
                        setSmotherTarget({
                          id: c.id,
                          label: c.text.slice(0, 40),
                          type: 'comment',
                        })
                      }
                      title="Smother (Report Comment)"
                      className="text-xs text-[#52607A] hover:text-[#DC2626]"
                    >
                      <Flag className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {post.allowComments ? (
              <div className="flex gap-2 pt-1">
                <input
                  type="text"
                  value={newCommentText}
                  onChange={(e) => setNewCommentText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddChatterComment(post.id)}
                  placeholder="Add to Chatter..."
                  className="flex-1 px-3.5 py-2 rounded-xl border border-[#D8E1F0] dark:border-slate-700 bg-white dark:bg-slate-800 text-sm"
                />
                <button
                  onClick={() => handleAddChatterComment(post.id)}
                  className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-bold"
                >
                  Post Chatter
                </button>
              </div>
            ) : (
              <p className="text-xs text-[#D97706] font-medium">
                Chatter is disabled for this post by the creator.
              </p>
            )}
          </div>
        )}
      </article>
    );
  };

  const isCurrentSectionPremium = Boolean(sectionPremiumMap[activeScreen] && globalPremiumOn);
  const isSectionBlockedByPremiumGate =
    isCurrentSectionPremium &&
    !userHasBoughtPremium &&
    activeScreen !== 'fuelUp' &&
    activeScreen !== 'installApp' &&
    activeScreen !== 'flameMaps' &&
    activeScreen !== 'controlCore' &&
    activeScreen !== 'adminFileVault' &&
    activeScreen !== 'adminPanel';

  return (
    <FismMapsApiProvider>
      <div
        className={`h-screen w-full max-w-[100vw] overflow-hidden flex flex-col pt-16 ${
          fontSizeScale === 'large' ? 'text-[17px]' : 'text-base'
        } ${highContrast ? 'contrast-125' : ''} ${
          reducedMotion ? '*:transition-none *:animate-none' : ''
        } ${userMilestone.redCyberpunkMode ? 'fism-cyberpunk-red dark' : ''}`}
      >
        {gmpQuotaExceeded && (
          <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
            <span>
              Google Maps Platform quota reached. If you are the app owner, visit{' '}
              <a
                href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-semibold text-amber-950 hover:text-amber-800"
              >
                maps developer site
              </a>{' '}
              for instructions to update your account.
            </span>
          </div>
        )}
        {deepLinkFallbackBanner && (
          <div className="bg-gradient-to-r from-[#0F172A] via-[#1E1B4B] to-[#0F172A] border-b border-[#38BDF8]/40 text-white px-4 py-2 text-xs flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2 min-w-0">
              <Link2 className="w-4 h-4 text-[#38BDF8] shrink-0" />
              <span className="font-bold truncate">{deepLinkFallbackBanner.label}</span>
              <span className="hidden sm:inline text-[11px] text-slate-300 font-mono truncate">
                ({FISM_PUBLIC_APP_ORIGIN})
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setActiveScreen('installApp');
                  setDeepLinkFallbackBanner(null);
                }}
                className="px-2.5 py-1 rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white text-[11px] font-extrabold flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" /> Open in / Install FISM APK
              </button>
              <button
                type="button"
                onClick={() => setDeepLinkFallbackBanner(null)}
                className="p-1 rounded hover:bg-white/10"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      {/* REAL-TIME INCOMING / OUTGOING CALL RINGING NOTIFICATION OVERLAY */}
      {incomingRealtimeCall && (
        <div className="fixed top-20 right-4 left-4 sm:left-auto sm:w-96 z-[85] rounded-2xl bg-gradient-to-r from-[#101426] via-[#1E1B4B] to-[#0F172A] border-2 border-[#16A34A] text-white p-4 shadow-2xl animate-bounce">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="relative shrink-0">
                <img
                  src={incomingRealtimeCall.callerAvatar}
                  alt={incomingRealtimeCall.callerName}
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-[#16A34A]"
                />
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-[#16A34A] animate-ping" />
              </div>
              <div className="min-w-0">
                <span className="px-2 py-0.5 rounded-full bg-[#16A34A] text-white text-[10px] font-extrabold uppercase">
                  {incomingRealtimeCall.mode === 'video'
                    ? '📹 Real-Time Video Call'
                    : '📞 Real-Time Voice Call'}
                </span>
                <div className="font-extrabold text-sm truncate mt-0.5">
                  {incomingRealtimeCall.callerName}
                </div>
                <div className="text-[11px] text-emerald-300 font-mono truncate">
                  Ringing live • {incomingRealtimeCall.callerPhone}
                </div>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-3">
            <button
              onClick={() => {
                setActiveCallInfo({
                  name: incomingRealtimeCall.callerName,
                  avatar: incomingRealtimeCall.callerAvatar,
                  phone: incomingRealtimeCall.callerPhone,
                  mode: incomingRealtimeCall.mode,
                });
                setIncomingRealtimeCall(null);
                triggerToast(`Connected live call with ${incomingRealtimeCall.callerName}`);
              }}
              className="py-2 rounded-xl bg-[#16A34A] hover:bg-emerald-500 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-lg"
            >
              <Phone className="w-3.5 h-3.5" /> Accept Call
            </button>
            <button
              onClick={() => {
                setIncomingRealtimeCall(null);
                setActiveCallInfo(null);
                triggerToast('Call declined.');
              }}
              className="py-2 rounded-xl bg-[#DC2626] hover:bg-red-500 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-lg"
            >
              <X className="w-3.5 h-3.5" /> Decline
            </button>
          </div>
        </div>
      )}

      {/* REAL-TIME PUSH NOTIFICATION FLOATING BANNER */}
      {realtimePushBanner && (
        <div
          onClick={() => {
            if (realtimePushBanner.targetScreen) {
              setActiveScreen(realtimePushBanner.targetScreen);
            }
            setRealtimePushBanner(null);
          }}
          className="fixed top-20 left-1/2 -translate-x-1/2 z-[80] w-[92vw] max-w-md rounded-2xl bg-[#101426]/95 border-2 border-[#FF5722] text-white p-3.5 shadow-2xl flex items-center justify-between gap-3 cursor-pointer backdrop-blur-md"
        >
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={realtimePushBanner.actorAvatar}
              alt={realtimePushBanner.actorName}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-[#FFB300] shrink-0"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="px-2 py-0.5 rounded bg-[#FF5722] text-white text-[9px] font-extrabold uppercase">
                  🔔 Real-Time Alert
                </span>
                <span className="text-[10px] text-[#FFB300] font-mono">Just now</span>
              </div>
              <p className="text-xs font-bold truncate mt-0.5">
                <span className="text-[#FFB300]">{realtimePushBanner.actorName}</span>{' '}
                {realtimePushBanner.message}
              </p>
            </div>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setRealtimePushBanner(null);
            }}
            className="p-1 rounded-lg bg-white/10 hover:bg-white/20 shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 fism-gradient-flame text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs sm:text-sm font-extrabold max-w-[92vw]">
          <Flame className="w-4 h-4 fill-white shrink-0" />
          <span className="truncate">{toastMessage}</span>
        </div>
      )}

      {/* TOP DESKTOP & MOBILE HEADER — STRICTLY FIXED AT TOP (NEVER SCROLLS AWAY) */}
      <header className="fixed top-0 left-0 right-0 z-50 h-16 bg-white/95 dark:bg-[#101426]/95 backdrop-blur-md border-b border-[#D8E1F0] dark:border-slate-800 px-2.5 sm:px-5 flex items-center justify-between gap-2 shadow-sm">
        {/* Left: 3-Line Hamburger Icon (Opens Slide-out Drawer) + FISM Brand Logo with Admin Custom Photo Background */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setMobileDrawerOpen(true)}
            aria-label="Open 3-Line Navigation Drawer"
            title="Open Full Menu, Settings, Shopping & 2D Games"
            className="p-2 rounded-xl fism-gradient-flame text-white shadow-sm hover:opacity-95"
          >
            <Menu className="w-5 h-5" />
          </button>

          <button
            onClick={() => navigateWithAuthGate('flameFeed')}
            className="flex items-center gap-2 text-left group"
          >
            <div
              className={`relative px-2.5 py-1.5 rounded-xl flex items-center gap-2 overflow-hidden border ${
                appLogoBgUrl
                  ? 'border-[#FFB300] shadow-md'
                  : 'border-transparent'
              }`}
              style={
                appLogoBgUrl
                  ? {
                      backgroundImage: `linear-gradient(to right, rgba(16,20,38,0.62), rgba(16,20,38,0.42)), url(${appLogoBgUrl})`,
                      backgroundSize: 'cover',
                      backgroundPosition: 'center',
                    }
                  : undefined
              }
            >
              <div
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl fism-gradient-flame flex items-center justify-center text-white shadow-md overflow-hidden relative shrink-0"
                style={
                  appLogoBgUrl
                    ? {
                        backgroundImage: `url(${appLogoBgUrl})`,
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                      }
                    : undefined
                }
              >
                {appLogoBgUrl && <div className="absolute inset-0 bg-black/25" />}
                <Flame className="w-4 h-4 sm:w-5 sm:h-5 fill-white relative z-10 drop-shadow" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span
                    className={`font-extrabold text-lg sm:text-xl tracking-tight ${
                      appLogoBgUrl
                        ? 'text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)]'
                        : 'text-[#151B2B] dark:text-white'
                    }`}
                  >
                    FISM
                  </span>
                  {globalPremiumOn && (
                    <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-[#FFB300] text-[#101426] flex items-center gap-0.5">
                      <Crown className="w-3 h-3" /> PRO
                    </span>
                  )}
                </div>
                <p
                  className={`hidden xl:block text-[10px] leading-none ${
                    appLogoBgUrl
                      ? 'text-amber-200 font-bold drop-shadow'
                      : 'text-[#52607A]'
                  }`}
                >
                  Flame Interactive Social Media
                </p>
              </div>
            </div>
          </button>
        </div>

        {/* Center: Global Find Flame Search Bar (High-Contrast Text Fix) */}
        <div className="flex-1 max-w-md mx-1">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-[#FF5722] absolute left-3 pointer-events-none" />
            <input
              type="text"
              value={globalSearchQuery}
              onChange={(e) => {
                setGlobalSearchQuery(e.target.value);
                if (isAuthenticated && activeScreen !== 'findFlame' && e.target.value.trim()) {
                  setActiveScreen('findFlame');
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  if (!isAuthenticated) {
                    setBlockedActionName('Global Search & Internal Sections');
                    setLoginGatePromptOpen(true);
                    return;
                  }
                  const trimmed = globalSearchQuery.trim();
                  if (trimmed) {
                    trackBehaviorSignal('search', [trimmed.toLowerCase()], 1);
                    if (!recentSearches.includes(trimmed)) {
                      setRecentSearches((prev) => [trimmed, ...prev.slice(0, 7)]);
                    }
                  }
                  setActiveScreen('findFlame');
                }
              }}
              onFocus={() => {
                if (!isAuthenticated) {
                  setBlockedActionName('Global Search & Internal Sections');
                  setLoginGatePromptOpen(true);
                  return;
                }
                if (activeScreen !== 'findFlame' && globalSearchQuery.trim()) {
                  setActiveScreen('findFlame');
                }
              }}
              placeholder="Search videos, creators, #hashtags..."
              className="w-full pl-9 pr-20 py-1.5 sm:py-2 rounded-xl bg-white dark:bg-[#1E293B] text-[#0F172A] dark:text-white placeholder:text-[#64748B] dark:placeholder:text-[#94A3B8] font-semibold border-2 border-[#CBD5E1] dark:border-slate-700 text-xs sm:text-sm focus:outline-none focus:border-[#FF5722] shadow-inner"
            />
            {globalSearchQuery && (
              <button
                type="button"
                onClick={() => setGlobalSearchQuery('')}
                title="Clear search"
                className="absolute right-14 p-1 rounded-full text-[#475569] dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={() => {
                if (!isAuthenticated) {
                  setBlockedActionName('Global Search & Internal Sections');
                  setLoginGatePromptOpen(true);
                  return;
                }
                const trimmed = globalSearchQuery.trim();
                if (trimmed) {
                  trackBehaviorSignal('search', [trimmed.toLowerCase()], 1);
                  if (!recentSearches.includes(trimmed)) {
                    setRecentSearches((prev) => [trimmed, ...prev.slice(0, 7)]);
                  }
                }
                navigateWithAuthGate('findFlame');
              }}
              className="absolute right-1 px-2.5 py-1 rounded-lg bg-[#FF5722] hover:bg-[#E64A19] text-white text-[11px] font-extrabold shadow-sm"
            >
              Find
            </button>
          </div>
        </div>

        {/* Right: Spark New, 2D Games, Shopping, Theme Switcher, Login Scene / Profile Avatar (NO Header Green Tick Button) */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            onClick={() => {
              if (!requireAuth('Upload Video / Spark New')) return;
              setSparkNewModalOpen(true);
            }}
            className="hidden md:inline-flex items-center gap-1.5 fism-btn-primary px-3.5 py-2 rounded-xl text-xs font-extrabold shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Spark New</span>
          </button>

          <button
            onClick={() => navigateWithAuthGate('coinLeaderboard')}
            title="Coin Wallet, 10k Pack & Global Leaderboard"
            className={`px-2.5 py-2 rounded-xl border text-xs font-extrabold flex items-center gap-1.5 tabular-nums ${
              activeScreen === 'coinLeaderboard'
                ? 'fism-btn-primary'
                : 'bg-[#FEF9C3] dark:bg-slate-800 border-[#FACC15] text-[#854D0E] dark:text-[#FACC15]'
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>{myWallet.coinBalance.toLocaleString()}</span>
          </button>

          <button
            onClick={() => navigateWithAuthGate('gameHub')}
            title="2D Game Hub"
            className={`p-2 rounded-xl border text-xs font-bold flex items-center gap-1 ${
              activeScreen === 'gameHub'
                ? 'fism-btn-primary'
                : 'bg-[#F1F5F9] dark:bg-slate-800 border-[#D8E1F0] dark:border-slate-700 text-[#16A34A]'
            }`}
          >
            <Gamepad2 className="w-4 h-4" />
            <span className="hidden lg:inline">2D Games</span>
          </button>

          <button
            onClick={() => navigateWithAuthGate('shoppingSection')}
            title="Shopping Section (Marketplace)"
            className={`p-2 rounded-xl border text-xs font-bold flex items-center gap-1 ${
              activeScreen === 'shoppingSection'
                ? 'fism-btn-primary'
                : 'bg-[#F1F5F9] dark:bg-slate-800 border-[#D8E1F0] dark:border-slate-700 text-[#FF5722]'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden lg:inline">Shop</span>
          </button>

          <button
            onClick={() => navigateWithAuthGate('installApp')}
            title="Install Official FISM Android APK"
            className={`px-2.5 py-2 rounded-xl border text-xs font-extrabold flex items-center gap-1.5 relative ${
              activeScreen === 'installApp'
                ? 'fism-btn-primary'
                : 'bg-[#EFF6FF] dark:bg-slate-800 border-[#93C5FD] dark:border-slate-700 text-[#2563EB] dark:text-[#60A5FA]'
            }`}
          >
            <Download className="w-4 h-4 shrink-0" />
            <span className="hidden sm:inline">Install APK</span>
            {apkRelease && (
              <span className="w-2 h-2 rounded-full bg-[#16A34A] shrink-0" title="APK Ready" />
            )}
          </button>

          <button
            onClick={() =>
              setThemeMode((prev) => (prev === 'light' ? 'dark' : 'light'))
            }
            title="Switch Theme"
            className="p-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700"
          >
            {themeMode === 'dark' ? (
              <Sun className="w-4 h-4 text-[#FFB300]" />
            ) : (
              <Moon className="w-4 h-4 text-[#151B2B]" />
            )}
          </button>

          {!isAuthenticated ? (
            <button
              onClick={() => {
                setBlockedActionName('Full Account Login');
                setLoginGatePromptOpen(true);
              }}
              className="px-3 py-2 rounded-xl fism-gradient-flame text-white text-xs font-extrabold flex items-center gap-1.5 shadow-md"
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>Login</span>
            </button>
          ) : (
            <button
              onClick={() => {
                setViewedProfileId(myProfile.uid);
                navigateWithAuthGate('myHearth');
              }}
              title="Open My Hearth Profile"
              className="flex items-center gap-1.5 p-1 pr-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 hover:border-[#FF5722]"
            >
              <img
                src={myProfile.avatarUrl}
                alt={myProfile.displayName}
                className="w-7 h-7 rounded-full object-cover ring-2 ring-[#FF5722]"
              />
              <span className="hidden sm:inline text-xs font-extrabold truncate max-w-[96px]">
                {myProfile.displayName}
              </span>
            </button>
          )}
          <button
            onClick={() => setPermissionsModalOpen(true)}
            title="App Permissions Manifest (AndroidManifest.xml)"
            className="px-2.5 py-1.5 rounded-xl bg-[#EEF3FB] dark:bg-slate-800 hover:bg-[#FF5722] hover:text-white text-xs font-extrabold flex items-center gap-1 transition-colors"
          >
            <Shield className="w-3.5 h-3.5 text-[#16A34A]" />
            <span className="hidden lg:inline">Permissions</span>
          </button>
        </div>
      </header>

      {/* APP HARDWARE PERMISSIONS REQUEST MODAL (AndroidManifest.xml & Browser Hardware Gate) */}
      {permissionsModalOpen && (
        <div className="fixed inset-0 z-[95] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="fism-card max-w-xl w-full p-6 border-2 border-[#FF5722] space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between gap-3 border-b border-[#D8E1F0] dark:border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl fism-gradient-flame text-white flex items-center justify-center shadow-lg">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <span className="px-2 py-0.5 rounded bg-[#16A34A] text-white text-[10px] font-extrabold uppercase">
                    AndroidManifest.xml • Hardware Permission Gate
                  </span>
                  <h2 className="text-lg font-extrabold mt-0.5">
                    FISM App Permissions Required
                  </h2>
                  <p className="text-xs text-[#52607A]">
                    काम शुरू करने से पहले ऐप को निम्नलिखित परमिशन्स (Camera, Mic, Screen Share,
                    Floating Window) की अनुमति दें: <strong>{pendingPermissionFeatureName}</strong>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setPermissionsModalOpen(false)}
                className="p-1.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2.5">
              {[
                {
                  key: 'camera' as const,
                  title: '📷 Camera Permission (android.permission.CAMERA)',
                  desc: 'Required for On Fire Live Broadcast, 3D Face Cam Head Tracking & Studio Capture.',
                },
                {
                  key: 'microphone' as const,
                  title: '🎙️ Microphone Permission (android.permission.RECORD_AUDIO)',
                  desc: 'Required for Live Voice Streaming, 3D Avatar Lip-Sync & Real-Time Calls.',
                },
                {
                  key: 'screenCapture' as const,
                  title: '🖥️ Screen Capture (FOREGROUND_SERVICE_MEDIA_PROJECTION)',
                  desc: 'Required for On Fire Gaming Live Real-Time Screen Sharing & HUD Optimizer.',
                },
                {
                  key: 'floatingOverlay' as const,
                  title: '🪟 Floating Window Overlay (SYSTEM_ALERT_WINDOW / OS PiP)',
                  desc: 'Required so Floating Gend & 3D Face Cam float over the entire screen even when app is cut.',
                },
                {
                  key: 'location' as const,
                  title: '📍 Location / GPS (android.permission.ACCESS_FINE_LOCATION)',
                  desc: 'Required for Shopping Marketplace Live Store Route & Turn-by-Turn GPS.',
                },
                {
                  key: 'notifications' as const,
                  title: '🔔 Real-Time Notifications (android.permission.POST_NOTIFICATIONS)',
                  desc: 'Required for Incoming Call Ringing Alerts, Admin Fuel Up & Withdrawal Updates.',
                },
              ].map((perm) => {
                const isGranted = appPermissions[perm.key];
                return (
                  <div
                    key={perm.key}
                    className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                      isGranted
                        ? 'border-[#16A34A] bg-emerald-50/40 dark:bg-emerald-950/20'
                        : 'border-[#D8E1F0] dark:border-slate-800 bg-[#F8FAFE] dark:bg-slate-900'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-extrabold">{perm.title}</div>
                      <div className="text-[11px] text-[#52607A]">{perm.desc}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const updated = { ...appPermissions, [perm.key]: !isGranted };
                        saveAppPermissions(updated);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-extrabold shrink-0 ${
                        isGranted
                          ? 'bg-[#16A34A] text-white'
                          : 'bg-[#FF5722] text-white'
                      }`}
                    >
                      {isGranted ? '✓ Allowed' : 'Allow'}
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="flex items-center justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={() => setPermissionsModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
              >
                Later
              </button>
              <button
                type="button"
                onClick={async () => {
                  const allGranted = {
                    camera: true,
                    microphone: true,
                    screenCapture: true,
                    floatingOverlay: true,
                    location: true,
                    notifications: true,
                  };
                  saveAppPermissions(allGranted);
                  try {
                    if ('Notification' in window && Notification.permission === 'default') {
                      await Notification.requestPermission();
                    }
                  } catch {
                    // ignore
                  }
                  setPermissionsModalOpen(false);
                  triggerToast(
                    '✅ All AndroidManifest.xml & Browser Hardware Permissions Granted!',
                  );
                  if (pendingPermissionActionRef.current) {
                    const fn = pendingPermissionActionRef.current;
                    pendingPermissionActionRef.current = null;
                    setTimeout(() => fn(), 80);
                  }
                }}
                className="flex-1 fism-btn-primary py-3 px-5 rounded-xl text-xs font-extrabold shadow-xl"
              >
                ✅ Allow All Permissions &amp; Continue
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Incoming Live Group Call Ring Notification (Community Chat / Live Creator Chat) */}
      {incomingGroupCallRing && (
        <div className="bg-gradient-to-r from-[#16A34A] via-[#059669] to-[#7C3AED] text-white px-4 py-2.5 text-xs font-extrabold flex items-center justify-between flex-wrap gap-3 shadow-xl animate-pulse">
          <div className="flex items-center gap-2.5">
            <PhoneCall className="w-5 h-5 shrink-0" />
            <span>
              🔔 INCOMING GROUP {incomingGroupCallRing.mode === 'video' ? 'VIDEO' : 'VOICE'} CALL
              in <strong>{incomingGroupCallRing.roomName}</strong> • Started by{' '}
              <strong>{incomingGroupCallRing.initiatorName}</strong>
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setActiveScreen(
                  incomingGroupCallRing.roomType === 'live_creator' && hasLiveCreatorAccess
                    ? 'liveCreatorChat'
                    : 'communityChat',
                );
                handleAnswerGroupCall(
                  incomingGroupCallRing.roomId,
                  incomingGroupCallRing.mode === 'video',
                  true,
                );
              }}
              className="px-3.5 py-1.5 rounded-lg bg-white text-[#065F46] font-black shadow flex items-center gap-1.5"
            >
              <PhoneCall className="w-3.5 h-3.5" /> Answer &amp; Snap to Grid
            </button>
            <button
              onClick={() => setIncomingGroupCallRing(null)}
              className="px-3 py-1.5 rounded-lg bg-red-600 text-white font-black flex items-center gap-1"
            >
              <PhoneOff className="w-3.5 h-3.5" /> Decline
            </button>
          </div>
        </div>
      )}

      {/* Guest Mode ("Nothing Login") Notice Banner when Unlogged */}
      {!isAuthenticated && (
        <div className="bg-gradient-to-r from-[#DC2626] via-[#FF5722] to-[#7C3AED] text-white px-4 py-2 text-xs font-extrabold flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 shrink-0" />
            <span>
              GUEST MODE (NOTHING LOGIN): You can ONLY watch Quick Burst (Shorts). Like, Comment,
              Share, Upload &amp; all other sections are locked until you Log In!
            </span>
          </div>
          <button
            onClick={() => {
              setBlockedActionName('Sign In to FISM');
              setLoginGatePromptOpen(true);
            }}
            className="px-3 py-1 rounded-lg bg-white text-[#101426] text-xs font-extrabold shadow"
          >
            Open Login Scene (Email / Google)
          </button>
        </div>
      )}

      {/* Active Section Premium Status Banner */}
      {isCurrentSectionPremium && (
        <div className="bg-gradient-to-r from-[#FF5722] via-[#E53935] to-[#7C3AED] text-white px-4 py-1.5 text-xs font-extrabold flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Crown className="w-4 h-4 text-[#FFB300] fill-[#FFB300]" />
            <span>
              {userHasBoughtPremium
                ? 'FISM PREMIUM UNLOCKED on this section • 8K HDR Streaming, Priority Visibility & AI Guard Enabled'
                : '🔒 FISM PREMIUM SECTION — Buy Premium (Fuel Up) to unlock and enter this section!'}
            </span>
          </div>
          {!userHasBoughtPremium ? (
            <button
              onClick={() => setActiveScreen('fuelUp')}
              className="px-3 py-0.5 rounded-lg bg-[#FFB300] text-[#101426] text-[11px] font-black shadow"
            >
              👑 Buy Premium
            </button>
          ) : (
            <span className="text-[11px] opacity-90">PRO Membership Active</span>
          )}
        </div>
      )}

      {/* Auth Error Notice */}
      {authError && (
        <div className="bg-[#DC2626] text-white px-4 py-2 text-xs font-semibold flex items-center justify-between">
          <span>Authentication notice: {authError}</span>
          <button onClick={() => setAuthError(null)} className="underline">
            Dismiss
          </button>
        </div>
      )}

      {/* 3-LINE HAMBURGER SLIDE-OUT NAVIGATION DRAWER */}
      {mobileDrawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/65"
            onClick={() => setMobileDrawerOpen(false)}
          />
          <aside className="relative w-80 max-w-[86vw] bg-white dark:bg-[#101426] h-full overflow-y-auto p-4 sm:p-5 flex flex-col justify-between z-10 border-r border-[#D8E1F0] dark:border-slate-800">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-[#D8E1F0] dark:border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl fism-gradient-flame flex items-center justify-center text-white">
                    <Flame className="w-5 h-5 fill-white" />
                  </div>
                  <div>
                    <div className="font-extrabold text-base">FISM Command Menu</div>
                    <div className="text-[11px] text-[#52607A]">
                      All Features, 2D Games, VR Cinema &amp; Settings
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setMobileDrawerOpen(false)}
                  className="p-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Isolated Profile IDs Quick Switcher (Password-Protected & Independent @Usernames) */}
              {isAuthenticated && (
                <div className="mt-3 p-3 rounded-xl bg-[#F5F7FF] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-extrabold text-[#52607A]">
                    <span>YOUR PROFILE IDs ({subAccounts.length} ISOLATED)</span>
                    <button
                      onClick={() => {
                        setSettingsSubTab('smart');
                        setActiveScreen('controlCore');
                        setMobileDrawerOpen(false);
                      }}
                      className="text-[#FF5722] hover:underline"
                    >
                      + Create / Security
                    </button>
                  </div>
                  <div className="space-y-1 max-h-44 overflow-y-auto">
                    {subAccounts.map((acc) => {
                      const isActiveId = acc.id === activeSubAccount?.id;
                      const isPublicAcc = acc.privacyMode === 'public' && acc.isAgeVerified;
                      return (
                        <button
                          key={acc.id}
                          onClick={() => {
                            setMobileDrawerOpen(false);
                            void handleRequestSwitchSubAccount(acc);
                          }}
                          className={`w-full px-2.5 py-1.5 rounded-lg flex items-center justify-between gap-2 text-xs font-bold ${
                            isActiveId
                              ? 'bg-[#FF5722] text-white'
                              : 'hover:bg-white dark:hover:bg-slate-800'
                          }`}
                        >
                          <span className="truncate flex items-center gap-1.5">
                            {acc.hasPassword && <Lock className="w-3 h-3 shrink-0 opacity-90" />}
                            <span className="truncate">
                              {acc.displayName} (@{acc.username})
                            </span>
                          </span>
                          <span className="text-[10px] opacity-90 shrink-0">
                            {isActiveId
                              ? 'Active'
                              : isPublicAcc
                                ? '🌐 Public'
                                : '🔒 Private'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Drawer Navigation List */}
              <nav className="mt-4 space-y-1">
                {primaryNavItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      navigateWithAuthGate(item.id);
                      setMobileDrawerOpen(false);
                    }}
                    className={`w-full px-3.5 py-2.5 rounded-xl flex items-center justify-between text-sm font-bold transition-all ${
                      activeScreen === item.id
                        ? 'fism-btn-primary'
                        : 'text-[#151B2B] dark:text-white hover:bg-[#F1F5F9] dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {item.icon}
                      <div className="text-left">
                        <div className="flex items-center gap-1.5">
                          <span>{item.label}</span>
                          {sectionPremiumMap[item.id] && globalPremiumOn && (
                            <Crown className="w-3.5 h-3.5 text-[#FFB300] fill-[#FFB300]" />
                          )}
                        </div>
                        <div
                          className={`text-[10px] font-normal ${
                            activeScreen === item.id ? 'text-white/90' : 'text-[#52607A]'
                          }`}
                        >
                          {item.sublabel}
                        </div>
                      </div>
                    </div>
                    {item.badge ? (
                      <span className="px-2 py-0.5 rounded-full text-xs bg-[#E53935] text-white">
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                ))}
              </nav>
            </div>

            <div className="mt-6 space-y-2">
              {/* Subtle Discreet System Vault Link inside Drawer Footer */}
              <button
                onClick={() => {
                  if (!requireAuth('Access Control Core')) return;
                  setSettingsSubTab('advanced');
                  setActiveScreen('controlCore');
                  setMobileDrawerOpen(false);
                }}
                className="w-full py-1.5 px-3 rounded-lg text-[11px] font-semibold text-[#52607A] hover:text-[#7C3AED] flex items-center justify-between opacity-75 hover:opacity-100"
              >
                <span className="flex items-center gap-1.5">
                  <Lock className="w-3 h-3" /> Advanced Core Vault
                </span>
                <span>•••</span>
              </button>

              <button
                onClick={() => {
                  setIsLoggedInSession(false);
                  handleCoolDownLogout();
                }}
                className="w-full px-4 py-2.5 rounded-xl bg-[#DC2626] text-white font-bold text-sm flex items-center justify-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Cool Down (Switch to Guest Mode)</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* MAIN 3-COLUMN DESKTOP WORKSPACE / RESPONSIVE MOBILE CONTAINER (INDEPENDENT SCROLLING) */}
      <div className="flex-1 min-h-0 max-w-[1600px] w-full mx-auto flex overflow-hidden">
        {/* LEFT DESKTOP SIDEBAR (> 950px) — LOCKED IN PLACE: NEVER SCROLLS WHEN MAIN PAGE SCROLLS */}
        <aside
          className={`hide-mobile-950 shrink-0 border-r border-[#D8E1F0] dark:border-slate-800 bg-white dark:bg-[#101426] p-3 flex flex-col justify-between h-full overflow-y-auto overscroll-contain transition-all ${
            sidebarCollapsed ? 'w-20' : 'w-64'
          }`}
        >
          <div className="space-y-1">
            <div className="flex items-center justify-between px-2 pb-2 mb-1 border-b border-[#D8E1F0] dark:border-slate-800">
              {!sidebarCollapsed && (
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#52607A]">
                  FISM Navigation
                </span>
              )}
              <button
                onClick={() => setSidebarCollapsed((c) => !c)}
                className="p-1.5 rounded-lg hover:bg-[#F1F5F9] dark:hover:bg-slate-800 text-[#52607A] mx-auto sm:mx-0"
              >
                {sidebarCollapsed ? (
                  <ChevronRight className="w-4 h-4" />
                ) : (
                  <ChevronLeft className="w-4 h-4" />
                )}
              </button>
            </div>

            {primaryNavItems.map((item) => (
              <button
                key={item.id}
                onClick={() => navigateWithAuthGate(item.id)}
                title={`${item.label} (${item.sublabel})`}
                className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-sm font-bold transition-all ${
                  activeScreen === item.id
                    ? 'fism-btn-primary shadow-sm'
                    : 'text-[#151B2B] dark:text-white hover:bg-[#F1F5F9] dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  {item.icon}
                  {!sidebarCollapsed && (
                    <div className="text-left leading-tight truncate">
                      <div className="flex items-center gap-1">
                        <span className="truncate">{item.label}</span>
                        {sectionPremiumMap[item.id] && globalPremiumOn && (
                          <Crown className="w-3 h-3 text-[#FFB300] fill-[#FFB300] shrink-0" />
                        )}
                      </div>
                      <div
                        className={`text-[10px] font-normal truncate ${
                          activeScreen === item.id ? 'text-white/85' : 'text-[#52607A]'
                        }`}
                      >
                        {item.sublabel}
                      </div>
                    </div>
                  )}
                </div>
                {!sidebarCollapsed && item.badge ? (
                  <span className="px-2 py-0.5 rounded-full text-[11px] bg-[#E53935] text-white">
                    {item.badge}
                  </span>
                ) : null}
              </button>
            ))}
          </div>

          <div className="pt-4 border-t border-[#D8E1F0] dark:border-slate-800 space-y-2">
            <button
              onClick={() => {
                if (!requireAuth('Upload Video / Spark New')) return;
                setSparkNewModalOpen(true);
              }}
              className="w-full fism-btn-primary py-2.5 px-3 rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 shadow-md"
            >
              <Plus className="w-5 h-5" />
              {!sidebarCollapsed && <span>Spark New (+)</span>}
            </button>

            <button
              onClick={() => {
                setIsLoggedInSession(false);
                handleCoolDownLogout();
              }}
              className="w-full py-2 px-3 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 hover:bg-[#DC2626] hover:text-white text-[#52607A] font-bold text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              {!sidebarCollapsed && <span>Cool Down</span>}
            </button>
          </div>
        </aside>

        {/* CENTER MAIN CONTENT AREA (SCROLLS INDEPENDENTLY WITHOUT MOVING SIDEBAR) */}
        <main className="flex-1 min-w-0 h-full overflow-y-auto overscroll-contain p-3 sm:p-6 pb-24 md:pb-10">
          {isSectionBlockedByPremiumGate ? (
            <div className="max-w-xl mx-auto my-8 fism-card p-6 sm:p-8 border-2 border-[#F59E0B] bg-gradient-to-br from-[#101426] via-[#1E1B4B] to-[#31102F] text-white space-y-5 shadow-2xl text-center">
              <div className="w-16 h-16 rounded-2xl bg-[#F59E0B]/20 border-2 border-[#F59E0B] flex items-center justify-center mx-auto shadow-lg">
                <Crown className="w-9 h-9 text-[#FFB300] fill-[#FFB300]" />
              </div>
              <div className="space-y-2">
                <span className="px-3 py-1 rounded-full bg-[#F59E0B] text-[#101426] text-xs font-black uppercase tracking-wider">
                  🔒 FISM Premium Required • PRO Section Locked
                </span>
                <h1 className="text-2xl font-extrabold mt-2">
                  Buy Premium to Enter This Section
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  आपने अभी तक <strong>FISM Premium (Fuel Up)</strong> बाय नहीं किया है। जब तक आप
                  प्रीमियम बाय नहीं करते, तब तक यह प्रीमियम सेक्शन (
                  <span className="text-[#FFB300] font-bold">{activeScreen}</span>) नहीं खुलेगा।
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white/10 border border-white/15 text-left space-y-2 text-xs">
                <div className="font-extrabold text-[#FFB300] flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" /> Fuel Up / Premium Membership Benefits:
                </div>
                <ul className="space-y-1 text-slate-200 list-disc list-inside">
                  <li>Unlock all PRO Sections (Main Blast 8K, On Fire Live, 3D VR Cinema, Games, Store)</li>
                  <li>Plans starting at ₹399 (1 Month) up to ₹3,599 (12 Months — 25% OFF)</li>
                  <li>Instant QR &amp; UPI Payment verification via Admin File</li>
                </ul>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={() => setActiveScreen('fuelUp')}
                  className="flex-1 py-3.5 px-5 rounded-xl bg-gradient-to-r from-[#FFB300] via-[#FF5722] to-[#E53935] text-white font-extrabold text-sm shadow-xl flex items-center justify-center gap-2"
                >
                  <Crown className="w-5 h-5 fill-white" /> Buy Premium Now (Open Fuel Up)
                </button>
                <button
                  onClick={() => setActiveScreen('flameFeed')}
                  className="py-3.5 px-5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs border border-white/20"
                >
                  ← Back to Home Feed
                </button>
              </div>
            </div>
          ) : (
            <>
          {/* SCREEN 1: FLAME FEED (HOME TIMELINE) */}
          {activeScreen === 'flameFeed' && (
            <div className="max-w-3xl mx-auto">
              {/* 1. TOP OF FLAME FEED: ACTIVE FLAME STORIES (Above On Fire as requested!) */}
              <section className="fism-card p-4 mb-5">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-xs font-extrabold uppercase tracking-wider text-[#52607A] flex items-center gap-1.5">
                    <Flame className="w-4 h-4 text-[#FF5722]" /> Active Flame Stories
                  </h2>
                  <button
                    onClick={() => {
                      if (!requireAuth('Add Story')) return;
                      setUploadCategory('story');
                      setSparkNewModalOpen(true);
                    }}
                    className="text-xs font-bold text-[#FF5722] hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Story
                  </button>
                </div>

                <div className="flex items-center gap-4 overflow-x-auto pb-1">
                  <button
                    onClick={() => {
                      if (!requireAuth('Add Story')) return;
                      setUploadCategory('story');
                      setSparkNewModalOpen(true);
                    }}
                    className="shrink-0 flex flex-col items-center gap-1.5 group"
                  >
                    <div className="w-16 h-16 rounded-full p-0.5 bg-gradient-to-tr from-[#FF5722] to-[#FFB300] relative">
                      <img
                        src={myProfile.avatarUrl}
                        alt="Your Story"
                        className="w-full h-full rounded-full object-cover border-2 border-white dark:border-slate-900"
                      />
                      <span className="absolute bottom-0 right-0 w-5 h-5 rounded-full bg-[#FF5722] text-white flex items-center justify-center text-xs font-bold ring-2 ring-white">
                        +
                      </span>
                    </div>
                    <span className="text-xs font-bold">Spark Story</span>
                  </button>

                  {stories.map((story, idx) => (
                    <button
                      key={story.id}
                      onClick={() => {
                        setActiveStoryIndex(idx);
                        setStories((prev) =>
                          prev.map((s, i) => (i === idx ? { ...s, viewed: true } : s)),
                        );
                      }}
                      className="shrink-0 flex flex-col items-center gap-1.5"
                    >
                      <div
                        className={`w-16 h-16 rounded-full p-0.5 ${
                          story.viewed
                            ? 'bg-[#D8E1F0] dark:bg-slate-700'
                            : 'fism-gradient-flame'
                        }`}
                      >
                        <img
                          src={story.avatarUrl}
                          alt={story.displayName}
                          className="w-full h-full rounded-full object-cover border-2 border-white dark:border-slate-900"
                        />
                      </div>
                      <span className="text-xs font-semibold truncate max-w-[74px]">
                        {story.displayName.split(' ')[0]}
                      </span>
                    </button>
                  ))}
                </div>
              </section>

              {/* 2. BELOW ACTIVE FLAME STORIES: ON FIRE • CURRENTLY LIVE ONLY (Past streams stay saved in Creator Profile, NOT here!) */}
              <section className="fism-card p-4 mb-5 border-2 border-[#E53935] bg-gradient-to-r from-[#1A0B12] via-[#1E1B4B] to-[#0F172A] text-white shadow-xl">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-2.5">
                    <span className="px-2.5 py-1 rounded-lg bg-[#E53935] text-white text-[11px] font-extrabold uppercase flex items-center gap-1.5 shadow">
                      <span
                        className={`w-2 h-2 rounded-full bg-white ${
                          isBroadcastingLive || gamingLiveState.isScreencasting ? 'animate-ping' : ''
                        }`}
                      />
                      ON FIRE • CURRENTLY LIVE
                    </span>
                    <div>
                      <h2 className="text-sm sm:text-base font-extrabold">
                        {(isBroadcastingLive || gamingLiveState.isScreencasting)
                          ? `🔴 LIVE RIGHT NOW: ${
                              gamingLiveState.isScreencasting
                                ? gamingLiveState.streamCustomTitle || gamingLiveState.selectedGameName
                                : liveStreamTitle
                            }`
                          : 'No On Fire Broadcast Live Right Now'}
                      </h2>
                      <p className="text-[11px] text-slate-300">
                        {isBroadcastingLive || gamingLiveState.isScreencasting
                          ? `${Math.max(1, liveViewerCount).toLocaleString()} watching right now • Older On Fire streams are saved in creator profiles.`
                          : 'Only active real-time On Fire streams appear here. Past On Fire videos are saved on your Profile!'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {(isBroadcastingLive || gamingLiveState.isScreencasting) && (
                      <button
                        onClick={() => {
                          setWatchLiveBannerOpen((v) => !v);
                          setTimeout(() => {
                            const activeStream =
                              gamingScreenStreamRef.current || liveMediaStreamRef.current;
                            if (flameFeedLiveVideoRef.current && activeStream) {
                              flameFeedLiveVideoRef.current.srcObject = activeStream;
                              flameFeedLiveVideoRef.current.play().catch(() => {});
                            }
                          }, 80);
                        }}
                        className="px-3.5 py-2 rounded-xl bg-[#FF5722] hover:bg-[#F4511E] text-white text-xs font-extrabold flex items-center gap-1.5 shadow-lg"
                      >
                        <Play className="w-3.5 h-3.5 fill-white" />
                        {watchLiveBannerOpen ? 'Hide Live Stream' : 'Watch Current Live'}
                      </button>
                    )}
                    <button
                      onClick={() => navigateWithAuthGate('onFire')}
                      className="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold border border-white/20 flex items-center gap-1.5"
                    >
                      <Radio className="w-3.5 h-3.5 text-[#FF5722]" /> Go On Fire
                    </button>
                    <button
                      onClick={() => {
                        setViewedProfileId(myProfile.uid);
                        setProfileTab('On Fire');
                        setActiveScreen('myHearth');
                      }}
                      className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-amber-300 text-xs font-extrabold border border-amber-400/30"
                    >
                      📁 Saved Profile On Fire ({onFireSavedVideos.length})
                    </button>
                  </div>
                </div>

                {/* Live Now Card — Shown ONLY for currently streaming On Fire session */}
                {(isBroadcastingLive || gamingLiveState.isScreencasting) && (
                  <div className="mt-3">
                    <div
                      onClick={() => setWatchLiveBannerOpen(true)}
                      className="p-3 rounded-xl bg-red-600/25 border-2 border-[#FF5722] flex items-center justify-between gap-2 cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={myProfile.avatarUrl}
                          alt={myProfile.displayName}
                          className="w-11 h-11 rounded-full object-cover ring-2 ring-[#E53935] shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="text-xs font-extrabold truncate">
                            🔴 {myProfile.displayName} — LIVE NOW
                          </div>
                          <div className="text-[11px] text-amber-300 font-bold truncate">
                            {gamingLiveState.isScreencasting
                              ? gamingLiveState.streamCustomTitle || gamingLiveState.selectedGameName
                              : liveStreamTitle}
                          </div>
                        </div>
                      </div>
                      <span className="px-3 py-1 rounded-lg bg-[#E53935] text-white text-[10px] font-extrabold shrink-0">
                        WATCH LIVE
                      </span>
                    </div>
                  </div>
                )}

                {/* Expandable Live Stream Player Right Inside Flame Feed */}
                {watchLiveBannerOpen && (isBroadcastingLive || gamingLiveState.isScreencasting) && (
                  <div className="mt-3 p-3 rounded-2xl bg-black/80 border border-[#FF5722] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold text-[#FFB300] flex items-center gap-1.5">
                        <Radio className="w-4 h-4 text-[#E53935]" /> Watching Current On Fire Live Stream
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={stopLiveBroadcast}
                          className="px-2.5 py-1 rounded-lg bg-[#DC2626] text-white text-[11px] font-extrabold"
                        >
                          End &amp; Save to Profile
                        </button>
                        <button
                          onClick={() => setWatchLiveBannerOpen(false)}
                          className="p-1 rounded-lg bg-white/10 text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <video
                      ref={flameFeedLiveVideoRef}
                      controls
                      autoPlay
                      playsInline
                      muted
                      className="w-full max-h-[340px] rounded-xl object-contain bg-black"
                    />
                  </div>
                )}
              </section>

              {/* FLAME FEED VIRAL (1M+ VIEWS) & PREMIUM CREATOR SHOWCASE BANNER */}
              <section className="fism-card p-4 sm:p-5 mb-5 border-2 border-[#FF5722] bg-gradient-to-r from-[#101426] via-[#1E1B4B] to-[#31102F] text-white">
                <div className="flex items-start justify-between flex-wrap gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2.5 py-0.5 rounded-full bg-[#FF5722] text-white text-[10px] font-extrabold uppercase">
                        🔥 1,000,000+ Views Viral Gate
                      </span>
                      <span className="px-2.5 py-0.5 rounded-full bg-[#FFB300] text-[#101426] text-[10px] font-extrabold uppercase flex items-center gap-1">
                        <Crown className="w-3 h-3" /> Premium Creators
                      </span>
                    </div>
                    <h2 className="text-base sm:text-lg font-extrabold flex items-center gap-2 mt-1">
                      <Flame className="w-5 h-5 text-[#FF5722] fill-[#FF5722]" /> Flame Feed — Viral
                      (1M+ Views) &amp; Premium Showcase
                    </h2>
                    <p className="text-xs text-slate-300 max-w-2xl">
                      Flame Feed is not a direct manual upload target: videos and posts appear here
                      automatically when they cross <strong>1 Million+ (1,000,000+) views</strong>{' '}
                      or when the creator has purchased <strong>FISM Premium</strong>!
                    </p>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      onClick={() => {
                        if (!requireAuth('Open Create Camera & YouCut Studio')) return;
                        setGreenScreenRemixSource(null);
                        setSparkNewModalOpen(true);
                      }}
                      className="fism-btn-primary px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-lg"
                    >
                      <Plus className="w-4 h-4" /> Open Create / YouCut Studio
                    </button>
                    <button
                      onClick={() => {
                        setPosts((prev) => {
                          const targetIdx = prev.findIndex((p) => !isPostCopyrightBlocked(p));
                          if (targetIdx === -1) return prev;
                          return prev.map((p, idx) =>
                            idx === targetIdx
                              ? {
                                  ...p,
                                  viewsCount: Math.max(1_250_000, p.viewsCount + 1_000_000),
                                  isPremiumCreator: true,
                                }
                              : p,
                          );
                        });
                        triggerToast(
                          '🔥 Boosted latest clean video past 1,250,000+ Views! It is now featured in Flame Feed!',
                        );
                      }}
                      className="px-3 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold border border-white/20"
                    >
                      🚀 Boost Latest Video to 1M+ Viral
                    </button>
                  </div>
                </div>
              </section>

              {/* Feed Filter Tabs */}
              <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
                <div className="flex items-center gap-1 bg-[#F1F5F9] dark:bg-slate-800 p-1 rounded-xl border border-[#D8E1F0] dark:border-slate-700">
                  {(['For You', 'Following', 'Trending', 'Latest'] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setFeedFilter(tab)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        feedFilter === tab
                          ? 'fism-btn-primary shadow-sm'
                          : 'text-[#52607A] hover:text-[#151B2B] dark:hover:text-white'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
                <span className="text-xs font-extrabold text-[#FF5722]">
                  Showing {visibleFeedPosts.length} Viral (1M+) &amp; Premium Sparks
                </span>
              </div>

              {/* Original-Size AdsTerra Banner Ad — Flame Feed Home Page */}
              <FismBanner320x50Ad
                adsterraConfig={adsterraConfig}
                isAdmin={isPrimaryAdmin}
                onOpenAdConfig={() => setActiveScreen('adminFileVault')}
                officialBannerAds={smartAds}
                onTrackAdClick={(adId) => handleEngageSmartAd(adId, 'click')}
              />

              {visibleFeedPosts.map((post, idx) => {
                const isEveryFifthPost = (idx + 1) % 5 === 0;
                const isRectBannerSpot = idx === 1;
                const isFallbackLastWhenUnderFive =
                  visibleFeedPosts.length < 5 && idx === visibleFeedPosts.length - 1;
                return (
                  <React.Fragment key={post.id}>
                    {renderPostCard(post)}
                    {isRectBannerSpot && (
                      <div className="mb-5 flex justify-center">
                        <FismBanner300x250Ad
                          adsterraConfig={adsterraConfig}
                          isAdmin={isPrimaryAdmin}
                          onOpenAdConfig={() => setActiveScreen('adminFileVault')}
                          officialBannerAds={smartAds}
                          onTrackAdClick={(adId) => handleEngageSmartAd(adId, 'click')}
                        />
                      </div>
                    )}
                    {(isEveryFifthPost || isFallbackLastWhenUnderFive) && (
                      <FismNativeBannerAd
                        slotIndex={Math.max(1, Math.floor((idx + 1) / 5))}
                        adsterraConfig={adsterraConfig}
                        isAdmin={isPrimaryAdmin}
                        onOpenAdConfig={() => setActiveScreen('adminFileVault')}
                        officialBannerAds={smartAds}
                        onTrackAdClick={(adId) => handleEngageSmartAd(adId, 'click')}
                      />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          )}

          {/* SCREEN 2: MAIN BLAST (LONG VIDEO FEED > 1 MINUTE) */}
          {activeScreen === 'mainBlast' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                  <h1 className="text-xl sm:text-2xl font-extrabold flex items-center gap-2">
                    <Play className="w-6 h-6 text-[#FF5722] fill-[#FF5722]" /> Main Blast — Long
                    Video Feed (&gt; 1 Minute)
                  </h1>
                  <p className="text-xs text-[#52607A]">
                    Videos exceeding 60 seconds automatically route here with real video playback,
                    AI Voice Language Translation, and Audio-to-Text Description Transcription.
                  </p>
                </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-3 py-1.5 rounded-xl bg-[#7C3AED]/15 text-[#7C3AED] border border-[#7C3AED]/30 text-[11px] font-extrabold">
                      📊 Session Mid-Roll Ads: {mainBlastSessionAdCount}/3 (Min 1 • Max 3)
                    </span>
                    <label className="px-4 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow">
                      <Upload className="w-4 h-4" /> Instant Upload Video File
                      <input
                        type="file"
                        accept="video/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleDirectInstantVideoUpload(file, 'video');
                          e.target.value = '';
                        }}
                      />
                    </label>
                    <button
                      onClick={() => {
                        if (!requireAuth('Upload Long Video')) return;
                        setUploadCategory('videoUpload');
                        setUploadedVideoSeconds(180);
                        setSparkNewModalOpen(true);
                      }}
                      className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" /> Studio Upload (&gt;60s)
                    </button>
                  </div>
                </div>

                {/* Exact-Size 320x50 Banner Ad above Featured Long Video Player */}
                <FismBanner320x50Ad
                  adsterraConfig={adsterraConfig}
                  isAdmin={isPrimaryAdmin}
                  onOpenAdConfig={() => setActiveScreen('adminFileVault')}
                  officialBannerAds={smartAds}
                  onTrackAdClick={(adId) => handleEngageSmartAd(adId, 'click')}
                />

                {/* Featured Interactive Player */}
                <div className="fism-card overflow-hidden">
                  <div className="relative bg-[#0F172A] aspect-video max-h-[520px] w-full flex items-center justify-center">
                    {mainBlastActiveAd ? (
                      <div className="relative w-full h-full flex items-center justify-center bg-black">
                        {mainBlastActiveAd.isVideo ? (
                          <video
                            key={mainBlastActiveAd.id}
                            src={mainBlastActiveAd.mediaUrl}
                            autoPlay
                            muted
                            playsInline
                            className="w-full h-full object-contain bg-black"
                          />
                        ) : (
                          <img
                            src={mainBlastActiveAd.mediaUrl || GENERATED_ASSETS.shopHeadset}
                            alt={mainBlastActiveAd.title}
                            className="w-full h-full object-cover opacity-85"
                          />
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-black/70" />

                        {/* Top Ad Badge & 15s Auto-Dismiss Countdown Timer */}
                        <div className="absolute top-4 inset-x-4 flex items-center justify-between gap-2 flex-wrap">
                          <div className="flex items-center gap-2">
                            <span className="px-3 py-1 rounded-full bg-[#FFB300] text-[#101426] text-[11px] font-black uppercase">
                              {mainBlastActiveAd.source === 'official'
                                ? '📢 Official Sponsored Ad'
                                : `📢 Creator Ad (@${mainBlastActiveAd.creatorUsername})`}
                            </span>
                            <span className="px-2.5 py-1 rounded-full bg-[#7C3AED]/90 text-white text-[10px] font-extrabold">
                              🔥 Matched via Flame Algorithm
                            </span>
                          </div>
                          <div className="px-3.5 py-1.5 rounded-xl bg-black/85 border-2 border-[#FF5722] text-white text-xs font-black font-mono">
                            ⏳ Ad ends in {mainBlastAdCountdown}s
                          </div>
                        </div>

                        {/* Bottom Ad Info & Product CTA */}
                        <div className="absolute bottom-5 inset-x-5 flex items-end justify-between gap-4 flex-wrap text-white">
                          <div className="space-y-1 max-w-xl">
                            <div className="text-[11px] font-extrabold text-[#4ADE80] uppercase">
                              {mainBlastActiveAd.storePlatform} Partner Campaign
                            </div>
                            <h3 className="text-base sm:text-xl font-extrabold">
                              {mainBlastActiveAd.title}
                            </h3>
                            <p className="text-xs text-slate-200 line-clamp-2">
                              {mainBlastActiveAd.description}
                            </p>
                          </div>
                          {mainBlastActiveAd.productLinkUrl && (
                            <a
                              href={mainBlastActiveAd.productLinkUrl}
                              target="_blank"
                              rel="noreferrer"
                              onClick={() => handleEngageSmartAd(mainBlastActiveAd.id, 'click')}
                              className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 shadow-xl"
                            >
                              <ShoppingBag className="w-4 h-4" />
                              <span>{mainBlastActiveAd.ctaLabel || 'Shop Now'}</span>
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                        </div>
                      </div>
                    ) : isRealPlayableVideo(
                      selectedVideoPost.mediaUrl,
                      selectedVideoPost.isRealVideo,
                    ) ? (
                      <video
                        key={selectedVideoPost.mediaUrl}
                        src={selectedVideoPost.mediaUrl}
                        controls
                        autoPlay
                        playsInline
                        onTimeUpdate={(e) => {
                          const dur = e.currentTarget.duration;
                          if (dur && Number.isFinite(dur)) {
                            updateVideoWatchProgress(
                              selectedVideoPost.id,
                              (e.currentTarget.currentTime / dur) * 100,
                            );
                          }
                        }}
                        onEnded={() => markGiftVideoWatchCompleted(selectedVideoPost.id)}
                        className="w-full h-full object-contain bg-black"
                      />
                    ) : (
                      <>
                        <canvas
                          ref={mainBlastCanvasRef}
                          width={960}
                          height={540}
                          className="w-full h-full object-cover"
                        />
                        {!videoPlaying && (
                          <img
                            src={selectedVideoPost.thumbnailUrl || GENERATED_ASSETS.heroCover}
                            alt={selectedVideoPost.title}
                            className="absolute inset-0 w-full h-full object-cover opacity-85"
                          />
                        )}
                        <button
                          onClick={() => setVideoPlaying((p) => !p)}
                          className="absolute z-10 w-16 h-16 rounded-full fism-gradient-flame text-white flex items-center justify-center shadow-2xl hover:scale-105 transition-transform"
                        >
                          {videoPlaying ? (
                            <Pause className="w-7 h-7 fill-white" />
                          ) : (
                            <Play className="w-7 h-7 fill-white ml-0.5" />
                          )}
                        </button>

                        {videoCaptionsOn && (
                          <div className="absolute bottom-16 left-1/2 -translate-x-1/2 px-3 py-1 rounded-lg bg-black/80 text-white text-xs font-medium text-center max-w-[90%]">
                            [CC] {selectedVideoPost.translatedVoiceText || selectedVideoPost.title}
                          </div>
                        )}

                        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/95 via-black/70 to-transparent p-3 sm:p-4 text-white">
                          <input
                            type="range"
                            min={0}
                            max={100}
                            value={videoProgress}
                            onChange={(e) => setVideoProgress(Number(e.target.value))}
                            aria-label="Seek timeline"
                            className="w-full accent-[#FF5722] h-1.5 rounded-lg cursor-pointer mb-2"
                          />
                          <div className="flex items-center justify-between gap-2 text-xs">
                            <div className="flex items-center gap-3">
                              <button
                                onClick={() => setVideoPlaying((p) => !p)}
                                className="font-bold flex items-center gap-1 hover:text-[#FF5722]"
                              >
                                {videoPlaying ? (
                                  <Pause className="w-4 h-4" />
                                ) : (
                                  <Play className="w-4 h-4" />
                                )}
                                <span>{videoPlaying ? 'Pause' : 'Play'}</span>
                              </button>
                              <button
                                onClick={() => setVideoMuted((m) => !m)}
                                className="hover:text-[#FF5722]"
                              >
                                {videoMuted ? (
                                  <VolumeX className="w-4 h-4" />
                                ) : (
                                  <Volume2 className="w-4 h-4" />
                                )}
                              </button>
                              <span className="font-mono">
                                03:{String(Math.floor((videoProgress / 100) * 59)).padStart(2, '0')} /{' '}
                                {selectedVideoPost.duration || '12:45'}
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setVideoCaptionsOn((c) => !c)}
                                className={`px-2 py-0.5 rounded font-bold ${
                                  videoCaptionsOn ? 'bg-[#FF5722] text-white' : 'bg-white/20'
                                }`}
                              >
                                CC
                              </button>
                              <button
                                onClick={() =>
                                  setVideoSpeed((s) =>
                                    s === 1 ? 1.25 : s === 1.25 ? 1.5 : s === 1.5 ? 2 : 1,
                                  )
                                }
                                className="px-2 py-0.5 rounded bg-white/20 font-mono font-bold"
                              >
                                {videoSpeed}x
                              </button>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                    {(() => {
                      if (mainBlastActiveAd || selectedVideoPost.has_gift_drop === false) return null;
                      const mainDrop = getDropForPost(selectedVideoPost.id);
                      if (!mainDrop) return null;
                      return (
                        <div className="absolute top-3 left-3 z-20">
                          <FismVideoGiftDropOverlay
                            drop={mainDrop}
                            currentUserId={activeIdentityUid}
                            watchCompleted={Boolean(completedGiftVideoIds[selectedVideoPost.id])}
                            watchProgressPct={
                              videoWatchProgressByPostId[selectedVideoPost.id] ?? videoProgress
                            }
                            onClaimDrop={handleClaimVideoGiftDrop}
                          />
                        </div>
                      );
                    })()}
                  </div>

                  <div className="p-4 sm:p-5 space-y-4">
                    <div className="flex items-start justify-between flex-wrap gap-4">
                      <div>
                        <h2 className="text-lg sm:text-xl font-extrabold">
                          {mainBlastActiveAd
                            ? `Sponsored: ${mainBlastActiveAd.title}`
                            : selectedVideoPost.title}
                        </h2>
                        <p className="text-xs text-[#52607A] mt-1">
                          {selectedVideoPost.viewsCount.toLocaleString()} views •{' '}
                          {selectedVideoPost.createdAt}
                        </p>
                      </div>
                      {/* Strictly hide ALL engagement buttons (3D VR, Spark, Spread, AshStash) while Main Blast mid-roll Ad plays */}
                      {!mainBlastActiveAd ? (
                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            onClick={() => {
                              setVrCinemaVideoUrl(
                                isRealPlayableVideo(
                                  selectedVideoPost.mediaUrl,
                                  selectedVideoPost.isRealVideo,
                                )
                                  ? selectedVideoPost.mediaUrl
                                  : '',
                              );
                              setVrCinemaVideoTitle(selectedVideoPost.title);
                              setActiveScreen('flame3DArena');
                            }}
                            className="px-3.5 py-2 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
                          >
                            <Box className="w-4 h-4" /> 🥽 Watch in 3D VR Cinema
                          </button>
                          <button
                            onClick={() => handleToggleSpark(selectedVideoPost.id)}
                            className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5"
                          >
                            <Flame className="w-4 h-4 fill-white" /> Spark (
                            {selectedVideoPost.sparkCount.toLocaleString()})
                          </button>
                          <button
                            onClick={() => setActiveSpreadPost(selectedVideoPost)}
                            className="px-3.5 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold flex items-center gap-1.5"
                          >
                            <Share2 className="w-4 h-4 text-[#7C3AED]" /> Spread
                          </button>
                          <button
                            onClick={() => handleToggleAshStash(selectedVideoPost.id)}
                            className="px-3.5 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold flex items-center gap-1.5"
                          >
                            <Bookmark className="w-4 h-4 text-[#F59E0B]" /> AshStash
                          </button>
                          <button
                            onClick={() => handleDownloadBrandedVideo(selectedVideoPost)}
                            disabled={downloadingBrandedPostId === selectedVideoPost.id}
                            className="px-3.5 py-2 rounded-xl bg-[#E53935] text-white text-xs font-extrabold flex items-center gap-1.5 shadow disabled:opacity-60"
                          >
                            <Download className="w-4 h-4" />{' '}
                            {downloadingBrandedPostId === selectedVideoPost.id
                              ? 'Burning FISM Watermark...'
                              : 'Branded Download'}
                          </button>
                        </div>
                      ) : (
                        <div className="px-3.5 py-2 rounded-xl bg-amber-500/15 border border-amber-500 text-amber-600 dark:text-amber-300 text-xs font-extrabold">
                          ⏳ Mid-Roll Ad Playing — Engagement controls hidden until {mainBlastAdCountdown}s
                        </div>
                      )}
                    </div>

                  {/* 🌐 UNIVERSAL VIDEO VOICE LANGUAGE TRANSLATOR BAR (Chinese <-> Hindi / Tamil / Indian / Any Language) */}
                  <div className="p-3.5 rounded-2xl bg-[#F5F7FF] dark:bg-slate-900 border-2 border-[#7C3AED] space-y-2.5">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="text-xs font-extrabold text-[#7C3AED] flex items-center gap-1.5">
                        <Languages className="w-4 h-4" /> 🌐 AI Video Voice Language Translator &amp;
                        Live Audio Dubbing (Chinese ↔ Indian / Hindi / Tamil / Global)
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          onClick={() => {
                            setVoiceSourceLang('Chinese (Mandarin)');
                            setVoiceTargetLang('Hindi (Indian)');
                          }}
                          className="px-2 py-0.5 rounded bg-[#7C3AED]/15 text-[#7C3AED] text-[10px] font-extrabold"
                        >
                          Chinese → Hindi
                        </button>
                        <button
                          onClick={() => {
                            setVoiceSourceLang('Hindi (Indian)');
                            setVoiceTargetLang('Chinese (Mandarin)');
                          }}
                          className="px-2 py-0.5 rounded bg-[#FF5722]/15 text-[#FF5722] text-[10px] font-extrabold"
                        >
                          Indian (Hindi) → Chinese
                        </button>
                        <button
                          onClick={() => {
                            setVoiceSourceLang('English');
                            setVoiceTargetLang('Hindi (Indian)');
                          }}
                          className="px-2 py-0.5 rounded bg-[#2563EB]/15 text-[#2563EB] text-[10px] font-extrabold"
                        >
                          English → Hindi
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <select
                        value={voiceSourceLang}
                        onChange={(e) => setVoiceSourceLang(e.target.value)}
                        aria-label="Source video language"
                        className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                      >
                        <option>Chinese (Mandarin)</option>
                        <option>Hindi (Indian)</option>
                        <option>Tamil (Indian)</option>
                        <option>Telugu (Indian)</option>
                        <option>Bengali (Indian)</option>
                        <option>English</option>
                        <option>Japanese</option>
                        <option>Spanish</option>
                        <option>Arabic</option>
                      </select>
                      <span className="text-xs font-extrabold text-[#7C3AED]">→</span>
                      <select
                        value={voiceTargetLang}
                        onChange={(e) => setVoiceTargetLang(e.target.value)}
                        aria-label="Target dubbing language"
                        className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-[#7C3AED] text-xs font-bold"
                      >
                        <option>Hindi (Indian)</option>
                        <option>Chinese (Mandarin)</option>
                        <option>Tamil (Indian)</option>
                        <option>Telugu (Indian)</option>
                        <option>Bengali (Indian)</option>
                        <option>Marathi (Indian)</option>
                        <option>English</option>
                        <option>Japanese</option>
                        <option>Spanish</option>
                        <option>Arabic</option>
                      </select>

                      <button
                        onClick={() => handleTranslateVideoVoice(selectedVideoPost)}
                        disabled={voiceTranslating}
                        className="fism-btn-primary px-4 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5"
                      >
                        <Volume2 className="w-4 h-4" />
                        {voiceTranslating
                          ? 'Translating & Dubbing Voice...'
                          : `Translate & Speak in ${voiceTargetLang}`}
                      </button>
                    </div>

                    {(selectedVideoPost.translatedVoiceText || translatedVoiceScript) && (
                      <div className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs space-y-1.5">
                        <div className="font-extrabold text-[#7C3AED]">
                          🔊 Dubbed Voice Output ({voiceSourceLang} → {voiceTargetLang}):
                        </div>
                        <p className="text-sm font-medium">
                          {selectedVideoPost.translatedVoiceText || translatedVoiceScript}
                        </p>
                        {translatedVoiceAudioUrl && (
                          <audio
                            src={translatedVoiceAudioUrl}
                            controls
                            className="w-full h-8 mt-1"
                          />
                        )}
                      </div>
                    )}
                  </div>

                  {/* 📝 VIDEO DESCRIPTION BOX WITH AUDIO-TO-TEXT TRANSCRIPTION */}
                  <div className="p-4 rounded-2xl bg-[#F1F5F9] dark:bg-slate-800/90 border border-[#D8E1F0] dark:border-slate-700 space-y-2.5">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <span className="text-xs font-extrabold uppercase tracking-wider text-[#52607A]">
                        Video Description &amp; Audio-to-Text Transcript
                      </span>
                      <button
                        onClick={() => handleTranscribeVideoToDescription(selectedVideoPost)}
                        disabled={transcribingVideoId === selectedVideoPost.id}
                        className="px-3 py-1.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-extrabold flex items-center gap-1.5 shadow-sm"
                      >
                        <FileAudio className="w-3.5 h-3.5" />
                        {transcribingVideoId === selectedVideoPost.id
                          ? 'Converting Video Audio to Text...'
                          : '📝 Convert Video Audio to Text (Inside Description)'}
                      </button>
                    </div>

                    <p className="text-sm text-[#151B2B] dark:text-slate-200 whitespace-pre-line">
                      {selectedVideoPost.caption}
                    </p>

                    {/* 🔗 CONNECTED ANOTHER VIDEO INSIDE MAIN BLAST DESCRIPTION */}
                    {selectedVideoPost.connectedVideo && (
                      <button
                        type="button"
                        onClick={() => handleOpenConnectedVideo(selectedVideoPost.connectedVideo!)}
                        className="w-full p-3 rounded-xl bg-[#0284C7]/15 hover:bg-[#0284C7]/25 border-2 border-[#0284C7] flex items-center justify-between gap-3 text-left transition-all"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={selectedVideoPost.connectedVideo.thumbnailUrl}
                            alt={selectedVideoPost.connectedVideo.title}
                            className="w-16 h-11 rounded-lg object-cover border border-[#0284C7] shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="text-[10px] font-extrabold uppercase text-[#0284C7] flex items-center gap-1">
                              <Link2 className="w-3.5 h-3.5" /> Connected Video •{' '}
                              {selectedVideoPost.connectedVideo.postType === 'quickBurst'
                                ? 'Quick Burst'
                                : 'Main Blast'}
                            </div>
                            <div className="text-xs sm:text-sm font-extrabold truncate">
                              {selectedVideoPost.connectedVideo.title}
                            </div>
                          </div>
                        </div>
                        <span className="px-3 py-1.5 rounded-xl bg-[#0284C7] text-white text-xs font-extrabold shrink-0 shadow">
                          ▶ Watch Video
                        </span>
                      </button>
                    )}

                    {/* 👥 COLLABORATORS ON MAIN BLAST VIDEO */}
                    {(() => {
                      const accepted = (selectedVideoPost.taggedCollaborators || []).filter(
                        (tc) => tc.status === 'accepted',
                      );
                      if (accepted.length === 0) return null;
                      return (
                        <div className="p-2.5 rounded-xl bg-[#7C3AED]/10 border border-[#7C3AED]/35 flex items-center justify-between gap-2 flex-wrap">
                          <div className="text-xs font-bold flex items-center gap-1.5 flex-wrap">
                            <Users className="w-4 h-4 text-[#7C3AED]" />
                            <span>
                              @{selectedVideoPost.authorUsername} + {accepted.length} collab
                              {accepted.length > 1 ? 's' : ''}:
                            </span>
                            <span className="text-[#7C3AED]">
                              {accepted.map((c) => `@${c.username}`).join(', ')}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setCollabFollowTargetPost(selectedVideoPost)}
                            className="px-3 py-1 rounded-lg bg-[#7C3AED] text-white text-xs font-extrabold"
                          >
                            Connect Creators
                          </button>
                        </div>
                      );
                    })()}

                    {/* 🛍️ AI-VERIFIED SHOPPING LINK INSIDE MAIN BLAST VIDEO DESCRIPTION (500+ SPARKS) */}
                    {selectedVideoPost.shoppingLinkUrl ? (
                      <div className="mt-2 p-3.5 rounded-xl bg-[#F0FDF4] dark:bg-emerald-950/40 border-2 border-[#16A34A] flex items-center justify-between gap-3 flex-wrap">
                        <div className="flex items-center gap-3 min-w-0">
                          {selectedVideoPost.shoppingProductImage && (
                            <img
                              src={selectedVideoPost.shoppingProductImage}
                              alt={selectedVideoPost.shoppingProductTitle || 'Shopping Item'}
                              className="w-14 h-14 rounded-xl object-cover border border-[#16A34A] shrink-0"
                            />
                          )}
                          <div className="min-w-0">
                            <div className="text-[10px] font-extrabold uppercase text-[#16A34A]">
                              🤖 AI Shopping Inspector Verified •{' '}
                              {selectedVideoPost.shoppingStoreName || 'FISM Official Store'}
                            </div>
                            <div className="text-sm font-extrabold truncate">
                              {selectedVideoPost.shoppingProductTitle || 'Creator Featured Gear'}
                            </div>
                            <div className="text-xs text-[#2563EB] underline truncate">
                              {selectedVideoPost.shoppingLinkUrl}
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => navigateWithAuthGate('shoppingSection')}
                          className="px-3.5 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold shrink-0 shadow"
                        >
                          🛍️ Open Shopping Link
                        </button>
                      </div>
                    ) : (
                      myProfile.sparksCount >= 500 && (
                        <div className="pt-1 flex items-center justify-between gap-2 flex-wrap text-xs text-[#52607A]">
                          <span>
                            🛍️ 500+ Sparks Unlocked: You can attach an AI-verified Shopping Link to
                            this Main Blast description.
                          </span>
                          <button
                            onClick={() => {
                              const firstProd = shoppingProducts[0];
                              const updated = {
                                ...selectedVideoPost,
                                shoppingLinkUrl: `https://fism.shop/product/${firstProd?.id || 'gear_1'}`,
                                shoppingProductTitle:
                                  firstProd?.title || 'Flame RGB Studio Headset',
                                shoppingProductImage:
                                  firstProd?.imageUrl ||
                                  firstProd?.photos?.[0] ||
                                  GENERATED_ASSETS.shopHeadset,
                                shoppingStoreName: 'FISM Official Store',
                              };
                              setSelectedVideoPost(updated);
                              setPosts((prev) =>
                                prev.map((p) => (p.id === updated.id ? updated : p)),
                              );
                              triggerToast(
                                '🤖 AI Shopping Inspector verified & added Shopping Link to this Main Blast video description!',
                              );
                            }}
                            className="px-3 py-1 rounded-lg bg-[#16A34A] text-white text-[11px] font-extrabold"
                          >
                            + Attach Verified Shopping Link
                          </button>
                        </div>
                      )
                    )}

                    {selectedVideoPost.transcriptText && (
                      <div className="mt-2 p-3.5 rounded-xl bg-white dark:bg-slate-900 border-2 border-[#2563EB] space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-extrabold text-[#2563EB]">
                            📝 Full Video Audio Transcript (gemini-3.5-transcribe):
                          </span>
                          <button
                            onClick={() => {
                              navigator.clipboard?.writeText(
                                selectedVideoPost.transcriptText || '',
                              );
                              triggerToast('Video transcript copied!');
                            }}
                            className="text-[11px] font-bold text-[#2563EB] underline"
                          >
                            Copy Text
                          </button>
                        </div>
                        <p className="text-xs sm:text-sm whitespace-pre-line leading-relaxed">
                          {selectedVideoPost.transcriptText}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Multi-Column Video Discovery Grid (Ranked by Flame Algorithm) */}
              <div>
                <h3 className="font-extrabold text-base mb-3 flex items-center gap-2">
                  <span>All Main Blast Long Videos</span>
                  <span className="px-2 py-0.5 rounded-full bg-[#7C3AED]/15 text-[#7C3AED] text-[10px] font-extrabold">
                    🔥 Flame Algorithm Ranked
                  </span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {rankedMainBlastVideos.map((video) => (
                      <div
                        key={video.id}
                        onClick={() => {
                          setSelectedVideoPost(video);
                          setVideoPlaying(true);
                        }}
                        className="fism-card overflow-hidden cursor-pointer group hover:border-[#FF5722] transition-all"
                      >
                        <div className="relative aspect-video bg-[#0F172A]">
                          {isRealPlayableVideo(video.mediaUrl, video.isRealVideo) ? (
                            <video
                              src={video.mediaUrl}
                              muted
                              playsInline
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <img
                              src={video.thumbnailUrl || video.mediaUrl}
                              alt={video.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                          )}
                          <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/85 text-white text-[11px] font-mono font-bold">
                            {video.duration || '08:24'}
                          </span>
                        </div>
                        <div className="p-3.5 flex gap-3">
                          <img
                            src={video.authorAvatar}
                            alt={video.authorDisplayName}
                            className="w-9 h-9 rounded-full object-cover shrink-0 mt-0.5"
                          />
                          <div className="min-w-0">
                            <h4 className="font-bold text-sm line-clamp-2 group-hover:text-[#FF5722]">
                              {video.title}
                            </h4>
                            <div className="text-xs text-[#52607A] mt-1 flex items-center gap-1">
                              <span>{video.authorDisplayName}</span>
                              {video.authorVerified && (
                                <CheckCircle2 className="w-3.5 h-3.5 text-[#2563EB]" />
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          )}

          {/* SCREEN 3: QUICK BURST (VERTICAL SCROLLING SHORTS FEED <= 60 SECONDS — NO NEXT BUTTON, 3-DOT MENU HAS VOICE TRANSLATION, TRANSCRIPT & 1x-3x SPEED) */}
          {activeScreen === 'quickBurst' && (
            <div className="max-w-md mx-auto space-y-3">
              {/* Top Quick Controls Bar (No Next Button — Scroll Down/Up to Switch Shorts) */}
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <Zap className="w-5 h-5 text-[#FF5722] fill-[#FF5722]" />
                  <div>
                    <span className="font-extrabold text-sm sm:text-base">Quick Burst Shorts</span>
                    <span className="ml-2 px-2 py-0.5 rounded-full bg-[#FF5722]/15 text-[#FF5722] text-[10px] font-extrabold">
                      ↕ Scroll Up/Down ({activeQuickBurstIndex + 1}/{quickBurstPosts.length}) •{' '}
                      {shortPlaybackSpeed}x
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    onClick={() => {
                      if (!requireAuth('Open Create Camera & YouCut Studio')) return;
                      setGreenScreenRemixSource(null);
                      setSparkNewModalOpen(true);
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1 shadow"
                  >
                    <Plus className="w-3.5 h-3.5" /> Create / Add Short
                  </button>
                  <button
                    onClick={() => navigateWithAuthGate('musicHub')}
                    className="px-2.5 py-1.5 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-1"
                  >
                    <Music className="w-3.5 h-3.5" /> Music Hub
                  </button>
                </div>
              </div>

              {/* VERTICAL SNAP-SCROLLING SHORTS FEED CONTAINER */}
              <div
                ref={shortScrollContainerRef}
                onScroll={(e) => {
                  const el = e.currentTarget;
                  if (el.clientHeight > 0) {
                    const nextIdx = Math.round(el.scrollTop / el.clientHeight);
                    if (
                      nextIdx >= 0 &&
                      nextIdx < quickBurstPosts.length &&
                      nextIdx !== activeQuickBurstIndex
                    ) {
                      setActiveQuickBurstIndex(nextIdx);
                    }
                  }
                }}
                onWheel={(e) => {
                  // If the 3-dot menu or comments drawer is open, let user scroll inside the drawer
                  if (openMenuPostId || activeChatterPostId) return;
                  const now = Date.now();
                  if (now - lastWheelScrollTimeRef.current < 420) return;
                  if (Math.abs(e.deltaY) > 25) {
                    lastWheelScrollTimeRef.current = now;
                    const container = shortScrollContainerRef.current;
                    const nextIdx =
                      e.deltaY > 0
                        ? Math.min(quickBurstPosts.length - 1, activeQuickBurstIndex + 1)
                        : Math.max(0, activeQuickBurstIndex - 1);
                    setActiveQuickBurstIndex(nextIdx);
                    if (container) {
                      container.scrollTo({
                        top: nextIdx * container.clientHeight,
                        behavior: 'smooth',
                      });
                    }
                  }
                }}
                className="h-[78vh] w-full overflow-y-scroll snap-y snap-mandatory rounded-3xl shadow-2xl border border-white/15 bg-black scrollbar-none"
                style={{ scrollbarWidth: 'none' }}
              >
                {quickBurstPosts.map((burst, burstIdx) => {
                  const isRealShortVid = isRealPlayableVideo(burst.mediaUrl, burst.isRealVideo);
                  const burstCreator = creators.find((c) => c.uid === burst.authorId);
                  const formatCompactCount = (n: number) =>
                    n >= 1_000_000
                      ? `${(n / 1_000_000).toFixed(1)}M`
                      : n >= 1_000
                        ? `${Math.round(n / 1000)}K`
                        : String(n);

                  return (
                    <div
                      key={burst.id}
                      onDoubleClick={() => handleToggleSpark(burst.id)}
                      className="relative h-[78vh] w-full snap-start snap-always overflow-hidden bg-black select-none shrink-0"
                    >
                      {/* Green Screen Background Layer if this Short was created with Green Screen */}
                      {burst.greenScreenBgUrl && (
                        <img
                          src={burst.greenScreenBgUrl}
                          alt="Green Screen Background"
                          className="absolute inset-0 w-full h-full object-cover opacity-55"
                        />
                      )}

                      {isRealShortVid ? (
                        <video
                          ref={(el) => {
                            shortVideoRefs.current[burst.id] = el;
                            if (el && el.playbackRate !== shortPlaybackSpeed) {
                              el.playbackRate = shortPlaybackSpeed;
                            }
                          }}
                          key={burst.mediaUrl}
                          src={burst.mediaUrl}
                          controls={false}
                          autoPlay={burstIdx === activeQuickBurstIndex}
                          loop={!autoScrollShortsOnEnd}
                          playsInline
                          muted={quickBurstMuted}
                          onPlay={(e) => {
                            e.currentTarget.playbackRate = shortPlaybackSpeed;
                          }}
                          onTimeUpdate={(e) => {
                            const dur = e.currentTarget.duration;
                            if (dur && Number.isFinite(dur)) {
                              updateVideoWatchProgress(
                                burst.id,
                                (e.currentTarget.currentTime / dur) * 100,
                              );
                            }
                          }}
                          onEnded={() => {
                            markGiftVideoWatchCompleted(burst.id);
                            if (autoScrollShortsOnEnd && shortScrollContainerRef.current) {
                              const nextIdx =
                                burstIdx < quickBurstPosts.length - 1 ? burstIdx + 1 : 0;
                              setActiveQuickBurstIndex(nextIdx);
                              shortScrollContainerRef.current.scrollTo({
                                top: nextIdx * shortScrollContainerRef.current.clientHeight,
                                behavior: 'smooth',
                              });
                            }
                          }}
                          onClick={() => setQuickBurstPlaying((p) => !p)}
                          className={`relative z-10 w-full h-full object-contain bg-transparent ${getFilterCssClass(
                            editorColorFilter,
                          )}`}
                        />
                      ) : (
                        <>
                          <img
                            src={burst.thumbnailUrl || burst.mediaUrl}
                            alt={burst.title}
                            className={`w-full h-full object-cover ${getFilterCssClass(
                              editorColorFilter,
                            )}`}
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-transparent to-black/45" />
                          <div className="absolute bottom-0 inset-x-0 z-20 h-1 bg-white/20">
                            <div
                              className="h-full bg-gradient-to-r from-[#FF5722] to-[#FACC15] transition-all duration-500"
                              style={{ width: `${videoWatchProgressByPostId[burst.id] ?? 0}%` }}
                            />
                          </div>
                        </>
                      )}

                      {/* TOP BAR: Left Sound/Remix/Speed/Ad Badge + Top-Right Search (🔍) & 3-Dots (•••) */}
                      <div className="absolute top-4 inset-x-4 z-20 flex items-center justify-between text-white">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {burst.smartAdItem ? (
                            <span className="px-2.5 py-1 rounded-full bg-[#FFB300] text-[#101426] text-[11px] font-black flex items-center gap-1 shadow">
                              📢 {burst.smartAdItem.source === 'official' ? 'Official Ad' : 'Creator Ad'} •{' '}
                              {burst.smartAdItem.storePlatform}
                            </span>
                          ) : null}
                          {burst.flameMatchLabel && (
                            <span className="px-2.5 py-1 rounded-full bg-[#7C3AED]/90 text-white text-[10px] font-extrabold shadow">
                              {burst.flameMatchLabel}
                            </span>
                          )}
                          {burst.remixedFromAuthor && (
                            <span className="px-2.5 py-1 rounded-full bg-[#16A34A]/90 text-[11px] font-extrabold flex items-center gap-1 shadow">
                              <Repeat className="w-3 h-3" /> Remixed @{burst.remixedFromAuthor}
                            </span>
                          )}
                          <button
                            onClick={() => setQuickBurstMuted((m) => !m)}
                            className="p-2 rounded-full bg-black/45 backdrop-blur-md text-white hover:bg-black/65"
                            title="Mute / Unmute"
                          >
                            {quickBurstMuted ? (
                              <VolumeX className="w-4 h-4" />
                            ) : (
                              <Volume2 className="w-4 h-4" />
                            )}
                          </button>
                          {shortPlaybackSpeed !== 1 && (
                            <span className="px-2.5 py-1 rounded-full bg-[#FF5722] text-white text-[11px] font-extrabold shadow">
                              ⚡ {shortPlaybackSpeed}x Speed
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => navigateWithAuthGate('findFlame')}
                            aria-label="Search Shorts"
                            className="p-2 rounded-full bg-black/35 hover:bg-black/60 backdrop-blur-md text-white"
                          >
                            <Search className="w-5 h-5" />
                          </button>
                          {!burst.smartAdItem && (
                            <button
                              onClick={() =>
                                setOpenMenuPostId((prev) => (prev === burst.id ? null : burst.id))
                              }
                              aria-label="Three Dot Short Options (Speed, Voice Translation & Transcript)"
                              className={`p-2 rounded-full backdrop-blur-md text-white transition-all ${
                                openMenuPostId === burst.id
                                  ? 'bg-[#FF5722] ring-2 ring-white'
                                  : 'bg-black/35 hover:bg-black/60'
                              }`}
                            >
                              <MoreHorizontal className="w-5 h-5" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* 🛍️ AI-VERIFIED SHOPPING PRODUCT PHOTO IN CORNER OF QUICK BURST SHORT */}
                      {burst.shoppingLinkUrl && burst.shoppingProductImage && (
                        <button
                          onClick={() => {
                            if (!requireAuth('Open Verified Shopping Product')) return;
                            setActiveScreen('shoppingSection');
                            triggerToast(
                              `🛍️ Opening AI-Verified Product: ${burst.shoppingProductTitle || 'FISM Store Item'}`,
                            );
                          }}
                          title="AI-Verified Shopping Link Product"
                          className="absolute top-16 left-4 z-20 p-1.5 rounded-2xl bg-black/75 backdrop-blur-md border-2 border-[#16A34A] text-white flex items-center gap-2 shadow-xl hover:scale-105 transition-transform max-w-[200px]"
                        >
                          <img
                            src={burst.shoppingProductImage}
                            alt={burst.shoppingProductTitle || 'Product'}
                            className="w-10 h-10 rounded-xl object-cover border border-white/40 shrink-0"
                          />
                          <div className="text-left min-w-0 pr-1">
                            <div className="text-[9px] font-extrabold uppercase text-[#4ADE80]">
                              🛍️ Shop Verified
                            </div>
                            <div className="text-[11px] font-extrabold truncate">
                              {burst.shoppingProductTitle || 'Creator Gear'}
                            </div>
                          </div>
                        </button>
                      )}

                      {/* 🔗 CONNECTED ANOTHER VIDEO OVERLAY IN CORNER OF QUICK BURST */}
                      {burst.connectedVideo && !burst.smartAdItem && (
                        <button
                          type="button"
                          onClick={() => handleOpenConnectedVideo(burst.connectedVideo!)}
                          title="Watch Connected Video"
                          className="absolute top-16 right-4 z-20 px-2.5 py-1.5 rounded-2xl bg-[#0284C7]/90 hover:bg-[#0284C7] backdrop-blur-md border border-white/40 text-white flex items-center gap-2 shadow-xl max-w-[190px]"
                        >
                          <img
                            src={burst.connectedVideo.thumbnailUrl}
                            alt={burst.connectedVideo.title}
                            className="w-8 h-8 rounded-lg object-cover border border-white/40 shrink-0"
                          />
                          <div className="text-left min-w-0">
                            <div className="text-[9px] font-black uppercase text-sky-200 flex items-center gap-1">
                              <Link2 className="w-2.5 h-2.5" /> Linked Video
                            </div>
                            <div className="text-[11px] font-extrabold truncate">
                              ▶ {burst.connectedVideo.title}
                            </div>
                          </div>
                        </button>
                      )}

                      {/* 🎁 VIDEO GIFT DROP OVERLAY IN QUICK BURST SHORT */}
                      {(() => {
                        if (burst.has_gift_drop === false || burst.smartAdItem) return null;
                        const shortDrop = getDropForPost(burst.id);
                        if (!shortDrop) return null;
                        return (
                          <div
                            className={`absolute left-4 z-20 ${
                              burst.shoppingLinkUrl && burst.shoppingProductImage
                                ? 'top-32'
                                : 'top-16'
                            }`}
                          >
                            <FismVideoGiftDropOverlay
                              drop={shortDrop}
                              currentUserId={activeIdentityUid}
                              compact
                              watchCompleted={Boolean(completedGiftVideoIds[burst.id])}
                              watchProgressPct={videoWatchProgressByPostId[burst.id] ?? 0}
                              onClaimDrop={handleClaimVideoGiftDrop}
                            />
                          </div>
                        );
                      })()}

                      {/* RIGHT VERTICAL ACTION STACK (Keeps Interactive Like & Share enabled on Quick Burst Ads!) */}
                      <div className="absolute right-3.5 bottom-6 z-20 flex flex-col items-center gap-4 text-white">
                        {/* 1. Heart / Like */}
                        <button
                          onClick={() => {
                            if (burst.smartAdItem) {
                              handleEngageSmartAd(burst.smartAdItem.id, 'like');
                              triggerToast(`❤️ Liked Sponsored Ad "${burst.smartAdItem.title}"!`);
                            } else {
                              handleToggleSpark(burst.id);
                            }
                          }}
                          className="flex flex-col items-center gap-1 group"
                        >
                          <div className="w-11 h-11 rounded-full bg-black/35 backdrop-blur-sm flex items-center justify-center group-active:scale-90 transition-transform">
                            <Heart
                              className={`w-7 h-7 ${
                                burst.isSparked
                                  ? 'text-[#E53935] fill-[#E53935]'
                                  : 'text-white'
                              }`}
                            />
                          </div>
                          <span className="text-xs font-bold drop-shadow">
                            {formatCompactCount(
                              burst.smartAdItem ? burst.smartAdItem.likes : burst.sparkCount,
                            )}
                          </span>
                        </button>

                        {/* 2. Comment (Organic Shorts) */}
                        {!burst.smartAdItem && (
                          <button
                            onClick={() => {
                              if (!requireAuth('Comment (Chatter) on Shorts')) return;
                              setActiveChatterPostId((prev) =>
                                prev === burst.id ? null : burst.id,
                              );
                            }}
                            className="flex flex-col items-center gap-1 group"
                          >
                            <div className="w-11 h-11 rounded-full bg-black/35 backdrop-blur-sm flex items-center justify-center">
                              <MessageCircle className="w-7 h-7 text-white" />
                            </div>
                            <span className="text-xs font-bold drop-shadow">
                              {formatCompactCount(burst.chatterCount)}
                            </span>
                          </button>
                        )}

                        {/* 3. Save (Organic Shorts) */}
                        {!burst.smartAdItem && (
                          <button
                            onClick={() => handleToggleAshStash(burst.id)}
                            className="flex flex-col items-center gap-1 group"
                          >
                            <div className="w-11 h-11 rounded-full bg-black/35 backdrop-blur-sm flex items-center justify-center">
                              <Bookmark
                                className={`w-7 h-7 ${
                                  burst.isStashed
                                    ? 'text-[#FFB300] fill-[#FFB300]'
                                    : 'text-white'
                                }`}
                              />
                            </div>
                            <span className="text-xs font-bold drop-shadow">Save</span>
                          </button>
                        )}

                        {/* 4. Share (Active on Both Organic Shorts AND Quick Burst Ads!) */}
                        <button
                          onClick={() => {
                            if (burst.smartAdItem) {
                              const shareUrl =
                                burst.smartAdItem.productLinkUrl ||
                                buildFismShareUrl('burst', burst.id);
                              void shareFismLink({
                                title: burst.title,
                                text: burst.caption || 'Watch on FISM Quick Burst',
                                url: shareUrl,
                                triggerToast,
                              });
                              handleEngageSmartAd(burst.smartAdItem.id, 'click');
                              return;
                            }
                            if (!requireAuth('Share (Spread) Short')) return;
                            setActiveSpreadPost(burst);
                          }}
                          className="flex flex-col items-center gap-1 group"
                        >
                          <div className="w-11 h-11 rounded-full bg-black/35 backdrop-blur-sm flex items-center justify-center">
                            <Share2 className="w-7 h-7 text-white" />
                          </div>
                          <span className="text-xs font-bold drop-shadow">Share</span>
                        </button>

                        {/* 5. Remix & Branded Download Buttons (Organic Shorts) */}
                        {!burst.smartAdItem && (
                          <>
                            <button
                              onClick={() => handleDownloadBrandedVideo(burst)}
                              disabled={downloadingBrandedPostId === burst.id}
                              title="Download Quick Burst with Permanent FISM Logo Watermark"
                              className="flex flex-col items-center gap-1 group disabled:opacity-60"
                            >
                              <div className="w-11 h-11 rounded-full bg-black/45 border border-white/30 backdrop-blur-sm flex items-center justify-center group-hover:border-[#E53935]">
                                <Download className="w-6 h-6 text-white" />
                              </div>
                              <span className="text-[11px] font-bold drop-shadow">
                                {downloadingBrandedPostId === burst.id ? '...' : 'Save MP4'}
                              </span>
                            </button>
                            <button
                              onClick={() => {
                                if (!requireAuth('Remix Short (Green Screen / Music)')) return;
                                setRemixActionSheetPost(burst);
                              }}
                              className="flex flex-col items-center gap-1 group"
                            >
                              <div className="w-11 h-11 rounded-full bg-black/45 border border-white/30 backdrop-blur-sm flex items-center justify-center group-hover:border-[#FFB300]">
                                <Repeat className="w-6 h-6 text-white" />
                              </div>
                              <span className="text-xs font-bold drop-shadow">
                                {burst.remixCount ?? 47}
                              </span>
                            </button>
                          </>
                        )}

                        {/* 6. Sound Thumbnail */}
                        <button
                          onClick={() => {
                            if (burst.smartAdItem && burst.smartAdItem.productLinkUrl) {
                              handleEngageSmartAd(burst.smartAdItem.id, 'click');
                              return;
                            }
                            if (!requireAuth('Use or Remix Sound')) return;
                            setRemixActionSheetPost(burst);
                          }}
                          title="Sound / Partner Avatar"
                          className="w-10 h-10 rounded-xl overflow-hidden border-2 border-white shadow-lg mt-1"
                        >
                          <img
                            src={burst.authorAvatar}
                            alt={burst.audioTrack || 'Sound'}
                            className="w-full h-full object-cover"
                          />
                        </button>
                      </div>

                      {/* BOTTOM-LEFT CREATOR / AD INFO + INTERACTIVE PRODUCT CTA ON QUICK BURST ADS */}
                      <div className="absolute bottom-5 left-4 right-20 z-20 text-white space-y-2.5 pointer-events-auto">
                        <div className="flex items-center gap-2.5 flex-wrap">
                          <img
                            src={burst.authorAvatar}
                            alt={burst.authorUsername}
                            onClick={() => {
                              if (burst.smartAdItem) return;
                              if (!requireAuth('View Creator Profile')) return;
                              setViewedProfileId(burst.authorId);
                              setActiveScreen('myHearth');
                            }}
                            className="w-10 h-10 rounded-full object-cover border border-white/60 cursor-pointer shrink-0"
                          />
                          <span className="font-extrabold text-sm tracking-tight drop-shadow inline-flex items-center gap-1.5 flex-wrap">
                            <span>@{burst.authorUsername}</span>
                            {!burst.smartAdItem &&
                              (burst.authorHasRedTick ||
                                getAuthorMilestoneInfo(burst.authorId).hasRedTick) && (
                                <FismRedMilestoneTick
                                  size="sm"
                                  onClick={() =>
                                    openMilestoneJourneyForUser({
                                      accountId: burst.authorId,
                                      username: burst.authorUsername,
                                      displayName: burst.authorDisplayName,
                                      avatarUrl: burst.authorAvatar,
                                    })
                                  }
                                />
                              )}
                            {(() => {
                              const acc = (burst.taggedCollaborators || []).filter(
                                (tc) => tc.status === 'accepted',
                              );
                              return acc.length > 0 ? ` + ${acc.length} collab${acc.length > 1 ? 's' : ''}` : '';
                            })()}
                          </span>
                          {!burst.smartAdItem && (
                            <button
                              onClick={() => {
                                const hasAcc = (burst.taggedCollaborators || []).some(
                                  (tc) => tc.status === 'accepted',
                                );
                                if (hasAcc) {
                                  setCollabFollowTargetPost(burst);
                                } else {
                                  handleToggleConnectCreator(burst.authorId);
                                }
                              }}
                              className={`px-4 py-1.5 rounded-full text-xs font-extrabold transition-all shadow ${
                                burstCreator?.isConnected
                                  ? 'bg-white/25 text-white border border-white/40'
                                  : 'bg-white text-black hover:bg-slate-100'
                              }`}
                            >
                              {(burst.taggedCollaborators || []).some((tc) => tc.status === 'accepted')
                                ? 'Connect'
                                : burstCreator?.isConnected
                                  ? 'Subscribed'
                                  : 'Subscribe'}
                            </button>
                          )}
                        </div>

                        <p className="text-xs sm:text-sm text-white font-medium line-clamp-2 drop-shadow">
                          {burst.caption || burst.title}
                        </p>

                        {burst.smartAdItem && burst.smartAdItem.productLinkUrl && (
                          <a
                            href={burst.smartAdItem.productLinkUrl}
                            target="_blank"
                            rel="noreferrer"
                            onClick={() => handleEngageSmartAd(burst.smartAdItem!.id, 'click')}
                            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF5722] to-[#FFB300] text-white text-xs font-black shadow-xl hover:scale-[1.02] transition-transform"
                          >
                            <ShoppingBag className="w-4 h-4" />
                            <span>{burst.smartAdItem.ctaLabel || 'Shop Now →'}</span>
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}

                        <div className="flex items-center gap-2 text-[11px] text-white/85">
                          <Music className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">
                            {burst.audioTrack || `Original Sound - @${burst.authorUsername}`}
                          </span>
                        </div>

                        {burst.generatedMusicUrl && (
                          <audio
                            src={burst.generatedMusicUrl}
                            controls
                            autoPlay
                            className="w-full h-8 mt-1"
                          />
                        )}
                      </div>

                      {/* THREE-DOT (•••) MENU DRAWER INSIDE SHORT: 1x-3x SPEED + VOICE TRANSLATOR + SHORT-TO-TEXT TRANSCRIPT */}
                      {openMenuPostId === burst.id && (
                        <div className="absolute inset-x-0 bottom-0 z-40 bg-[#101426]/98 backdrop-blur-md p-4 sm:p-5 rounded-t-3xl border-t-2 border-[#FF5722] text-white space-y-4 max-h-[82%] overflow-y-auto shadow-2xl">
                          <div className="flex items-center justify-between border-b border-white/15 pb-2.5">
                            <div className="flex items-center gap-2">
                              <Sliders className="w-4 h-4 text-[#FF5722]" />
                              <span className="font-extrabold text-sm">
                                Short Controls (•••) — Speed, Voice Translation &amp; Transcript
                              </span>
                            </div>
                            <button
                              onClick={() => setOpenMenuPostId(null)}
                              className="p-1.5 rounded-full bg-white/10 hover:bg-white/20"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>

                          {/* 1. PLAYBACK SPEED CONTROLLER (Normally 1x, selectable: 1x, 1.5x, 2x, 2.5x, 3x) */}
                          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/15 space-y-2.5">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-extrabold text-[#FFB300] flex items-center gap-1.5">
                                <Zap className="w-4 h-4 text-[#FF5722]" /> ⚡ Video Playback Speed
                                (Default 1x — Up to 3x)
                              </span>
                              <span className="text-[11px] font-mono font-bold text-white/80">
                                Current: {shortPlaybackSpeed}x
                              </span>
                            </div>
                            <div className="grid grid-cols-5 gap-2">
                              {([1, 1.5, 2, 2.5, 3] as const).map((spd) => (
                                <button
                                  key={spd}
                                  type="button"
                                  onClick={() => {
                                    setShortPlaybackSpeed(spd);
                                    const vid = shortVideoRefs.current[burst.id];
                                    if (vid) vid.playbackRate = spd;
                                    triggerToast(
                                      spd === 1
                                        ? '▶ Playback Speed set to 1x (Normal)'
                                        : `⚡ Playback Speed set to ${spd}x!`,
                                    );
                                  }}
                                  className={`py-2 rounded-xl text-xs font-extrabold transition-all border ${
                                    shortPlaybackSpeed === spd
                                      ? 'bg-[#FF5722] text-white border-white shadow-lg scale-105'
                                      : 'bg-white/10 text-white/85 border-white/15 hover:bg-white/20'
                                  }`}
                                >
                                  {spd}x{spd === 1 ? ' (Normal)' : ''}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* 2. SHORTS VOICE LANGUAGE TRANSLATION (Moved Inside 3-Dot Menu!) */}
                          <div className="p-3.5 rounded-2xl bg-purple-500/15 border border-[#7C3AED] space-y-2.5">
                            <div className="flex items-center justify-between flex-wrap gap-2">
                              <span className="text-xs font-extrabold text-purple-300 flex items-center gap-1.5">
                                <Languages className="w-4 h-4 text-[#7C3AED]" /> 🌐 Shorts Voice
                                Language Translation
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <select
                                value={voiceSourceLang}
                                onChange={(e) => setVoiceSourceLang(e.target.value)}
                                aria-label="Short source language"
                                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-white/20 text-xs font-bold text-white"
                              >
                                <option>Hindi (Indian)</option>
                                <option>English</option>
                                <option>Chinese (Mandarin)</option>
                                <option>Japanese</option>
                                <option>Urdu (Pakistan)</option>
                                <option>Tamil (Indian)</option>
                                <option>Spanish</option>
                              </select>
                              <span className="text-xs font-extrabold text-amber-400">→</span>
                              <select
                                value={voiceTargetLang}
                                onChange={(e) => setVoiceTargetLang(e.target.value)}
                                aria-label="Short target language"
                                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-[#7C3AED] text-xs font-bold text-white"
                              >
                                <option>Hindi (Indian)</option>
                                <option>English</option>
                                <option>Chinese (Mandarin)</option>
                                <option>Japanese</option>
                                <option>Urdu (Pakistan)</option>
                                <option>Tamil (Indian)</option>
                                <option>Telugu (Indian)</option>
                                <option>Spanish</option>
                              </select>
                              <button
                                onClick={() => handleTranslateVideoVoice(burst)}
                                disabled={voiceTranslating}
                                className="fism-btn-primary px-3 py-1.5 rounded-xl text-xs font-extrabold shadow"
                              >
                                {voiceTranslating ? 'Dubbing...' : '🔊 Translate Voice'}
                              </button>
                            </div>
                            {burst.translatedVoiceText && (
                              <div className="p-2.5 rounded-xl bg-black/50 border border-purple-400/40 text-xs text-purple-100">
                                <span className="font-extrabold text-amber-300">
                                  🌐 Dubbed ({burst.translatedVoiceLang}):{' '}
                                </span>
                                {burst.translatedVoiceText}
                              </div>
                            )}
                          </div>

                          {/* 3. TRANSCRIPT SHORT TO TEXT (Moved Inside 3-Dot Menu!) */}
                          <div className="p-3.5 rounded-2xl bg-blue-500/15 border border-[#2563EB] space-y-2.5">
                            <div className="flex items-center justify-between flex-wrap gap-2">
                              <span className="text-xs font-extrabold text-blue-300 flex items-center gap-1.5">
                                <FileAudio className="w-4 h-4 text-[#2563EB]" /> 📝 Transcript Short
                                to Text
                              </span>
                              <button
                                onClick={() => handleTranscribeVideoToDescription(burst)}
                                className="px-3 py-1.5 rounded-xl bg-[#2563EB] hover:bg-blue-700 text-white text-xs font-extrabold flex items-center gap-1 shadow"
                              >
                                <FileAudio className="w-3.5 h-3.5" />
                                {transcribingVideoId === burst.id
                                  ? 'Transcribing...'
                                  : '📝 Transcribe Short to Text'}
                              </button>
                            </div>
                            {burst.transcriptText && (
                              <div className="p-2.5 rounded-xl bg-black/50 border border-blue-400/40 text-xs text-blue-100 whitespace-pre-line">
                                {burst.transcriptText}
                              </div>
                            )}
                          </div>

                          {/* Quick Extra Actions */}
                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={() => {
                                const shareUrl = buildFismShareUrl('burst', burst.id);
                                void shareFismLink({
                                  title: burst.title,
                                  text: burst.caption || `Watch @${burst.authorUsername} on FISM`,
                                  url: shareUrl,
                                  triggerToast,
                                });
                                setOpenMenuPostId(null);
                              }}
                              className="flex-1 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold flex items-center justify-center gap-1.5"
                            >
                              <Copy className="w-3.5 h-3.5" /> Copy Link
                            </button>
                            <button
                              onClick={() => {
                                setSmotherTarget({
                                  id: burst.id,
                                  label: burst.title,
                                  type: 'video',
                                });
                                setOpenMenuPostId(null);
                              }}
                              className="flex-1 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 text-xs font-bold flex items-center justify-center gap-1.5"
                            >
                              <Flag className="w-3.5 h-3.5" /> Report Short
                            </button>
                          </div>
                        </div>
                      )}

                      {/* INLINE CHATTER (COMMENTS) SHEET OVER SHORT IF OPEN */}
                      {activeChatterPostId === burst.id && (
                        <div className="absolute inset-x-0 bottom-0 z-30 bg-[#101426]/95 backdrop-blur-md p-4 rounded-t-3xl border-t border-white/20 text-white max-h-[60%] flex flex-col justify-between space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-extrabold">
                              Comments ({burst.chatterCount})
                            </span>
                            <button onClick={() => setActiveChatterPostId(null)}>
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                          <div className="space-y-2 overflow-y-auto max-h-44 pr-1">
                            {burst.comments.map((c) => (
                              <div key={c.id} className="text-xs bg-white/10 p-2.5 rounded-xl space-y-1.5">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="font-bold text-[#FFB300]">
                                    @{c.authorUsername}
                                  </span>
                                  {(c.authorHasRedTick ||
                                    getAuthorMilestoneInfo(c.authorId).hasRedTick) && (
                                    <FismRedMilestoneTick
                                      size="sm"
                                      onClick={() =>
                                        openMilestoneJourneyForUser({
                                          accountId: c.authorId,
                                          username: c.authorUsername,
                                          displayName: `@${c.authorUsername}`,
                                          avatarUrl: c.authorAvatar,
                                        })
                                      }
                                    />
                                  )}
                                  {(c.authorVipGoldBadge ||
                                    getAuthorMilestoneInfo(c.authorId).vipGoldBadge) && (
                                    <FismVipGoldChatBadge />
                                  )}
                                  {c.isAutoBotReply && (
                                    <span className="mr-1.5 px-1.5 py-0.5 rounded bg-[#7C3AED] text-white text-[9px] font-black uppercase">
                                      🤖 Auto-Bot
                                    </span>
                                  )}
                                  <span>{c.text}</span>
                                </div>
                                {c.isAutoBotReply && c.productLinkUrl && (
                                  <a
                                    href={c.productLinkUrl}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#16A34A] text-white text-[10px] font-extrabold"
                                  >
                                    <ShoppingBag className="w-3 h-3" />
                                    <span>
                                      {c.productTitle || 'Buy Now'} ({c.productStoreName || 'Store'})
                                    </span>
                                    <ExternalLink className="w-2.5 h-2.5" />
                                  </a>
                                )}
                              </div>
                            ))}
                          </div>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={newCommentText}
                              onChange={(e) => setNewCommentText(e.target.value)}
                              placeholder="Add comment..."
                              className="flex-1 px-3 py-1.5 rounded-xl bg-white/10 border border-white/20 text-xs text-white"
                            />
                            <button
                              onClick={() => handleAddChatterComment(burst.id)}
                              className="px-3 py-1.5 rounded-xl fism-gradient-flame text-xs font-extrabold"
                            >
                              Send
                            </button>
                          </div>
                        </div>
                      )}

                      {/* REMIX STUDIO ACTION SHEET (GREEN SCREEN BACKGROUND OR MUSIC REMIX) */}
                      {remixActionSheetPost?.id === burst.id && (
                        <div className="absolute inset-x-0 bottom-0 z-40 bg-[#101426]/98 backdrop-blur-md p-5 rounded-t-3xl border-t-2 border-[#FF5722] text-white space-y-3.5 shadow-2xl">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Repeat className="w-5 h-5 text-[#FF5722]" />
                              <div>
                                <h4 className="font-extrabold text-sm">
                                  Remix Short (@{burst.authorUsername})
                                </h4>
                                <p className="text-[11px] text-white/65">
                                  Use this video as a Green Screen background or remix its music!
                                </p>
                              </div>
                            </div>
                            <button
                              onClick={() => setRemixActionSheetPost(null)}
                              className="p-1.5 rounded-full bg-white/10"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="grid grid-cols-1 gap-2.5">
                            <button
                              onClick={() => {
                                setGreenScreenRemixSource(burst);
                                setRemixActionSheetPost(null);
                                setSparkNewModalOpen(true);
                                triggerToast(
                                  `🟢 Loaded @${burst.authorUsername}'s video as Green Screen Background!`,
                                );
                              }}
                              className="w-full p-3.5 rounded-2xl bg-[#16A34A] hover:bg-[#15803D] text-white text-left flex items-center justify-between gap-3 shadow-lg"
                            >
                              <div>
                                <div className="font-extrabold text-xs sm:text-sm">
                                  🟢 Use Video as Green Screen Background
                                </div>
                                <div className="text-[11px] text-white/85">
                                  ग्रीन स्क्रीन में इस वीडियो को पीछे बैकग्राउंड के तौर पर यूज़ करें
                                </div>
                              </div>
                              <ChevronRight className="w-5 h-5 shrink-0" />
                            </button>

                            <button
                              onClick={() => {
                                const matchedTrack: FismMusicTrack = {
                                  id: `remix_music_${burst.id}`,
                                  title:
                                    burst.audioTrack ||
                                    `Original Sound - @${burst.authorUsername}`,
                                  artist: burst.authorUsername,
                                  uploaderUsername: burst.authorUsername,
                                  audioUrl: burst.generatedMusicUrl || '',
                                  coverUrl: burst.authorAvatar,
                                  duration: burst.duration || '00:15',
                                  genre: 'Remixed Short Audio',
                                  usesCount: (burst.remixCount || 47) + 1,
                                  createdAt: 'Remixed Sound',
                                };
                                setSelectedStudioMusicTrack(matchedTrack);
                                setGreenScreenRemixSource(null);
                                setRemixActionSheetPost(null);
                                setSparkNewModalOpen(true);
                                triggerToast(
                                  `🎵 Attached sound "${matchedTrack.title}" for your Remix Short!`,
                                );
                              }}
                              className="w-full p-3.5 rounded-2xl bg-[#7C3AED] hover:bg-[#6D28D9] text-white text-left flex items-center justify-between gap-3 shadow-lg"
                            >
                              <div>
                                <div className="font-extrabold text-xs sm:text-sm">
                                  🎵 Remix This Music / Audio Track
                                </div>
                                <div className="text-[11px] text-white/85">
                                  इस शॉर्ट के म्यूज़िक और साउंड को अपने वीडियो में लगाएं
                                </div>
                              </div>
                              <ChevronRight className="w-5 h-5 shrink-0" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* SCREEN 3B: DEDICATED IN-APP MUSIC SECTION (FISM MUSIC HUB) */}
          {activeScreen === 'musicHub' && (
            <FismMusicHubScreen
              musicTracks={musicTracks}
              onUploadMusicTrack={(newTrack) =>
                setMusicTracks((prev) => [newTrack, ...prev])
              }
              onUseMusicInShort={(track) => {
                setSelectedStudioMusicTrack(track);
                setSparkNewModalOpen(true);
                triggerToast(`🎵 Loaded "${track.title}" into Create Studio!`);
              }}
              currentUsername={myProfile.username}
              onTriggerToast={triggerToast}
            />
          )}

          {/* SCREEN 4: CIRCLE FEED (SUBSCRIPTIONS) */}
          {activeScreen === 'circleFeed' && (
            <div className="max-w-3xl mx-auto space-y-5">
              <div className="fism-card p-5 flex items-center justify-between flex-wrap gap-4">
                <div>
                  <h1 className="text-xl font-extrabold flex items-center gap-2">
                    <Compass className="w-6 h-6 text-[#7C3AED]" /> Circle Feed — Flames &amp;
                    Fuelers
                  </h1>
                  <p className="text-xs text-[#52607A]">
                    Chronological and exclusive posts from creators you Connect with or Fuel Up.
                  </p>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {(['All', 'Latest', 'Photos', 'Videos', 'Exclusive'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setCircleFilter(f)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold ${
                        circleFilter === f
                          ? 'fism-btn-primary'
                          : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A]'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              {posts
                .filter((p) => {
                  if (isPostCopyrightBlocked(p)) return false;
                  if (circleFilter === 'Photos') return p.postType === 'photo';
                  if (circleFilter === 'Videos') return p.postType === 'video';
                  if (circleFilter === 'Exclusive') return p.visibility === 'subscribers';
                  return true;
                })
                .map((post) => renderPostCard(post))}
            </div>
          )}

          {/* SCREEN 5: SHOPPING SECTION (MARKETPLACE: 2–15 Photos, 1 Video, GPS, Buy -> Call/Video Call) */}
          {activeScreen === 'shoppingSection' && (
            <FismShoppingHub
              products={shoppingProducts}
              onAddProduct={(newProd) => setShoppingProducts((prev) => [newProd, ...prev])}
              onStartCall={(callInfo) =>
                triggerRealtimeCall(callInfo, { incomingRingOnly: false, broadcast: true })
              }
              onOpenSellerChat={(sellerName, sellerAvatar) => {
                const newUserId = `seller_${Date.now()}`;
                setConversations((prev) => [
                  {
                    userId: newUserId,
                    username: sellerName.toLowerCase().replace(/\s+/g, '_'),
                    displayName: `${sellerName} (Marketplace Seller)`,
                    avatarUrl: sellerAvatar,
                    online: true,
                    unreadCount: 0,
                    messages: [
                      {
                        id: `m_${Date.now()}`,
                        senderId: newUserId,
                        senderName: sellerName,
                        recipientId: myProfile.uid,
                        text: `Hi! Let me know if you want to inspect or buy my product 🔥`,
                        messageType: 'text',
                        reactions: ['🔥'],
                        isRead: true,
                        delivered: true,
                        createdAt: 'Just now',
                      },
                    ],
                  },
                  ...prev,
                ]);
                setActiveChatUserId(newUserId);
                setActiveScreen('emberChat');
              }}
              onOpenLocationMap={(loc) =>
                setInAppMapModalTarget({
                  lat: loc.lat,
                  lng: loc.lng,
                  title: loc.title,
                  label: loc.label,
                })
              }
              onTriggerToast={triggerToast}
              isPremiumSection={Boolean(sectionPremiumMap.shoppingSection && globalPremiumOn)}
            />
          )}

          {/* SCREEN 6: EMBER CHAT (LIVE LOCATION SHARING, SECRET/DISAPPEARING CHATS, CALLING & LONG-PRESS EMOJI BLAST GAME) */}
          {activeScreen === 'emberChat' && (
            <div className="fism-card overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[640px]">
              {/* Left Followers / Following Conversation List */}
              <div className="md:col-span-4 border-r border-[#D8E1F0] dark:border-slate-800 p-4 flex flex-col">
                <div className="flex items-center justify-between mb-1">
                  <h2 className="font-extrabold text-base flex items-center gap-2">
                    <MessageCircle className="w-5 h-5 text-[#2563EB]" /> Ember Chat
                  </h2>
                  {secretChatPassword && (
                    <button
                      type="button"
                      onClick={() => {
                        setSecretChatsLocked((v) => !v);
                        setSecretUnlockInput('');
                        setSecretUnlockError(null);
                      }}
                      className={`px-2 py-1 rounded-lg text-[10px] font-extrabold flex items-center gap-1 ${
                        secretChatsLocked
                          ? 'bg-[#DC2626] text-white'
                          : 'bg-[#16A34A] text-white'
                      }`}
                    >
                      <Lock className="w-3 h-3" />
                      {secretChatsLocked ? 'Secret Locked' : 'Lock Secrets'}
                    </button>
                  )}
                </div>
                <p className="text-[11px] text-[#52607A] mb-3">
                  Live Location Sharing, Secret/Disappearing Chats &amp; E2E Calls
                </p>
                <input
                  type="text"
                  value={chatSearchQuery}
                  onChange={(e) => setChatSearchQuery(e.target.value)}
                  placeholder="Search followers or following..."
                  className="w-full px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs mb-3"
                />
                <div className="space-y-1.5 flex-1 overflow-y-auto">
                  {conversations
                    .filter((c) =>
                      c.displayName.toLowerCase().includes(chatSearchQuery.toLowerCase()),
                    )
                    .map((conv) => (
                      <button
                        key={conv.userId}
                        onClick={() => {
                          setActiveChatUserId(conv.userId);
                          setConversations((prev) =>
                            prev.map((item) =>
                              item.userId === conv.userId ? { ...item, unreadCount: 0 } : item,
                            ),
                          );
                        }}
                        className={`w-full p-3 rounded-xl flex items-center justify-between text-left transition-all ${
                          activeChatUserId === conv.userId
                            ? 'bg-[#EEF3FB] dark:bg-slate-800 border border-[#2563EB]'
                            : 'hover:bg-[#F1F5F9] dark:hover:bg-slate-800/60'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="relative shrink-0">
                            <img
                              src={conv.avatarUrl}
                              alt={conv.displayName}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                            {conv.online && (
                              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[#16A34A] ring-2 ring-white" />
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="font-bold text-xs sm:text-sm truncate flex items-center gap-1">
                              <span>{conv.displayName}</span>
                              {conv.isSecretChat && (
                                <Lock className="w-3 h-3 text-[#7C3AED] shrink-0" />
                              )}
                            </div>
                            <div className="text-xs text-[#52607A] truncate">
                              {conv.isSecretChat && secretChatsLocked
                                ? '🔒 Secret Chat Locked'
                                : conv.messages[conv.messages.length - 1]?.text || 'No messages yet'}
                            </div>
                          </div>
                        </div>
                        {conv.unreadCount > 0 && (
                          <span className="px-2 py-0.5 rounded-full bg-[#2563EB] text-white text-[10px] font-bold">
                            {conv.unreadCount}
                          </span>
                        )}
                      </button>
                    ))}
                </div>
              </div>

              {/* Right Active Chat Thread + Secret Lock + Live Location Map + Voice/Video Call */}
              <div className="md:col-span-8 flex flex-col justify-between p-4">
                {(() => {
                  const activeConv =
                    conversations.find((c) => c.userId === activeChatUserId) || conversations[0];

                  const isThreadLocked =
                    Boolean(activeConv.isSecretChat) &&
                    secretChatsLocked &&
                    Boolean(secretChatPassword);

                  const startLiveLocationShare = () => {
                    const shareId = `loc_${myProfile.uid}_${activeConv.userId}_${Date.now()}`;
                    const emitCoords = (lat: number, lng: number, accuracyMeters: number) => {
                      const locPayload: FismLiveLocationState = {
                        shareId,
                        senderId: myProfile.uid,
                        senderName: myProfile.displayName,
                        recipientId: activeConv.userId,
                        lat,
                        lng,
                        accuracyMeters,
                        isSharing: true,
                        updatedAt: new Date().toLocaleTimeString(),
                      };
                      setLiveLocationsMap((prev) => ({ ...prev, [shareId]: locPayload }));
                      if (locationWsRef.current?.readyState === WebSocket.OPEN) {
                        locationWsRef.current.send(
                          JSON.stringify({ type: 'location_update', ...locPayload }),
                        );
                      }
                      if (auth.currentUser?.emailVerified) {
                        const safeShareId = shareId.replace(/[^a-zA-Z0-9_-]/g, '_');
                        const safeRecipientId = activeConv.userId.replace(/[^a-zA-Z0-9_-]/g, '_');
                        setDoc(doc(db, 'liveLocations', safeShareId), {
                          senderId: auth.currentUser.uid,
                          senderName: String(myProfile.displayName || 'FISM Creator').slice(0, 80),
                          recipientId: safeRecipientId,
                          lat,
                          lng,
                          accuracyMeters,
                          isSharing: true,
                          updatedAt: serverTimestamp(),
                        }).catch(() => {});
                      }
                    };

                    const insertLocMessage = (lat: number, lng: number, accuracyMeters: number) => {
                      const expiresAtMs =
                        activeConv.disappearAfterSeconds && activeConv.disappearAfterSeconds > 0
                          ? Date.now() + activeConv.disappearAfterSeconds * 1000
                          : undefined;
                      setActiveLiveShareId(shareId);
                      setConversations((prev) =>
                        prev.map((c) =>
                          c.userId === activeConv.userId
                            ? {
                                ...c,
                                messages: [
                                  ...c.messages,
                                  {
                                    id: `m_loc_${Date.now()}`,
                                    senderId: myProfile.uid,
                                    senderName: myProfile.displayName,
                                    recipientId: activeConv.userId,
                                    text: `📍 Sharing Live Location (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
                                    messageType: 'location',
                                    reactions: ['📍'],
                                    isRead: true,
                                    delivered: true,
                                    createdAt: 'Live Location • Real-Time',
                                    lat,
                                    lng,
                                    accuracyMeters,
                                    liveShareId: shareId,
                                    liveSharingActive: true,
                                    isSecret: Boolean(activeConv.isSecretChat),
                                    expiresAtMs,
                                  },
                                ],
                              }
                            : c,
                        ),
                      );
                      emitCoords(lat, lng, accuracyMeters);
                    };

                    if (navigator.geolocation) {
                      navigator.geolocation.getCurrentPosition(
                        (pos) => {
                          const lat = pos.coords.latitude;
                          const lng = pos.coords.longitude;
                          const acc = Math.round(pos.coords.accuracy || 10);
                          insertLocMessage(lat, lng, acc);
                          if (locationWatchIdRef.current !== null) {
                            navigator.geolocation.clearWatch(locationWatchIdRef.current);
                          }
                          locationWatchIdRef.current = navigator.geolocation.watchPosition(
                            (livePos) => {
                              emitCoords(
                                livePos.coords.latitude,
                                livePos.coords.longitude,
                                Math.round(livePos.coords.accuracy || 10),
                              );
                            },
                            () => {},
                            { enableHighAccuracy: true, maximumAge: 2000 },
                          );
                          triggerToast('📍 Real-Time Live Location Sharing active via GPS + WebSocket!');
                        },
                        () => {
                          // Fallback coordinates when browser geolocation denied in iframe
                          insertLocMessage(28.6139, 77.209, 15);
                          triggerToast(
                            '📍 Live Location Map Card shared (Enable browser GPS for real coordinates)!',
                          );
                        },
                        { enableHighAccuracy: true, timeout: 6000 },
                      );
                    } else {
                      insertLocMessage(28.6139, 77.209, 15);
                    }
                  };

                  const stopLiveLocationShare = (shareId: string) => {
                    if (locationWatchIdRef.current !== null && navigator.geolocation) {
                      navigator.geolocation.clearWatch(locationWatchIdRef.current);
                      locationWatchIdRef.current = null;
                    }
                    setActiveLiveShareId(null);
                    setLiveLocationsMap((prev) => ({
                      ...prev,
                      [shareId]: {
                        ...(prev[shareId] || {
                          shareId,
                          senderId: myProfile.uid,
                          senderName: myProfile.displayName,
                          recipientId: activeConv.userId,
                          lat: 28.6139,
                          lng: 77.209,
                          accuracyMeters: 15,
                        }),
                        isSharing: false,
                        updatedAt: 'Stopped',
                      },
                    }));
                    setConversations((prev) =>
                      prev.map((c) => ({
                        ...c,
                        messages: c.messages.map((msg) =>
                          msg.liveShareId === shareId ? { ...msg, liveSharingActive: false } : msg,
                        ),
                      })),
                    );
                    if (locationWsRef.current?.readyState === WebSocket.OPEN) {
                      locationWsRef.current.send(
                        JSON.stringify({ type: 'location_stop', shareId }),
                      );
                    }
                    triggerToast('📍 Stopped Live Location Sharing.');
                  };

                  return (
                    <>
                      {/* Chat Header with E2E Encryption Badge, Secret/Disappearing Controls, Live Location & Call Buttons */}
                      <div className="pb-3 border-b border-[#D8E1F0] dark:border-slate-800 space-y-2.5">
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-3">
                            <img
                              src={activeConv.avatarUrl}
                              alt={activeConv.displayName}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                            <div>
                              <div className="font-bold text-sm flex items-center gap-1.5 flex-wrap">
                                <span>{activeConv.displayName}</span>
                                <span className="px-2 py-0.5 rounded-full bg-[#16A34A]/15 text-[#16A34A] text-[10px] font-extrabold">
                                  🔒 AES-256 E2E
                                </span>
                                {activeConv.isSecretChat && (
                                  <span className="px-2 py-0.5 rounded-full bg-[#7C3AED] text-white text-[10px] font-extrabold">
                                    🕵️ Secret Mode
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-[#52607A] font-medium">
                                Disappearing Timer:{' '}
                                <strong>
                                  {activeConv.disappearAfterSeconds
                                    ? `${activeConv.disappearAfterSeconds}s`
                                    : 'Off'}
                                </strong>{' '}
                                • Auto-Reply ({autoReplyRules.filter((r) => r.enabled).length} rules)
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 flex-wrap">
                            <button
                              type="button"
                              onClick={startLiveLocationShare}
                              className="px-2.5 py-1.5 rounded-xl bg-[#0EA5E9] text-white text-xs font-extrabold flex items-center gap-1 shadow"
                            >
                              <MapPin className="w-3.5 h-3.5" /> Live Location
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setConversations((prev) =>
                                  prev.map((c) =>
                                    c.userId === activeConv.userId
                                      ? { ...c, isSecretChat: !c.isSecretChat }
                                      : c,
                                  ),
                                );
                                if (!secretChatPassword) {
                                  triggerToast(
                                    'Tip: Set a Secret Chat Security Password in Control Core → Advanced Settings!',
                                  );
                                }
                              }}
                              className={`px-2.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1 shadow ${
                                activeConv.isSecretChat
                                  ? 'bg-[#7C3AED] text-white'
                                  : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A]'
                              }`}
                            >
                              <Lock className="w-3.5 h-3.5" />{' '}
                              {activeConv.isSecretChat ? 'Secret ON' : 'Make Secret'}
                            </button>
                            <select
                              value={activeConv.disappearAfterSeconds || 0}
                              aria-label="Disappearing message timer"
                              onChange={(e) => {
                                const secs = Number(e.target.value);
                                setConversations((prev) =>
                                  prev.map((c) =>
                                    c.userId === activeConv.userId
                                      ? { ...c, disappearAfterSeconds: secs }
                                      : c,
                                  ),
                                );
                                triggerToast(
                                  secs > 0
                                    ? `⏳ Disappearing messages set to ${secs} seconds!`
                                    : 'Disappearing timer turned OFF.',
                                );
                              }}
                              className="px-2 py-1.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-bold"
                            >
                              <option value={0}>Timer: Off</option>
                              <option value={10}>⏳ 10s</option>
                              <option value={60}>⏳ 60s</option>
                              <option value={86400}>⏳ 24h</option>
                            </select>
                            <button
                              onClick={() =>
                                triggerRealtimeCall(
                                  {
                                    name: activeConv.displayName,
                                    avatar: activeConv.avatarUrl,
                                    phone: '+91 98765 43210',
                                    mode: 'audio',
                                  },
                                  { incomingRingOnly: false, broadcast: true },
                                )
                              }
                              className="px-2.5 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1 shadow"
                            >
                              <Phone className="w-3.5 h-3.5" /> Call
                            </button>
                            <button
                              onClick={() =>
                                triggerRealtimeCall(
                                  {
                                    name: activeConv.displayName,
                                    avatar: activeConv.avatarUrl,
                                    phone: '+91 98765 43210',
                                    mode: 'video',
                                  },
                                  { incomingRingOnly: false, broadcast: true },
                                )
                              }
                              className="px-2.5 py-1.5 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold flex items-center gap-1 shadow"
                            >
                              <Video className="w-3.5 h-3.5" /> Video Call
                            </button>
                            <button
                              onClick={() => setEmojiGameActiveEmoji('🔥')}
                              className="px-2.5 py-1.5 rounded-xl fism-gradient-flame text-white text-xs font-extrabold flex items-center gap-1 shadow"
                            >
                              🎮 Game
                            </button>
                          </div>
                        </div>

                        {/* Simulate Incoming Message from Follower to Test Automatic Profile Auto-Reply */}
                        <div className="p-2.5 rounded-xl bg-[#F5F7FF] dark:bg-slate-900 border border-[#7C3AED]/40 flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-[11px] font-extrabold text-[#7C3AED]">
                            🤖 Test Incoming Message from @{activeConv.username} (Triggers Profile Auto-Reply):
                          </span>
                          <div className="flex items-center gap-1.5 flex-wrap flex-1 sm:flex-initial">
                            <input
                              type="text"
                              value={simulatedIncomingChatText}
                              onChange={(e) => setSimulatedIncomingChatText(e.target.value)}
                              placeholder="Type incoming text (e.g. hi, price, collab)..."
                              className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                            />
                            <button
                              onClick={() => {
                                const incomingRaw = simulatedIncomingChatText.trim();
                                if (!incomingRaw) return;
                                const matchedRule = autoReplyRules.find(
                                  (r) =>
                                    r.enabled &&
                                    r.triggerText.trim().toLowerCase() ===
                                      incomingRaw.toLowerCase(),
                                );
                                const incomingMsg = {
                                  id: `m_in_${Date.now()}`,
                                  senderId: activeConv.userId,
                                  senderName: activeConv.displayName,
                                  recipientId: myProfile.uid,
                                  text: incomingRaw,
                                  messageType: 'text' as const,
                                  reactions: [],
                                  isRead: Boolean(matchedRule),
                                  delivered: true,
                                  createdAt: 'Just now',
                                  isEncrypted: true,
                                  awaitingManualReply: !matchedRule,
                                };

                                const autoReplyMsg = matchedRule
                                  ? {
                                      id: `m_auto_${Date.now() + 1}`,
                                      senderId: myProfile.uid,
                                      senderName: `${myProfile.displayName} (Auto-Reply)`,
                                      recipientId: activeConv.userId,
                                      text: matchedRule.replyText,
                                      messageType: 'text' as const,
                                      reactions: ['🤖'],
                                      replyToText: incomingRaw,
                                      isRead: true,
                                      delivered: true,
                                      createdAt: 'Auto-Reply • Instant',
                                      isEncrypted: true,
                                      isAutoReply: true,
                                    }
                                  : null;

                                setConversations((prev) =>
                                  prev.map((c) =>
                                    c.userId === activeConv.userId
                                      ? {
                                          ...c,
                                          messages: autoReplyMsg
                                            ? [...c.messages, incomingMsg, autoReplyMsg]
                                            : [...c.messages, incomingMsg],
                                        }
                                      : c,
                                  ),
                                );

                                if (matchedRule) {
                                  triggerToast(
                                    `🤖 Auto-Reply Sent Automatically for "${incomingRaw}"`,
                                  );
                                } else {
                                  triggerToast(
                                    `📩 Message "${incomingRaw}" received — waiting for manual reply.`,
                                  );
                                }
                              }}
                              className="px-3 py-1 rounded-lg bg-[#7C3AED] text-white text-[11px] font-extrabold"
                            >
                              Simulate Receive
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* SECRET CHAT PASSWORD LOCK GATE */}
                      {isThreadLocked ? (
                        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-4">
                          <div className="w-16 h-16 rounded-2xl fism-gradient-royal text-white flex items-center justify-center shadow-xl">
                            <Lock className="w-8 h-8" />
                          </div>
                          <div>
                            <h3 className="text-lg font-extrabold">
                              Secret Chat Locked ({activeConv.displayName})
                            </h3>
                            <p className="text-xs text-[#52607A] max-w-sm mt-1">
                              Enter your Chat Security Password to view or send disappearing messages
                              in this Secret Chat.
                            </p>
                          </div>
                          {secretUnlockError && (
                            <div className="px-3 py-2 rounded-xl bg-[#DC2626] text-white text-xs font-bold">
                              {secretUnlockError}
                            </div>
                          )}
                          <div className="flex items-center gap-2 w-full max-w-xs">
                            <input
                              type="password"
                              value={secretUnlockInput}
                              onChange={(e) => setSecretUnlockInput(e.target.value)}
                              placeholder="Enter Secret Chat Password..."
                              className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm font-bold"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                if (secretUnlockInput === secretChatPassword) {
                                  setSecretChatsLocked(false);
                                  setSecretUnlockInput('');
                                  setSecretUnlockError(null);
                                  triggerToast('🔓 Secret Chats Unlocked!');
                                } else {
                                  setSecretUnlockError('❌ Incorrect Secret Chat Password!');
                                }
                              }}
                              className="fism-btn-primary px-4 py-2.5 rounded-xl text-xs font-extrabold"
                            >
                              Unlock
                            </button>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setSettingsSubTab('advanced');
                              setActiveScreen('controlCore');
                            }}
                            className="text-xs font-extrabold text-[#7C3AED] hover:underline"
                          >
                            Forgot / Delete Password? Recover via Firebase OTP in Advanced Settings →
                          </button>
                        </div>
                      ) : (
                        <>
                          {/* Messages List (Including Live Location Map Cards + Long-Press Emoji Blast Game) */}
                          <div className="flex-1 py-4 space-y-3 overflow-y-auto max-h-[400px]">
                            {activeConv.messages.map((m) => {
                              const isMe = m.senderId === myProfile.uid;
                              const extractedEmoji =
                                m.text.match(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/u)?.[0] ||
                                '🔥';
                              const liveLoc = m.liveShareId ? liveLocationsMap[m.liveShareId] : undefined;
                              const displayLat = liveLoc?.lat ?? m.lat ?? 28.6139;
                              const displayLng = liveLoc?.lng ?? m.lng ?? 77.209;
                              const isStillSharing = liveLoc ? liveLoc.isSharing : Boolean(m.liveSharingActive);

                              const startHoldMsg = () => {
                                if (chatMsgHoldTimerRef.current)
                                  clearTimeout(chatMsgHoldTimerRef.current);
                                chatMsgHoldTimerRef.current = setTimeout(() => {
                                  setEmojiGameActiveEmoji(extractedEmoji);
                                }, 420);
                              };
                              const endHoldMsg = () => {
                                if (chatMsgHoldTimerRef.current) {
                                  clearTimeout(chatMsgHoldTimerRef.current);
                                  chatMsgHoldTimerRef.current = null;
                                }
                              };

                              return (
                                <div
                                  key={m.id}
                                  onMouseDown={startHoldMsg}
                                  onMouseUp={endHoldMsg}
                                  onMouseLeave={endHoldMsg}
                                  onTouchStart={startHoldMsg}
                                  onTouchEnd={endHoldMsg}
                                  className={`flex flex-col select-none cursor-pointer ${
                                    isMe ? 'items-end' : 'items-start'
                                  }`}
                                >
                                  {m.replyToText && (
                                    <div className="text-[11px] text-[#52607A] italic mb-1 px-2 border-l-2 border-[#FF5722]">
                                      Replying to: "{m.replyToText}"
                                    </div>
                                  )}

                                  {m.messageType === 'location' ? (
                                    <div className="w-full max-w-sm rounded-2xl overflow-hidden border-2 border-[#0EA5E9] bg-[#0F172A] text-white shadow-xl">
                                      <FismEmberLiveLocationMap
                                        lat={displayLat}
                                        lng={displayLng}
                                        senderName={m.senderName}
                                        accuracyMeters={
                                          liveLoc?.accuracyMeters ?? m.accuracyMeters ?? 15
                                        }
                                        isSharing={isStillSharing}
                                        updatedAt={liveLoc?.updatedAt || m.createdAt}
                                      />

                                      <div className="p-3 flex items-center justify-between gap-2 text-xs">
                                        <div>
                                          <div className="font-extrabold">
                                            {m.senderName}&apos;s Live Location
                                          </div>
                                          <div className="text-[10px] text-slate-400">
                                            Updated: {liveLoc?.updatedAt || m.createdAt}
                                          </div>
                                        </div>
                                        <div className="flex items-center gap-1.5">
                                          <button
                                            type="button"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              setInAppMapModalTarget({
                                                lat: displayLat,
                                                lng: displayLng,
                                                title: `${m.senderName}'s Live Location`,
                                                label: m.senderName,
                                                isLive: isStillSharing,
                                                accuracyMeters:
                                                  liveLoc?.accuracyMeters ?? m.accuracyMeters ?? 15,
                                              });
                                            }}
                                            className="px-2.5 py-1.5 rounded-lg bg-[#0EA5E9] hover:bg-sky-600 text-white text-[10px] font-extrabold"
                                          >
                                            Open Map
                                          </button>
                                          {isStillSharing && m.liveShareId && isMe && (
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                stopLiveLocationShare(m.liveShareId!);
                                              }}
                                              className="px-2.5 py-1.5 rounded-lg bg-[#DC2626] text-white text-[10px] font-extrabold"
                                            >
                                              Stop
                                            </button>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                  ) : (
                                    <div
                                      className={`max-w-md px-4 py-2.5 rounded-2xl text-sm shadow-sm ${
                                        isMe
                                          ? 'fism-gradient-flame text-white'
                                          : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#151B2B] dark:text-white'
                                      }`}
                                    >
                                      {m.isAutoReply && (
                                        <div className="text-[10px] font-extrabold uppercase text-[#FFB300] mb-0.5">
                                          🤖 Automatic Profile Auto-Reply
                                        </div>
                                      )}
                                      <p>{m.text}</p>
                                    </div>
                                  )}

                                  <div className="flex items-center gap-2 mt-1 text-[10px] text-[#52607A] flex-wrap">
                                    <span>{m.createdAt}</span>
                                    <span className="text-[#16A34A] font-bold">🔒 E2E Encrypted</span>
                                    {m.expiresAtMs && (
                                      <span className="px-1.5 py-0.5 rounded bg-[#7C3AED]/15 text-[#7C3AED] font-extrabold">
                                        ⏳ Auto-Deletes in{' '}
                                        {Math.max(1, Math.ceil((m.expiresAtMs - Date.now()) / 1000))}s
                                      </span>
                                    )}
                                    {m.awaitingManualReply && (
                                      <span className="px-1.5 py-0.5 rounded bg-amber-500/15 text-[#D97706] font-extrabold">
                                        ⏳ Pending Manual Reply
                                      </span>
                                    )}
                                    <button
                                      onClick={() => setEmojiGameActiveEmoji(extractedEmoji)}
                                      className="text-[#FF5722] font-extrabold hover:underline"
                                    >
                                      🎮 Play {extractedEmoji} Game
                                    </button>
                                    <button
                                      onClick={() => setReplyingToMessage(m.text)}
                                      className="hover:underline font-semibold"
                                    >
                                      Reply
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>

                          {/* Quick Emoji Bar & Message Input */}
                          <div className="pt-3 border-t border-[#D8E1F0] dark:border-slate-800 space-y-2">
                            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                              <span className="text-[11px] font-bold text-[#52607A] mr-1">
                                Quick Emoji + Game:
                              </span>
                              {['🔥', '⚡', '❤️', '🚀', '💎', '🎉', '👑'].map((emo) => (
                                <button
                                  key={emo}
                                  onClick={() => {
                                    const msgId = `m_${Date.now()}`;
                                    const expiresAtMs =
                                      activeConv.disappearAfterSeconds &&
                                      activeConv.disappearAfterSeconds > 0
                                        ? Date.now() + activeConv.disappearAfterSeconds * 1000
                                        : undefined;
                                    setConversations((prev) =>
                                      prev.map((c) =>
                                        c.userId === activeConv.userId
                                          ? {
                                              ...c,
                                              messages: [
                                                ...c.messages,
                                                {
                                                  id: msgId,
                                                  senderId: myProfile.uid,
                                                  senderName: myProfile.displayName,
                                                  recipientId: activeConv.userId,
                                                  text: `${emo} Let's play Emoji Blast! (Long-press to launch)`,
                                                  messageType: 'text',
                                                  reactions: [emo],
                                                  isRead: true,
                                                  delivered: true,
                                                  createdAt: 'Just now',
                                                  isSecret: Boolean(activeConv.isSecretChat),
                                                  expiresAtMs,
                                                },
                                              ],
                                            }
                                          : c,
                                      ),
                                    );
                                    setEmojiGameActiveEmoji(emo);
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-[#F1F5F9] dark:bg-slate-800 hover:bg-[#FF5722] hover:text-white text-sm transition-colors"
                                >
                                  {emo}
                                </button>
                              ))}
                            </div>

                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={chatInput}
                                onChange={(e) => setChatInput(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' && chatInput.trim()) {
                                    const cleanText = chatInput.trim();
                                    const matchedRule = autoReplyRules.find(
                                      (r) =>
                                        r.enabled &&
                                        r.triggerText.trim().toLowerCase() ===
                                          cleanText.toLowerCase(),
                                    );
                                    const expiresAtMs =
                                      activeConv.disappearAfterSeconds &&
                                      activeConv.disappearAfterSeconds > 0
                                        ? Date.now() + activeConv.disappearAfterSeconds * 1000
                                        : undefined;
                                    const userMsg = {
                                      id: `m_${Date.now()}`,
                                      senderId: myProfile.uid,
                                      senderName: myProfile.displayName,
                                      recipientId: activeConv.userId,
                                      text: cleanText,
                                      messageType: 'text' as const,
                                      reactions: [],
                                      replyToText: replyingToMessage || undefined,
                                      isRead: true,
                                      delivered: true,
                                      createdAt: 'Just now',
                                      isSecret: Boolean(activeConv.isSecretChat),
                                      expiresAtMs,
                                    };
                                    const autoReplyObj = matchedRule
                                      ? {
                                          id: `m_auto_${Date.now() + 1}`,
                                          senderId: activeConv.userId,
                                          senderName: `${activeConv.displayName} (Auto-Reply)`,
                                          recipientId: myProfile.uid,
                                          text: matchedRule.replyText,
                                          messageType: 'text' as const,
                                          reactions: ['🤖'],
                                          replyToText: cleanText,
                                          isRead: true,
                                          delivered: true,
                                          createdAt: 'Auto-Reply • Instant',
                                          isAutoReply: true,
                                          expiresAtMs,
                                        }
                                      : null;

                                    setConversations((prev) =>
                                      prev.map((c) =>
                                        c.userId === activeConv.userId
                                          ? {
                                              ...c,
                                              messages: autoReplyObj
                                                ? [
                                                    ...c.messages.map((item) => ({
                                                      ...item,
                                                      awaitingManualReply: false,
                                                    })),
                                                    userMsg,
                                                    autoReplyObj,
                                                  ]
                                                : [
                                                    ...c.messages.map((item) => ({
                                                      ...item,
                                                      awaitingManualReply: false,
                                                    })),
                                                    userMsg,
                                                  ],
                                            }
                                          : c,
                                      ),
                                    );
                                    setChatInput('');
                                    setReplyingToMessage(null);
                                  }
                                }}
                                placeholder="Write an E2E encrypted message (or type hi / price / collab)..."
                                className="flex-1 px-3.5 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm"
                              />
                              <button
                                onClick={() => {
                                  if (!chatInput.trim()) return;
                                  const cleanText = chatInput.trim();
                                  const matchedRule = autoReplyRules.find(
                                    (r) =>
                                      r.enabled &&
                                      r.triggerText.trim().toLowerCase() ===
                                        cleanText.toLowerCase(),
                                  );
                                  const expiresAtMs =
                                    activeConv.disappearAfterSeconds &&
                                    activeConv.disappearAfterSeconds > 0
                                      ? Date.now() + activeConv.disappearAfterSeconds * 1000
                                      : undefined;
                                  const userMsg = {
                                    id: `m_${Date.now()}`,
                                    senderId: myProfile.uid,
                                    senderName: myProfile.displayName,
                                    recipientId: activeConv.userId,
                                    text: cleanText,
                                    messageType: 'text' as const,
                                    reactions: [],
                                    replyToText: replyingToMessage || undefined,
                                    isRead: true,
                                    delivered: true,
                                    createdAt: 'Just now',
                                    isSecret: Boolean(activeConv.isSecretChat),
                                    expiresAtMs,
                                  };
                                  const autoReplyObj = matchedRule
                                    ? {
                                        id: `m_auto_${Date.now() + 1}`,
                                        senderId: activeConv.userId,
                                        senderName: `${activeConv.displayName} (Auto-Reply)`,
                                        recipientId: myProfile.uid,
                                        text: matchedRule.replyText,
                                        messageType: 'text' as const,
                                        reactions: ['🤖'],
                                        replyToText: cleanText,
                                        isRead: true,
                                        delivered: true,
                                        createdAt: 'Auto-Reply • Instant',
                                        isAutoReply: true,
                                        expiresAtMs,
                                      }
                                    : null;

                                  setConversations((prev) =>
                                    prev.map((c) =>
                                      c.userId === activeConv.userId
                                        ? {
                                            ...c,
                                            messages: autoReplyObj
                                              ? [
                                                  ...c.messages.map((item) => ({
                                                    ...item,
                                                    awaitingManualReply: false,
                                                  })),
                                                  userMsg,
                                                  autoReplyObj,
                                                ]
                                              : [
                                                  ...c.messages.map((item) => ({
                                                    ...item,
                                                    awaitingManualReply: false,
                                                  })),
                                                  userMsg,
                                                ],
                                          }
                                        : c,
                                    ),
                                  );
                                  setChatInput('');
                                  setReplyingToMessage(null);
                                }}
                                className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5"
                              >
                                <Send className="w-4 h-4" /> Send
                              </button>
                            </div>
                          </div>
                        </>
                      )}
                    </>
                  );
                })()}
              </div>
            </div>
          )}

          {/* SCREEN 7: WARM SPARKS (NOTIFICATIONS) */}
          {activeScreen === 'warmSparks' && (
            <div className="max-w-3xl mx-auto fism-card p-5 space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                  <h1 className="text-xl font-extrabold flex items-center gap-2">
                    <Bell className="w-5 h-5 text-[#FF5722]" /> Warm Sparks — Real-Time Notifications
                  </h1>
                  <p className="text-xs text-[#52607A]">
                    Real-Time Call Notifications &amp; Instant Live Alerts across all sections.
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() =>
                      dispatchRealtimeNotification(
                        {
                          id: `notif_rt_${Date.now()}`,
                          actorId: myProfile.uid,
                          actorName: myProfile.displayName,
                          actorAvatar: myProfile.avatarUrl,
                          notificationType: 'spark',
                          message: 'sent you a Real-Time Spark & Live Notification Alert! 🔥',
                          isRead: false,
                          createdAt: 'Real-Time • Just now',
                          targetScreen: 'warmSparks',
                        },
                        true,
                      )
                    }
                    className="px-3 py-1.5 rounded-xl bg-[#FF5722] text-white text-xs font-extrabold shadow"
                  >
                    🔔 Send Real-Time Notification
                  </button>
                  <button
                    onClick={() =>
                      triggerRealtimeCall(
                        {
                          name: 'Aarav Blaze (Live Caller)',
                          avatar:
                            'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
                          phone: '+91 98765 43210',
                          mode: 'video',
                        },
                        { incomingRingOnly: true, broadcast: true },
                      )
                    }
                    className="px-3 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold shadow"
                  >
                    📞 Simulate Incoming Call Notification
                  </button>
                  <button
                    onClick={() => {
                      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
                      triggerToast('All Warm Sparks marked as read.');
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold hover:text-[#FF5722]"
                  >
                    Mark All as Read
                  </button>
                </div>
              </div>

              <div className="flex gap-2 flex-wrap">
                {(['all', 'unread', 'follow_request', 'spark', 'chatter', 'fuelUp', 'collab_tag'] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setNotifFilter(f)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold uppercase ${
                      notifFilter === f
                        ? 'fism-btn-primary'
                        : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A]'
                    }`}
                  >
                    {f === 'collab_tag'
                      ? 'Collabs'
                      : f === 'follow_request'
                        ? 'Follow Requests'
                        : f}
                  </button>
                ))}
              </div>

              <div className="space-y-2.5">
                {notifications
                  .filter((n) => {
                    if (notifFilter === 'unread') return !n.isRead;
                    if (notifFilter === 'all') return true;
                    return n.notificationType === notifFilter;
                  })
                  .map((n) => (
                    <div
                      key={n.id}
                      className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 flex-wrap ${
                        n.isRead
                          ? 'bg-white dark:bg-slate-900 border-[#D8E1F0] dark:border-slate-800'
                          : 'bg-[#F8FAFE] dark:bg-slate-800/90 border-[#FF5722]'
                      }`}
                    >
                      <div
                        onClick={() => {
                          setNotifications((prev) =>
                            prev.map((item) =>
                              item.id === n.id ? { ...item, isRead: true } : item,
                            ),
                          );
                          if (n.targetScreen) setActiveScreen(n.targetScreen);
                        }}
                        className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                      >
                        <img
                          src={n.actorAvatar}
                          alt={n.actorName}
                          className="w-10 h-10 rounded-full object-cover shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="text-sm">
                            <span className="font-bold">{n.actorName}</span> {n.message}
                          </p>
                          <span className="text-xs text-[#52607A]">{n.createdAt}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0 flex-wrap">
                        {n.notificationType === 'follow_request' && n.followRequestId && (
                          n.followRequestStatus === 'accepted' ? (
                            <span className="px-2.5 py-1 rounded-lg bg-[#16A34A]/15 text-[#16A34A] text-xs font-extrabold">
                              ✓ Request Accepted
                            </span>
                          ) : n.followRequestStatus === 'declined' ? (
                            <span className="px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 text-[#52607A] text-xs font-extrabold">
                              ✕ Declined
                            </span>
                          ) : (
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() =>
                                  void handleRespondFollowRequest(n.followRequestId!, 'accept')
                                }
                                className="min-h-[36px] px-3 py-1.5 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white text-xs font-extrabold shadow"
                              >
                                ✓ Accept
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  void handleRespondFollowRequest(n.followRequestId!, 'decline')
                                }
                                className="min-h-[36px] px-3 py-1.5 rounded-xl bg-[#DC2626] hover:bg-[#B91C1C] text-white text-xs font-extrabold shadow"
                              >
                                ✕ Decline
                              </button>
                            </div>
                          )
                        )}
                        {n.notificationType === 'collab_tag' && n.targetPostId && (
                          n.collabStatus === 'accepted' ? (
                            <span className="px-2.5 py-1 rounded-lg bg-[#16A34A]/15 text-[#16A34A] text-xs font-extrabold">
                              ✓ Accepted Collab
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() =>
                                handleAcceptCollabTag(
                                  n.id,
                                  n.targetPostId!,
                                  n.targetUid || activeIdentityUid,
                                )
                              }
                              className="min-h-[36px] px-3 py-1.5 rounded-xl bg-[#7C3AED] hover:bg-[#6D28D9] text-white text-xs font-extrabold shadow"
                            >
                              ✓ Accept Collaboration
                            </button>
                          )
                        )}
                        <button
                          onClick={() =>
                            setNotifications((prev) => prev.filter((item) => item.id !== n.id))
                          }
                          className="text-xs text-[#52607A] hover:text-[#DC2626] p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* SCREEN 8: FIND FLAME (SEARCH & EXPLORE) */}
          {activeScreen === 'findFlame' && (
            <div className="space-y-6">
              <div className="fism-card p-5 space-y-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h1 className="text-xl font-extrabold flex items-center gap-2">
                    <Search className="w-5 h-5 text-[#FF5722]" /> Find Flame — Real-Time Discovery
                  </h1>
                  <span className="text-xs font-bold text-[#52607A] dark:text-slate-400">
                    High-Contrast Instant Search
                  </span>
                </div>

                {/* Dedicated High-Contrast Search Input inside Find Flame */}
                <div className="relative flex items-center">
                  <Search className="w-5 h-5 text-[#FF5722] absolute left-3.5 pointer-events-none" />
                  <input
                    type="text"
                    value={globalSearchQuery}
                    onChange={(e) => setGlobalSearchQuery(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && globalSearchQuery.trim()) {
                        const trimmed = globalSearchQuery.trim();
                        trackBehaviorSignal('search', [trimmed.toLowerCase()], 1);
                        if (!recentSearches.includes(trimmed)) {
                          setRecentSearches((prev) => [trimmed, ...prev.slice(0, 7)]);
                        }
                      }
                    }}
                    placeholder="Type here to search posts, Shorts, creators, or #hashtags..."
                    className="w-full pl-11 pr-24 py-3 rounded-2xl bg-white dark:bg-[#1E293B] text-[#0F172A] dark:text-white placeholder:text-[#64748B] dark:placeholder:text-[#94A3B8] font-bold text-sm border-2 border-[#FF5722]/60 focus:border-[#FF5722] focus:outline-none shadow-sm"
                  />
                  {globalSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setGlobalSearchQuery('')}
                      className="absolute right-20 p-1.5 rounded-full text-[#0F172A] dark:text-white hover:bg-slate-200 dark:hover:bg-slate-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      const trimmed = globalSearchQuery.trim();
                      if (trimmed) {
                        trackBehaviorSignal('search', [trimmed.toLowerCase()], 1);
                        if (!recentSearches.includes(trimmed)) {
                          setRecentSearches((prev) => [trimmed, ...prev.slice(0, 7)]);
                        }
                      }
                    }}
                    className="absolute right-2 px-4 py-1.5 rounded-xl fism-btn-primary text-xs font-extrabold"
                  >
                    Search
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {(['All', 'People', 'Posts', 'Videos', 'Hashtags', 'Creators', 'Live'] as const).map(
                    (cat) => (
                      <button
                        key={cat}
                        onClick={() => setFindCategory(cat)}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-bold ${
                          findCategory === cat
                            ? 'fism-btn-primary'
                            : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#0F172A] dark:text-slate-200'
                        }`}
                      >
                        {cat}
                      </button>
                    ),
                  )}
                </div>

                {recentSearches.length > 0 && (
                  <div className="flex items-center justify-between flex-wrap gap-2 pt-3 border-t border-[#D8E1F0] dark:border-slate-800">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-[#52607A]">Recent:</span>
                      {recentSearches.map((term) => (
                        <button
                          key={term}
                          onClick={() => setGlobalSearchQuery(term)}
                          className="px-2.5 py-1 rounded-lg bg-[#F1F5F9] dark:bg-slate-800 text-[#0F172A] dark:text-white text-xs font-semibold hover:text-[#FF5722]"
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                    <button
                      onClick={() => setRecentSearches([])}
                      className="text-xs text-[#DC2626] font-semibold hover:underline"
                    >
                      Clear History
                    </button>
                  </div>
                )}
              </div>

              {/* Matching Creators / People Section */}
              {(findCategory === 'All' || findCategory === 'People' || findCategory === 'Creators') && (
                <div className="fism-card p-4 space-y-3">
                  <h2 className="text-sm font-extrabold flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#FF5722]" /> Matching Creators & People
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {creators
                      .filter((c) => {
                        if (!globalSearchQuery.trim()) return true;
                        const q = globalSearchQuery.toLowerCase();
                        return (
                          c.displayName.toLowerCase().includes(q) ||
                          c.username.toLowerCase().includes(q) ||
                          c.bio.toLowerCase().includes(q)
                        );
                      })
                      .map((c) => (
                        <div
                          key={c.uid}
                          onClick={() => {
                            setViewedProfileId(c.uid);
                            setActiveScreen('myHearth');
                          }}
                          className="p-3 rounded-xl border border-[#D8E1F0] dark:border-slate-800 bg-[#F8FAFE] dark:bg-slate-900/70 flex items-center justify-between gap-2 cursor-pointer hover:border-[#FF5722]"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <img
                              src={c.avatarUrl}
                              alt={c.displayName}
                              className="w-10 h-10 rounded-full object-cover shrink-0"
                            />
                            <div className="min-w-0">
                              <div className="text-xs font-extrabold truncate flex items-center gap-1">
                                <span>{c.displayName}</span>
                                {c.isVerified && (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-[#16A34A] shrink-0" />
                                )}
                                {c.isPrivate && (
                                  <Lock className="w-3 h-3 text-[#F59E0B] shrink-0" />
                                )}
                              </div>
                              <div className="text-[11px] text-[#52607A] truncate">
                                @{c.username} • {c.isPrivate ? '🔒 Private' : '🌐 Public'}
                              </div>
                            </div>
                          </div>
                          <span className="px-2.5 py-1 rounded-lg bg-[#FF5722]/15 text-[#FF5722] text-[10px] font-extrabold shrink-0">
                            View
                          </span>
                        </div>
                      ))}

                    {subAccounts
                      .filter((sa) => sa.id !== activeSubAccount?.id)
                      .filter((sa) => {
                        if (!globalSearchQuery.trim()) return true;
                        const q = globalSearchQuery.toLowerCase();
                        return (
                          sa.displayName.toLowerCase().includes(q) ||
                          sa.username.toLowerCase().includes(q) ||
                          (sa.bio || '').toLowerCase().includes(q)
                        );
                      })
                      .map((sa) => {
                        const isPublicSub = sa.privacyMode === 'public' && sa.isAgeVerified;
                        return (
                          <div
                            key={sa.id}
                            onClick={() => {
                              setViewedProfileId(sa.id);
                              setActiveScreen('myHearth');
                            }}
                            className="p-3 rounded-xl border border-[#D8E1F0] dark:border-slate-800 bg-[#F8FAFE] dark:bg-slate-900/70 flex items-center justify-between gap-2 cursor-pointer hover:border-[#FF5722]"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <img
                                src={sa.avatarUrl}
                                alt={sa.displayName}
                                className="w-10 h-10 rounded-full object-cover shrink-0"
                              />
                              <div className="min-w-0">
                                <div className="text-xs font-extrabold truncate flex items-center gap-1">
                                  <span>{sa.displayName}</span>
                                  {sa.isAgeVerified && (
                                    <CheckCircle2 className="w-3.5 h-3.5 text-[#16A34A] shrink-0" />
                                  )}
                                  {!isPublicSub && (
                                    <Lock className="w-3 h-3 text-[#F59E0B] shrink-0" />
                                  )}
                                </div>
                                <div className="text-[11px] text-[#52607A] truncate">
                                  @{sa.username} • {isPublicSub ? '🌐 Public ID' : '🔒 Private Sub-ID'}
                                </div>
                              </div>
                            </div>
                            <span className="px-2.5 py-1 rounded-lg bg-[#7C3AED]/15 text-[#7C3AED] text-[10px] font-extrabold shrink-0">
                              Open
                            </span>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}

              {/* Matching Posts, Shorts & Videos across all FISM Posts (Respects Private Account Gate) */}
              <div className="space-y-4">
                {posts
                  .filter((p) => {
                    if (isPostCopyrightBlocked(p) || blockedCreatorIds.has(p.authorId)) return false;
                    if (!canViewAuthorContent(p.authorId, p.visibility)) return false;
                    if (
                      findCategory === 'Videos' &&
                      p.postType !== 'video' &&
                      p.postType !== 'quickBurst'
                    )
                      return false;
                    if (findCategory === 'Posts' && p.postType !== 'photo') return false;
                    if (findCategory === 'Live' && p.postType !== 'live') return false;
                    if (!globalSearchQuery.trim()) return true;
                    const q = globalSearchQuery.toLowerCase();
                    return (
                      p.title.toLowerCase().includes(q) ||
                      p.caption.toLowerCase().includes(q) ||
                      p.authorDisplayName.toLowerCase().includes(q) ||
                      p.authorUsername.toLowerCase().includes(q) ||
                      p.hashtags.some((h) => h.toLowerCase().includes(q))
                    );
                  })
                  .map((p) => renderPostCard(p))}
              </div>
            </div>
          )}

          {/* SCREEN 9: MY HEARTH (USER PROFILE PAGE) */}
          {activeScreen === 'myHearth' && (
            <div className="max-w-4xl mx-auto space-y-5">
              {(() => {
                const subMatch = subAccounts.find((a) => a.id === viewedProfileId);
                const subAsCreator: FismCreator | undefined = subMatch
                  ? {
                      uid: subMatch.id,
                      username: subMatch.username,
                      displayName: subMatch.displayName,
                      bio: subMatch.bio || `FISM Sub-ID @${subMatch.username}`,
                      avatarUrl: subMatch.avatarUrl,
                      coverUrl: subMatch.coverUrl || myProfile.coverUrl,
                      isVerified: Boolean(subMatch.isAgeVerified),
                      isAgeVerified: Boolean(subMatch.isAgeVerified),
                      isPrivate: !(subMatch.privacyMode === 'public' && subMatch.isAgeVerified),
                      sparksCount: subMatch.sparksCount ?? 0,
                      flamesCount: subMatch.flamesCount ?? 0,
                      fuelersCount: subMatch.fuelersCount ?? 0,
                      categories: subMatch.categories || [],
                      location: subMatch.location || myProfile.location,
                      website: subMatch.website || `https://fism.social/@${subMatch.username}`,
                      isConnected: Boolean(
                        activeSubAccount?.connectedCreatorUids?.includes(subMatch.id),
                      ),
                      isFuelledUp: false,
                      monthlyPrice: 4.99,
                    }
                  : undefined;

                const isViewingOwn =
                  viewedProfileId === myProfile.uid ||
                  viewedProfileId === activeSubAccount?.id ||
                  viewedProfileId === 'local_hearth_user';

                const profile = isViewingOwn
                  ? myProfile
                  : creators.find((c) => c.uid === viewedProfileId) ||
                    subAsCreator ||
                    myProfile;
                const isOwnProfile =
                  profile.uid === myProfile.uid || profile.uid === activeSubAccount?.id;
                const targetIsPrivate = Boolean(
                  isOwnProfile
                    ? !(
                        activeSubAccount?.privacyMode === 'public' &&
                        activeSubAccount?.isAgeVerified
                      )
                    : profile.isPrivate,
                );
                const viewerCanSeeContent =
                  isOwnProfile ||
                  canViewAuthorContent(profile.uid, targetIsPrivate ? 'private' : 'public');
                const viewerSubId = activeSubAccount?.id || activeIdentityUid;
                const pendingFollowRequest = followRequests.find(
                  (r) =>
                    r.requesterUid === viewerSubId &&
                    r.targetUid === profile.uid &&
                    r.status === 'pending',
                );

                const applyCustomStyle = isOwnProfile && userHasBoughtPremium;
                const activeFontObj =
                  PREMIUM_USERNAME_FONTS.find((f) => f.id === premiumProfileStyle.usernameFontId) ||
                  PREMIUM_USERNAME_FONTS[0];
                const profileMilestone = isOwnProfile
                  ? {
                      hasRedTick: userMilestone.hasRedMilestoneTick,
                      tier: userMilestone.currentTier,
                      vipGoldBadge: userMilestone.vipGoldBadgeUnlocked,
                      frame: userMilestone.equippedFrame,
                    }
                  : getAuthorMilestoneInfo(profile.uid);
                const frameCls = getProfileFrameClasses(profileMilestone.frame);

                return (
                  <>
                    <div
                      style={
                        applyCustomStyle
                          ? {
                              borderColor: premiumProfileStyle.themeColorHex,
                              backgroundColor: premiumProfileStyle.customDarkAccent
                                ? '#0B0F1A'
                                : undefined,
                              color: premiumProfileStyle.customDarkAccent ? '#F8FAFC' : undefined,
                            }
                          : undefined
                      }
                      className={`fism-card overflow-hidden ${
                        applyCustomStyle ? 'border-2 shadow-xl' : ''
                      }`}
                    >
                      <div className="h-44 sm:h-56 relative bg-[#0F172A]">
                        <img
                          src={profile.coverUrl}
                          alt="Cover"
                          className="w-full h-full object-cover"
                        />
                        {applyCustomStyle && (
                          <div
                            className="absolute inset-x-0 bottom-0 h-2"
                            style={{ backgroundColor: premiumProfileStyle.themeColorHex }}
                          />
                        )}
                      </div>

                      <div className="px-4 sm:px-6 pb-5">
                        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-12 relative z-10">
                          <div className="flex items-end gap-4">
                            <img
                              src={profile.avatarUrl}
                              alt={profile.displayName}
                              style={
                                applyCustomStyle && !frameCls
                                  ? { boxShadow: `0 0 0 4px ${premiumProfileStyle.themeColorHex}` }
                                  : undefined
                              }
                              className={`w-24 h-24 rounded-2xl object-cover shadow-xl ${
                                frameCls || 'ring-4 ring-white dark:ring-slate-900'
                              }`}
                            />
                            <div className="pb-1">
                              <h1 className="text-xl sm:text-2xl font-extrabold flex items-center gap-2 flex-wrap">
                                <span
                                  className={`${applyCustomStyle ? activeFontObj.fontClass : ''} ${
                                    applyCustomStyle &&
                                    premiumProfileStyle.usernameEffectId === 'flameGradient'
                                      ? 'bg-gradient-to-r from-[#FF5722] to-[#FFB300] bg-clip-text text-transparent'
                                      : applyCustomStyle &&
                                          premiumProfileStyle.usernameEffectId === 'goldShimmer'
                                        ? 'text-[#F59E0B]'
                                        : applyCustomStyle &&
                                            premiumProfileStyle.usernameEffectId === 'royalOutline'
                                          ? 'text-[#A855F7]'
                                          : ''
                                  }`}
                                >
                                  {profile.displayName}
                                </span>
                                {profileMilestone.hasRedTick && (
                                  <FismRedMilestoneTick
                                    size="lg"
                                    onClick={() =>
                                      openMilestoneJourneyForUser({
                                        accountId: profile.uid,
                                        username: profile.username,
                                        displayName: profile.displayName,
                                        avatarUrl: profile.avatarUrl,
                                      })
                                    }
                                  />
                                )}
                                {profileMilestone.vipGoldBadge && <FismVipGoldChatBadge />}
                                {(isOwnProfile ? activeSubAccount?.isAgeVerified : profile.isVerified) && (
                                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#16A34A]/15 text-[#16A34A] border border-[#16A34A] text-xs font-extrabold">
                                    <CheckCircle2 className="w-4 h-4 fill-[#16A34A]/20" />
                                    18+ Verified
                                  </span>
                                )}
                                <span
                                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-extrabold border ${
                                    targetIsPrivate
                                      ? 'bg-[#F59E0B]/15 text-[#D97706] border-[#F59E0B]'
                                      : 'bg-[#2563EB]/15 text-[#2563EB] border-[#2563EB]'
                                  }`}
                                >
                                  {targetIsPrivate ? (
                                    <>
                                      <Lock className="w-3.5 h-3.5" /> Private Account
                                    </>
                                  ) : (
                                    '🌐 Public Account'
                                  )}
                                </span>
                              </h1>
                              <p
                                style={
                                  applyCustomStyle
                                    ? { color: premiumProfileStyle.themeColorHex }
                                    : undefined
                                }
                                className={`text-xs sm:text-sm font-bold ${
                                  applyCustomStyle ? activeFontObj.fontClass : 'text-[#52607A]'
                                }`}
                              >
                                @{profile.username}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 flex-wrap">
                            {isOwnProfile ? (
                              <>
                                <button
                                  onClick={() => setEditProfileModalOpen(true)}
                                  className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5"
                                >
                                  <Edit3 className="w-4 h-4" /> Edit My Hearth
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    void handleUpdateActiveAccountPrivacy(
                                      targetIsPrivate ? 'public' : 'private',
                                    )
                                  }
                                  className="px-3.5 py-2 rounded-xl bg-[#0F172A] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
                                >
                                  {targetIsPrivate ? '🌐 Go Public (18+)' : '🔒 Switch to Private'}
                                </button>
                                <button
                                  onClick={() => {
                                    setSettingsSubTab('standard');
                                    setActiveScreen('controlCore');
                                  }}
                                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#F59E0B] to-[#FF5722] text-white text-xs font-extrabold flex items-center gap-1 shadow"
                                >
                                  <Crown className="w-3.5 h-3.5" /> Customize Theme
                                </button>
                                  <button
                                    onClick={() => {
                                      setSettingsSubTab('smart');
                                      setActiveScreen('controlCore');
                                    }}
                                    className="px-3.5 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
                                  >
                                    Switch / Sub-ID &amp; 18+ ID ({subAccounts.length})
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      void shareFismLink({
                                        title: `${profile.displayName} (@${profile.username}) on FISM`,
                                        text: `Follow @${profile.username} on FISM Flame Interactive Social Media!`,
                                        url: buildFismShareUrl('user', profile.username),
                                        triggerToast,
                                      })
                                    }
                                    className="px-3.5 py-2 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
                                  >
                                    <Share2 className="w-3.5 h-3.5" /> Share Profile Link
                                  </button>
                                </>
                              ) : (
                              <>
                                {targetIsPrivate && !viewerCanSeeContent ? (
                                  <button
                                    type="button"
                                    disabled={Boolean(pendingFollowRequest)}
                                    onClick={() =>
                                      void handleSendPrivateFollowRequest({
                                        uid: profile.uid,
                                        username: profile.username,
                                        displayName: profile.displayName,
                                        isPrivate: true,
                                      })
                                    }
                                    className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 ${
                                      pendingFollowRequest
                                        ? 'bg-[#F59E0B]/20 text-[#D97706] border border-[#F59E0B] cursor-default'
                                        : 'fism-btn-primary'
                                    }`}
                                  >
                                    <Lock className="w-3.5 h-3.5" />
                                    {pendingFollowRequest ? 'Requested ⏳' : 'Send Follow Request'}
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => handleToggleConnectCreator(profile.uid)}
                                    className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-bold"
                                  >
                                    {profile.isConnected ? 'Flames' : 'Connect'}
                                  </button>
                                )}
                                <button
                                  onClick={() => handleToggleFuelUpCreator(profile)}
                                  className="px-4 py-2 rounded-xl bg-[#F59E0B] text-white text-xs font-bold"
                                >
                                  Fuel Up (${profile.monthlyPrice}/mo)
                                </button>
                                {(() => {
                                  const alreadyMember = channelMemberships.some(
                                    (m) =>
                                      m.creatorUid === profile.uid &&
                                      m.memberUid === activeIdentityUid,
                                  );
                                  return (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        alreadyMember
                                          ? triggerToast(`🎖️ You are already a Channel Member of @${profile.username}!`)
                                          : handleJoinChannelMembership({
                                              uid: profile.uid,
                                              username: profile.username,
                                              displayName: profile.displayName,
                                              avatarUrl: profile.avatarUrl,
                                            })
                                      }
                                      className={`px-4 py-2 rounded-xl text-xs font-extrabold ${
                                        alreadyMember
                                          ? 'bg-[#16A34A] text-white'
                                          : 'bg-[#7C3AED] hover:bg-[#6D28D9] text-white'
                                      }`}
                                    >
                                      {alreadyMember
                                        ? '★ Channel Member'
                                        : `Join Membership (${CHANNEL_MEMBERSHIP_SP_COST} SP)`}
                                    </button>
                                  );
                                })()}
                              </>
                            )}
                          </div>
                        </div>

                        {/* PROFILE GREEN VERIFY BADGE + LOGIN STATUS + MOBILE NUMBER VERIFICATION CARD (Moved from Header to User Profile!) */}
                        {isOwnProfile && (
                          <div className="mt-4 p-3.5 rounded-2xl bg-[#F0FDF4] dark:bg-emerald-950/30 border-2 border-[#16A34A] flex flex-wrap items-center justify-between gap-3">
                            <div className="flex flex-wrap items-center gap-2.5 text-xs">
                              <span className="px-3 py-1 rounded-xl bg-[#16A34A] text-white font-extrabold flex items-center gap-1.5 shadow-sm">
                                <CheckCircle2 className="w-4 h-4" />{' '}
                                {activeSubAccount?.isAgeVerified
                                  ? '18+ Vision ID Verified'
                                  : 'Aadhaar 18+ Verification Pending'}
                              </span>
                              <span className="px-3 py-1 rounded-xl bg-white dark:bg-slate-900 border border-[#16A34A]/40 font-bold text-[#151B2B] dark:text-white">
                                📧 Login ID: {currentUser?.email || loginEmailInput}
                              </span>
                              <span className="px-3 py-1 rounded-xl bg-white dark:bg-slate-900 border border-[#16A34A]/40 font-bold text-[#16A34A] flex items-center gap-1">
                                <Smartphone className="w-3.5 h-3.5" /> Number Verified:{' '}
                                {activeSubAccount?.phoneNumber || subAccounts[0]?.phoneNumber || loginMobileNumber}
                              </span>
                            </div>
                            <button
                              onClick={() => setLoginGatePromptOpen(true)}
                              className="px-3 py-1.5 rounded-xl bg-[#151B2B] text-white text-xs font-extrabold"
                            >
                              Account &amp; Login Options
                            </button>
                          </div>
                        )}

                        {/* ANNUAL MILESTONE TICK & COLLECTIBLE CARDS BANNER */}
                        {(() => {
                          const msInfo = isOwnProfile
                            ? {
                                hasRedTick: userMilestone.hasRedMilestoneTick,
                                tier: userMilestone.currentTier,
                                tenureYears: userMilestone.tenureYears,
                                tenureDays: userMilestone.tenureDays,
                              }
                            : {
                                ...computeTenureStats(getAuthorMilestoneInfo(profile.uid).joinedAtIso),
                                hasRedTick: getAuthorMilestoneInfo(profile.uid).hasRedTick,
                                tier: getAuthorMilestoneInfo(profile.uid).tier,
                              };
                          return (
                            <div className="mt-3 p-3.5 rounded-2xl bg-gradient-to-r from-[#18060B] via-[#3B0A16] to-[#0F172A] text-white border border-[#EF4444]/60 flex items-center justify-between gap-3 flex-wrap shadow-lg">
                              <div className="flex items-center gap-3 min-w-0">
                                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#EF4444] to-[#991B1B] flex items-center justify-center shadow shrink-0">
                                  <Check className="w-5 h-5 stroke-[3]" />
                                </div>
                                <div className="min-w-0">
                                  <div className="text-xs sm:text-sm font-black flex items-center gap-1.5 flex-wrap">
                                    <span>
                                      {msInfo.hasRedTick
                                        ? `${msInfo.tier.toUpperCase()} Milestone Card Active`
                                        : 'Annual Red Milestone Card Progress'}
                                    </span>
                                    {msInfo.hasRedTick && (
                                      <FismRedMilestoneTick
                                        size="sm"
                                        onClick={() =>
                                          openMilestoneJourneyForUser({
                                            accountId: profile.uid,
                                            username: profile.username,
                                            displayName: profile.displayName,
                                            avatarUrl: profile.avatarUrl,
                                          })
                                        }
                                      />
                                    )}
                                  </div>
                                  <div className="text-[11px] text-red-100/85 tabular-nums">
                                    {msInfo.tenureYears.toFixed(1)} Years ({msInfo.tenureDays} Days) •{' '}
                                    {isOwnProfile
                                      ? `SP Wallet: ${spWallet.spCoins.toLocaleString()} SP`
                                      : 'Click Red Tick to inspect Year 1–5+ Journey'}
                                  </div>
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() =>
                                  openMilestoneJourneyForUser({
                                    accountId: profile.uid,
                                    username: profile.username,
                                    displayName: profile.displayName,
                                    avatarUrl: profile.avatarUrl,
                                  })
                                }
                                className="min-h-[40px] px-4 py-2 rounded-xl bg-gradient-to-r from-[#EF4444] to-[#FF5722] text-white text-xs font-black shadow whitespace-nowrap shrink-0"
                              >
                                {isOwnProfile
                                  ? 'View Cards & Test Years 0–5+'
                                  : 'Open Achievement Card'}
                              </button>
                            </div>
                          );
                        })()}

                        {/* Selected Profile Categories (Up to 4 Categories) */}
                        {profile.categories && profile.categories.length > 0 && (
                          <div className="mt-3 flex items-center gap-1.5 flex-wrap">
                            {profile.categories.map((cat) => (
                              <span
                                key={cat}
                                className="px-2.5 py-1 rounded-full bg-[#7C3AED]/15 text-[#7C3AED] border border-[#7C3AED]/30 text-xs font-extrabold"
                              >
                                #{cat}
                              </span>
                            ))}
                          </div>
                        )}

                        {/* Channel Detail / Bio Clamped to 2 Lines with "More" Expand Button */}
                        <div className="mt-3 max-w-2xl">
                          <p
                            className={`text-sm whitespace-pre-line leading-relaxed ${
                              bioExpanded ? '' : 'line-clamp-2'
                            }`}
                          >
                            {profile.bio}
                          </p>
                          {profile.bio && profile.bio.length > 90 && (
                            <button
                              onClick={() => setBioExpanded((prev) => !prev)}
                              className="mt-1 text-xs font-extrabold text-[#FF5722] hover:underline"
                            >
                              {bioExpanded ? 'Show Less ▲' : 'More... ▼'}
                            </button>
                          )}
                        </div>

                        {/* Clean FISM Metric Labels: Strictly Sparks, Flames, Fuelers ONLY (Sparks hidden on unapproved Private Accounts) */}
                        <div className="grid grid-cols-3 gap-2 sm:gap-3 mt-5 pt-4 border-t border-[#D8E1F0] dark:border-slate-800 max-w-lg">
                          <button
                            onClick={() => {
                              if (!viewerCanSeeContent) {
                                triggerToast(
                                  '🔒 Sparks are hidden on Private Accounts until your Follow Request is accepted.',
                                );
                                return;
                              }
                              setProfileModalList('Sparks');
                            }}
                            className="p-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-left"
                          >
                            <div className="font-extrabold text-sm sm:text-base flex items-center gap-1">
                              {viewerCanSeeContent ? (
                                profile.sparksCount.toLocaleString()
                              ) : (
                                <>
                                  <Lock className="w-3.5 h-3.5 text-[#D97706]" /> Private
                                </>
                              )}
                            </div>
                            <div className="text-[11px] font-bold text-[#52607A]">Sparks</div>
                          </button>
                          <button
                            onClick={() => setProfileModalList('Flames')}
                            className="p-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-left"
                          >
                            <div className="font-extrabold text-sm sm:text-base">
                              {profile.flamesCount.toLocaleString()}
                            </div>
                            <div className="text-[11px] font-bold text-[#52607A]">Flames</div>
                          </button>
                          <button
                            onClick={() => setProfileModalList('Fuelers')}
                            className="p-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-left"
                          >
                            <div className="font-extrabold text-sm sm:text-base">
                              {profile.fuelersCount.toLocaleString()}
                            </div>
                            <div className="text-[11px] font-bold text-[#52607A]">Fuelers</div>
                          </button>
                        </div>

                        {/* CONNECTED MEMBER CHANNELS (Shows on BOTH Creator & Buyer Channels) */}
                        {(() => {
                          const linkedMemberships = channelMemberships.filter(
                            (m) =>
                              m.memberUid === profile.uid ||
                              m.creatorUid === profile.uid ||
                              (isOwnProfile &&
                                (m.memberUid === activeIdentityUid || m.creatorUid === activeIdentityUid)),
                          );
                          if (linkedMemberships.length === 0) return null;
                          return (
                            <div className="mt-4 p-3.5 rounded-2xl bg-[#7C3AED]/10 border border-[#7C3AED]/40 space-y-2.5">
                              <div className="flex items-center justify-between gap-2 flex-wrap">
                                <span className="text-xs font-extrabold uppercase text-[#7C3AED] flex items-center gap-1.5">
                                  <Crown className="w-4 h-4" /> Connected Member Channels (500 SP)
                                </span>
                                <span className="text-[11px] font-bold text-[#52607A]">
                                  {linkedMemberships.length} Connected
                                </span>
                              </div>
                              <div className="flex flex-wrap gap-2">
                                {linkedMemberships.map((m) => {
                                  const isBuyerHere =
                                    m.memberUid === profile.uid ||
                                    (isOwnProfile && m.memberUid === activeIdentityUid);
                                  const peerUid = isBuyerHere ? m.creatorUid : m.memberUid;
                                  const peerUsername = isBuyerHere ? m.creatorUsername : m.memberUsername;
                                  const peerName = isBuyerHere ? m.creatorDisplayName : m.memberDisplayName;
                                  const peerAvatar = isBuyerHere ? m.creatorAvatar : m.memberAvatar;
                                  return (
                                    <button
                                      key={m.id}
                                      type="button"
                                      onClick={() => {
                                        setViewedProfileId(peerUid);
                                        setActiveScreen('myHearth');
                                      }}
                                      className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-[#7C3AED]/40 hover:border-[#FF5722] text-xs font-bold shadow-sm"
                                    >
                                      <img
                                        src={peerAvatar}
                                        alt={peerName}
                                        className="w-6 h-6 rounded-full object-cover"
                                      />
                                      <div className="text-left">
                                        <div className="text-xs font-extrabold leading-tight">
                                          {peerName}
                                        </div>
                                        <div className="text-[10px] text-[#7C3AED] font-semibold">
                                          @{peerUsername} • {isBuyerHere ? 'Creator' : 'Member'}
                                        </div>
                                      </div>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })()}

                        {/* SPARKS MILESTONE UNLOCKS TRACKER (50 Live, 500 Shopping Link, 2000 3D VR Video) */}
                        {isOwnProfile && (
                          <div className="mt-4 p-4 rounded-2xl bg-[#F5F7FF] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
                            <div className="flex items-center justify-between flex-wrap gap-2">
                              <span className="text-xs font-extrabold uppercase text-[#FF5722]">
                                🔥 Channel Sparks Milestones (AI Real-Time Verified Every 1s)
                              </span>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-[11px] text-[#52607A] font-bold">
                                  Test Sparks Level:
                                </span>
                                {[
                                  { val: 25, label: '25 (<50)' },
                                  { val: 120, label: '120 (50+ Live)' },
                                  { val: 650, label: '650 (500+ Shop)' },
                                  { val: 2500, label: '2,500 (3D VR)' },
                                  { val: 5500, label: '5,500 (5000+ Earning 💰)' },
                                ].map((preset) => (
                                  <button
                                    key={preset.val}
                                    onClick={() => {
                                      setMyProfile((prev) => ({
                                        ...prev,
                                        sparksCount: preset.val,
                                      }));
                                      triggerToast(
                                        `⚡ Channel Sparks set to ${preset.val.toLocaleString()} Sparks!`,
                                      );
                                    }}
                                    className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold ${
                                      myProfile.sparksCount === preset.val
                                        ? 'bg-[#FF5722] text-white'
                                        : 'bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700'
                                    }`}
                                  >
                                    {preset.label}
                                  </button>
                                ))}
                              </div>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
                              <div
                                className={`p-3 rounded-xl border ${
                                  myProfile.sparksCount >= 50
                                    ? 'bg-[#16A34A]/10 border-[#16A34A] text-[#16A34A]'
                                    : 'bg-white dark:bg-slate-800 border-[#D8E1F0] text-[#52607A]'
                                }`}
                              >
                                <div className="font-extrabold">
                                  {myProfile.sparksCount >= 50 ? '✓ Unlocked' : '🔒 Locked'} • 50
                                  Sparks
                                </div>
                                <div className="text-[11px] mt-0.5">
                                  On Fire Live Streaming on Channel
                                </div>
                              </div>
                              <div
                                className={`p-3 rounded-xl border ${
                                  myProfile.sparksCount >= 500
                                    ? 'bg-[#16A34A]/10 border-[#16A34A] text-[#16A34A]'
                                    : 'bg-white dark:bg-slate-800 border-[#D8E1F0] text-[#52607A]'
                                }`}
                              >
                                <div className="font-extrabold">
                                  {myProfile.sparksCount >= 500 ? '✓ Unlocked' : '🔒 Locked'} • 500
                                  Sparks
                                </div>
                                <div className="text-[11px] mt-0.5">
                                  Enter Shopping Link (Corner Photo in Shorts &amp; Description Link
                                  in Main Blast)
                                </div>
                              </div>
                              <div
                                className={`p-3 rounded-xl border ${
                                  myProfile.sparksCount >= 2000
                                    ? 'bg-[#16A34A]/10 border-[#16A34A] text-[#16A34A]'
                                    : 'bg-white dark:bg-slate-800 border-[#D8E1F0] text-[#52607A]'
                                }`}
                              >
                                <div className="font-extrabold">
                                  {myProfile.sparksCount >= 2000 ? '✓ Unlocked' : '🔒 Locked'} •
                                  2,000 Sparks
                                </div>
                                <div className="text-[11px] mt-0.5">
                                  3D VR Videos &amp; Upload Your Own 3D VR Video
                                </div>
                              </div>
                              <div
                                onClick={() => setActiveScreen('earningHub')}
                                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                                  myProfile.sparksCount >= 5000
                                    ? 'bg-[#16A34A]/10 border-[#16A34A] text-[#16A34A] shadow-sm'
                                    : 'bg-white dark:bg-slate-800 border-[#D8E1F0] text-[#52607A]'
                                }`}
                              >
                                <div className="font-extrabold">
                                  {myProfile.sparksCount >= 5000 ? '✓ Unlocked' : '🔒 Locked'} •
                                  5,000 Sparks
                                </div>
                                <div className="text-[11px] mt-0.5">
                                  💰 Creator Earning (1 Lakh Views = $0.0001 USD + Global Currency)
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                        {/* CREATOR STUDIO COPYRIGHT PROTECTION & APPEAL / DISPUTE PANEL (Own Profile Only) */}
                        {isOwnProfile &&
                          posts.some((p) => p.authorId === profile.uid && isPostCopyrightBlocked(p)) && (
                            <div className="mt-4 p-4 rounded-2xl bg-red-50/70 dark:bg-red-950/30 border-2 border-[#DC2626] space-y-3">
                              <div className="flex items-center justify-between flex-wrap gap-2">
                                <div className="flex items-center gap-2 text-xs font-extrabold uppercase text-[#DC2626]">
                                  <ShieldAlert className="w-4 h-4" /> Creator Copyright Protection &amp;
                                  Appeal / Dispute Center
                                </div>
                                <span className="px-2.5 py-0.5 rounded-full bg-[#DC2626] text-white text-[10px] font-black">
                                  Views Blocked (0 Views)
                                </span>
                              </div>
                              <div className="space-y-2.5">
                                {posts
                                  .filter((p) => p.authorId === profile.uid && isPostCopyrightBlocked(p))
                                  .map((flaggedPost) => (
                                    <div
                                      key={flaggedPost.id}
                                      className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-[#DC2626]/40 space-y-2 text-xs"
                                    >
                                      <div className="flex items-center justify-between flex-wrap gap-2">
                                        <div>
                                          <div className="font-extrabold text-sm">
                                            {flaggedPost.title}
                                          </div>
                                          <div className="text-[11px] text-[#DC2626] font-bold">
                                            {RESTRICTED_COPYRIGHT_MESSAGE}
                                          </div>
                                        </div>
                                        <span className="px-2.5 py-1 rounded-lg bg-[#DC2626] text-white text-[10px] font-black">
                                          {flaggedPost.copyrightStatus} • 0 Views
                                        </span>
                                      </div>

                                      <div className="text-[11px] text-[#52607A]">
                                        Match Details: {flaggedPost.copyrightReason}
                                      </div>

                                      {flaggedPost.copyrightStatus === 'APPEAL_PENDING' ? (
                                        <div className="p-2.5 rounded-lg bg-amber-500/15 border border-amber-500 text-amber-700 dark:text-amber-300 font-bold">
                                          ⏳ Appeal Pending Review — Proof submitted:{' '}
                                          {flaggedPost.copyrightAppeal?.proofText}
                                        </div>
                                      ) : activeAppealPostId === flaggedPost.id ? (
                                        <div className="space-y-2 pt-1">
                                          <textarea
                                            rows={2}
                                            value={appealProofText}
                                            onChange={(e) => setAppealProofText(e.target.value)}
                                            placeholder="Provide license URL, original project proof, or dispute explanation..."
                                            className="w-full p-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                                          />
                                          <div className="flex items-center justify-between flex-wrap gap-2">
                                            <label className="px-3 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-bold cursor-pointer">
                                              📎 Attach License Proof{' '}
                                              {appealProofFileName ? `(${appealProofFileName})` : ''}
                                              <input
                                                type="file"
                                                className="hidden"
                                                onChange={(e) => {
                                                  const f = e.target.files?.[0];
                                                  if (f) setAppealProofFileName(f.name);
                                                }}
                                              />
                                            </label>
                                            <div className="flex items-center gap-2">
                                              <button
                                                type="button"
                                                onClick={() => setActiveAppealPostId(null)}
                                                className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 text-xs font-bold"
                                              >
                                                Cancel
                                              </button>
                                              <button
                                                type="button"
                                                onClick={() =>
                                                  handleSubmitCopyrightAppeal(flaggedPost.id)
                                                }
                                                className="fism-btn-primary px-3.5 py-1.5 rounded-lg text-xs font-extrabold"
                                              >
                                                Submit Appeal to Admin
                                              </button>
                                            </div>
                                          </div>
                                        </div>
                                      ) : (
                                        <button
                                          type="button"
                                          onClick={() => setActiveAppealPostId(flaggedPost.id)}
                                          className="px-3.5 py-1.5 rounded-lg bg-[#F59E0B] text-white text-xs font-extrabold"
                                        >
                                          🛡️ Appeal / Dispute False Positive
                                        </button>
                                      )}
                                    </div>
                                  ))}
                              </div>
                            </div>
                          )}
                      </div>
                    </div>

                    {!viewerCanSeeContent ? (
                      <div className="fism-card p-8 text-center border-2 border-[#F59E0B] space-y-3">
                        <div className="w-14 h-14 mx-auto rounded-2xl bg-[#F59E0B]/15 flex items-center justify-center">
                          <Lock className="w-7 h-7 text-[#D97706]" />
                        </div>
                        <h3 className="text-lg font-extrabold">This Account Is Private</h3>
                        <p className="text-xs text-[#52607A] max-w-md mx-auto">
                          @{profile.username}&apos;s Posts, Videos, Quick Bursts &amp; Sparks are
                          hidden from non-followers. Send a Follow Request—content unlocks as soon
                          as the owner accepts.
                        </p>
                        <button
                          type="button"
                          disabled={Boolean(pendingFollowRequest)}
                          onClick={() =>
                            void handleSendPrivateFollowRequest({
                              uid: profile.uid,
                              username: profile.username,
                              displayName: profile.displayName,
                              isPrivate: true,
                            })
                          }
                          className={`px-5 py-2.5 rounded-xl text-xs font-extrabold inline-flex items-center gap-1.5 ${
                            pendingFollowRequest
                              ? 'bg-[#F59E0B]/20 text-[#D97706] border border-[#F59E0B] cursor-default'
                              : 'fism-btn-primary'
                          }`}
                        >
                          <Lock className="w-3.5 h-3.5" />
                          {pendingFollowRequest ? 'Follow Request Pending ⏳' : 'Send Follow Request'}
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="flex gap-2 flex-wrap">
                          {(
                            [
                              'Posts',
                              'Videos',
                              'Quick Burst',
                              'On Fire',
                              'AshStash',
                              'Ad & Affiliate',
                              'About',
                            ] as const
                          )
                            .filter((t) => isOwnProfile || t !== 'Ad & Affiliate')
                            .map((t) => (
                              <button
                                key={t}
                                onClick={() => setProfileTab(t)}
                                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
                                  profileTab === t
                                    ? 'fism-btn-primary'
                                    : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A]'
                                }`}
                              >
                                {t === 'On Fire' && <Radio className="w-3.5 h-3.5" />}
                                {t === 'Ad & Affiliate' && <Megaphone className="w-3.5 h-3.5" />}
                                {t}
                                {t === 'On Fire' &&
                                  ` (${onFireSavedVideos.filter((v) => v.authorId === profile.uid || isOwnProfile).length})`}
                              </button>
                            ))}
                        </div>

                        {profileTab === 'Ad & Affiliate' && isOwnProfile ? (
                          <FismAdAndAffiliateStudio
                            currentUserId={currentUser?.uid || myProfile.uid}
                            currentUsername={myProfile.username}
                            currentDisplayName={myProfile.displayName}
                            currentAvatar={myProfile.avatarUrl}
                            subscriberCount={myProfile.sparksCount}
                            storeConfig={affiliateStoreConfig}
                            onSaveStoreConfig={handleSaveStoreConfig}
                            smartAds={smartAds}
                            onCreateCreatorAd={handleCreateSmartAd}
                            onToggleAdActive={handleToggleSmartAd}
                            onDeleteAd={handleDeleteSmartAd}
                            behaviorProfile={behaviorProfile}
                            onTriggerToast={triggerToast}
                          />
                        ) : profileTab === 'About' ? (
                          <div className="fism-card p-5 space-y-2 text-sm">
                            <h3 className="font-bold text-base">About {profile.displayName}</h3>
                            <p>{profile.bio}</p>
                          </div>
                        ) : profileTab === 'On Fire' ? (
                          <div className="space-y-4">
                            <div className="fism-card p-4 border-2 border-[#E53935]/40 flex items-center justify-between flex-wrap gap-2">
                              <div>
                                <h3 className="font-extrabold text-sm flex items-center gap-2">
                                  <Radio className="w-4 h-4 text-[#E53935]" /> Saved On Fire Live Videos (
                                  {profile.displayName})
                                </h3>
                                <p className="text-xs text-[#52607A]">
                                  Every On Fire camera or screen-sharing stream created by this profile
                                  is saved here so users can watch anytime.
                                </p>
                              </div>
                            </div>
                            {onFireSavedVideos.filter((v) => v.authorId === profile.uid || isOwnProfile)
                              .length === 0 ? (
                              <div className="fism-card p-6 text-center text-xs text-[#52607A] font-semibold">
                                No On Fire broadcasts recorded yet on this profile. Start an On Fire Live
                                stream and end it to automatically save the replay here!
                              </div>
                            ) : (
                              onFireSavedVideos
                                .filter((v) => v.authorId === profile.uid || isOwnProfile)
                                .map((v) => renderPostCard(v))
                            )}
                          </div>
                        ) : (
                          posts
                            .filter((p) => {
                              if (!isOwnProfile && isPostCopyrightBlocked(p)) return false;
                              const isChannelOwner = isOwnProfile
                                ? p.authorId === profile.uid ||
                                  p.authorId === activeIdentityUid ||
                                  (activeSubAccount?.isMaster && p.authorId === 'local_hearth_user')
                                : p.authorId === profile.uid;
                              const isAcceptedCollab = (p.taggedCollaborators || []).some(
                                (tc) =>
                                  (tc.uid === profile.uid ||
                                    (isOwnProfile && tc.uid === activeIdentityUid)) &&
                                  tc.status === 'accepted',
                              );
                              if (!isChannelOwner && !isAcceptedCollab) return false;
                              if (profileTab === 'Videos') return p.postType === 'video';
                              if (profileTab === 'Quick Burst') return p.postType === 'quickBurst';
                              if (profileTab === 'AshStash') return p.isStashed;
                              return true;
                            })
                            .map((p) => renderPostCard(p))
                        )}
                      </>
                    )}
                  </>
                );
              })()}
            </div>
          )}

          {/* SCREEN 10: ASHSTASH (SAVED COLLECTIONS) */}
          {activeScreen === 'ashStash' && (
            <div className="max-w-4xl mx-auto space-y-5">
              <div className="fism-card p-5 flex items-center justify-between flex-wrap gap-3">
                <div>
                  <h1 className="text-xl font-extrabold flex items-center gap-2">
                    <Bookmark className="w-5 h-5 text-[#F59E0B] fill-[#F59E0B]" /> AshStash — Saved
                    Collections
                  </h1>
                  <p className="text-xs text-[#52607A]">
                    Organize your bookmarked posts, Main Blast videos, and Quick Bursts.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newCollectionName}
                    onChange={(e) => setNewCollectionName(e.target.value)}
                    placeholder="New collection..."
                    className="px-3 py-1.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                  />
                  <button
                    onClick={() => {
                      if (!newCollectionName.trim()) return;
                      setStashCollections((prev) => [...prev, newCollectionName.trim()]);
                      setSelectedStashCollection(newCollectionName.trim());
                      setNewCollectionName('');
                      triggerToast('Created new AshStash collection!');
                    }}
                    className="fism-btn-primary px-3.5 py-1.5 rounded-xl text-xs font-bold"
                  >
                    + Create
                  </button>
                </div>
              </div>

              <div className="flex gap-2 flex-wrap">
                {stashCollections.map((col) => (
                  <button
                    key={col}
                    onClick={() => setSelectedStashCollection(col)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold ${
                      selectedStashCollection === col
                        ? 'bg-[#F59E0B] text-white'
                        : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A]'
                    }`}
                  >
                    {col}
                  </button>
                ))}
              </div>

              {posts
                .filter((p) => p.isStashed && !isPostCopyrightBlocked(p))
                .map((post) => renderPostCard(post))}
            </div>
          )}

          {/* SCREEN 11: ON FIRE (REAL WEBRTC LIVE STREAMING + SCREEN SHARING & 3D STUDIO) */}
          {activeScreen === 'onFire' && (
            <div className="space-y-5">
              {/* Camera Live Format Choice Modal: Long (16:9) vs Quick Burst (9:16) */}
              {cameraLiveFormatModalOpen && (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                  <div className="w-full max-w-lg rounded-3xl bg-[#101426] border-2 border-[#FF5722] p-6 text-white shadow-2xl space-y-5">
                    <div className="flex items-center justify-between">
                      <span className="px-3 py-1 rounded-full bg-[#FF5722]/20 border border-[#FF5722] text-[#FFB300] text-xs font-extrabold uppercase">
                        Camera Studio Live Format
                      </span>
                      <button
                        onClick={() => setCameraLiveFormatModalOpen(false)}
                        className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <h3 className="text-xl font-extrabold">
                      कैमरा लाइव स्ट्रीम के लिए फॉर्मेट चुनें (Long या Quick Burst)
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                      <button
                        onClick={async () => {
                          setCameraLiveAspectMode('long');
                          setCameraLiveFormatModalOpen(false);
                          await startLiveBroadcast();
                        }}
                        className="p-4 rounded-2xl bg-[#181F36] hover:bg-[#FF5722]/20 border-2 border-[#FF5722] text-left space-y-2 transition-all"
                      >
                        <Monitor className="w-8 h-8 text-[#FF5722]" />
                        <div className="font-extrabold text-sm text-white">
                          1. Long Camera Live (16:9)
                        </div>
                        <p className="text-[11px] text-slate-300">
                          Standard widescreen camera broadcast with Full Screen &amp; Side Chat.
                        </p>
                      </button>
                      <button
                        onClick={async () => {
                          setCameraLiveAspectMode('quickBurst');
                          setCameraLiveFormatModalOpen(false);
                          await startLiveBroadcast();
                        }}
                        className="p-4 rounded-2xl bg-[#181F36] hover:bg-[#FFB300]/20 border-2 border-[#FFB300] text-left space-y-2 transition-all"
                      >
                        <Smartphone className="w-8 h-8 text-[#FFB300]" />
                        <div className="font-extrabold text-sm text-[#FFB300]">
                          2. Quick Burst Live (9:16)
                        </div>
                        <p className="text-[11px] text-slate-300">
                          Animates to vertical Shorts size &amp; appears inside Quick Burst scroll feed!
                        </p>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* FULL-SCREEN CAMERA STUDIO BROADCAST MODAL (With Side Chat Box, Stop Stream & Filter Changer — No Screen Share Edit Button) */}
              {cameraFullScreenOpen && (
                <div className="fixed inset-0 z-50 bg-[#090D16] text-white flex flex-col lg:flex-row overflow-hidden">
                  {/* Left/Main Full-Screen Camera Feed + Top/Bottom Controls & Filter Switcher */}
                  <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
                    {isBroadcastingLive ? (
                      <video
                        ref={liveVideoRef}
                        muted
                        playsInline
                        className={`w-full h-full object-cover transition-all duration-300 ${getFilterCssClass(
                          cameraLiveFilter,
                        )}`}
                      />
                    ) : (
                      <div className="text-center p-8 space-y-3">
                        <Radio className="w-14 h-14 text-[#FF5722] mx-auto animate-pulse" />
                        <h3 className="text-xl font-extrabold">
                          Full-Screen Camera Broadcast Studio
                        </h3>
                        <p className="text-xs text-slate-300 max-w-md mx-auto">
                          Click &quot;Start Camera Live&quot; below to broadcast in full screen with live
                          filters and side chat!
                        </p>
                        <button
                          onClick={startLiveBroadcast}
                          className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold"
                        >
                          Start Camera Live Now
                        </button>
                      </div>
                    )}

                    {/* Top Full-Screen Header Bar */}
                    <div className="absolute top-4 left-4 right-4 flex items-center justify-between flex-wrap gap-2 z-20">
                      <div className="flex items-center gap-2">
                        <span className="px-3 py-1 rounded-lg bg-[#E53935] text-white text-xs font-extrabold uppercase">
                          ● ON FIRE CAMERA FULL SCREEN
                        </span>
                        <span className="px-3 py-1 rounded-lg bg-black/75 text-white text-xs font-bold">
                          {liveViewerCount} watching
                        </span>
                        <span className="px-2.5 py-1 rounded-lg bg-[#FF5722]/80 text-white text-xs font-extrabold">
                          {liveStreamTitle}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {isBroadcastingLive && (
                          <button
                            onClick={() => {
                              stopLiveBroadcast();
                              setCameraFullScreenOpen(false);
                            }}
                            className="px-4 py-2 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold flex items-center gap-1.5 shadow-lg"
                          >
                            <X className="w-4 h-4" /> Stop Stream
                          </button>
                        )}
                        <button
                          onClick={() => setCameraFullScreenOpen(false)}
                          className="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold flex items-center gap-1"
                        >
                          Exit Full Screen
                        </button>
                      </div>
                    </div>

                    {/* Bottom Camera Filter Switcher Bar inside Full-Screen Camera Live */}
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between flex-wrap gap-2 bg-black/80 backdrop-blur-md p-3 rounded-2xl border border-white/15 z-20">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-extrabold text-[#FFB300] mr-1 flex items-center gap-1">
                          <Wand2 className="w-4 h-4 text-[#FF5722]" /> Change Camera Filter:
                        </span>
                        {(
                          [
                            { id: 'none', label: 'Normal' },
                            { id: 'flameWarm', label: '🔥 Flame Warm' },
                            { id: 'cyberNeon', label: '⚡ Cyber Neon' },
                            { id: 'goldenHour', label: '☀️ Golden Hour' },
                            { id: 'tealOrange', label: '🎬 Cinema Teal' },
                            { id: 'bwContrast', label: '🖤 B&W Noir' },
                          ] as const
                        ).map((f) => (
                          <button
                            key={f.id}
                            onClick={() => setCameraLiveFilter(f.id)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all ${
                              cameraLiveFilter === f.id
                                ? 'bg-[#FF5722] text-white shadow'
                                : 'bg-white/10 text-slate-200 hover:bg-white/20'
                            }`}
                          >
                            {f.label}
                          </button>
                        ))}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setFaceSelectorModalOpen(true)}
                          className="px-3 py-1.5 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-1"
                        >
                          <Sparkles className="w-3.5 h-3.5" /> 3D Avatar ({4 + custom3DModels.length})
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Right Side Dedicated Live Chat Box inside Full-Screen Mode (Supports 50 SP Super Chat & Stickers) */}
                  <div className="w-full lg:w-88 bg-[#101426] border-t lg:border-t-0 lg:border-l border-slate-800 flex flex-col justify-between h-80 lg:h-full p-4">
                    <div className="flex flex-col flex-1 min-h-0">
                      <div className="pb-2.5 border-b border-slate-800 flex items-center justify-between gap-2">
                        <h3 className="font-extrabold text-sm text-[#FFB300] flex items-center gap-1.5">
                          <MessageCircle className="w-4 h-4 text-[#FF5722]" /> Side Live Chat
                        </h3>
                        <span className="text-[10px] font-black px-2 py-0.5 rounded bg-[#FFB300]/20 text-[#FFB300] tabular-nums">
                          🪙 {spWallet.spCoins.toLocaleString()} SP
                        </span>
                      </div>
                      <div className="py-2.5 space-y-2 flex-1 overflow-y-auto">
                        {superChats.slice(0, 3).map((sc) => {
                          const tier =
                            SUPER_CHAT_BOX_TIERS.find((t) => t.id === sc.boxStyle) ||
                            SUPER_CHAT_BOX_TIERS[0];
                          return (
                            <div
                              key={sc.id}
                              className={`p-2 rounded-xl border text-xs shadow ${tier.cardClass}`}
                            >
                              <div className="font-black text-[10px] flex items-center justify-between">
                                <span>
                                  {sc.kind === 'sticker'
                                    ? `${sc.stickerEmoji || '🎁'} STICKER`
                                    : '🔥 SUPER CHAT'}
                                </span>
                                <span>{sc.spCost} SP</span>
                              </div>
                              <div>
                                <span className="font-extrabold">@{sc.senderUsername}:</span> {sc.text}
                              </div>
                            </div>
                          );
                        })}
                        {liveChatMessages.map((msg) => (
                          <div
                            key={msg.id}
                            className="p-2 rounded-xl bg-white/5 border border-white/10 text-xs"
                          >
                            <span className="font-extrabold text-[#FF5722]">@{msg.user}</span>:{' '}
                            <span className="text-slate-100">{msg.text}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2.5 border-t border-slate-800 space-y-2">
                      <div className="flex items-center gap-1">
                        {(['normal', 'superchat', 'sticker'] as const).map((m) => (
                          <button
                            key={m}
                            type="button"
                            onClick={() => setFullScreenChatKind(m)}
                            className={`flex-1 py-1 rounded-lg text-[10px] font-extrabold ${
                              fullScreenChatKind === m
                                ? 'bg-[#FFB300] text-[#101426]'
                                : 'bg-white/10 text-white/75'
                            }`}
                          >
                            {m === 'normal'
                              ? 'Chat'
                              : m === 'superchat'
                                ? `Super Chat (${SP_SUPER_CHAT_COST} SP)`
                                : `Sticker (${SP_SUPER_CHAT_COST} SP)`}
                          </button>
                        ))}
                      </div>

                      {fullScreenChatKind === 'superchat' && (
                        <div className="grid grid-cols-2 gap-1">
                          {SUPER_CHAT_BOX_TIERS.map((tier) => (
                            <button
                              key={tier.id}
                              type="button"
                              onClick={() => setFullScreenSuperBoxStyle(tier.id)}
                              className={`px-2 py-1 rounded-lg text-[10px] font-bold ${tier.cardClass} ${
                                fullScreenSuperBoxStyle === tier.id ? 'ring-2 ring-white' : 'opacity-75'
                              }`}
                            >
                              {tier.label}
                            </button>
                          ))}
                        </div>
                      )}

                      {fullScreenChatKind === 'sticker' && (
                        <div className="grid grid-cols-3 gap-1">
                          {SUPER_STICKER_OPTIONS.map((stk) => (
                            <button
                              key={stk.id}
                              type="button"
                              onClick={() =>
                                void handleSendSuperChat({
                                  kind: 'sticker',
                                  text: `${stk.label} Boost!`,
                                  boxStyle: fullScreenSuperBoxStyle,
                                  stickerId: stk.id,
                                  stickerLabel: stk.label,
                                  stickerEmoji: stk.emoji,
                                  hostUid: activeIdentityUid,
                                })
                              }
                              className="p-1.5 rounded-lg bg-[#181F36] border border-[#FFB300]/40 hover:border-[#FFB300] text-white text-[10px] font-bold"
                            >
                              {stk.emoji} {stk.label}
                            </button>
                          ))}
                        </div>
                      )}

                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={liveChatInput}
                          onChange={(e) => setLiveChatInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && liveChatInput.trim()) {
                              if (fullScreenChatKind === 'superchat') {
                                void handleSendSuperChat({
                                  kind: 'superchat',
                                  text: liveChatInput.trim(),
                                  boxStyle: fullScreenSuperBoxStyle,
                                  hostUid: activeIdentityUid,
                                }).then((ok) => {
                                  if (ok) {
                                    setLiveChatInput('');
                                    setFullScreenChatKind('normal');
                                  }
                                });
                              } else {
                                setLiveChatMessages((prev) => [
                                  ...prev,
                                  {
                                    id: `lc_${Date.now()}`,
                                    user: myProfile.username,
                                    text: liveChatInput.trim(),
                                  },
                                ]);
                                setLiveChatInput('');
                              }
                            }
                          }}
                          placeholder={
                            fullScreenChatKind === 'superchat'
                              ? 'Type 50 SP Super Chat message...'
                              : 'Send chat in Full Screen...'
                          }
                          className="flex-1 px-3 py-2 rounded-xl bg-[#181F36] border border-slate-700 text-xs text-white"
                        />
                        <button
                          onClick={() => {
                            if (!liveChatInput.trim()) return;
                            if (fullScreenChatKind === 'superchat') {
                              void handleSendSuperChat({
                                kind: 'superchat',
                                text: liveChatInput.trim(),
                                boxStyle: fullScreenSuperBoxStyle,
                                hostUid: activeIdentityUid,
                              }).then((ok) => {
                                if (ok) {
                                  setLiveChatInput('');
                                  setFullScreenChatKind('normal');
                                }
                              });
                              return;
                            }
                            setLiveChatMessages((prev) => [
                              ...prev,
                              {
                                id: `lc_${Date.now()}`,
                                user: myProfile.username,
                                text: liveChatInput.trim(),
                              },
                            ]);
                            setLiveChatInput('');
                          }}
                          className="fism-btn-primary px-3.5 py-2 rounded-xl text-xs font-extrabold"
                        >
                          {fullScreenChatKind === 'superchat' ? '50 SP' : 'Send'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Screen Sharing + Edit Screen Layout + Subscriber Voice Alert & 5s Dancing Sticker + 3D Character Studio */}
              <FismOnFireGamingStudioPanel
                gamingState={gamingLiveState}
                setGamingState={setGamingLiveState}
                onStartScreencast={startGamingScreencast}
                onStopScreencast={stopGamingScreencast}
                onToggleFloatingPip={toggleFloatingPipWindow}
                onOpenFaceSelector={() => setFaceSelectorModalOpen(true)}
                screenVideoRef={gamingScreenVideoRef}
                simCanvasRef={gamingSimCanvasRef}
                usingSimulatedScreen={usingSimulatedGamingScreen}
                onPublishHighlightToFeed={handlePublishGamingLiveToFeed}
                custom3DModels={custom3DModels}
                liveChatMessages={liveChatMessages}
                onSendLiveChat={(text) => {
                  setLiveChatMessages((prev) => [
                    ...prev,
                    { id: `lc_${Date.now()}`, user: myProfile.username, text },
                  ]);
                }}
                userSpCoins={spWallet.spCoins}
                superChats={superChats}
                onSendSuperChat={(opts) =>
                  handleSendSuperChat({ ...opts, hostUid: activeIdentityUid })
                }
                onJoinHostMembership={() =>
                  void handleJoinChannelMembership({
                    uid: activeIdentityUid,
                    username: myProfile.username,
                    displayName: myProfile.displayName,
                    avatarUrl: myProfile.avatarUrl,
                  })
                }
                isHostMember={channelMemberships.some(
                  (m) =>
                    m.creatorUid === activeIdentityUid && m.memberUid === activeIdentityUid,
                )}
                onOpenBuySpCoins={() => {
                  setFuelCheckoutMode('sp_coin_pack');
                  setActiveScreen('fuelUp');
                }}
              />

              {/* CAMERA STUDIO BROADCAST (Full Screen + Side Chat + Filter Changer + Long vs Quick Burst Format) */}
              <div className="fism-card p-5 flex items-center justify-between flex-wrap gap-4">
                <div>
                  <h1 className="text-xl font-extrabold flex items-center gap-2">
                    <Radio className="w-6 h-6 text-[#E53935]" /> On Fire — Real-Time Camera Broadcast
                    Studio
                  </h1>
                  <p className="text-xs text-[#52607A]">
                    Broadcast live from your camera with <strong>Full Screen Mode</strong>, Side Chat
                    Box, Live Filter Changer, and <strong>Long (16:9) / Quick Burst (9:16)</strong>{' '}
                    format animation.
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() =>
                      setCameraLiveAspectMode((m) => (m === 'long' ? 'quickBurst' : 'long'))
                    }
                    className="px-3.5 py-2.5 rounded-xl bg-[#101426] text-[#FFB300] border border-[#FF5722] text-xs font-extrabold"
                  >
                    Format: {cameraLiveAspectMode === 'quickBurst' ? '⚡ Quick Burst (9:16)' : '📺 Long (16:9)'}
                  </button>

                  <button
                    onClick={() => setCameraFullScreenOpen(true)}
                    className="px-4 py-2.5 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-1.5 shadow-lg"
                  >
                    <Maximize2 className="w-4 h-4" /> Full Screen (Side Chat + Filters)
                  </button>

                  {!isBroadcastingLive ? (
                    <button
                      onClick={() => setCameraLiveFormatModalOpen(true)}
                      className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-lg"
                    >
                      <Video className="w-4 h-4" /> Start On Fire Live Camera
                    </button>
                  ) : (
                    <button
                      onClick={stopLiveBroadcast}
                      className="px-5 py-2.5 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold flex items-center gap-2 shadow-lg"
                    >
                      <X className="w-4 h-4" /> End Live Stream
                    </button>
                  )}
                </div>
              </div>

              {liveCameraError && (
                <div className="p-4 rounded-xl bg-[#DC2626] text-white text-xs font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{liveCameraError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                <div className="lg:col-span-8 fism-card overflow-hidden p-3">
                  <div
                    className={`relative rounded-2xl overflow-hidden bg-[#0F172A] flex items-center justify-center mx-auto transition-all duration-500 ${
                      cameraLiveAspectMode === 'quickBurst'
                        ? 'max-w-[360px] aspect-[9/16] shadow-2xl border-2 border-[#FFB300]'
                        : 'w-full aspect-video'
                    }`}
                  >
                    {isBroadcastingLive ? (
                      <video
                        ref={liveVideoRef}
                        muted
                        playsInline
                        className={`w-full h-full object-cover transition-all duration-300 ${getFilterCssClass(
                          cameraLiveFilter,
                        )}`}
                      />
                    ) : (
                      <div className="text-center p-8 text-white space-y-3">
                        <Radio className="w-12 h-12 text-[#FF5722] mx-auto" />
                        <h3 className="text-lg font-bold">Camera Studio Standby</h3>
                        <p className="text-xs text-slate-300 max-w-md mx-auto">
                          Click &quot;Start On Fire Live Camera&quot; to choose{' '}
                          <strong>Long (16:9)</strong> or <strong>Quick Burst (9:16)</strong>, or open{' '}
                          <strong>Full Screen</strong> for Side Chat &amp; Live Filters!
                        </p>
                      </div>
                    )}
                    {isBroadcastingLive && (
                      <div className="absolute top-4 left-4 right-4 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="px-3 py-1 rounded-lg bg-[#E53935] text-white text-xs font-extrabold uppercase">
                            ● ON FIRE ({cameraLiveAspectMode === 'quickBurst' ? '9:16' : '16:9'})
                          </span>
                          <span className="px-2.5 py-1 rounded-lg bg-black/75 text-white text-xs font-bold">
                            {liveViewerCount} watching
                          </span>
                        </div>
                        <button
                          onClick={() => setCameraFullScreenOpen(true)}
                          className="px-3 py-1 rounded-lg bg-black/80 border border-white/20 text-white text-xs font-extrabold flex items-center gap-1"
                        >
                          <Maximize2 className="w-3.5 h-3.5" /> Full Screen
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Camera Live Filter Selector & Stream Title Bar */}
                  <div className="pt-3 space-y-2.5">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-extrabold text-[#FF5722] mr-1">
                        Camera Filter:
                      </span>
                      {(
                        [
                          { id: 'none', label: 'Normal' },
                          { id: 'flameWarm', label: '🔥 Flame Warm' },
                          { id: 'cyberNeon', label: '⚡ Cyber Neon' },
                          { id: 'goldenHour', label: '☀️ Golden Hour' },
                          { id: 'tealOrange', label: '🎬 Cinema Teal' },
                          { id: 'bwContrast', label: '🖤 B&W Noir' },
                        ] as const
                      ).map((f) => (
                        <button
                          key={f.id}
                          onClick={() => setCameraLiveFilter(f.id)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold ${
                            cameraLiveFilter === f.id
                              ? 'bg-[#FF5722] text-white'
                              : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A]'
                          }`}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>

                    <div className="flex gap-2 flex-wrap">
                      <input
                        type="text"
                        value={liveStreamTitle}
                        onChange={(e) => setLiveStreamTitle(e.target.value)}
                        className="flex-1 px-3 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm font-bold"
                      />
                      <select
                        value={liveStreamCategory}
                        onChange={(e) => setLiveStreamCategory(e.target.value)}
                        aria-label="Stream category"
                        className="px-3 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-semibold"
                      >
                        <option>Music &amp; Production</option>
                        <option>3D &amp; Spatial Art</option>
                        <option>Filmmaking</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-4 fism-card p-4 flex flex-col justify-between min-h-[380px]">
                  <div>
                    <div className="flex items-center justify-between pb-3 border-b border-[#D8E1F0] dark:border-slate-800">
                      <h3 className="font-extrabold text-sm">On Fire Live Chat</h3>
                      <span className="px-2 py-0.5 rounded-full bg-[#FFB300]/20 text-[#D97706] dark:text-[#FFB300] text-[10px] font-black tabular-nums">
                        🪙 {spWallet.spCoins.toLocaleString()} SP
                      </span>
                    </div>
                    <div className="py-3 space-y-2.5 max-h-64 overflow-y-auto">
                      {superChats.slice(0, 2).map((sc) => {
                        const tier =
                          SUPER_CHAT_BOX_TIERS.find((t) => t.id === sc.boxStyle) ||
                          SUPER_CHAT_BOX_TIERS[0];
                        return (
                          <div
                            key={sc.id}
                            className={`p-2 rounded-xl border text-xs shadow ${tier.cardClass}`}
                          >
                            <div className="font-black text-[10px]">
                              {sc.kind === 'sticker'
                                ? `${sc.stickerEmoji || '🎁'} ${sc.stickerLabel}`
                                : '🔥 SUPER CHAT'}{' '}
                              • {sc.spCost} SP
                            </div>
                            <span className="font-extrabold">@{sc.senderUsername}:</span> {sc.text}
                          </div>
                        );
                      })}
                      {liveChatMessages.map((msg) => (
                        <div key={msg.id} className="text-xs">
                          <span className="font-bold text-[#FF5722]">@{msg.user}</span>:{' '}
                          <span>{msg.text}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="pt-3 border-t border-[#D8E1F0] dark:border-slate-800 space-y-2">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={liveChatInput}
                        onChange={(e) => setLiveChatInput(e.target.value)}
                        placeholder="Send live chat or 50 SP Super Chat..."
                        className="flex-1 px-3 py-1.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                      />
                      <button
                        onClick={() => {
                          if (!liveChatInput.trim()) return;
                          setLiveChatMessages((prev) => [
                            ...prev,
                            {
                              id: `lc_${Date.now()}`,
                              user: myProfile.username,
                              text: liveChatInput.trim(),
                            },
                          ]);
                          setLiveChatInput('');
                        }}
                        className="fism-btn-primary px-3 py-1.5 rounded-xl text-xs font-bold"
                      >
                        Send
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const txt = liveChatInput.trim() || '🔥 Super Flame Boost!';
                        void handleSendSuperChat({
                          kind: 'superchat',
                          text: txt,
                          boxStyle: 'amber_flame',
                          hostUid: activeIdentityUid,
                        }).then((ok) => {
                          if (ok && liveChatInput.trim()) setLiveChatInput('');
                        });
                      }}
                      className="w-full py-1.5 rounded-xl bg-gradient-to-r from-[#F59E0B] to-[#FF5722] text-white text-[11px] font-extrabold shadow"
                    >
                      🔥 Send Super Chat Box ({SP_SUPER_CHAT_COST} SP)
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SCREEN 12: FUEL UP (MANUAL UPI & QR CODE PAYMENT + ADMIN APPROVAL SYSTEM) */}
          {activeScreen === 'fuelUp' && (
            <div className="max-w-[950px] mx-auto space-y-6 pb-8">
              {/* 24-Hour Confirmation Popup Modal */}
              {upiSubmittedPopupMsg && (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                  <div className="w-full max-w-md rounded-3xl bg-[#101426] border-2 border-[#FF5722] p-6 text-white shadow-2xl space-y-4 text-center">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF5722] to-[#FFB300] flex items-center justify-center mx-auto shadow-lg">
                      <CheckCircle2 className="w-9 h-9 text-white" />
                    </div>
                    <span className="px-3 py-1 rounded-full bg-[#FF5722]/20 border border-[#FF5722] text-[#FFB300] text-[11px] font-extrabold uppercase">
                      Payment Request Sent to Admin File
                    </span>
                    <h3 className="text-xl font-extrabold text-white leading-snug">
                      {upiSubmittedPopupMsg}
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      आपकी पेमेंट रिक्वेस्ट एडमिन फाइल के <strong>Notifications</strong> सेक्शन में भेज दी गई है। जैसे ही एडमिन आपका पेमेंट वेरीफाई करके <strong>Accept</strong> करेंगे, आपका फ्यूल अप तुरंत एक्टिव हो जाएगा।
                    </p>
                    <button
                      onClick={() => setUpiSubmittedPopupMsg(null)}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-[#E53935] via-[#FF5722] to-[#FFB300] text-white text-sm font-extrabold shadow-lg"
                    >
                      ठीक है (OK, Got It)
                    </button>
                  </div>
                </div>
              )}

              {/* Header Banner */}
              <div className="rounded-2xl p-6 bg-gradient-to-r from-[#101426] via-[#2A0F1D] to-[#431407] border-2 border-[#FF5722] text-white shadow-xl">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2.5 py-1 rounded bg-[#FFB300] text-[#101426] text-xs font-extrabold uppercase">
                        🔥 Flame UPI &amp; QR Checkout
                      </span>
                      <span className="px-2.5 py-1 rounded bg-[#7C3AED] text-white text-xs font-extrabold tabular-nums">
                        🪙 SP Coins: {spWallet.spCoins.toLocaleString()} SP
                      </span>
                      {globalPremiumOn && (
                        <span className="px-2.5 py-1 rounded bg-[#16A34A] text-white text-xs font-extrabold uppercase flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Fuel Up Active on Your Account
                        </span>
                      )}
                    </div>
                    <h1 className="text-2xl font-extrabold mt-2 flex items-center gap-2">
                      <Crown className="w-6 h-6 text-[#FFB300]" /> Fuel Up — Premium Plans &amp; SP Coins
                    </h1>
                    <p className="text-xs text-slate-300 mt-1">
                      प्रीमियम प्लान चुनने पर आपको <strong className="text-[#FACC15]">+{PREMIUM_COIN_PACK_BONUS.toLocaleString()} Wallet Coins</strong> और{' '}
                      <strong className="text-[#C084FC]">+{PREMIUM_SP_COIN_BONUS} SP Coins Bonus</strong> भी मिलते हैं! सिर्फ SP Coins खरीदने के लिए नीचे स्क्रॉल करें।
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setSettingsSubTab('smart');
                      setActiveScreen('controlCore');
                    }}
                    className="px-4 py-2.5 rounded-xl bg-[#FF5722] hover:bg-[#E53935] text-white text-xs font-extrabold shadow-lg flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> + Create / Edit Unlimited Profile IDs ({subAccounts.length})
                  </button>
                </div>
              </div>

              {/* SECTION A: SELECT FUEL UP CREATOR (ONLY USER'S OWN PROFILES SHOWN) */}
              <div className="fism-card p-5 border-2 border-[#FF5722]/60 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <span className="px-2.5 py-0.5 rounded-full bg-[#FF5722]/15 text-[#FF5722] text-[10px] font-extrabold uppercase">
                      Only Your Own Profiles Shown
                    </span>
                    <h2 className="text-base sm:text-lg font-extrabold mt-0.5">
                      1. Select Fuel Up Creator (आप किस प्रोफाइल के लिए फ्यूल अप करना चाहते हैं?)
                    </h2>
                    <p className="text-xs text-[#52607A]">
                      यहाँ केवल आपकी अपनी प्रोफाइल IDs दिखती हैं। हर Sub-ID का अपना स्वतंत्र @username और प्राइवेसी सेटिंग है।
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {subAccounts.map((acc, idx) => {
                    const isSelected = selectedFuelCreatorId === acc.id;
                    return (
                      <div
                        key={acc.id}
                        onClick={() => setSelectedFuelCreatorId(acc.id)}
                        className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between gap-3 ${
                          isSelected
                            ? 'border-[#FF5722] bg-[#FF5722]/10 shadow-md'
                            : 'border-[#D8E1F0] dark:border-slate-700 hover:border-[#FF5722]/50'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={acc.avatarUrl}
                            alt={acc.displayName}
                            className="w-12 h-12 rounded-full object-cover ring-2 ring-[#FF5722] shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="font-extrabold text-xs sm:text-sm truncate flex items-center gap-1">
                              <span>{acc.displayName}</span>
                              {idx === 0 && (
                                <span className="px-1.5 py-0.5 rounded bg-[#FFB300] text-[#101426] text-[9px] font-extrabold">
                                  MAIN
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] font-mono text-[#52607A] truncate">
                              @{acc.username}
                            </div>
                          </div>
                        </div>
                        <span
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold shrink-0 ${
                            isSelected
                              ? 'bg-[#FF5722] text-white'
                              : 'bg-slate-200 dark:bg-slate-800 text-[#52607A]'
                          }`}
                        >
                          {isSelected ? '✓ Selected' : 'Select'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* SECTION B: SELECT FUEL UP PLAN (5 PLANS: 399 1M, 778 2M 10% OFF, 1099 3M 15% OFF, 1999 6M 20% OFF, 3599 12M 25% OFF) */}
              <div className="fism-card p-5 border-2 border-[#FFB300]/70 space-y-3">
                <div>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#FFB300]/20 text-[#D97706] dark:text-[#FFB300] text-[10px] font-extrabold uppercase">
                    5 Exclusive Fuel Up Plans
                  </span>
                  <h2 className="text-base sm:text-lg font-extrabold mt-0.5">
                    2. Select Fuel Up Plan (अपना फ्यूल अप प्लान चुनें)
                  </h2>
                  <p className="text-xs text-[#52607A]">
                    पहला प्लान ₹399 (1 Month), दूसरा प्लान ₹778 (2 Months • 10% OFF) और कुल 5 स्पेशल प्लान्स उपलब्ध हैं:
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                  {FISM_FUEL_UP_PLANS.map((plan) => {
                    const isSelected = selectedFuelPlanId === plan.id;
                    return (
                      <div
                        key={plan.id}
                        onClick={() => {
                          setSelectedFuelPlanId(plan.id);
                          setSelectedTierPrice(plan.priceInr > 500 ? 9.99 : 4.99);
                        }}
                        className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between relative ${
                          isSelected
                            ? 'border-[#FF5722] bg-gradient-to-b from-[#FF5722]/15 to-[#FFB300]/10 shadow-lg scale-[1.02]'
                            : 'border-[#D8E1F0] dark:border-slate-700 hover:border-[#FF5722]/60'
                        }`}
                      >
                        <div>
                          <span
                            className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                              plan.id === 'plan_2m_778'
                                ? 'bg-[#16A34A] text-white'
                                : isSelected
                                ? 'bg-[#FF5722] text-white'
                                : 'bg-[#FFB300]/20 text-[#D97706] dark:text-[#FFB300]'
                            }`}
                          >
                            {plan.discountBadge}
                          </span>
                          <div className="mt-2 font-extrabold text-sm">{plan.name}</div>
                          <div className="text-2xl font-black text-[#FF5722] mt-1">
                            ₹{plan.priceInr}
                          </div>
                          <div className="text-[11px] font-bold text-[#52607A]">
                            Duration: {plan.duration}
                          </div>
                          <p className="text-[11px] text-[#52607A] mt-2 leading-snug">
                            {plan.desc}
                          </p>
                        </div>
                        <button
                          type="button"
                          className={`mt-3 w-full py-2 rounded-xl text-xs font-extrabold ${
                            isSelected
                              ? 'bg-[#FF5722] text-white shadow'
                              : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#151B2B] dark:text-white'
                          }`}
                        >
                          {isSelected ? '✓ Plan Selected' : `Choose ₹${plan.priceInr}`}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Live Alert Banner (Accept / Decline / Pending Notification) */}
              {subVerificationMsg && (
                <div
                  className={`p-4 rounded-2xl text-white text-xs sm:text-sm font-extrabold flex items-center justify-between gap-3 shadow-lg border-2 ${
                    subVerificationMsg.includes('डिक्लाइन')
                      ? 'bg-[#DC2626] border-red-300'
                      : subVerificationMsg.includes('बधाई हो')
                      ? 'bg-[#16A34A] border-emerald-300'
                      : 'bg-gradient-to-r from-[#E53935] to-[#FF5722] border-[#FFB300]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Bell className="w-5 h-5 shrink-0" />
                    <span>{subVerificationMsg}</span>
                  </div>
                  <button
                    onClick={() => setSubVerificationMsg(null)}
                    className="p-1 rounded-lg bg-black/20 hover:bg-black/40"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* MAIN UPI & QR CODE CHECKOUT CARD */}
              <div
                id="fism-upi-checkout-card"
                className="rounded-2xl bg-[#101426] text-white border-2 border-[#FF5722] p-5 sm:p-6 shadow-2xl grid grid-cols-1 lg:grid-cols-12 gap-6 items-center"
              >
                {/* Left Column: Admin's QR Code + UPI ID */}
                <div className="lg:col-span-5 flex flex-col items-center text-center bg-[#181F36] border border-[#FF5722]/40 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center gap-2 text-[#FFB300] text-xs font-extrabold uppercase tracking-wider">
                    <QrCode className="w-4 h-4 text-[#FF5722]" /> Scan QR Code or Pay via UPI ID
                  </div>

                  <div className="w-52 h-52 rounded-2xl bg-white p-3 shadow-xl border-4 border-[#FF5722] flex items-center justify-center overflow-hidden">
                    <img
                      src={upiConfig.qrCodeUrl}
                      alt="Admin Payment QR Code"
                      className="w-full h-full object-contain"
                    />
                  </div>

                  <div className="w-full space-y-2">
                    <div className="text-[11px] text-slate-300 font-bold">
                      Merchant: <span className="text-white">{upiConfig.merchantName}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-[#101426] border border-[#FF5722] flex items-center justify-between gap-2">
                      <div className="text-left min-w-0">
                        <div className="text-[10px] uppercase font-extrabold text-[#FFB300]">
                          Official UPI ID
                        </div>
                        <div className="font-mono font-extrabold text-sm text-white truncate">
                          {upiConfig.upiId}
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          navigator.clipboard?.writeText(upiConfig.upiId);
                          triggerToast(`✅ UPI ID Copied: ${upiConfig.upiId}`);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#FF5722] hover:bg-[#E53935] text-white text-xs font-extrabold flex items-center gap-1 shrink-0"
                      >
                        <Copy className="w-3.5 h-3.5" /> Copy
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right Column: User Payment Details Submission Form */}
                <div className="lg:col-span-7 space-y-4">
                  <div>
                    <span className="px-2.5 py-0.5 rounded-full bg-[#FF5722]/20 border border-[#FF5722] text-[#FFB300] text-[10px] font-extrabold uppercase">
                      Step 2 • Submit Your Payment Details
                    </span>
                    <h2 className="text-lg sm:text-xl font-extrabold mt-1 text-white">
                      पेमेंट करने के बाद अपना UPI ID और डिटेल नीचे भरें
                    </h2>
                    <p className="text-xs text-slate-300">
                      पेमेंट पूरा करने के बाद नीचे अपना UPI ID और UTR / Transaction डिटेल भरकर <strong>Send</strong> पर क्लिक करें।
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                          1. Select Fuel Up Creator (Only Your Profiles)
                        </label>
                        <select
                          value={selectedFuelCreatorId}
                          onChange={(e) => setSelectedFuelCreatorId(e.target.value)}
                          aria-label="Select Fuel Up Creator"
                          className="w-full px-3.5 py-2.5 rounded-xl bg-[#181F36] border border-[#FF5722] text-white text-xs font-bold"
                        >
                          {subAccounts.map((acc, idx) => (
                            <option key={acc.id} value={acc.id}>
                              👤 {acc.displayName} (@{mainProfileUsername})
                              {idx === 0 ? ' — Main Profile' : ` — ID #${idx + 1}`}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                          2. {fuelCheckoutMode === 'sp_coin_pack' ? 'Selected Only SP Coins Pack (No Premium)' : 'Select Fuel Up Plan (5 Plans)'}
                        </label>
                        {fuelCheckoutMode === 'sp_coin_pack' ? (
                          <div className="flex items-center gap-2">
                            <select
                              value={selectedSpPackId}
                              onChange={(e) => setSelectedSpPackId(e.target.value)}
                              aria-label="Select Only SP Coins Pack"
                              className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#181F36] border border-[#C084FC] text-white text-xs font-bold"
                            >
                              {SP_COIN_BUY_PACKS.map((pk) => (
                                <option key={pk.id} value={pk.id}>
                                  🪙 {pk.label} — ₹{pk.priceInr.toLocaleString()} (No Premium)
                                </option>
                              ))}
                            </select>
                            <button
                              type="button"
                              onClick={() => setFuelCheckoutMode('premium')}
                              className="px-2.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-[10px] font-extrabold text-[#FFB300] shrink-0"
                            >
                              Switch to Premium
                            </button>
                          </div>
                        ) : (
                          <select
                            value={selectedFuelPlanId}
                            onChange={(e) => {
                              setSelectedFuelPlanId(e.target.value);
                              setFuelCheckoutMode('premium');
                            }}
                            aria-label="Select Fuel Up Plan"
                            className="w-full px-3.5 py-2.5 rounded-xl bg-[#181F36] border border-[#FFB300] text-white text-xs font-bold"
                          >
                            {FISM_FUEL_UP_PLANS.map((plan) => (
                              <option key={plan.id} value={plan.id}>
                                🔥 ₹{plan.priceInr} — {plan.duration} ({plan.discountBadge}) + 500 SP
                              </option>
                            ))}
                          </select>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                          3. आपका UPI ID (Your UPI ID) *
                        </label>
                        <input
                          type="text"
                          value={userSenderUpiId}
                          onChange={(e) => setUserSenderUpiId(e.target.value)}
                          placeholder="e.g. yourname@ybl or 9876543210@paytm"
                          className="w-full px-3.5 py-2.5 rounded-xl bg-[#181F36] border border-[#FF5722]/60 text-white text-xs font-mono font-bold focus:outline-none focus:border-[#FFB300]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                          4. UTR / Transaction ID (12-Digit Ref) *
                        </label>
                        <input
                          type="text"
                          value={userUtrNumber}
                          onChange={(e) => setUserUtrNumber(e.target.value)}
                          placeholder="e.g. 412589632147"
                          className="w-full px-3.5 py-2.5 rounded-xl bg-[#181F36] border border-[#FF5722]/60 text-white text-xs font-mono font-bold focus:outline-none focus:border-[#FFB300]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                        5. आपका नाम और अतिरिक्त डिटेल (Your Name / Payment Note)
                      </label>
                      <input
                        type="text"
                        value={userPayerName}
                        onChange={(e) => setUserPayerName(e.target.value)}
                        placeholder="Paid via PhonePe / GPay / Paytm..."
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#181F36] border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:border-[#FFB300]"
                      />
                    </div>

                    <button
                      onClick={() => handleSubmitUpiPaymentRequest()}
                      className={`w-full py-3.5 rounded-xl text-white text-sm font-extrabold shadow-xl hover:opacity-95 transition-all flex items-center justify-center gap-2 ${
                        fuelCheckoutMode === 'sp_coin_pack'
                          ? 'bg-gradient-to-r from-[#7C3AED] to-[#2563EB]'
                          : 'bg-gradient-to-r from-[#E53935] via-[#FF5722] to-[#FFB300]'
                      }`}
                    >
                      <Send className="w-4 h-4" />{' '}
                      {fuelCheckoutMode === 'sp_coin_pack'
                        ? 'Send Payment Details for ONLY SP Coins (No Premium)'
                        : 'Send Payment Details for Fuel Up (सेंड पे क्लिक करें)'}
                    </button>
                  </div>
                </div>
              </div>

              {/* SCROLL DOWN SECTION: ONLY BUY SP COINS (NO PREMIUM FEATURES) */}
              <div className="fism-card p-5 border-2 border-[#7C3AED] bg-gradient-to-br from-[#101426] via-[#1E1B4B] to-[#0F172A] text-white space-y-4">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <span className="px-2.5 py-0.5 rounded-full bg-[#7C3AED] text-white text-[10px] font-extrabold uppercase">
                      Only Buy SP Coins • No Premium Features Included
                    </span>
                    <h2 className="text-lg font-extrabold mt-1 flex items-center gap-2">
                      <Coins className="w-5 h-5 text-[#FFB300]" /> Only Buy SP Coins (Super Chat, Stickers &amp; 500 SP Membership)
                    </h2>
                    <p className="text-xs text-slate-300 mt-0.5">
                      Use SP Coins for On Fire <strong>Super Chat Boxes (50 SP)</strong>, <strong>Super Stickers (50 SP)</strong>, and{' '}
                      <strong>Channel Memberships (500 SP)</strong>. Buying these packs unlocks SP Coins only — no Premium features!
                    </p>
                  </div>
                  <div className="px-3.5 py-2 rounded-xl bg-black/40 border border-[#C084FC]/50 text-xs font-extrabold tabular-nums">
                    Balance: <span className="text-[#FFB300]">{spWallet.spCoins.toLocaleString()} SP</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                  {SP_COIN_BUY_PACKS.map((pk) => {
                    const isPicked = fuelCheckoutMode === 'sp_coin_pack' && selectedSpPackId === pk.id;
                    return (
                      <div
                        key={pk.id}
                        className={`p-4 rounded-2xl border-2 flex flex-col justify-between gap-3 transition-all ${
                          isPicked
                            ? 'border-[#FFB300] bg-[#7C3AED]/30 shadow-xl'
                            : 'border-white/15 bg-black/35 hover:border-[#C084FC]'
                        }`}
                      >
                        <div>
                          <div className="text-[10px] font-black uppercase text-[#C084FC]">
                            {pk.badge}
                          </div>
                          <div className="text-base font-extrabold text-white mt-1 tabular-nums">
                            {pk.label}
                          </div>
                          <div className="text-xl font-black text-[#FFB300] mt-1 tabular-nums">
                            ₹{pk.priceInr.toLocaleString()}
                          </div>
                          <div className="text-[10px] text-slate-300 mt-1">
                            Only SP Coins • No Premium
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setFuelCheckoutMode('sp_coin_pack');
                            setSelectedSpPackId(pk.id);
                            const el = document.getElementById('fism-upi-checkout-card');
                            if (el) el.scrollIntoView({ behavior: 'smooth' });
                            triggerToast(
                              `🪙 Selected ${pk.label} (₹${pk.priceInr.toLocaleString()}) — Pay via QR/UPI above & click Send!`,
                            );
                          }}
                          className={`min-h-[40px] w-full py-2 rounded-xl text-xs font-extrabold transition-all ${
                            isPicked
                              ? 'bg-[#FFB300] text-[#101426]'
                              : 'bg-[#7C3AED] hover:bg-[#6D28D9] text-white'
                          }`}
                        >
                          {isPicked ? '✓ Selected Above' : `Buy ${pk.label}`}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* User's Recent UPI Payment Requests & Status Tracker */}
              {upiRequests.filter((r) => r.userId === myProfile.uid).length > 0 && (
                <div className="fism-card p-5 space-y-3 border-2 border-[#FF5722]/40">
                  <h3 className="font-extrabold text-sm sm:text-base flex items-center gap-2">
                    <Bell className="w-4 h-4 text-[#FF5722]" /> Your Fuel Up Payment Status (आपकी पेमेंट स्थिति)
                  </h3>
                  <div className="space-y-2.5">
                    {upiRequests
                      .filter((r) => r.userId === myProfile.uid)
                      .map((req) => (
                        <div
                          key={req.id}
                          className={`p-4 rounded-xl border-2 flex items-center justify-between flex-wrap gap-3 ${
                            req.status === 'accepted'
                              ? 'border-[#16A34A] bg-emerald-500/10'
                              : req.status === 'declined'
                              ? 'border-[#DC2626] bg-red-500/10'
                              : 'border-[#FFB300] bg-amber-500/10'
                          }`}
                        >
                          <div className="space-y-1 text-xs">
                            <div className="font-extrabold text-sm flex items-center gap-2 flex-wrap">
                              <span>{req.planName}</span>
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                                  req.status === 'accepted'
                                    ? 'bg-[#16A34A] text-white'
                                    : req.status === 'declined'
                                    ? 'bg-[#DC2626] text-white'
                                    : 'bg-[#FFB300] text-[#101426]'
                                }`}
                              >
                                {req.status === 'pending'
                                  ? '⏳ 24 घंटे में वेरीफाई होगा (Pending)'
                                  : req.status === 'accepted'
                                  ? '✓ Accepted — Fuel Up Active'
                                  : '✕ Declined by Admin'}
                              </span>
                            </div>
                            <div className="text-[#52607A] dark:text-slate-300 font-mono">
                              UPI ID: <strong>{req.senderUpiId}</strong> • UTR: <strong>{req.utrTransactionId}</strong> • {req.submittedAt}
                            </div>
                            {req.status === 'pending' && (
                              <div className="font-bold text-[#D97706] dark:text-[#FFB300]">
                                आपका पेमेंट सबमिट हो गया है, 24 घंटे में आपका फ्यूल अप हो जाएगा।
                              </div>
                            )}
                            {req.status === 'declined' && (
                              <div className="font-extrabold text-[#DC2626] dark:text-red-400">
                                आपका फ्यूल अप डिक्लाइन हो गया है। कृपया रीट्राई करें क्योंकि आपने पेमेंट नहीं किया है।
                              </div>
                            )}
                            {req.status === 'accepted' && (
                              <div className="font-extrabold text-[#16A34A]">
                                आपका फ्यूल अप स्वीकार कर लिया गया है और प्रीमियम एक्टिव हो गया है!
                              </div>
                            )}
                          </div>

                          {req.status === 'declined' && (
                            <button
                              onClick={() => {
                                setUserSenderUpiId(req.senderUpiId);
                                const el = document.getElementById('fism-upi-checkout-card');
                                if (el) el.scrollIntoView({ behavior: 'smooth' });
                              }}
                              className="px-3.5 py-2 rounded-xl bg-[#FF5722] text-white text-xs font-extrabold shadow"
                            >
                              🔄 Retry Payment (रीट्राई करें)
                            </button>
                          )}
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {/* User's Own Profile IDs Directory for Fuel Up */}
              <div className="fism-card p-5 space-y-3 border border-[#D8E1F0] dark:border-slate-800">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h3 className="font-extrabold text-sm sm:text-base">
                    Your Own Profile IDs Eligible for Fuel Up ({subAccounts.length} Profiles)
                  </h3>
                  <span className="text-xs text-[#52607A] font-mono">
                    Locked Main Username: @{mainProfileUsername}
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {subAccounts.map((acc, idx) => (
                    <div
                      key={acc.id}
                      className="p-4 rounded-xl border border-[#D8E1F0] dark:border-slate-800 flex flex-col justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={acc.avatarUrl}
                          alt={acc.displayName}
                          className="w-12 h-12 rounded-full object-cover ring-2 ring-[#FFB300]"
                        />
                        <div className="min-w-0">
                          <h4 className="font-extrabold text-sm truncate flex items-center gap-1">
                            <span>{acc.displayName}</span>
                            <CheckCircle2 className="w-4 h-4 text-[#16A34A] shrink-0" />
                          </h4>
                          <p className="text-xs text-[#52607A] font-mono truncate">
                            @{mainProfileUsername} • {idx === 0 ? 'Main Profile' : `Profile ID #${idx + 1}`}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setSelectedFuelCreatorId(acc.id);
                          const el = document.getElementById('fism-upi-checkout-card');
                          if (el) el.scrollIntoView({ behavior: 'smooth' });
                          triggerToast(`Selected your profile "${acc.displayName}" for Fuel Up!`);
                        }}
                        className={`w-full py-2 rounded-xl text-xs font-extrabold transition-all ${
                          selectedFuelCreatorId === acc.id
                            ? 'bg-[#16A34A] text-white'
                            : 'fism-btn-primary'
                        }`}
                      >
                        {selectedFuelCreatorId === acc.id
                          ? '✓ Selected for Fuel Up'
                          : 'Select This Profile for Fuel Up'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SCREEN 13A: DEDICATED 2D MULTI-GAME HUB (USER PLAY-ONLY; ADMIN UPLOADS GAMES IN ADMIN FILE) */}
          {activeScreen === 'gameHub' && (
            <Fism2DGameCenter games={gamesCatalog} onTriggerToast={triggerToast} />
          )}

          {/* SCREEN 13B: 3D VR CINEMA & SPATIAL VIDEO THEATER (UNLOCKS AT 2,000 SPARKS • IN-APP VIDEO SEARCH ONLY) */}
          {activeScreen === 'flame3DArena' && (
            <div className="space-y-4">
              <div className="fism-card p-4 bg-gradient-to-r from-[#101426] via-[#1E1B4B] to-[#31102F] text-white flex items-center justify-between flex-wrap gap-3">
                <div>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#FFB300] text-[#101426] text-[10px] font-extrabold uppercase">
                    2,000 Sparks Milestone Feature • Realistic 3D Cinema Hall
                  </span>
                  <h2 className="text-lg font-extrabold mt-1">
                    🥽 3D VR Spatial Video Cinema &amp; In-App Video Search
                  </h2>
                  <p className="text-xs text-white/75">
                    {myProfile.sparksCount >= 2000
                      ? `Unlocked (${myProfile.sparksCount.toLocaleString()} Sparks)! Search and watch any video available inside the FISM app with realistic 3D seated audience!`
                      : `Requires 2,000 Sparks to unlock 3D VR Videos (Current: ${myProfile.sparksCount} Sparks).`}
                  </p>
                </div>
              </div>

              {myProfile.sparksCount < 2000 ? (
                <div className="fism-card p-8 text-center space-y-3">
                  <Lock className="w-10 h-10 text-[#FF5722] mx-auto" />
                  <h3 className="text-lg font-extrabold">
                    3D VR Videos Unlock at 2,000 Sparks
                  </h3>
                  <p className="text-xs text-[#52607A] max-w-md mx-auto">
                    Your channel currently has {myProfile.sparksCount} Sparks. Reach 2,000 Sparks
                    to unlock the 3D VR Cinema Theater!
                  </p>
                  <button
                    onClick={() => {
                      setMyProfile((prev) => ({ ...prev, sparksCount: 2500 }));
                      triggerToast('⚡ Boosted to 2,500 Sparks! 3D VR Videos unlocked.');
                    }}
                    className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold"
                  >
                    Boost to 2,500 Sparks to Test 3D VR Now
                  </button>
                </div>
              ) : (
                <FismThreeArena
                  activeVideoUrl={vrCinemaVideoUrl}
                  activeVideoTitle={vrCinemaVideoTitle}
                  availableVideos={posts
                    .filter(
                      (p) =>
                        !isPostCopyrightBlocked(p) &&
                        (p.postType === 'video' || p.postType === 'quickBurst' || p.isRealVideo),
                    )
                    .map((p) => ({
                      id: p.id,
                      title: p.title,
                      creatorName: `${p.authorDisplayName} (@${p.authorUsername})`,
                      category: p.hashtags?.[0] || 'FISM Video',
                      videoUrl:
                        isRealPlayableVideo(p.mediaUrl, p.isRealVideo)
                          ? p.mediaUrl
                          : 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
                      viewsLabel: `${p.viewsCount.toLocaleString()} views`,
                    }))}
                  onVideoLoaded={(url, title) => {
                    setVrCinemaVideoUrl(url);
                    setVrCinemaVideoTitle(title);
                    recordUserActivity(`Watched "${title}" in 3D VR Cinema`, 'In-app VR theater playback');
                    triggerToast(`🥽 Playing "${title}" in 3D VR Cinema!`);
                  }}
                />
              )}
            </div>
          )}

          {/* SCREEN 14: AI, MAPS & GOOGLE WORKSPACE HUB */}
          {activeScreen === 'aiWorkspaceHub' && (
            <FismWorkspaceMapsStudio
              activeSection="gemini"
              checkInPins={userMilestone.checkInHistory || []}
              onPublishGeneratedPost={async (genPost) => {
                const newItem: FismPostItem = {
                  id: `post_${Date.now()}`,
                  authorId: currentUser?.uid || myProfile.uid,
                  authorUsername: myProfile.username,
                  authorDisplayName: myProfile.displayName,
                  authorAvatar: myProfile.avatarUrl,
                  authorVerified: true,
                  postType: genPost.postType,
                  title: genPost.title,
                  caption: genPost.caption,
                  mediaUrl: genPost.mediaUrl || GENERATED_ASSETS.mountainPost,
                  thumbnailUrl: genPost.mediaUrl || GENERATED_ASSETS.mountainPost,
                  aspectRatio: genPost.aspectRatio,
                  hashtags: ['#FISMAI', '#GeminiStudio', '#FlameCreative'],
                  location: myProfile.location,
                  visibility: 'public',
                  allowComments: true,
                  sparkCount: 1,
                  chatterCount: 0,
                  spreadCount: 0,
                  viewsCount: 1,
                  isSparked: true,
                  isStashed: false,
                  createdAt: 'Just now',
                  comments: [],
                  isRealVideo: isRealPlayableVideo(genPost.mediaUrl),
                };
                setPosts((prev) => [newItem, ...prev]);
                if (newItem.postType === 'video' || newItem.postType === 'quickBurst') {
                  const flagged = await runCopyrightScanForPost(newItem);
                  if (flagged) {
                    setViewedProfileId(myProfile.uid);
                    setActiveScreen('myHearth');
                    return;
                  }
                }
                setActiveScreen('flameFeed');
                triggerToast('Published AI Studio creation to Flame Feed!');
              }}
            />
          )}

          {/* SCREEN 14-MAPS: DEDICATED FLAME MAPS & CHECK-IN LOCATE STUDIO */}
          {activeScreen === 'flameMaps' && (
            <FismWorkspaceMapsStudio
              activeSection="maps"
              checkInPins={userMilestone.checkInHistory || []}
              onPublishGeneratedPost={async (genPost) => {
                const newItem: FismPostItem = {
                  id: `post_map_${Date.now()}`,
                  authorId: currentUser?.uid || myProfile.uid,
                  authorUsername: myProfile.username,
                  authorDisplayName: myProfile.displayName,
                  authorAvatar: myProfile.avatarUrl,
                  authorVerified: true,
                  postType: genPost.postType,
                  title: genPost.title,
                  caption: genPost.caption,
                  mediaUrl: genPost.mediaUrl || GENERATED_ASSETS.mountainPost,
                  thumbnailUrl: genPost.mediaUrl || GENERATED_ASSETS.mountainPost,
                  aspectRatio: genPost.aspectRatio,
                  hashtags: ['#FISMMaps', '#CheckInLocate', '#FlameCreator'],
                  location: myProfile.location,
                  visibility: 'public',
                  allowComments: true,
                  sparkCount: 1,
                  chatterCount: 0,
                  spreadCount: 0,
                  viewsCount: 1,
                  isSparked: true,
                  isStashed: false,
                  createdAt: 'Just now',
                  comments: [],
                  isRealVideo: isRealPlayableVideo(genPost.mediaUrl),
                };
                setPosts((prev) => [newItem, ...prev]);
                setActiveScreen('flameFeed');
                triggerToast('Published Maps creation to Flame Feed!');
              }}
            />
          )}

          {/* SCREEN 14-INSTALL: OFFICIAL SINGLE-SLOT ANDROID APK INSTALL HUB */}
          {activeScreen === 'installApp' && (
            <div className="max-w-2xl mx-auto space-y-5">
              <div className="fism-card p-6 border-2 border-[#2563EB] bg-gradient-to-br from-[#0F172A] via-[#1E1B4B] to-[#101426] text-white space-y-5 shadow-2xl">
                <div className="flex items-start justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#2563EB] to-[#FF5722] flex items-center justify-center shadow-lg shrink-0">
                      <Smartphone className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full bg-[#16A34A] text-white text-[10px] font-black uppercase">
                        Official FISM Android Build • Single Verified Release
                      </span>
                      <h1 className="text-xl sm:text-2xl font-extrabold mt-1">
                        {apkRelease ? apkRelease.appName : 'FISM Android App (APK) Install'}
                      </h1>
                      <p className="text-xs text-slate-300">
                        Verified Android App Links domain:{' '}
                        <span className="font-mono text-[#38BDF8]">{FISM_PUBLIC_APP_ORIGIN}</span>
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      void shareFismLink({
                        title: apkRelease?.appName || 'Install Official FISM Android App',
                        text: 'Download the official FISM Android APK with verified App Links!',
                        url: buildFismShareUrl('install'),
                        triggerToast,
                      })
                    }
                    className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-extrabold flex items-center gap-1.5"
                  >
                    <Share2 className="w-4 h-4" /> Share Install Link
                  </button>
                </div>

                {apkRelease ? (
                  <div className="p-5 rounded-2xl bg-white/10 border border-white/15 space-y-4">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      <div className="p-2.5 rounded-xl bg-black/30">
                        <div className="text-[10px] text-slate-400">App Name</div>
                        <div className="font-extrabold truncate">{apkRelease.appName}</div>
                      </div>
                      <div className="p-2.5 rounded-xl bg-black/30">
                        <div className="text-[10px] text-slate-400">Version</div>
                        <div className="font-extrabold font-mono text-[#FFB300]">
                          v{apkRelease.version}
                        </div>
                      </div>
                      <div className="p-2.5 rounded-xl bg-black/30">
                        <div className="text-[10px] text-slate-400">Package Size</div>
                        <div className="font-extrabold font-mono">
                          {(apkRelease.sizeBytes / (1024 * 1024)).toFixed(2)} MB
                        </div>
                      </div>
                      <div className="p-2.5 rounded-xl bg-black/30">
                        <div className="text-[10px] text-slate-400">Package ID</div>
                        <div className="font-bold font-mono text-[11px] truncate text-[#38BDF8]">
                          {apkRelease.packageName}
                        </div>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-black/30 border border-white/10 space-y-1">
                      <div className="text-[11px] font-extrabold text-[#FFB300] uppercase">
                        Release Notes &amp; Details (Admin Verified)
                      </div>
                      <p className="text-xs text-slate-200 whitespace-pre-line leading-relaxed">
                        {apkRelease.details}
                      </p>
                      <div className="text-[10px] text-slate-400 pt-1">
                        File: <span className="font-mono">{apkRelease.fileName}</span> • Uploaded{' '}
                        {new Date(apkRelease.uploadedAt).toLocaleString()}
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3">
                      <a
                        href={apkRelease.downloadUrl}
                        download={apkRelease.fileName}
                        onClick={() =>
                          triggerToast(
                            `⬇️ Downloading ${apkRelease.appName} (${apkRelease.fileName})...`,
                          )
                        }
                        className="flex-1 py-3.5 px-5 rounded-xl bg-gradient-to-r from-[#16A34A] to-[#2563EB] hover:opacity-95 text-white font-extrabold text-sm shadow-xl flex items-center justify-center gap-2"
                      >
                        <Download className="w-5 h-5" /> Install / Download Official APK (v
                        {apkRelease.version})
                      </a>
                      {isPrimaryAdmin && (
                        <button
                          type="button"
                          onClick={() => setActiveScreen('adminFileVault')}
                          className="px-4 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-extrabold"
                        >
                          Manage APK in Admin Vault
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="p-6 rounded-2xl bg-white/5 border border-dashed border-white/25 text-center space-y-3">
                    <Smartphone className="w-10 h-10 text-[#38BDF8] mx-auto" />
                    <h2 className="font-extrabold text-base">
                      Official FISM APK Pending Admin Upload
                    </h2>
                    <p className="text-xs text-slate-300 max-w-md mx-auto">
                      Only 1 active official <span className="font-mono">.apk</span> package is
                      hosted here at a time. Once the Admin enters the App Name, Details &amp;
                      uploads the <span className="font-mono">.apk</span> inside Admin File Vault,
                      the direct Install button appears automatically for all users.
                    </p>
                    {isPrimaryAdmin && (
                      <button
                        type="button"
                        onClick={() => setActiveScreen('adminFileVault')}
                        className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold inline-flex items-center gap-2"
                      >
                        <Upload className="w-4 h-4" /> Upload APK in Admin Vault
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* SCREEN 14A: AI CLONE STUDIO & DIGITAL AVATAR VIDEO GENERATION */}
          {activeScreen === 'aiCloneStudio' && (
            <FismAiCloneStudio
              currentUserId={currentUser?.uid || myProfile.uid}
              currentUsername={myProfile.username}
              currentDisplayName={myProfile.displayName}
              avatars={aiCloneAvatars}
              onSaveAvatar={(newAvatar) =>
                setAiCloneAvatars((prev) => [newAvatar, ...prev.filter((a) => a.id !== newAvatar.id)])
              }
              onPublishToFismFeed={async (payload) => {
                const isShort = payload.targetMode === 'quickBurst';
                const mins = Math.floor(payload.durationSec / 60);
                const secs = payload.durationSec % 60;
                const formattedDur = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
                const newClonePost: FismPostItem = {
                  id: `post_aiclone_${Date.now()}`,
                  authorId: currentUser?.uid || myProfile.uid,
                  authorUsername: myProfile.username,
                  authorDisplayName: myProfile.displayName,
                  authorAvatar: myProfile.avatarUrl,
                  authorVerified: true,
                  postType: isShort ? 'quickBurst' : 'video',
                  title: payload.title,
                  caption: payload.caption,
                  mediaUrl: payload.videoUrl,
                  thumbnailUrl: payload.thumbnailUrl || GENERATED_ASSETS.studioThumb,
                  aspectRatio: isShort ? '9:16' : '16:9',
                  duration: formattedDur,
                  audioTrack: `AI Clone Voice (${payload.avatarName}) – @${myProfile.username}`,
                  hashtags: ['#AIClone', '#FISMAvatar', isShort ? '#QuickBurst' : '#MainBlast'],
                  location: myProfile.location,
                  visibility: 'public',
                  allowComments: true,
                  sparkCount: 1,
                  chatterCount: 0,
                  spreadCount: 0,
                  viewsCount: globalPremiumOn ? 1_250_000 : 10,
                  isSparked: true,
                  isStashed: false,
                  isRealVideo: true,
                  isPremiumCreator: globalPremiumOn,
                  createdAt: 'Just now',
                  comments: [],
                };

                setPosts((prev) => [newClonePost, ...prev]);
                const flagged = await runCopyrightScanForPost(newClonePost);
                if (flagged) {
                  setViewedProfileId(myProfile.uid);
                  setActiveScreen('myHearth');
                  return;
                }

                if (isShort) {
                  setActiveQuickBurstIndex(0);
                  setQuickBurstPlaying(true);
                  setActiveScreen('quickBurst');
                  triggerToast(`AI Clone Short "${payload.title}" published to Quick Burst!`);
                } else {
                  setSelectedVideoPost(newClonePost);
                  setVideoPlaying(true);
                  setActiveScreen('mainBlast');
                  triggerToast(`AI Clone Video "${payload.title}" published to Main Blast!`);
                }
              }}
              onTriggerToast={triggerToast}
            />
          )}

          {/* SCREEN 14B: COMMUNITY CHAT & MUTUAL-FOLLOWER GROUP CALLING */}
          {activeScreen === 'communityChat' && (
            <FismCommunityAndCreatorChat
              mode="community"
              currentUser={{
                uid: activeIdentityUid,
                username: myProfile.username,
                displayName: myProfile.displayName,
                avatarUrl: myProfile.avatarUrl,
              }}
              creators={creators}
              onToggleConnectCreator={handleToggleConnectCreator}
              communityRooms={communityRooms}
              liveCreatorRoom={liveCreatorRoom}
              hasLiveCreatorAccess={hasLiveCreatorAccess}
              messagesByRoom={communityMessagesByRoom}
              activeCalls={activeGroupCalls}
              onCreateRoom={handleCreateCommunityRoom}
              onJoinRoom={handleJoinCommunityRoom}
              onSendMessage={handleSendCommunityMessage}
              onStartGroupCall={handleStartGroupCall}
              onAnswerGroupCall={handleAnswerGroupCall}
              onToggleCallMedia={handleToggleGroupCallMedia}
              onLeaveGroupCall={handleLeaveGroupCall}
              localCallStream={localGroupCallStream}
              remotePeerStreams={remotePeerStreams}
              onSwitchToMode={(nextMode) => {
                if (nextMode === 'liveCreator' && hasLiveCreatorAccess) {
                  setActiveScreen('liveCreatorChat');
                } else {
                  setActiveScreen('communityChat');
                }
              }}
              onTriggerToast={triggerToast}
              milestoneMembersMap={milestoneMembersMap}
              onOpenMilestoneJourney={(targetUid) => {
                const matchedCreator = creators.find((c) => c.uid === targetUid);
                openMilestoneJourneyForUser({
                  accountId: targetUid,
                  username: matchedCreator?.username || myProfile.username,
                  displayName: matchedCreator?.displayName || myProfile.displayName,
                  avatarUrl: matchedCreator?.avatarUrl || myProfile.avatarUrl,
                });
              }}
            />
          )}

          {/* SCREEN 14C: ADMIN-GATED EXCLUSIVE LIVE CREATOR CHAT (HIDDEN BY DEFAULT) */}
          {activeScreen === 'liveCreatorChat' && hasLiveCreatorAccess && (
            <FismCommunityAndCreatorChat
              mode="liveCreator"
              currentUser={{
                uid: activeIdentityUid,
                username: myProfile.username,
                displayName: myProfile.displayName,
                avatarUrl: myProfile.avatarUrl,
              }}
              creators={creators}
              onToggleConnectCreator={handleToggleConnectCreator}
              communityRooms={communityRooms}
              liveCreatorRoom={liveCreatorRoom}
              hasLiveCreatorAccess={hasLiveCreatorAccess}
              messagesByRoom={communityMessagesByRoom}
              activeCalls={activeGroupCalls}
              onCreateRoom={handleCreateCommunityRoom}
              onJoinRoom={handleJoinCommunityRoom}
              onSendMessage={handleSendCommunityMessage}
              onStartGroupCall={handleStartGroupCall}
              onAnswerGroupCall={handleAnswerGroupCall}
              onToggleCallMedia={handleToggleGroupCallMedia}
              onLeaveGroupCall={handleLeaveGroupCall}
              localCallStream={localGroupCallStream}
              remotePeerStreams={remotePeerStreams}
              onSwitchToMode={(nextMode) => {
                if (nextMode === 'community') setActiveScreen('communityChat');
              }}
              onTriggerToast={triggerToast}
              milestoneMembersMap={milestoneMembersMap}
              onOpenMilestoneJourney={(targetUid) => {
                const matchedCreator = creators.find((c) => c.uid === targetUid);
                openMilestoneJourneyForUser({
                  accountId: targetUid,
                  username: matchedCreator?.username || myProfile.username,
                  displayName: matchedCreator?.displayName || myProfile.displayName,
                  avatarUrl: matchedCreator?.avatarUrl || myProfile.avatarUrl,
                });
              }}
            />
          )}

          {/* SCREEN 14D: CREATOR EARNING HUB (UNLOCKS AT 5,000 SPARKS • $500 MIN WITHDRAWAL + GLOBAL CURRENCY CONVERTER) */}
          {activeScreen === 'earningHub' && (
            <FismCreatorEarningHub
              sparksCount={myProfile.sparksCount}
              onSetSparksCount={(val) =>
                setMyProfile((prev) => ({ ...prev, sparksCount: val }))
              }
              posts={posts}
              selectedCurrencyCode={earningCurrencyCode}
              onSelectCurrencyCode={setEarningCurrencyCode}
              onTriggerToast={triggerToast}
              userProfileId={subAccounts[0]?.id || myProfile.uid}
              userProfileName={myProfile.displayName}
              userMainUsername={mainProfileUsername}
              userAvatar={myProfile.avatarUrl}
              subAccounts={subAccounts}
              withdrawalRequests={withdrawalRequests}
              onSubmitWithdrawalRequest={handleSubmitWithdrawalRequest}
            />
          )}

          {/* SCREEN 14E: CREATOR COIN WALLET, 10K PACK, 100K FREE PREMIUM & GLOBAL LEADERBOARD */}
          {activeScreen === 'coinLeaderboard' && (
            <FismCoinWalletAndLeaderboard
              currentUserId={activeIdentityUid}
              currentUsername={myProfile.username}
              currentDisplayName={myProfile.displayName}
              myWallet={myWallet}
              leaderboard={leaderboardWallets}
              claimedReceipts={claimedGiftReceipts}
              activeGiftDrops={giftDrops}
              userHasBoughtPremium={userHasBoughtPremium}
              onTopUpCoins={handleTopUpCoins}
              onRedeemFreePremiumWithCoins={handleRedeemFreePremiumWithCoins}
              onOpenFuelUpPremium={() => setActiveScreen('fuelUp')}
              onOpenCreateVideoWithGiftDrop={() => setSparkNewModalOpen(true)}
              onClaimGiftDrop={handleClaimVideoGiftDrop}
              onTriggerToast={triggerToast}
            />
          )}

          {/* SCREEN 15: CONTROL CORE (STANDARD SETTINGS, SMART SETTINGS & ADVANCED SETTINGS -> ADMIN FILE) */}
          {activeScreen === 'controlCore' && (
            <div className="max-w-4xl mx-auto space-y-5">
              <div className="fism-card p-5 flex items-center justify-between flex-wrap gap-4">
                <div>
                  <h1 className="text-xl font-extrabold flex items-center gap-2">
                    <Settings className="w-5 h-5 text-[#FF5722]" /> Control Core — Settings
                    Architecture
                  </h1>
                  <p className="text-xs text-[#52607A]">
                    Organized into Standard Settings, Smart Settings (Multi-Account, Shorts Speed
                    &amp; Currency), and Advanced Settings (5,000 Sparks Earning, Auto-Message
                    &amp; Admin File Vault).
                  </p>
                </div>

                {/* 3 Settings Category Tabs */}
                <div className="flex items-center gap-1.5 bg-[#F1F5F9] dark:bg-slate-800 p-1.5 rounded-xl">
                  <button
                    onClick={() => setSettingsSubTab('standard')}
                    className={`px-3.5 py-2 rounded-lg text-xs font-extrabold ${
                      settingsSubTab === 'standard'
                        ? 'fism-btn-primary'
                        : 'text-[#52607A] hover:text-[#151B2B]'
                    }`}
                  >
                    1. Standard Settings
                  </button>
                  <button
                    onClick={() => setSettingsSubTab('smart')}
                    className={`px-3.5 py-2 rounded-lg text-xs font-extrabold ${
                      settingsSubTab === 'smart'
                        ? 'fism-btn-primary'
                        : 'text-[#52607A] hover:text-[#151B2B]'
                    }`}
                  >
                    2. Smart Settings
                  </button>
                  <button
                    onClick={() => setSettingsSubTab('advanced')}
                    className={`px-3.5 py-2 rounded-lg text-xs font-extrabold flex items-center gap-1 ${
                      settingsSubTab === 'advanced'
                        ? 'fism-gradient-royal text-white'
                        : 'text-[#7C3AED] hover:text-[#151B2B]'
                    }`}
                  >
                    <Lock className="w-3.5 h-3.5" /> 3. Advanced Settings
                  </button>
                </div>
              </div>

              {/* SUB-TAB 1: STANDARD (NORMAL) SETTINGS */}
              {settingsSubTab === 'standard' && (
                <div className="space-y-4">
                  {/* STRICTLY GATED PREMIUM PROFILE CUSTOMIZER (THEME COLOR HEX & USERNAME STYLES) */}
                  <div className="fism-card p-5 border-2 border-[#F59E0B] space-y-4 relative overflow-hidden">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <span className="px-2.5 py-0.5 rounded-full bg-[#F59E0B] text-white text-[10px] font-black uppercase">
                          Premium Profile Customizer
                        </span>
                        <h2 className="font-extrabold text-base sm:text-lg mt-1 flex items-center gap-2">
                          <Crown className="w-5 h-5 text-[#F59E0B]" /> Profile Theme Colors &amp;
                          Username Styles
                        </h2>
                        <p className="text-xs text-[#52607A]">
                          Strictly reserved for paid FISM Premium users. Rejects arbitrary HTML/CSS
                          &amp; &lt;script&gt; injection tags.
                        </p>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-xl text-xs font-extrabold ${
                          userHasBoughtPremium
                            ? 'bg-[#16A34A] text-white'
                            : 'bg-[#DC2626] text-white'
                        }`}
                      >
                        {userHasBoughtPremium ? '👑 Premium Unlocked' : '🔒 Locked (Free User)'}
                      </span>
                    </div>

                    {!userHasBoughtPremium ? (
                      <div className="p-4 rounded-2xl bg-[#101426] text-white flex items-center justify-between flex-wrap gap-3">
                        <div className="space-y-1">
                          <div className="text-sm font-extrabold text-[#FFB300]">
                            🔒 Buy FISM Premium to Unlock Custom Profile Themes &amp; Username Fonts
                          </div>
                          <p className="text-xs text-slate-300">
                            Non-premium accounts cannot access custom Hex colors, Custom Dark Mode
                            accents, or Flame/Gold username styles.
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setActiveScreen('fuelUp')}
                          className="fism-btn-primary px-4 py-2.5 rounded-xl text-xs font-extrabold shrink-0"
                        >
                          Buy Fuel Up Premium →
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {profileStyleError && (
                          <div className="p-3 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold">
                            🚫 {profileStyleError}
                          </div>
                        )}

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="block text-xs font-extrabold">
                              1. Profile Color Theme (Preset or Strict 6-Digit Hex Code)
                            </label>
                            <div className="flex items-center gap-2 flex-wrap">
                              {PREMIUM_COLOR_PRESETS.map((c) => (
                                <button
                                  key={c.hex}
                                  type="button"
                                  onClick={() => {
                                    setCustomHexDraft(c.hex);
                                    setProfileStyleError(null);
                                  }}
                                  title={c.label}
                                  style={{ backgroundColor: c.hex }}
                                  className={`w-8 h-8 rounded-full border-2 ${
                                    customHexDraft.toUpperCase() === c.hex
                                      ? 'border-white ring-2 ring-[#FF5722] scale-110'
                                      : 'border-transparent'
                                  }`}
                                />
                              ))}
                            </div>
                            <input
                              type="text"
                              value={customHexDraft}
                              onChange={(e) => setCustomHexDraft(e.target.value)}
                              placeholder="#FF5722 (Blocks <script> or <style> tags)"
                              className="w-full px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono font-bold"
                            />
                            <label className="flex items-center gap-2 text-xs font-bold cursor-pointer">
                              <input
                                type="checkbox"
                                checked={customDarkAccentDraft}
                                onChange={(e) => setCustomDarkAccentDraft(e.target.checked)}
                                className="accent-[#7C3AED]"
                              />
                              Enable Custom Dark Profile Card Accent
                            </label>
                          </div>

                          <div className="space-y-2">
                            <label className="block text-xs font-extrabold">
                              2. Username Font &amp; Visual Style
                            </label>
                            <select
                              value={fontDraft}
                              onChange={(e) =>
                                setFontDraft(
                                  e.target.value as FismPremiumProfileStyle['usernameFontId'],
                                )
                              }
                              className="w-full px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                            >
                              {PREMIUM_USERNAME_FONTS.map((f) => (
                                <option key={f.id} value={f.id}>
                                  Font: {f.label}
                                </option>
                              ))}
                            </select>
                            <select
                              value={effectDraft}
                              onChange={(e) =>
                                setEffectDraft(
                                  e.target.value as FismPremiumProfileStyle['usernameEffectId'],
                                )
                              }
                              className="w-full px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                            >
                              {PREMIUM_USERNAME_EFFECTS.map((ef) => (
                                <option key={ef.id} value={ef.id}>
                                  Effect: {ef.label}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div className="flex items-center justify-between flex-wrap gap-3 pt-2 border-t border-[#D8E1F0] dark:border-slate-800">
                          <div className="text-xs font-bold">
                            Live Preview:{' '}
                            <span
                              style={{ color: /^#[0-9A-Fa-f]{6}$/.test(customHexDraft) ? customHexDraft : '#FF5722' }}
                              className="font-extrabold text-sm"
                            >
                              {myProfile.displayName} (@{myProfile.username})
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={async () => {
                              const check = sanitizeAndValidateProfileStyle({
                                themeColorHex: customHexDraft,
                                customDarkAccent: customDarkAccentDraft,
                                usernameFontId: fontDraft,
                                usernameEffectId: effectDraft,
                                rawCustomInput: customHexDraft,
                              });
                              if (!check.valid || !check.style) {
                                setProfileStyleError(check.error || 'Invalid style input.');
                                triggerToast(`🚫 ${check.error}`);
                                return;
                              }
                              try {
                                const res = await fetch('/api/profile/validate-style', {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    isPremium: userHasBoughtPremium,
                                    ...check.style,
                                    rawCustomInput: customHexDraft,
                                  }),
                                });
                                const data = await res.json();
                                if (!res.ok || !data.valid) {
                                  setProfileStyleError(data.error || 'Rejected by server validation.');
                                  return;
                                }
                              } catch {
                                // Already client-validated strictly
                              }
                              setProfileStyleError(null);
                              setPremiumProfileStyle(check.style);
                              try {
                                localStorage.setItem(
                                  'fism_premium_profile_style_v1',
                                  JSON.stringify(check.style),
                                );
                              } catch {
                                // ignore
                              }
                              triggerToast(
                                '👑 Premium Profile Theme & Username Style applied to My Hearth!',
                              );
                            }}
                            className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold shadow"
                          >
                            Apply &amp; Save Custom Style
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="fism-card p-5 space-y-4">
                    <h2 className="font-bold text-base flex items-center gap-2">
                      <Sun className="w-4 h-4 text-[#FF5722]" /> Appearance &amp; Theme Mode
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        onClick={() => setThemeMode('light')}
                        className={`p-4 rounded-xl border text-left ${
                          themeMode === 'light'
                            ? 'border-[#FF5722] bg-[#F5F7FF] dark:bg-slate-800'
                            : 'border-[#D8E1F0] dark:border-slate-700'
                        }`}
                      >
                        <div className="font-bold text-sm flex items-center gap-2">
                          <Sun className="w-4 h-4 text-[#FF5722]" /> Rich Light Mode
                        </div>
                        <p className="text-xs text-[#52607A] mt-1">
                          Crisp white surfaces with deep navy text and fiery orange-red gradients.
                        </p>
                      </button>
                      <button
                        onClick={() => setThemeMode('dark')}
                        className={`p-4 rounded-xl border text-left ${
                          themeMode === 'dark'
                            ? 'border-[#FF5722] bg-[#F5F7FF] dark:bg-slate-800'
                            : 'border-[#D8E1F0] dark:border-slate-700'
                        }`}
                      >
                        <div className="font-bold text-sm flex items-center gap-2">
                          <Moon className="w-4 h-4 text-[#7C3AED]" /> Charcoal Dark Mode
                        </div>
                        <p className="text-xs text-[#52607A] mt-1">
                          Deep charcoal #101426 with glowing amber and fiery orange accents.
                        </p>
                      </button>
                      <button
                        onClick={() => setThemeMode('system')}
                        className={`p-4 rounded-xl border text-left ${
                          themeMode === 'system'
                            ? 'border-[#FF5722] bg-[#F5F7FF] dark:bg-slate-800'
                            : 'border-[#D8E1F0] dark:border-slate-700'
                        }`}
                      >
                        <div className="font-bold text-sm flex items-center gap-2">
                          <Monitor className="w-4 h-4 text-[#2563EB]" /> System Mode
                        </div>
                        <p className="text-xs text-[#52607A] mt-1">
                          Automatically follows your device display setting.
                        </p>
                      </button>
                    </div>
                  </div>

                  {/* Quick Burst Playback Speed & Video Streaming Settings */}
                  <div className="fism-card p-5 space-y-4">
                    <h2 className="font-bold text-base flex items-center gap-2">
                      <Zap className="w-4 h-4 text-[#FF5722]" /> Quick Burst Shorts Speed &amp;
                      Video Playback Settings
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-3.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 space-y-2">
                        <div className="text-xs font-extrabold">
                          Default Quick Burst Playback Speed (1x Normal to 3x Max)
                        </div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {([1, 1.5, 2, 2.5, 3] as const).map((spd) => (
                            <button
                              key={spd}
                              onClick={() => {
                                setShortPlaybackSpeed(spd);
                                triggerToast(`⚡ Default Short speed set to ${spd}x`);
                              }}
                              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold ${
                                shortPlaybackSpeed === spd
                                  ? 'fism-btn-primary'
                                  : 'bg-white dark:bg-slate-900 text-[#52607A]'
                              }`}
                            >
                              {spd}x
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="p-3.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 space-y-2">
                        <div className="text-xs font-extrabold">
                          Stream Quality &amp; Auto-Scroll Shorts
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          {(['4k60', '1080p', 'auto', 'dataSaver'] as const).map((q) => (
                            <button
                              key={q}
                              onClick={() => setStreamQualityMode(q)}
                              className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase ${
                                streamQualityMode === q
                                  ? 'bg-[#2563EB] text-white'
                                  : 'bg-white dark:bg-slate-900 text-[#52607A]'
                              }`}
                            >
                              {q}
                            </button>
                          ))}
                          <button
                            onClick={() => setAutoScrollShortsOnEnd((v) => !v)}
                            className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                              autoScrollShortsOnEnd
                                ? 'bg-[#16A34A] text-white'
                                : 'bg-white dark:bg-slate-900 text-[#52607A]'
                            }`}
                          >
                            Auto-Scroll Next Short: {autoScrollShortsOnEnd ? 'ON' : 'OFF'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Global Earning Currency & Creator Monetization Shortcut in Settings */}
                  <div className="fism-card p-5 space-y-3 border-2 border-[#FFB300]">
                    <div className="flex items-center justify-between flex-wrap gap-3">
                      <div>
                        <h2 className="font-extrabold text-base flex items-center gap-2">
                          <Crown className="w-5 h-5 text-[#FFB300]" /> Creator Earning &amp;
                          Country Currency Settings (5,000 Sparks)
                        </h2>
                        <p className="text-xs text-[#52607A]">
                          Minimum 1 Lakh (1,00,000) Views = $0.0001 USD • Select your preferred
                          country currency (India ₹, China Yuan ¥, Japan ¥, Pakistan ₨, USA $).
                        </p>
                      </div>
                      <button
                        onClick={() => setActiveScreen('earningHub')}
                        className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold shadow"
                      >
                        💰 Open Creator Earning Section →
                      </button>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap pt-1">
                      {WORLD_CURRENCIES.slice(0, 8).map((c) => (
                        <button
                          key={c.code}
                          onClick={() => {
                            setEarningCurrencyCode(c.code);
                            triggerToast(`🌍 Primary Currency set to ${c.flag} ${c.name} (${c.code})`);
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border ${
                            earningCurrencyCode === c.code
                              ? 'bg-[#FF5722] text-white border-[#FF5722]'
                              : 'bg-[#F1F5F9] dark:bg-slate-800 border-[#D8E1F0] dark:border-slate-700'
                          }`}
                        >
                          <span>{c.flag}</span>
                          <span>{c.code}</span>
                          <span>({c.symbol})</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="fism-card p-5 space-y-3">
                    <h2 className="font-bold text-base flex items-center gap-2">
                      <Sliders className="w-4 h-4 text-[#2563EB]" /> Accessibility &amp; Display
                    </h2>
                    <div className="flex flex-wrap gap-3">
                      <button
                        onClick={() =>
                          setFontSizeScale((s) => (s === 'normal' ? 'large' : 'normal'))
                        }
                        className="px-4 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
                      >
                        Font Size: {fontSizeScale === 'large' ? 'Large (17px)' : 'Standard (16px)'}
                      </button>
                      <button
                        onClick={() => setHighContrast((c) => !c)}
                        className="px-4 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
                      >
                        High Contrast: {highContrast ? 'Enabled' : 'Standard'}
                      </button>
                      <button
                        onClick={() => setReducedMotion((m) => !m)}
                        className="px-4 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
                      >
                        Reduced Motion: {reducedMotion ? 'Enabled' : 'Off'}
                      </button>
                    </div>
                  </div>

                  {/* ABOUT & LEGAL / PRIVACY SECTION */}
                  <div className="fism-card p-5 space-y-3 border border-[#D8E1F0] dark:border-slate-800">
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <div>
                        <h3 className="font-extrabold text-sm flex items-center gap-2">
                          <FileText className="w-4 h-4 text-[#2563EB]" /> About &amp; Legal — Legal
                          &amp; Privacy
                        </h3>
                        <p className="text-xs text-[#52607A] dark:text-slate-400 mt-0.5">
                          Last Updated: November 20, 2026 • Clear plain-English policies covering
                          all FISM features
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          setLegalDocsModalState({ open: true, returnLabel: 'Back to Settings' })
                        }
                        className="min-h-[44px] px-4 py-2 rounded-xl bg-[#EFF6FF] dark:bg-[#1E293B] border border-[#BFDBFE] dark:border-[#3B82F6]/40 text-[#2563EB] dark:text-[#3B82F6] text-xs font-extrabold cursor-pointer hover:underline"
                      >
                        Open Legal Center
                      </button>
                    </div>
                    <div className="p-3.5 rounded-xl bg-[#F8FAFC] dark:bg-[#0F172A] border border-[#E2E8F0] dark:border-slate-800">
                      <p className="text-xs sm:text-sm text-[#334155] dark:text-slate-300 leading-relaxed">
                        This is our{' '}
                        <button
                          type="button"
                          onClick={() =>
                            setLegalDocsModalState({ open: true, returnLabel: 'Back to Settings' })
                          }
                          className="font-extrabold text-[#2563EB] dark:text-[#3B82F6] hover:underline cursor-pointer inline"
                        >
                          Terms of Service &amp; Privacy Policy
                        </button>
                        .{' '}
                        <button
                          type="button"
                          onClick={() =>
                            setLegalDocsModalState({ open: true, returnLabel: 'Back to Settings' })
                          }
                          className="font-extrabold text-[#2563EB] dark:text-[#3B82F6] hover:underline cursor-pointer inline"
                        >
                          Click and Read
                        </button>
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* SUB-TAB 2: SMART SETTINGS (UNLIMITED PROFILE IDs MANAGER + LOCKED USERNAME + AI BOT RESTORE) */}
              {settingsSubTab === 'smart' && (
                <div className="space-y-5">
                  {/* AI Flame Algorithm & 5k Creator Ad / Affiliate Studio Shortcut */}
                  <div className="fism-card p-4 border-2 border-[#7C3AED] flex items-center justify-between flex-wrap gap-3">
                    <div>
                      <h3 className="font-extrabold text-sm flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-[#7C3AED]" /> AI Flame Algorithm &amp; 5k
                        Ad &amp; Affiliate Studio
                      </h3>
                      <p className="text-xs text-[#52607A]">
                        Connect Amazon, Flipkart &amp; Meesho affiliate stores and launch targeted
                        Quick Burst &amp; Main Blast Creator Ads.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setViewedProfileId(myProfile.uid);
                        setProfileTab('Ad & Affiliate');
                        setActiveScreen('myHearth');
                      }}
                      className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold"
                    >
                      Open Ad &amp; Affiliate Studio →
                    </button>
                  </div>

                  {/* Master & Sub-ID Security, Password Lock, Account Privacy & 18+ Aadhaar Vision Hub */}
                  {activeSubAccount && (
                    <FismAccountPrivacySecurityHub
                      subAccounts={subAccounts}
                      activeSubAccount={activeSubAccount}
                      followRequests={followRequests}
                      creatingSubId={creatingSubId}
                      verifyingAge={verifyingAge}
                      lastAgeResult={lastAgeResult}
                      onRequestSwitchSubAccount={(acc) => void handleRequestSwitchSubAccount(acc)}
                      onCreateSubAccount={handleCreateIsolatedSubAccount}
                      onUpdateActiveAccountPrivacy={handleUpdateActiveAccountPrivacy}
                      onOpenEditActiveProfile={() => setEditProfileModalOpen(true)}
                      onSetAccountPassword={handleSetAccountPassword}
                      onVerifyAadhaarImage={handleVerifyAadhaarImage}
                      onRespondFollowRequest={handleRespondFollowRequest}
                      onSendFollowRequestToTarget={(targetAcc) =>
                        handleSendPrivateFollowRequest({
                          uid: targetAcc.id,
                          username: targetAcc.username,
                          displayName: targetAcc.displayName,
                          isPrivate: targetAcc.privacyMode === 'private',
                        })
                      }
                    />
                  )}

                  {/* Smart Floating AI Chatbot & Smart Routing Settings */}
                  <div className="fism-card p-5 space-y-3">
                    <h2 className="font-extrabold text-base flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-[#FF5722]" /> Smart AI &amp; Automation
                      Controls
                    </h2>
                    <div className="flex items-center justify-between p-3 rounded-xl bg-[#F1F5F9] dark:bg-slate-800">
                      <div>
                        <div className="font-bold text-sm">
                          Floating AI Chatbot Launcher Icon
                        </div>
                        <div className="text-xs text-[#52607A]">
                          Long-pressing the floating icon dismisses it. Toggle here to restore or
                          hide.
                        </div>
                      </div>
                      <button
                        onClick={() => setFloatingBotVisible((v) => !v)}
                        className={`px-4 py-2 rounded-xl text-xs font-extrabold ${
                          floatingBotVisible
                            ? 'bg-[#16A34A] text-white'
                            : 'bg-[#FF5722] text-white'
                        }`}
                      >
                        {floatingBotVisible ? 'Launcher Visible' : 'Restore Floating AI Icon'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* SUB-TAB 3: ADVANCED SETTINGS (SETUP YOUR PROFILE AUTO MESSAGE + ADMIN FILE 3-STEP LOCK + E2E ENCRYPTED CHAT LOGS) */}
              {settingsSubTab === 'advanced' && (
                <div className="space-y-5">
                  {/* NEW FEATURE IN ADVANCED SETTINGS: SETUP YOUR PROFILE AUTO MESSAGE */}
                  <div className="fism-card p-6 border-2 border-[#16A34A] space-y-4">
                    <div className="flex items-center justify-between flex-wrap gap-3">
                      <div>
                        <span className="px-2.5 py-0.5 rounded-full bg-[#16A34A] text-white text-[10px] font-extrabold uppercase">
                          Advanced Profile Automation &amp; E2E Chat
                        </span>
                        <h2 className="text-lg sm:text-xl font-extrabold mt-1 flex items-center gap-2">
                          <MessageCircle className="w-5 h-5 text-[#16A34A]" /> Setup Your Profile
                          Auto Message
                        </h2>
                        <p className="text-xs text-[#52607A]">
                          Write any incoming trigger text and the automatic reply message. When
                          anyone sends that text to you in Ember Chat, your reply is sent
                          automatically (visible to both you and the sender). If no auto-reply is
                          set for a text, the message stays pending until you manually reply.
                        </p>
                      </div>
                      <button
                        onClick={() => setActiveScreen('emberChat')}
                        className="px-4 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold shadow"
                      >
                        Test in Ember Chat →
                      </button>
                    </div>

                    {/* Add New Auto-Reply Rule Form */}
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 p-3.5 rounded-2xl bg-[#F1F5F9] dark:bg-slate-800">
                      <input
                        type="text"
                        value={newAutoTriggerInput}
                        onChange={(e) => setNewAutoTriggerInput(e.target.value)}
                        placeholder="If someone sends text (e.g. hi, hello, rate)..."
                        className="sm:col-span-4 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                      />
                      <input
                        type="text"
                        value={newAutoReplyInput}
                        onChange={(e) => setNewAutoReplyInput(e.target.value)}
                        placeholder="Automatically send this reply message..."
                        className="sm:col-span-6 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                      />
                      <button
                        onClick={() => {
                          if (!newAutoTriggerInput.trim() || !newAutoReplyInput.trim()) {
                            triggerToast(
                              'Please enter both the incoming trigger text and the automatic reply!',
                            );
                            return;
                          }
                          const newRule: FismAutoReplyRule = {
                            id: `auto_${Date.now()}`,
                            triggerText: newAutoTriggerInput.trim(),
                            replyText: newAutoReplyInput.trim(),
                            enabled: true,
                            createdAt: 'Just added',
                          };
                          setAutoReplyRules((prev) => [newRule, ...prev]);
                          setNewAutoTriggerInput('');
                          setNewAutoReplyInput('');
                          triggerToast(
                            `✅ Profile Auto Message saved: "${newRule.triggerText}" → "${newRule.replyText}"`,
                          );
                        }}
                        className="sm:col-span-2 fism-btn-primary py-2 px-3 rounded-xl text-xs font-extrabold"
                      >
                        + Save Rule
                      </button>
                    </div>

                    {/* Active Auto-Reply Rules List */}
                    <div className="space-y-2">
                      {autoReplyRules.map((rule) => (
                        <div
                          key={rule.id}
                          className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between gap-3 flex-wrap"
                        >
                          <div className="text-xs space-y-0.5">
                            <div>
                              <span className="font-extrabold text-[#2563EB]">
                                When user sends:{' '}
                              </span>
                              <span className="px-2 py-0.5 rounded bg-[#2563EB]/10 font-mono font-bold">
                                &quot;{rule.triggerText}&quot;
                              </span>
                            </div>
                            <div>
                              <span className="font-extrabold text-[#16A34A]">
                                Auto-Reply sent:{' '}
                              </span>
                              <span className="font-semibold">&quot;{rule.replyText}&quot;</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() =>
                                setAutoReplyRules((prev) =>
                                  prev.map((r) =>
                                    r.id === rule.id ? { ...r, enabled: !r.enabled } : r,
                                  ),
                                )
                              }
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold ${
                                rule.enabled
                                  ? 'bg-[#16A34A] text-white'
                                  : 'bg-slate-200 dark:bg-slate-700 text-[#52607A]'
                              }`}
                            >
                              {rule.enabled ? 'Active' : 'Paused'}
                            </button>
                            <button
                              onClick={() =>
                                setAutoReplyRules((prev) => prev.filter((r) => r.id !== rule.id))
                              }
                              className="p-1.5 rounded-lg text-[#DC2626] hover:bg-red-500/10"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* SECRET / DISAPPEARING CHAT PASSWORD LOCK & FIREBASE AUTH OTP RESET FLOW */}
                  <div className="fism-card p-6 border-2 border-[#0EA5E9] space-y-4">
                    <div className="flex items-center justify-between flex-wrap gap-3">
                      <div>
                        <span className="px-2.5 py-0.5 rounded-full bg-[#0EA5E9] text-white text-[10px] font-black uppercase">
                          Chat Lock Security &amp; Firebase Auth OTP Recovery
                        </span>
                        <h2 className="text-lg sm:text-xl font-extrabold mt-1 flex items-center gap-2">
                          <KeyRound className="w-5 h-5 text-[#0EA5E9]" /> Secret Chat Lock &amp;
                          Delete / Reset Password
                        </h2>
                        <p className="text-xs text-[#52607A]">
                          Protect Secret &amp; Disappearing Chats in Ember Chat with a security
                          password. Forgot or want to delete your password? Verify via registered
                          Email or Phone OTP using Firebase Auth!
                        </p>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-xl text-xs font-extrabold ${
                          secretChatPassword
                            ? 'bg-[#16A34A] text-white'
                            : 'bg-slate-200 dark:bg-slate-800 text-[#52607A]'
                        }`}
                      >
                        {secretChatPassword ? '🔒 Password Set' : 'No Password Set'}
                      </span>
                    </div>

                    {/* Set Initial Password if None Exists */}
                    {!secretChatPassword && (
                      <div className="p-3.5 rounded-2xl bg-[#F1F5F9] dark:bg-slate-800 flex items-center gap-2 flex-wrap">
                        <input
                          type="password"
                          value={newChatPassDraft}
                          onChange={(e) => setNewChatPassDraft(e.target.value)}
                          placeholder="Create Secret Chat Security Password (min 4 chars)..."
                          className="flex-1 min-w-[200px] px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (newChatPassDraft.trim().length < 4) {
                              triggerToast('Password must be at least 4 characters.');
                              return;
                            }
                            updateSecretChatPassword(newChatPassDraft.trim());
                            setSecretChatsLocked(true);
                            setNewChatPassDraft('');
                            triggerToast('🔒 Secret Chat Security Password saved!');
                          }}
                          className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold"
                        >
                          Save Chat Password
                        </button>
                      </div>
                    )}

                    {/* Delete / Reset Security Password Flow via Firebase Auth Email/Phone OTP */}
                    <div className="p-4 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 space-y-3">
                      <div className="text-xs font-extrabold text-[#0EA5E9] uppercase">
                        Delete / Reset Chat Security Password (Verify Registered Email or Phone OTP)
                      </div>
                      <div id="fism-recaptcha-container" />

                      <div className="flex items-center gap-2 flex-wrap">
                        <input
                          type="text"
                          value={recoveryContactInput}
                          onChange={(e) => setRecoveryContactInput(e.target.value)}
                          placeholder="Enter registered Email or Phone (e.g. +919876543210 or you@gmail.com)"
                          className="flex-1 min-w-[220px] px-3 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                        />
                        <button
                          type="button"
                          disabled={recoverySending}
                          onClick={async () => {
                            const contact = recoveryContactInput.trim();
                            if (!contact) {
                              triggerToast('Please enter your registered Email or Phone Number.');
                              return;
                            }
                            setRecoverySending(true);
                            setRecoveryStatusMsg(null);
                            setRecoveryOtpVerified(false);
                            setRecoveryFirebaseConfirm(null);

                            // Attempt Firebase Auth Phone OTP or Email Reset first, paired with challenge verification
                            if (!contact.includes('@') && contact.startsWith('+')) {
                              try {
                                if (!recaptchaVerifierRef.current) {
                                  recaptchaVerifierRef.current = new RecaptchaVerifier(
                                    auth,
                                    'fism-recaptcha-container',
                                    { size: 'invisible' },
                                  );
                                }
                                const confirmation = await signInWithPhoneNumber(
                                  auth,
                                  contact,
                                  recaptchaVerifierRef.current,
                                );
                                setRecoveryFirebaseConfirm(confirmation);
                                setRecoveryStatusMsg(
                                  `📲 Firebase SMS OTP sent to ${contact}! Enter the 6-digit SMS code below.`,
                                );
                                setRecoverySending(false);
                                return;
                              } catch {
                                // Fallback to server-issued OTP challenge if phone domain/captcha isn't configured for current preview host
                              }
                            } else if (contact.includes('@')) {
                              sendPasswordResetEmail(auth, contact).catch(() => {});
                            }

                            try {
                              const res = await fetch('/api/security/send-chat-otp', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ contact }),
                              });
                              const data = await res.json();
                              if (!res.ok) {
                                setRecoveryStatusMsg(`⚠️ ${data.error || 'Failed to send OTP.'}`);
                              } else {
                                setRecoveryChallengeId(data.challengeId);
                                setRecoveryOtpPreview(data.demoOtpPreview);
                                setRecoveryStatusMsg(
                                  `📲 Verification OTP dispatched to ${data.maskedContact}.`,
                                );
                              }
                            } catch {
                              setRecoveryStatusMsg('⚠️ Could not dispatch OTP.');
                            } finally {
                              setRecoverySending(false);
                            }
                          }}
                          className="px-4 py-2.5 rounded-xl bg-[#0EA5E9] text-white text-xs font-extrabold shadow disabled:opacity-60"
                        >
                          {recoverySending ? 'Sending OTP...' : 'Send Verification OTP'}
                        </button>
                      </div>

                      {recoveryStatusMsg && (
                        <div className="p-2.5 rounded-xl bg-[#0EA5E9]/15 border border-[#0EA5E9] text-xs font-bold">
                          {recoveryStatusMsg}
                          {recoveryOtpPreview && (
                            <span className="ml-2 px-2 py-0.5 rounded bg-[#0EA5E9] text-white font-mono">
                              OTP: {recoveryOtpPreview}
                            </span>
                          )}
                        </div>
                      )}

                      {(recoveryChallengeId || recoveryFirebaseConfirm) && !recoveryOtpVerified && (
                        <div className="flex items-center gap-2 flex-wrap">
                          <input
                            type="text"
                            value={recoveryOtpInput}
                            onChange={(e) => setRecoveryOtpInput(e.target.value)}
                            placeholder="Enter 6-digit OTP..."
                            className="flex-1 min-w-[160px] px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono font-bold"
                          />
                          <button
                            type="button"
                            onClick={async () => {
                              if (recoveryFirebaseConfirm) {
                                try {
                                  await recoveryFirebaseConfirm.confirm(recoveryOtpInput.trim());
                                  updateSecretChatPassword('');
                                  setSecretChatsLocked(false);
                                  setRecoveryOtpVerified(true);
                                  setRecoveryOtpPreview(null);
                                  triggerToast(
                                    '✅ Firebase OTP Verified! Old password deleted. Set a new password below.',
                                  );
                                  return;
                                } catch {
                                  triggerToast('❌ Invalid Firebase SMS OTP code.');
                                  return;
                                }
                              }
                              const res = await fetch('/api/security/verify-chat-otp', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                  challengeId: recoveryChallengeId,
                                  otpCode: recoveryOtpInput.trim(),
                                }),
                              });
                              const data = await res.json();
                              if (res.ok && data.verified) {
                                updateSecretChatPassword('');
                                setSecretChatsLocked(false);
                                setRecoveryOtpVerified(true);
                                setRecoveryOtpPreview(null);
                                triggerToast(
                                  '✅ OTP Verified! Old security password deleted. Set a new password below.',
                                );
                              } else {
                                triggerToast(`❌ ${data.error || 'OTP Verification failed'}`);
                              }
                            }}
                            className="px-4 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold"
                          >
                            Verify OTP &amp; Delete Old Password
                          </button>
                        </div>
                      )}

                      {recoveryOtpVerified && (
                        <div className="p-3 rounded-xl bg-[#16A34A]/15 border border-[#16A34A] space-y-2">
                          <div className="text-xs font-extrabold text-[#16A34A]">
                            ✓ Old Secret Chat Password Deleted! Set a New Security Password:
                          </div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <input
                              type="password"
                              value={recoveryNewPasswordInput}
                              onChange={(e) => setRecoveryNewPasswordInput(e.target.value)}
                              placeholder="Enter new security password (min 4 chars)..."
                              className="flex-1 min-w-[180px] px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                if (recoveryNewPasswordInput.trim().length < 4) {
                                  triggerToast('New password must be at least 4 characters.');
                                  return;
                                }
                                updateSecretChatPassword(recoveryNewPasswordInput.trim());
                                setSecretChatsLocked(true);
                                setRecoveryNewPasswordInput('');
                                setRecoveryOtpVerified(false);
                                setRecoveryChallengeId(null);
                                setRecoveryOtpInput('');
                                setRecoveryStatusMsg(null);
                                triggerToast(
                                  '🔐 New Secret Chat Security Password set & active!',
                                );
                              }}
                              className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold"
                            >
                              Set New Password
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="fism-card p-6 border-2 border-[#7C3AED] space-y-4">
                    <div className="flex items-center justify-between flex-wrap gap-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl fism-gradient-royal text-white flex items-center justify-center shadow-lg">
                          <Lock className="w-6 h-6" />
                        </div>
                        <div>
                          <span className="px-2 py-0.5 rounded bg-[#7C3AED] text-white text-[10px] font-extrabold uppercase">
                            Confidential Advanced Section
                          </span>
                          <h2 className="text-xl font-extrabold mt-0.5">
                            Admin File Open Section (एडमिन फाइल)
                          </h2>
                          <p className="text-xs text-[#52607A]">
                            Protected by 3-Step Security Lock • Includes Live User ID Ban/Unban,
                            Long-Press Secret User Dossier, Per-Section Premium ON/OFF Switches,
                            AI Anti-Hacking Security Guard, E2E Encrypted Chat Audit, and Admin
                            Exclusive 2D Game Uploader.
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => setActiveScreen('adminFileVault')}
                        className="fism-btn-primary px-6 py-3 rounded-xl text-xs sm:text-sm font-extrabold shadow-xl flex items-center gap-2"
                      >
                        <Lock className="w-4 h-4" /> Open Admin File (3-Step Lock) →
                      </button>
                    </div>
                  </div>

                  {/* Embedded Preview / Direct Access to Admin File Vault */}
                  <FismAdminFileVault
                    unlocked={adminFileUnlocked}
                    onUnlockSuccess={() => setAdminFileUnlocked(true)}
                    userDossiers={adminUserDossiers}
                    onToggleBanUser={(uid) => {
                      setAdminUserDossiers((prev) =>
                        prev.map((u) =>
                          u.uid === uid
                            ? {
                                ...u,
                                isBanned: !u.isBanned,
                                liveStatusText: !u.isBanned
                                  ? 'BANNED BY ADMIN • Access Revoked Live'
                                  : 'UNBANNED BY ADMIN • Live & Active',
                              }
                            : u,
                        ),
                      );
                      triggerToast(`Updated live Ban/Unban status for user ID: ${uid}`);
                    }}
                    globalPremiumOn={globalPremiumOn}
                    onToggleGlobalPremium={(next) => {
                      setGlobalPremiumOn(next);
                      triggerToast(
                        next
                          ? 'Global App Premium is now ON!'
                          : 'Global App Premium is now OFF.',
                      );
                    }}
                    sectionPremiumMap={sectionPremiumMap}
                    onToggleSectionPremium={(scr) => {
                      setSectionPremiumMap((prev) => {
                        const updated = !prev[scr];
                        triggerToast(
                          `${scr} Premium mode switched ${updated ? 'ON' : 'OFF'}!`,
                        );
                        return { ...prev, [scr]: updated };
                      });
                    }}
                    onTriggerToast={triggerToast}
                    gamesList={gamesCatalog}
                    onAdminUploadGame={handleAdminUploadGame}
                    activeSurvey={activeSurveyCampaign}
                    onLaunchSurvey={(campaign) => {
                      setActiveSurveyCampaign(campaign);
                      setSurveyAnswersDraft({});
                      try {
                        localStorage.setItem('fism_active_survey', JSON.stringify(campaign));
                      } catch {
                        // ignore
                      }
                    }}
                    onStopSurvey={() => {
                      setActiveSurveyCampaign(null);
                      try {
                        localStorage.removeItem('fism_active_survey');
                      } catch {
                        // ignore
                      }
                    }}
                    surveySubmissions={surveySubmissions}
                    upiConfig={upiConfig}
                    onUpdateUpiConfig={handleUpdateUpiConfig}
                    upiRequests={upiRequests}
                    onAcceptUpiRequest={handleAcceptUpiRequest}
                    onDeclineUpiRequest={handleDeclineUpiRequest}
                    custom3DModels={custom3DModels}
                    onAdminUpload3DModel={handleAdminUpload3DModel}
                    appLogoBgUrl={appLogoBgUrl}
                    onUpdateAppLogoBg={handleUpdateAppLogoBg}
                    withdrawalRequests={withdrawalRequests}
                    onAcceptWithdrawalRequest={handleAcceptWithdrawalRequest}
                    onDeclineWithdrawalRequest={handleDeclineWithdrawalRequest}
                    userHasBoughtPremium={userHasBoughtPremium}
                    onToggleUserBoughtPremium={handleToggleUserBoughtPremium}
                    publishedArFilters={publishedArFilters}
                    onPublishArFilter={handlePublishArFilter}
                    publishedStudioFilters={publishedStudioFilters}
                    onPublishStudioFilter={handlePublishStudioFilter}
                    onDeleteStudioFilter={handleDeleteStudioFilter}
                    copyrightAssets={copyrightAssets}
                    copyrightViolations={copyrightViolations}
                    onAddCopyrightAsset={handleAddCopyrightAsset}
                    onApproveCopyrightAppeal={handleApproveCopyrightAppeal}
                    onRejectCopyrightAppeal={handleRejectCopyrightAppeal}
                    liveCreatorUsers={liveCreatorUsersDirectory}
                    onGrantLiveCreatorAccess={handleGrantLiveCreatorAccess}
                    smartAds={smartAds}
                    onCreateSmartAd={handleCreateSmartAd}
                    onToggleSmartAd={handleToggleSmartAd}
                    onDeleteSmartAd={handleDeleteSmartAd}
                    founderGiftClaims={adminFounderGiftClaims}
                    onRespondFounderGift={handleAdminRespondFounderGift}
                    adsterraConfig={adsterraConfig}
                    onSaveAdsterraConfig={handleSaveAdsterraConfig}
                    apkRelease={apkRelease}
                    onUploadApkRelease={handleUploadApkRelease}
                    onDeleteApkRelease={handleDeleteApkRelease}
                  />
                </div>
              )}
            </div>
          )}

          {/* SCREEN 16: DIRECT ADMIN FILE VAULT SCREEN */}
          {(activeScreen === 'adminFileVault' || activeScreen === 'adminPanel') && (
            <FismAdminFileVault
              unlocked={adminFileUnlocked}
              onUnlockSuccess={() => setAdminFileUnlocked(true)}
              userDossiers={adminUserDossiers}
              onToggleBanUser={(uid) => {
                setAdminUserDossiers((prev) =>
                  prev.map((u) =>
                    u.uid === uid
                      ? {
                          ...u,
                          isBanned: !u.isBanned,
                          liveStatusText: !u.isBanned
                            ? 'BANNED BY ADMIN • Access Revoked Live'
                            : 'UNBANNED BY ADMIN • Live & Active',
                        }
                      : u,
                  ),
                );
                triggerToast(`Updated live Ban/Unban status for user ID: ${uid}`);
              }}
              globalPremiumOn={globalPremiumOn}
              onToggleGlobalPremium={(next) => {
                setGlobalPremiumOn(next);
                triggerToast(
                  next ? 'Global App Premium is now ON!' : 'Global App Premium is now OFF.',
                );
              }}
              sectionPremiumMap={sectionPremiumMap}
              onToggleSectionPremium={(scr) => {
                setSectionPremiumMap((prev) => {
                  const updated = !prev[scr];
                  triggerToast(`${scr} Premium mode switched ${updated ? 'ON' : 'OFF'}!`);
                  return { ...prev, [scr]: updated };
                });
              }}
              onTriggerToast={triggerToast}
              gamesList={gamesCatalog}
              onAdminUploadGame={handleAdminUploadGame}
              activeSurvey={activeSurveyCampaign}
              onLaunchSurvey={(campaign) => {
                setActiveSurveyCampaign(campaign);
                setSurveyAnswersDraft({});
                try {
                  localStorage.setItem('fism_active_survey', JSON.stringify(campaign));
                } catch {
                  // ignore
                }
              }}
              onStopSurvey={() => {
                setActiveSurveyCampaign(null);
                try {
                  localStorage.removeItem('fism_active_survey');
                } catch {
                  // ignore
                }
              }}
              surveySubmissions={surveySubmissions}
              upiConfig={upiConfig}
              onUpdateUpiConfig={handleUpdateUpiConfig}
              upiRequests={upiRequests}
              onAcceptUpiRequest={handleAcceptUpiRequest}
              onDeclineUpiRequest={handleDeclineUpiRequest}
              custom3DModels={custom3DModels}
              onAdminUpload3DModel={handleAdminUpload3DModel}
              appLogoBgUrl={appLogoBgUrl}
              onUpdateAppLogoBg={handleUpdateAppLogoBg}
              withdrawalRequests={withdrawalRequests}
              onAcceptWithdrawalRequest={handleAcceptWithdrawalRequest}
              onDeclineWithdrawalRequest={handleDeclineWithdrawalRequest}
              userHasBoughtPremium={userHasBoughtPremium}
              onToggleUserBoughtPremium={handleToggleUserBoughtPremium}
              publishedArFilters={publishedArFilters}
              onPublishArFilter={handlePublishArFilter}
              publishedStudioFilters={publishedStudioFilters}
              onPublishStudioFilter={handlePublishStudioFilter}
              onDeleteStudioFilter={handleDeleteStudioFilter}
              copyrightAssets={copyrightAssets}
              copyrightViolations={copyrightViolations}
              onAddCopyrightAsset={handleAddCopyrightAsset}
              onApproveCopyrightAppeal={handleApproveCopyrightAppeal}
              onRejectCopyrightAppeal={handleRejectCopyrightAppeal}
              liveCreatorUsers={liveCreatorUsersDirectory}
              onGrantLiveCreatorAccess={handleGrantLiveCreatorAccess}
              smartAds={smartAds}
              onCreateSmartAd={handleCreateSmartAd}
              onToggleSmartAd={handleToggleSmartAd}
              onDeleteSmartAd={handleDeleteSmartAd}
              founderGiftClaims={adminFounderGiftClaims}
              onRespondFounderGift={handleAdminRespondFounderGift}
              adsterraConfig={adsterraConfig}
              onSaveAdsterraConfig={handleSaveAdsterraConfig}
              apkRelease={apkRelease}
              onUploadApkRelease={handleUploadApkRelease}
              onDeleteApkRelease={handleDeleteApkRelease}
            />
          )}

          {/* INFORMATIONAL SCREENS */}
          {(activeScreen === 'helpSupport' ||
            activeScreen === 'aboutFism' ||
            activeScreen === 'privacyPolicy' ||
            activeScreen === 'termsConditions') && (
            <div className="max-w-3xl mx-auto fism-card p-6 space-y-4">
              <h1 className="text-2xl font-extrabold">FISM Platform Documentation</h1>
              <p className="text-sm text-[#52607A] dark:text-slate-300 leading-relaxed">
                FISM (Flame Interactive Social Media) combines Main Blast long-form video, Quick
                Burst vertical shorts, 3D VR Cinema, 2D Game Hub, Shopping Marketplace with GPS
                navigation, Ember Chat with live calling &amp; Emoji Blast mini-game, and the
                discreet 3-Step Locked Admin File Vault inside Advanced Settings.
              </p>
              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() =>
                    setLegalDocsModalState({ open: true, returnLabel: 'Back to Settings' })
                  }
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-extrabold cursor-pointer"
                >
                  Open Full Terms of Service &amp; Privacy Policy
                </button>
                <button
                  onClick={() => navigateWithAuthGate('flameFeed')}
                  className="min-h-[44px] fism-btn-primary px-4 py-2 rounded-xl text-xs font-bold"
                >
                  Return to Flame Feed
                </button>
              </div>
            </div>
          )}
            </>
          )}
        </main>

        {/* RIGHT DESKTOP DISCOVERY SIDEBAR (> 1199px) — Widened to 336px so exact 300x250 Banner fits cleanly without clipping */}
        <aside className="hide-mobile-950 hide-tablet-1199 w-[336px] shrink-0 border-l border-[#D8E1F0] dark:border-slate-800 bg-white dark:bg-[#101426] p-4 space-y-5 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto">
          <div className="fism-card p-4">
            <h3 className="font-extrabold text-xs uppercase tracking-wider text-[#52607A] mb-3 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-[#FF5722]" /> Trending on FISM
            </h3>
            <div className="space-y-2">
              {[
                { tag: '#AlpineFlame', count: '48.2K Sparks' },
                { tag: '#MainBlast8K', count: '31.9K Sparks' },
                { tag: '#QuickBurstChallenge', count: '94.1K Sparks' },
                { tag: '#FISMShopping', count: '29.4K Sparks' },
              ].map((item) => (
                <button
                  key={item.tag}
                  onClick={() => {
                    if (!requireAuth('Explore Trending Hashtags')) return;
                    setGlobalSearchQuery(item.tag);
                    setActiveScreen('findFlame');
                  }}
                  className="w-full flex items-center justify-between text-left hover:bg-[#F1F5F9] dark:hover:bg-slate-800 p-1.5 rounded-lg transition-colors"
                >
                  <span className="font-bold text-xs text-[#2563EB]">{item.tag}</span>
                  <span className="text-[11px] text-[#52607A]">{item.count}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="fism-card p-4">
            <h3 className="font-extrabold text-xs uppercase tracking-wider text-[#52607A] mb-3 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-[#7C3AED]" /> Suggested Creators
            </h3>
            <div className="space-y-3">
              {creators.map((c) => (
                <div key={c.uid} className="flex items-center justify-between gap-2">
                  <div
                    onClick={() => {
                      if (!requireAuth('View Creator Profile')) return;
                      setViewedProfileId(c.uid);
                      setActiveScreen('myHearth');
                    }}
                    className="flex items-center gap-2 min-w-0 cursor-pointer"
                  >
                    <img
                      src={c.avatarUrl}
                      alt={c.displayName}
                      className="w-8 h-8 rounded-full object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="font-bold text-xs truncate">{c.displayName}</div>
                      <div className="text-[10px] text-[#52607A] truncate">@{c.username}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggleConnectCreator(c.uid)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold shrink-0 ${
                      c.isConnected ? 'bg-[#EEF3FB] text-[#172033]' : 'fism-btn-primary'
                    }`}
                  >
                    {c.isConnected ? 'Flames' : 'Connect'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="fism-card p-4 fism-gradient-flame text-white space-y-2.5">
            <div className="font-extrabold text-xs flex items-center gap-1.5">
              <Box className="w-4 h-4" /> 3D VR Cinema &amp; 2D Games
            </div>
            <p className="text-[11px] text-white/90">
              Watch any video in stereoscopic 3D VR Headset Mode or play 2D Arcade games in the Game
              Hub!
            </p>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => navigateWithAuthGate('flame3DArena')}
                className="py-1.5 rounded-lg bg-white text-[#101426] text-[11px] font-extrabold"
              >
                🥽 3D VR Cinema
              </button>
              <button
                onClick={() => navigateWithAuthGate('gameHub')}
                className="py-1.5 rounded-lg bg-black/35 text-white text-[11px] font-extrabold border border-white/25"
              >
                🎮 2D Game Hub
              </button>
            </div>
          </div>

          {/* Exact-Size 300x250 Medium Rectangle Ad — Right Desktop Sidebar */}
          <FismBanner300x250Ad
            adsterraConfig={adsterraConfig}
            isAdmin={isPrimaryAdmin}
            onOpenAdConfig={() => setActiveScreen('adminFileVault')}
            officialBannerAds={smartAds}
            onTrackAdClick={(adId) => handleEngageSmartAd(adId, 'click')}
          />
        </aside>
      </div>

      {/* FLOATING AI CHATBOT WIDGET (Click to Open, Long-Press to Dismiss/Hide) */}
      <FismFloatingChatbotWidget
        visible={floatingBotVisible && isAuthenticated}
        onDismiss={() => {
          setFloatingBotVisible(false);
          triggerToast(
            'Floating AI Chatbot hidden! Restore anytime in Control Core -> Smart Settings.',
          );
        }}
        onOpenFullStudio={() => navigateWithAuthGate('aiWorkspaceHub')}
      />

      {/* ============================================================================
          MOBILE FIXED BOTTOM NAVIGATION BAR (STRICTLY 4 MAIN BUTTONS: Home, Shorts, Create (+), Profile)
          ============================================================================ */}
      <nav className="show-mobile-grid-950 fixed bottom-0 inset-x-0 z-40 h-16 bg-white dark:bg-[#101426] border-t-2 border-[#D8E1F0] dark:border-slate-800 px-2 grid-cols-4 items-center">
        {/* Button 1: Home (Flame Feed) */}
        <button
          onClick={() => navigateWithAuthGate('flameFeed')}
          className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-extrabold ${
            activeScreen === 'flameFeed' ? 'text-[#FF5722]' : 'text-[#52607A]'
          }`}
        >
          <Flame className="w-5 h-5" />
          <span className="truncate">Home</span>
        </button>

        {/* Button 2: Shorts (Quick Burst — Always Accessible even in Guest Mode) */}
        <button
          onClick={() => setActiveScreen('quickBurst')}
          className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-extrabold ${
            activeScreen === 'quickBurst' ? 'text-[#FF5722]' : 'text-[#52607A]'
          }`}
        >
          <Zap className="w-5 h-5" />
          <span className="truncate">Shorts</span>
        </button>

        {/* Button 3: Create (+ / Spark New) */}
        <div className="flex items-center justify-center">
          <button
            onClick={() => {
              if (!requireAuth('Create & Upload Video/Post')) return;
              setSparkNewModalOpen(true);
            }}
            aria-label="Create (+)"
            className="px-4 py-2 rounded-2xl fism-gradient-flame text-white flex items-center justify-center gap-1 shadow-[0_6px_20px_rgba(255,87,34,0.55)] font-extrabold text-xs"
          >
            <Plus className="w-5 h-5" />
            <span>Create</span>
          </button>
        </div>

        {/* Button 4: Profile (My Hearth) */}
        <button
          onClick={() => {
            if (!requireAuth('View My Hearth Profile')) return;
            setViewedProfileId(myProfile.uid);
            setActiveScreen('myHearth');
          }}
          className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-extrabold ${
            activeScreen === 'myHearth' ? 'text-[#FF5722]' : 'text-[#52607A]'
          }`}
        >
          <UserIcon className="w-5 h-5" />
          <span className="truncate">Profile</span>
        </button>
      </nav>

      {/* ============================================================================
          MODAL: SCREENSHOT-2 ACCURATE CREATE (+), "ADD" FILE PICKER, CAMERA, GREEN SCREEN & YOUCUT VIDEO EDITOR
          ============================================================================ */}
      <FismCreateCameraYouCutModal
        open={sparkNewModalOpen}
        onClose={() => setSparkNewModalOpen(false)}
        musicTracks={musicTracks}
        selectedMusicTrack={selectedStudioMusicTrack}
        onSelectMusicTrack={(track) => setSelectedStudioMusicTrack(track)}
        onUploadNewMusicTrack={(newTrack) =>
          setMusicTracks((prev) => [newTrack, ...prev])
        }
        greenScreenSourcePost={greenScreenRemixSource}
        onClearGreenScreenSource={() => setGreenScreenRemixSource(null)}
        onSwitchToLiveStream={() => {
          setActiveScreen('onFire');
        }}
        onPublishCreatedMedia={async (payload) => {
          const postId = `post_create_${Date.now()}`;
          let createdGiftDrop: FismGiftDropConfig | undefined;

          if (payload.giftDrop) {
            try {
              const dropRes = await fetch('/api/gift-drops', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  id: `drop_${Date.now()}`,
                  postId,
                  creatorId: activeIdentityUid,
                  creatorUsername: myProfile.username,
                  creatorDisplayName: myProfile.displayName,
                  creatorAvatar: myProfile.avatarUrl,
                  rewardType: payload.giftDrop.rewardType,
                  rewardTitle: payload.giftDrop.rewardTitle,
                  rewardValue: payload.giftDrop.rewardValue,
                  coinsPerWinner: payload.giftDrop.coinsPerWinner,
                  winnerLimit: payload.giftDrop.winnerLimit,
                }),
              });
              const dropData = await dropRes.json();
              if (!dropRes.ok) {
                triggerToast(
                  dropData.error ||
                    'Insufficient coins in your wallet. Purchase a Premium subscription to get 10,000 coins or top up your wallet!',
                );
                return;
              }
              if (dropData.giftDrop) {
                createdGiftDrop = dropData.giftDrop as FismGiftDropConfig;
                upsertGiftDrop(createdGiftDrop);
              }
              if (dropData.wallet) {
                upsertWalletRecord(dropData.wallet);
              }
              if (auth.currentUser?.emailVerified && createdGiftDrop) {
                const safeDropId = createdGiftDrop.id.replace(/[^a-zA-Z0-9_-]/g, '_');
                const safeUid = activeIdentityUid.replace(/[^a-zA-Z0-9_-]/g, '_');
                setDoc(doc(db, 'giftDrops', safeDropId), {
                  ...createdGiftDrop,
                  createdAt: serverTimestamp(),
                }).catch(() => {});
                if (dropData.wallet) {
                  setDoc(doc(db, 'wallets', safeUid), {
                    ...dropData.wallet,
                    updatedAt: serverTimestamp(),
                  }).catch(() => {});
                }
              }
            } catch {
              triggerToast('Unable to create Gift Drop right now.');
              return;
            }
          }

          const mins = Math.floor(payload.durationSec / 60);
          const secs = payload.durationSec % 60;
          const formattedDur = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
          const mappedType: FismPostItem['postType'] =
            payload.targetMode === 'mainBlast'
              ? 'video'
              : payload.targetMode === 'photoPost'
                ? 'photo'
                : 'quickBurst';

          const publishVisibility: 'public' | 'private' =
            activeSubAccount?.privacyMode === 'public' && activeSubAccount?.isAgeVerified
              ? 'public'
              : 'private';

          const newCreatedPost: FismPostItem = {
            id: postId,
            authorId: activeSubAccount?.isMaster
              ? currentUser?.uid || 'local_hearth_user'
              : activeSubAccount?.id || myProfile.uid,
            authorUsername: myProfile.username,
            authorDisplayName: myProfile.displayName,
            authorAvatar: myProfile.avatarUrl,
            authorVerified: Boolean(activeSubAccount?.isAgeVerified),
            postType: mappedType,
            title: payload.title,
            caption: payload.caption,
            mediaUrl: payload.mediaUrl,
            thumbnailUrl: payload.thumbnailUrl,
            aspectRatio: mappedType === 'quickBurst' ? '9:16' : '16:9',
            duration: formattedDur,
            audioTrack: payload.musicTrack
              ? `${payload.musicTrack.title} – ${payload.musicTrack.artist}`
              : `Original Audio – @${myProfile.username}`,
            hashtags: payload.hashtags
              .split(/\s+/)
              .filter((t) => t.startsWith('#'))
              .slice(0, 8),
            location: myProfile.location,
            visibility: publishVisibility,
            allowComments: true,
            sparkCount: 1,
            chatterCount: 0,
            spreadCount: 0,
            viewsCount: globalPremiumOn ? 1_250_000 : 100,
            remixCount: 1,
            isSparked: true,
            isStashed: false,
            createdAt: 'Just now',
            comments: [],
            isRealVideo: payload.isRealVideo,
            generatedMusicUrl: payload.musicTrack?.audioUrl || generatedMusicUrl || undefined,
            isPremiumCreator: globalPremiumOn,
            remixedFromId: payload.remixedFromId,
            remixedFromAuthor: payload.remixedFromAuthor,
            greenScreenBgUrl: payload.greenScreenBgUrl,
            shoppingLinkUrl: payload.shoppingLinkUrl,
            shoppingProductTitle: payload.shoppingProductTitle,
            shoppingProductImage: payload.shoppingProductImage,
            shoppingStoreName: payload.shoppingStoreName,
            affiliateKeywords: payload.affiliateKeywords,
            is3DVrVideo: payload.is3DVrVideo,
            connectedVideo: payload.connectedVideo,
            taggedCollaborators: payload.taggedCollaborators,
            giftDropId: createdGiftDrop?.id,
            giftDrop: createdGiftDrop,
            has_gift_drop: Boolean(createdGiftDrop),
            algorithmBoostTier: userMilestone.currentTier,
            authorHasRedTick: userMilestone.hasRedMilestoneTick,
            authorVipGoldBadge: userMilestone.vipGoldBadgeUnlocked,
          };

          if (!activeSubAccount?.isAgeVerified) {
            triggerToast(
              '🔒 Published as Private (18+ Aadhaar / Gov ID verification required for Public publishing).',
            );
          }

          setPosts((prev) => [newCreatedPost, ...prev]);
          setSparkNewModalOpen(false);
          setGreenScreenRemixSource(null);
          void persistPostToFirestore(newCreatedPost);

          if (payload.taggedCollaborators && payload.taggedCollaborators.length > 0) {
            payload.taggedCollaborators.forEach((tc) => {
              dispatchRealtimeNotification({
                id: `notif_collab_${Date.now()}_${tc.uid}`,
                actorId: activeIdentityUid,
                actorName: myProfile.displayName,
                actorAvatar: myProfile.avatarUrl,
                notificationType: 'collab_tag',
                message: `invited @${tc.username} to collaborate on "${payload.title}"! Click Accept Collaboration to show on both channels.`,
                createdAt: 'Real-Time • Just now',
                isRead: false,
                targetScreen: 'warmSparks',
                targetPostId: postId,
                targetUid: tc.uid,
                collabStatus: 'pending',
              });
            });
          }

          if (mappedType === 'quickBurst' || mappedType === 'video') {
            const flagged = await runCopyrightScanForPost(newCreatedPost);
            if (flagged) {
              setViewedProfileId(myProfile.uid);
              setActiveScreen('myHearth');
              return;
            }
          }

          if (payload.is3DVrVideo) {
            setVrCinemaVideoUrl(payload.mediaUrl);
            setVrCinemaVideoTitle(payload.title);
          }

          const dropToastSuffix = createdGiftDrop
            ? ` + 🎁 Gift Drop (${createdGiftDrop.winnerLimit} winners)`
            : '';

          if (mappedType === 'quickBurst') {
            setActiveQuickBurstIndex(0);
            setQuickBurstPlaying(true);
            setActiveScreen('quickBurst');
            triggerToast(
              `✅ Short "${payload.title}" uploaded to Quick Burst${dropToastSuffix}${
                payload.shoppingProductImage ? ' with AI-Verified Shopping Photo in corner!' : '!'
              }`,
            );
          } else if (mappedType === 'video') {
            setSelectedVideoPost(newCreatedPost);
            setVideoPlaying(true);
            setActiveScreen('mainBlast');
            triggerToast(
              `✅ Video "${payload.title}" uploaded to Main Blast${dropToastSuffix}${
                payload.shoppingLinkUrl ? ' with AI-Verified Shopping Link in description!' : '!'
              }`,
            );
          } else {
            setActiveScreen('flameFeed');
            triggerToast(`✅ Photo Post "${payload.title}" published${dropToastSuffix}!`);
          }
        }}
        aiMusicPrompt={aiMusicPrompt}
        setAiMusicPrompt={setAiMusicPrompt}
        aiMusicGenerating={aiMusicGenerating}
        onGenerateAiMusicAndCover={handleGenerateMusicAndCoverPhoto}
        generatedMusicUrl={generatedMusicUrl}
        generatedMusicCover={generatedMusicCover}
        onUploadAiMusicToChannel={handleUploadMusicAndPhotoToChannel}
        currentUsername={myProfile.username}
        onTriggerToast={triggerToast}
        userSparksCount={myProfile.sparksCount}
        shoppingProducts={shoppingProducts}
        publishedArFilters={publishedArFilters}
        publishedStudioFilters={publishedStudioFilters}
        userCoinBalance={myWallet.coinBalance}
        userVideos={posts.filter(
          (p) =>
            (p.postType === 'video' || p.postType === 'quickBurst') &&
            (p.authorId === activeIdentityUid ||
              p.authorId === myProfile.uid ||
              p.authorId === 'local_hearth_user'),
        )}
        availableUsers={[
          ...creators.map((c) => ({
            uid: c.uid,
            username: c.username,
            displayName: c.displayName,
            avatarUrl: c.avatarUrl,
          })),
          ...adminUserDossiers.map((d) => ({
            uid: d.uid,
            username: d.username,
            displayName: d.displayName,
            avatarUrl: d.avatarUrl,
          })),
        ].filter(
          (u, idx, arr) =>
            u.uid !== activeIdentityUid &&
            arr.findIndex((x) => x.uid === u.uid) === idx,
        )}
        onOpenWalletOrPremium={() => {
          setSparkNewModalOpen(false);
          setActiveScreen('coinLeaderboard');
        }}
      />

      {/* ============================================================================
          MODAL: REAL LOGIN SCENE (1. EMAIL & PASSWORD LOGIN, 2. DIRECT GOOGLE LOGIN, OR "NOTHING LOGIN" GUEST MODE)
          ============================================================================ */}
      {loginGatePromptOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="fism-card max-w-md w-full p-6 space-y-4 border border-[#D8E1F0] dark:border-slate-700 shadow-2xl my-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-11 h-11 rounded-2xl fism-gradient-flame text-white flex items-center justify-center shadow-lg">
                  <Flame className="w-6 h-6 fill-white" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base sm:text-lg text-[#0B1120] dark:text-white">
                    Welcome to FISM
                  </h3>
                  <p className="text-[11px] text-[#52607A] dark:text-slate-400">
                    {blockedActionName
                      ? `Action "${blockedActionName}" requires Sign In`
                      : 'Sign in with Email & Password or Direct Google Login'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                aria-label="Close login modal"
                onClick={() => setLoginGatePromptOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-[#0B1120] dark:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold">
                {authError}
              </div>
            )}

            {/* OPTION 1: EMAIL & PASSWORD LOGIN / SIGN UP */}
            <form onSubmit={handleEmailPasswordLogin} className="space-y-2.5">
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-[#FF5722]">
                Email &amp; Password Login / Sign Up
              </div>
              <input
                type="email"
                value={loginEmailInput}
                onChange={(e) => setLoginEmailInput(e.target.value)}
                placeholder="Enter your Email ID..."
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm font-semibold text-[#0B1120] dark:text-white"
              />
              <input
                type="password"
                value={loginPasswordInput}
                onChange={(e) => setLoginPasswordInput(e.target.value)}
                placeholder="Enter Password (min 4 chars)..."
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm font-semibold text-[#0B1120] dark:text-white"
              />
              <button
                type="submit"
                className="w-full min-h-[44px] fism-btn-primary py-2.5 rounded-xl text-xs sm:text-sm font-extrabold shadow-md cursor-pointer"
              >
                🔐 Login / Sign Up with Email
              </button>
            </form>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-[#D8E1F0] dark:border-slate-700" />
              <span className="flex-shrink mx-3 text-[11px] font-bold text-[#52607A] dark:text-slate-400">
                OR
              </span>
              <div className="flex-grow border-t border-[#D8E1F0] dark:border-slate-700" />
            </div>

            {/* OPTION 2: DIRECT GOOGLE LOGIN */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 shadow-md cursor-pointer"
              >
                <Globe className="w-4 h-4" /> Continue with Google
              </button>
            </div>

            {/* OPTION 3: "NOTHING LOGIN" (CONTINUE AS GUEST — SHORTS WATCHING ONLY) */}
            <div className="pt-2 border-t border-[#D8E1F0] dark:border-slate-800 space-y-2">
              <button
                type="button"
                onClick={handleNothingLoginGuestMode}
                className="w-full min-h-[44px] py-2.5 px-3 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-extrabold text-[#52607A] dark:text-slate-300 cursor-pointer"
              >
                👀 Nothing Login (Continue as Guest — Watch Quick Burst Only)
              </button>
              <p className="text-[11px] text-[#52607A] dark:text-slate-400 text-center leading-relaxed">
                Guests can watch <strong>Quick Burst (Shorts)</strong> only. Likes, Comments,
                Shares, Purchases &amp; Uploads require an account.
              </p>
            </div>

            {/* BOTTOM LEGAL AGREEMENT CHECKBOX & TERMS / PRIVACY LINK */}
            <div className="pt-3 border-t border-[#D8E1F0] dark:border-slate-800 space-y-2.5">
              <label className="flex items-start gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={loginAgreeLegal}
                  onChange={(e) => {
                    setLoginAgreeLegal(e.target.checked);
                    if (e.target.checked) setAuthError(null);
                  }}
                  className="mt-0.5 w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB] focus:ring-[#2563EB] cursor-pointer"
                />
                <span className="text-xs font-semibold text-[#334155] dark:text-slate-300 leading-snug">
                  I agree to the Terms of Service &amp; Privacy Policy
                </span>
              </label>

              <p className="text-xs text-center text-[#334155] dark:text-slate-300 leading-relaxed bg-[#F8FAFC] dark:bg-[#0F172A] px-3 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-800">
                This is our{' '}
                <button
                  type="button"
                  onClick={() =>
                    setLegalDocsModalState({ open: true, returnLabel: 'Back to Login' })
                  }
                  className="font-extrabold text-[#2563EB] dark:text-[#3B82F6] hover:underline cursor-pointer inline"
                >
                  Terms of Service &amp; Privacy Policy
                </button>
                .{' '}
                <button
                  type="button"
                  onClick={() =>
                    setLegalDocsModalState({ open: true, returnLabel: 'Back to Login' })
                  }
                  className="font-extrabold text-[#2563EB] dark:text-[#3B82F6] hover:underline cursor-pointer inline"
                >
                  Click and Read
                </button>
              </p>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: EMOJI BLAST MINI-GAME (Triggered by Long-Pressing a Chat Message) */}
      {emojiGameActiveEmoji && (
        <FismEmojiBlastGameModal
          emoji={emojiGameActiveEmoji}
          onClose={() => setEmojiGameActiveEmoji(null)}
        />
      )}

      {/* MODAL: AUDIO / VIDEO CALLING */}
      {activeCallInfo && (
        <FismCallModal
          targetName={activeCallInfo.name}
          targetAvatar={activeCallInfo.avatar}
          targetPhone={activeCallInfo.phone}
          mode={activeCallInfo.mode}
          publishedArFilters={publishedArFilters}
          onClose={() => setActiveCallInfo(null)}
        />
      )}

      {/* MODAL: FULL-SCREEN STORY VIEWER */}
      {activeStoryIndex !== null && stories[activeStoryIndex] && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4">
          <div className="relative max-w-md w-full aspect-[9/16] max-h-[88vh] rounded-2xl overflow-hidden bg-[#0F172A] border border-slate-700 flex flex-col justify-between">
            <img
              src={stories[activeStoryIndex].mediaUrl}
              alt={stories[activeStoryIndex].displayName}
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-transparent to-black/85" />

            <div className="relative z-10 p-4 space-y-2 text-white">
              <div className="h-1 w-full bg-white/30 rounded-full overflow-hidden">
                <div className={`h-full bg-[#FF5722] ${storyPaused ? 'w-1/2' : 'w-full'}`} />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <img
                    src={stories[activeStoryIndex].avatarUrl}
                    alt={stories[activeStoryIndex].displayName}
                    className="w-9 h-9 rounded-full object-cover ring-2 ring-[#FF5722]"
                  />
                  <div>
                    <div className="font-bold text-sm">
                      {stories[activeStoryIndex].displayName}
                    </div>
                    <div className="text-[11px] text-slate-300">
                      {stories[activeStoryIndex].createdAt}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setStoryPaused((p) => !p)}
                    className="p-1.5 rounded-lg bg-black/50"
                  >
                    {storyPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => setActiveStoryIndex(null)}
                    className="p-1.5 rounded-lg bg-black/50"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="relative z-10 flex items-center justify-between px-2">
              <button
                onClick={() =>
                  setActiveStoryIndex((i) =>
                    i !== null && i > 0 ? i - 1 : stories.length - 1,
                  )
                }
                className="p-2 rounded-full bg-black/50 text-white"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() =>
                  setActiveStoryIndex((i) =>
                    i !== null && i < stories.length - 1 ? i + 1 : null,
                  )
                }
                className="p-2 rounded-full bg-black/50 text-white"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            <div className="relative z-10 p-4 space-y-3 text-white">
              <p className="text-sm font-medium">{stories[activeStoryIndex].caption}</p>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={storyReplyText}
                  onChange={(e) => setStoryReplyText(e.target.value)}
                  placeholder="Reply to story..."
                  className="flex-1 px-3.5 py-2 rounded-xl bg-black/60 border border-white/30 text-xs text-white"
                />
                <button
                  onClick={() => {
                    if (!storyReplyText.trim()) return;
                    setStoryReplyText('');
                    triggerToast('Story reply sent to Ember Chat!');
                  }}
                  className="fism-btn-primary px-3.5 py-2 rounded-xl text-xs font-bold"
                >
                  Reply
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: SPREAD (SHARE) */}
      {activeSpreadPost && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="fism-card max-w-md w-full p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base flex items-center gap-2">
                <Share2 className="w-5 h-5 text-[#7C3AED]" /> Spread across FISM
              </h3>
              <button onClick={() => setActiveSpreadPost(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-3 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-mono break-all">
              {buildFismShareUrl(
                activeSpreadPost.postType === 'quickBurst'
                  ? 'burst'
                  : activeSpreadPost.postType === 'video'
                    ? 'video'
                    : 'post',
                activeSpreadPost.id,
              )}
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => {
                  if (!requireAuth('Repost to Flame Feed')) return;
                  setPosts((prev) =>
                    prev.map((p) =>
                      p.id === activeSpreadPost.id
                        ? { ...p, spreadCount: p.spreadCount + 1 }
                        : p,
                    ),
                  );
                  setActiveSpreadPost(null);
                  triggerToast('Reposted to your Flame Feed!');
                }}
                className="p-3 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
              >
                Repost to Flame Feed
              </button>
              <button
                onClick={() => {
                  const kind =
                    activeSpreadPost.postType === 'quickBurst'
                      ? 'burst'
                      : activeSpreadPost.postType === 'video'
                        ? 'video'
                        : 'post';
                  const shareUrl = buildFismShareUrl(kind, activeSpreadPost.id);
                  void shareFismLink({
                    title: activeSpreadPost.title,
                    text: activeSpreadPost.caption || `Check out ${activeSpreadPost.title} on FISM`,
                    url: shareUrl,
                    triggerToast,
                  });
                  setPosts((prev) =>
                    prev.map((p) =>
                      p.id === activeSpreadPost.id
                        ? { ...p, spreadCount: p.spreadCount + 1 }
                        : p,
                    ),
                  );
                  setActiveSpreadPost(null);
                }}
                className="p-3 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold"
              >
                Share / Copy App Link (Guest OK)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: SMOTHER (REPORT) */}
      {smotherTarget && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="fism-card max-w-md w-full p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base flex items-center gap-2 text-[#F59E0B]">
                <Flag className="w-5 h-5" /> Smother — Report {smotherTarget.type}
              </h3>
              <button onClick={() => setSmotherTarget(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <select
              value={smotherReason}
              onChange={(e) => setSmotherReason(e.target.value as FismReportItem['reason'])}
              aria-label="Report reason"
              className="w-full px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
            >
              <option value="Spam">Spam</option>
              <option value="Harassment">Harassment</option>
              <option value="Hate Speech">Hate Speech</option>
              <option value="Inappropriate Content">Inappropriate Content</option>
            </select>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setSmotherTarget(null)}
                className="px-4 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitSmotherReport}
                className="px-4 py-2 rounded-xl bg-[#F59E0B] text-white text-xs font-bold"
              >
                Submit Smother Report
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: EXTINGUISH (BLOCK / MUTE) */}
      {extinguishTargetCreator && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="fism-card max-w-md w-full p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base flex items-center gap-2 text-[#DC2626]">
                <Ban className="w-5 h-5" /> Extinguish @{extinguishTargetCreator.username}
              </h3>
              <button onClick={() => setExtinguishTargetCreator(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => handleExtinguishUser(extinguishTargetCreator, 'mute')}
                className="px-4 py-2 rounded-xl bg-[#F59E0B] text-white text-xs font-bold"
              >
                Mute Creator
              </button>
              <button
                onClick={() => handleExtinguishUser(extinguishTargetCreator, 'block')}
                className="px-4 py-2 rounded-xl bg-[#DC2626] text-white text-xs font-bold"
              >
                Extinguish (Block)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: EDIT POST */}
      {editingPost && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="fism-card max-w-lg w-full p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base">Edit Post</h3>
              <button onClick={() => setEditingPost(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <input
              type="text"
              value={editingPost.title}
              onChange={(e) => setEditingPost({ ...editingPost, title: e.target.value })}
              className="w-full px-3.5 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm font-bold"
            />
            <textarea
              rows={3}
              value={editingPost.caption}
              onChange={(e) => setEditingPost({ ...editingPost, caption: e.target.value })}
              className="w-full p-3 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setEditingPost(null)}
                className="px-4 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setPosts((prev) =>
                    prev.map((p) => (p.id === editingPost.id ? editingPost : p)),
                  );
                  setEditingPost(null);
                  triggerToast('Post updated!');
                }}
                className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-bold"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: EDIT MY HEARTH PROFILE (Profile Photo File Upload, Cover Banner File Upload, Name, @Username, Unlimited 1000-2000+ Word Bio, and Up to 4 Categories) */}
      {editProfileModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto">
          <div className="fism-card max-w-2xl w-full p-5 sm:p-6 space-y-4 my-8 border-2 border-[#FF5722] max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#D8E1F0] dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-extrabold text-base sm:text-lg flex items-center gap-2">
                  <Edit3 className="w-5 h-5 text-[#FF5722]" /> Edit My Hearth Profile
                </h3>
                <p className="text-xs text-[#52607A]">
                  Customize your Profile Picture, Banner, Name, @Username, Unlimited Channel
                  Description (1,000–2,000+ words), and up to 4 Categories!
                </p>
              </div>
              <button
                onClick={() => setEditProfileModalOpen(false)}
                className="p-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 1. Profile Picture & Cover Banner Direct File Pickers */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 flex items-center gap-3">
                <img
                  src={myProfile.avatarUrl}
                  alt="Avatar Preview"
                  className="w-16 h-16 rounded-2xl object-cover ring-2 ring-[#FF5722] shrink-0"
                />
                <div className="space-y-1.5">
                  <div className="text-xs font-extrabold">Profile Picture (प्रोफाइल फोटो)</div>
                  <label className="px-3 py-1.5 rounded-xl bg-[#FF5722] text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow">
                    <Upload className="w-3.5 h-3.5" /> Open File / Select Photo
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = () => {
                          if (typeof reader.result === 'string') {
                            setMyProfile((prev) => ({ ...prev, avatarUrl: reader.result as string }));
                            triggerToast('✅ Profile picture loaded from your file!');
                          }
                        };
                        reader.readAsDataURL(file);
                      }}
                    />
                  </label>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 flex items-center gap-3">
                <img
                  src={myProfile.coverUrl}
                  alt="Banner Preview"
                  className="w-20 h-16 rounded-xl object-cover ring-2 ring-[#7C3AED] shrink-0"
                />
                <div className="space-y-1.5">
                  <div className="text-xs font-extrabold">Profile Banner (बैनर फोटो)</div>
                  <label className="px-3 py-1.5 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer shadow">
                    <ImageIcon className="w-3.5 h-3.5" /> Open File / Select Banner
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = () => {
                          if (typeof reader.result === 'string') {
                            setMyProfile((prev) => ({ ...prev, coverUrl: reader.result as string }));
                            triggerToast('✅ Profile cover banner loaded from your file!');
                          }
                        };
                        reader.readAsDataURL(file);
                      }}
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* 2. Display Name, Independent @Username & Account Privacy Mode */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-extrabold mb-1">
                  Display Name (आपका नाम)
                </label>
                <input
                  type="text"
                  value={myProfile.displayName}
                  onChange={(e) => setMyProfile({ ...myProfile, displayName: e.target.value })}
                  placeholder="Enter your Display Name..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-extrabold mb-1 text-[#2563EB] flex items-center gap-1">
                  @Username (Isolated to this ID Only)
                </label>
                <input
                  type="text"
                  value={myProfile.username}
                  onChange={(e) =>
                    setMyProfile({
                      ...myProfile,
                      username: e.target.value.replace(/^@+/, '').replace(/\s+/g, '_').toLowerCase(),
                    })
                  }
                  placeholder="unique_username"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm font-mono font-extrabold"
                />
              </div>
            </div>

            {/* Privacy Mode Selector (Public requires 18+ Aadhaar Vision Verification) */}
            <div className="p-3.5 rounded-xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 flex items-center justify-between flex-wrap gap-3">
              <div>
                <div className="text-xs font-extrabold flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#FF5722]" /> Account Privacy Mode (Isolated)
                </div>
                <div className="text-[11px] text-[#52607A]">
                  {activeSubAccount?.isAgeVerified
                    ? '✓ 18+ Aadhaar Verified — Public & Private modes unlocked.'
                    : '🔒 18+ Vision ID required before switching to Public mode.'}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setMyProfile((prev) => ({ ...prev, isPrivate: true }))}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold ${
                    myProfile.isPrivate
                      ? 'bg-[#D97706] text-white'
                      : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A]'
                  }`}
                >
                  🔒 Private
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!activeSubAccount?.isAgeVerified) {
                      triggerToast(
                        '🔒 18+ Aadhaar / Government ID Vision verification is required for Public accounts.',
                      );
                      return;
                    }
                    setMyProfile((prev) => ({ ...prev, isPrivate: false }));
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold ${
                    !myProfile.isPrivate
                      ? 'bg-[#16A34A] text-white'
                      : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A]'
                  }`}
                >
                  🌐 Public
                </button>
              </div>
            </div>

            {/* 3. Unlimited Channel Detail / Bio (1,000–2,000+ words supported) */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-extrabold">
                  Channel Detail / Bio (1,000–2,000+ Words Supported • Shows 2 Lines + &quot;More&quot; on Profile)
                </label>
                <span className="text-[11px] font-mono text-[#52607A]">
                  {myProfile.bio.trim() ? myProfile.bio.trim().split(/\s+/).length : 0} words
                </span>
              </div>
              <textarea
                rows={4}
                value={myProfile.bio}
                onChange={(e) => setMyProfile({ ...myProfile, bio: e.target.value })}
                placeholder="Write your full Channel Detail / Bio (up to 1,000–2,000+ words)..."
                className="w-full p-3 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm leading-relaxed"
              />
            </div>

            {/* 4. Choose Your Category (Up to 4 Categories Selectable at Once) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-extrabold text-[#7C3AED]">
                  Choose Your Category — Select Up to 4 Categories ({(myProfile.categories || []).length}/4 Selected)
                </label>
                {(myProfile.categories || []).length > 0 && (
                  <button
                    type="button"
                    onClick={() => setMyProfile({ ...myProfile, categories: [] })}
                    className="text-[11px] font-bold text-[#DC2626] hover:underline"
                  >
                    Clear Categories
                  </button>
                )}
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto p-2.5 rounded-xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800">
                {FISM_PROFILE_CATEGORIES.map((cat) => {
                  const selectedList = myProfile.categories || [];
                  const isSelected = selectedList.includes(cat);
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => {
                        if (isSelected) {
                          setMyProfile({
                            ...myProfile,
                            categories: selectedList.filter((item) => item !== cat),
                          });
                        } else {
                          if (selectedList.length >= 4) {
                            triggerToast('You can select up to 4 categories at once!');
                            return;
                          }
                          setMyProfile({
                            ...myProfile,
                            categories: [...selectedList, cat],
                          });
                        }
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all ${
                        isSelected
                          ? 'bg-[#7C3AED] text-white shadow ring-2 ring-[#FF5722]'
                          : 'bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-[#151B2B] dark:text-slate-200 hover:border-[#7C3AED]'
                      }`}
                    >
                      {isSelected ? `✓ ${cat}` : cat}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#D8E1F0] dark:border-slate-800">
              <button
                onClick={() => setEditProfileModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  const targetId = activeSubAccount?.id || 'acc_1';
                  const cleanUsername = (myProfile.username || 'flame_pioneer')
                    .replace(/^@+/, '')
                    .replace(/\s+/g, '_')
                    .toLowerCase();
                  const desiredPrivacy: FismAccountPrivacyMode =
                    !myProfile.isPrivate && activeSubAccount?.isAgeVerified ? 'public' : 'private';
                  try {
                    const res = await fetch(
                      `/api/accounts/sub-ids/${encodeURIComponent(targetId)}`,
                      {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          username: cleanUsername,
                          displayName: myProfile.displayName,
                          bio: myProfile.bio,
                          avatarUrl: myProfile.avatarUrl,
                          coverUrl: myProfile.coverUrl,
                          categories: myProfile.categories || [],
                          privacyMode: desiredPrivacy,
                        }),
                      },
                    );
                    const data = await res.json();
                    if (!res.ok) {
                      triggerToast(data.error || 'Unable to save isolated profile changes.');
                      return;
                    }
                    const updated = data.account as FismSubAccount;
                    saveSubAccountsToStorage(
                      subAccounts.map((a) => (a.id === updated.id ? updated : a)),
                    );
                    setMyProfile((prev) => ({
                      ...prev,
                      username: updated.username,
                      displayName: updated.displayName,
                      bio: updated.bio ?? prev.bio,
                      avatarUrl: updated.avatarUrl,
                      coverUrl: updated.coverUrl ?? prev.coverUrl,
                      categories: updated.categories ?? prev.categories,
                      isPrivate: updated.privacyMode === 'private',
                    }));
                    setEditProfileModalOpen(false);
                    recordUserActivity(
                      'Updated Isolated Profile',
                      `Saved @${updated.username} (${updated.privacyMode}) without affecting other Sub-IDs`,
                    );
                    triggerToast(
                      `✅ Isolated profile @${updated.username} saved! Other Sub-IDs remain untouched.`,
                    );
                  } catch {
                    triggerToast('Network error saving profile.');
                  }
                }}
                className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold shadow-lg"
              >
                Save My Hearth
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: SPARKS / FLAMES / FUELERS LIST */}
      {profileModalList && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="fism-card max-w-md w-full p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base">{profileModalList}</h3>
              <button onClick={() => setProfileModalList(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-2.5">
              {creators.map((c) => (
                <div key={c.uid} className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={c.avatarUrl}
                      alt={c.displayName}
                      className="w-9 h-9 rounded-full object-cover"
                    />
                    <div>
                      <div className="font-bold text-xs">{c.displayName}</div>
                      <div className="text-[11px] text-[#52607A]">@{c.username}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggleConnectCreator(c.uid)}
                    className="px-3 py-1 rounded-lg fism-btn-primary text-xs font-bold"
                  >
                    {c.isConnected ? 'Flames' : 'Connect'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ============================================================================
          SCREEN-BLOCKING USER SURVEY MODAL (Launched from Admin File Survey Builder)
          ============================================================================ */}
      {activeSurveyCampaign &&
        activeSurveyCampaign.isActive &&
        !dismissedSurveyIds.includes(activeSurveyCampaign.id) && (
          <div className="fixed inset-0 z-[90] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
            <div className="fism-card max-w-xl w-full p-6 space-y-5 border-2 border-[#2563EB] shadow-2xl my-8 max-h-[90vh] overflow-y-auto">
              <div className="flex items-start justify-between gap-3 border-b border-[#D8E1F0] dark:border-slate-800 pb-3">
                <div>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#2563EB] text-white text-[10px] font-extrabold uppercase">
                    Official FISM Live Survey
                  </span>
                  <h3 className="text-lg sm:text-xl font-extrabold mt-1">
                    {activeSurveyCampaign.title}
                  </h3>
                  <p className="text-xs text-[#52607A]">
                    Please answer the survey below. Selecting <strong>More / Other</strong> opens a
                    textbox where you can write your own response!
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                {activeSurveyCampaign.questions.map((q, qIdx) => {
                  const currentAns = surveyAnswersDraft[q.id] || {
                    selectedOption: q.options[0] || '',
                    customMoreText: '',
                  };
                  const isMoreSelected = currentAns.selectedOption === 'More / Other';

                  return (
                    <div
                      key={q.id}
                      className="p-4 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-2.5"
                    >
                      <div className="font-extrabold text-sm">
                        Q{qIdx + 1}. {q.questionText}
                      </div>

                      <div className="grid grid-cols-1 gap-2">
                        {q.options.map((opt, optIdx) => {
                          const chosen = currentAns.selectedOption === opt;
                          return (
                            <button
                              key={optIdx}
                              type="button"
                              onClick={() =>
                                setSurveyAnswersDraft((prev) => ({
                                  ...prev,
                                  [q.id]: {
                                    ...currentAns,
                                    selectedOption: opt,
                                  },
                                }))
                              }
                              className={`p-3 rounded-xl border text-left text-xs font-extrabold flex items-center justify-between transition-all ${
                                chosen
                                  ? 'border-[#2563EB] bg-[#2563EB] text-white shadow'
                                  : 'border-[#D8E1F0] dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-[#2563EB]'
                              }`}
                            >
                              <span>
                                {optIdx + 1}. {opt}
                              </span>
                              {chosen && <CheckCircle2 className="w-4 h-4 shrink-0" />}
                            </button>
                          );
                        })}

                        {/* Locked 4th/Last Option: More / Other (Opens Custom Textbox) */}
                        <button
                          type="button"
                          onClick={() =>
                            setSurveyAnswersDraft((prev) => ({
                              ...prev,
                              [q.id]: {
                                ...currentAns,
                                selectedOption: 'More / Other',
                              },
                            }))
                          }
                          className={`p-3 rounded-xl border text-left text-xs font-extrabold flex items-center justify-between transition-all ${
                            isMoreSelected
                              ? 'border-[#FF5722] bg-[#FF5722] text-white shadow'
                              : 'border-[#FF5722]/50 bg-orange-500/10 text-[#FF5722] hover:bg-orange-500/20'
                          }`}
                        >
                          <span>
                            {q.options.length + 1}. More / Other (अपना खुद का जवाब लिखें)
                          </span>
                          {isMoreSelected && <CheckCircle2 className="w-4 h-4 shrink-0" />}
                        </button>
                      </div>

                      {/* Custom Textbox when user clicks "More / Other" */}
                      {isMoreSelected && (
                        <div className="pt-2 space-y-1.5">
                          <label className="block text-xs font-extrabold text-[#FF5722]">
                            ✍️ Write Your Answer / Review (अपना जवाब यहाँ लिखें):
                          </label>
                          <textarea
                            rows={2}
                            value={currentAns.customMoreText}
                            onChange={(e) =>
                              setSurveyAnswersDraft((prev) => ({
                                ...prev,
                                [q.id]: {
                                  ...currentAns,
                                  selectedOption: 'More / Other',
                                  customMoreText: e.target.value,
                                },
                              }))
                            }
                            placeholder="Type your custom response here and click Send below..."
                            className="w-full p-3 rounded-xl bg-white dark:bg-slate-800 border-2 border-[#FF5722] text-xs font-semibold focus:outline-none"
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between flex-wrap gap-3 pt-2 border-t border-[#D8E1F0] dark:border-slate-800">
                <label className="flex items-center gap-2 text-xs font-bold text-[#52607A] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={dontShowSurveyAgain}
                    onChange={(e) => setDontShowSurveyAgain(e.target.checked)}
                    className="rounded accent-[#2563EB]"
                  />
                  <span>Don&apos;t show this survey again after submitting</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const nextDismissed = [...dismissedSurveyIds, activeSurveyCampaign.id];
                      setDismissedSurveyIds(nextDismissed);
                      try {
                        localStorage.setItem(
                          'fism_dismissed_surveys',
                          JSON.stringify(nextDismissed),
                        );
                      } catch {
                        // ignore
                      }
                      triggerToast('Survey dismissed • Will not show again.');
                    }}
                    className="px-3.5 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold text-[#52607A]"
                  >
                    Don&apos;t Show Again
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const submission: FismSurveySubmission = {
                        id: `sub_${Date.now()}`,
                        surveyId: activeSurveyCampaign.id,
                        userId: myProfile.uid,
                        username: myProfile.username,
                        displayName: myProfile.displayName,
                        userEmail: currentUser?.email || loginEmailInput || primaryEmail,
                        ipAddress: clientRealTimeIp,
                        submittedAt: new Date().toLocaleString(),
                        answers: activeSurveyCampaign.questions.map((q) => {
                          const draft = surveyAnswersDraft[q.id];
                          return {
                            questionId: q.id,
                            questionText: q.questionText,
                            selectedOption: draft?.selectedOption || q.options[0] || 'Option 1',
                            customMoreText:
                              draft?.selectedOption === 'More / Other'
                                ? draft.customMoreText.trim()
                                : undefined,
                          };
                        }),
                      };

                      const nextSubs = [submission, ...surveySubmissions];
                      setSurveySubmissions(nextSubs);
                      try {
                        localStorage.setItem('fism_survey_submissions', JSON.stringify(nextSubs));
                      } catch {
                        // ignore
                      }

                      if (dontShowSurveyAgain) {
                        const nextDismissed = [...dismissedSurveyIds, activeSurveyCampaign.id];
                        setDismissedSurveyIds(nextDismissed);
                        try {
                          localStorage.setItem(
                            'fism_dismissed_surveys',
                            JSON.stringify(nextDismissed),
                          );
                        } catch {
                          // ignore
                        }
                      } else {
                        setActiveSurveyCampaign((prev) =>
                          prev ? { ...prev, isActive: false } : null,
                        );
                      }

                      recordUserActivity(
                        `Submitted Survey: ${activeSurveyCampaign.title}`,
                        'User review saved to Admin File Survey Data Board',
                      );
                      triggerToast(
                        '✅ Survey response sent! Saved to Admin File Survey Data Board (Leaderboard).',
                      );
                    }}
                    className="fism-btn-primary px-6 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-lg"
                  >
                    <Send className="w-4 h-4" /> Send Survey Response
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      {/* MULTI-FOLLOW CREATORS MODAL FOR COLLABORATION POSTS */}
      {collabFollowTargetPost && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="fism-card max-w-md w-full p-5 space-y-4 border-2 border-[#7C3AED] shadow-2xl">
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-extrabold text-base flex items-center gap-2">
                <Users className="w-5 h-5 text-[#7C3AED]" /> Follow Collab Creators
              </h3>
              <button
                type="button"
                onClick={() => setCollabFollowTargetPost(null)}
                className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-[#52607A]">
              Connect with the creators collaborating on{' '}
              <strong>&quot;{collabFollowTargetPost.title}&quot;</strong> individually or follow
              all together:
            </p>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {[
                {
                  uid: collabFollowTargetPost.authorId,
                  username: collabFollowTargetPost.authorUsername,
                  displayName: collabFollowTargetPost.authorDisplayName,
                  avatarUrl: collabFollowTargetPost.authorAvatar,
                  role: 'Uploader',
                },
                ...(collabFollowTargetPost.taggedCollaborators || [])
                  .filter((tc) => tc.status === 'accepted')
                  .map((tc) => ({
                    uid: tc.uid,
                    username: tc.username,
                    displayName: tc.displayName,
                    avatarUrl: tc.avatarUrl,
                    role: 'Collaborator',
                  })),
              ].map((person) => {
                const isSelf =
                  person.uid === activeIdentityUid || person.uid === myProfile.uid;
                const matchedCreator = creators.find((c) => c.uid === person.uid);
                const isFollowed = Boolean(matchedCreator?.isConnected);
                return (
                  <div
                    key={person.uid}
                    className="p-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between gap-2.5"
                  >
                    <div
                      onClick={() => {
                        setViewedProfileId(person.uid);
                        setActiveScreen('myHearth');
                        setCollabFollowTargetPost(null);
                      }}
                      className="flex items-center gap-2.5 min-w-0 cursor-pointer"
                    >
                      <img
                        src={person.avatarUrl}
                        alt={person.displayName}
                        className="w-9 h-9 rounded-full object-cover shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="text-xs font-extrabold truncate">
                          {person.displayName}
                        </div>
                        <div className="text-[11px] text-[#52607A] truncate">
                          @{person.username} · {person.role}
                        </div>
                      </div>
                    </div>
                    {!isSelf && (
                      <button
                        type="button"
                        onClick={() => {
                          if (!matchedCreator) {
                            setCreators((prev) => [
                              ...prev,
                              {
                                uid: person.uid,
                                username: person.username,
                                displayName: person.displayName,
                                bio: 'FISM Collaborator Creator',
                                avatarUrl: person.avatarUrl,
                                coverUrl: GENERATED_ASSETS.heroCover,
                                location: 'FISM Network',
                                website: '',
                                isVerified: true,
                                isPrivate: false,
                                sparksCount: 1,
                                flamesCount: 1,
                                fuelersCount: 0,
                                monthlyPrice: 4.99,
                                isConnected: true,
                              },
                            ]);
                            triggerToast(`Connected with ${person.displayName}`);
                          } else {
                            handleToggleConnectCreator(person.uid);
                          }
                        }}
                        className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-extrabold shrink-0 ${
                          isFollowed
                            ? 'bg-emerald-500/15 text-[#16A34A] border border-[#16A34A]/40'
                            : 'fism-btn-primary'
                        }`}
                      >
                        {isFollowed ? 'Flames ✓' : 'Follow'}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
            <button
              type="button"
              onClick={() => handleFollowAllCreatorsForPost(collabFollowTargetPost)}
              className="min-h-[44px] w-full py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#FF5722] text-white text-xs font-extrabold shadow-lg"
            >
              🔥 Follow All Together
            </button>
          </div>
        </div>
      )}

      {/* SUB-ID PASSWORD VERIFICATION MODAL */}
      <FismSubIdPasswordModal
        targetAccount={subIdSwitchTarget}
        verifying={subIdSwitching}
        errorMsg={subIdSwitchError}
        onVerifyAndSwitch={handleVerifyPasswordAndSwitch}
        onClose={() => {
          setSubIdSwitchTarget(null);
          setSubIdSwitchError(null);
        }}
      />

      {/* PERSISTENT FLOATING GAMING LIVE BALL ("GEND") + FRONT FACE CAM + 3D CHARACTER FACES */}
      <FismFloatingGamingLiveOverlay
        gamingState={gamingLiveState}
        setGamingState={setGamingLiveState}
        onOpenOnFireScreen={() => setActiveScreen('onFire')}
        faceSelectorOpen={faceSelectorModalOpen}
        setFaceSelectorOpen={setFaceSelectorModalOpen}
        onToggleFloatingPip={toggleFloatingPipWindow}
        onStopLiveAndHideAll={stopLiveBroadcast}
        triggerToast={triggerToast}
        custom3DModels={custom3DModels}
      />

      {/* IN-APP GOOGLE MAPS MODAL (SELLER LOCATION & EMBER CHAT LIVE LOCATION) */}
      {inAppMapModalTarget && (
        <FismInAppMapModal
          open={Boolean(inAppMapModalTarget)}
          title={inAppMapModalTarget.title}
          subtitle={inAppMapModalTarget.subtitle}
          lat={inAppMapModalTarget.lat}
          lng={inAppMapModalTarget.lng}
          label={inAppMapModalTarget.label}
          isLive={inAppMapModalTarget.isLive}
          accuracyMeters={inAppMapModalTarget.accuracyMeters}
          onClose={() => setInAppMapModalTarget(null)}
        />
      )}

      {/* ANNUAL PROFILE MILESTONE ACHIEVEMENT CARDS & JOURNEY POP-UP */}
      <FismMilestoneJourneyModal
        open={Boolean(milestoneModalTarget)}
        target={milestoneModalTarget}
        ownMilestone={userMilestone}
        founderGiftClaims={founderGiftClaims}
        onClose={() => setMilestoneModalTarget(null)}
        onDailyCheckInLocate={handleDailyCheckInLocate}
        onOpenMapsTab={() => {
          setMilestoneModalTarget(null);
          setActiveScreen('flameMaps');
        }}
        onClaimTier={handleClaimMilestoneTier}
        onSelectFrame={(frameId) => handleUpdateMilestonePrefs({ equippedFrame: frameId })}
        onToggleCyberpunkMode={(enabled) =>
          handleUpdateMilestonePrefs({ redCyberpunkMode: enabled })
        }
        onSubmitFounderGift={handleSubmitFounderGiftClaim}
        onFlexToFismStory={handleFlexMilestoneToStory}
        onTriggerToast={triggerToast}
      />

      {/* FULL-SCREEN SCROLLABLE LEGAL DOCUMENTATION MODAL (TERMS OF SERVICE & PRIVACY POLICY) */}
      <FismLegalDocsModal
        open={legalDocsModalState.open}
        returnLabel={legalDocsModalState.returnLabel}
        onClose={() => setLegalDocsModalState((prev) => ({ ...prev, open: false }))}
      />
      </div>
    </FismMapsApiProvider>
  );
}
