import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Radio,
  Monitor,
  Mic,
  MicOff,
  Camera,
  CameraOff,
  Sparkles,
  Gamepad2,
  PictureInPicture2,
  Cpu,
  X,
  Search,
  CheckCircle2,
  Share2,
  Disc,
  Zap,
  Volume2,
  Move,
  Sliders,
  Send,
  Bell,
  UserPlus,
  Smartphone,
  Coins,
  Crown,
} from 'lucide-react';
import {
  CHANNEL_MEMBERSHIP_SP_COST,
  FismSuperChatBoxStyle,
  FismSuperChatMessage,
  SP_SUPER_CHAT_COST,
  SUPER_CHAT_BOX_TIERS,
  SUPER_STICKER_OPTIONS,
} from '../types';

export interface Face3DModelPreset {
  id: string;
  name: string;
  category:
    | 'Gaming Legends'
    | 'Comedy & Icons'
    | 'Cartoon & Kids'
    | 'Anime 3D'
    | 'Cyber & Heroes'
    | 'Admin Custom 3D';
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  eyeStyle:
    | 'glow-red'
    | 'glow-cyan'
    | 'glow-gold'
    | 'cartoon-big'
    | 'anime-sharp'
    | 'visor'
    | 'bean-expressive';
  headgear:
    | 'bunny-ears'
    | 'hoodie-headset'
    | 'crown'
    | 'horns'
    | 'straw-hat'
    | 'spiky-hair'
    | 'helmet'
    | 'cat-ears'
    | 'none';
  maskStyle:
    | 'warrior-mask'
    | 'full-toon'
    | 'cyber-visor'
    | 'skull-flame'
    | 'ninja-half'
    | 'beard-mustache';
  badgeText: string;
  tagline: string;
  modelFileName?: string;
  uploadedByAdmin?: boolean;
}

/**
 * INITIAL 4 DEFAULT 3D CHARACTER MODELS
 * (As requested: Initially 4 models are built-in; Admin can upload additional 3D models via Admin File -> Open File Select 3D Model & Upload!)
 */
export const INITIAL_4_3D_FACE_MODELS: Face3DModelPreset[] = [
  {
    id: 'model_3d_1',
    name: 'Raistar 3D White Bunny',
    category: 'Gaming Legends',
    primaryColor: '#F8FAFC',
    secondaryColor: '#0F172A',
    accentColor: '#FF5722',
    eyeStyle: 'glow-red',
    headgear: 'bunny-ears',
    maskStyle: 'warrior-mask',
    badgeText: 'RAISTAR 3D',
    tagline: 'Head Tracking + Sitting/Standing Pose + Real-Time Lip-Sync',
  },
  {
    id: 'model_3d_2',
    name: 'Star 3D Bunny Bundle',
    category: 'Gaming Legends',
    primaryColor: '#FACC15',
    secondaryColor: '#1E1B4B',
    accentColor: '#38BDF8',
    eyeStyle: 'glow-gold',
    headgear: 'bunny-ears',
    maskStyle: 'full-toon',
    badgeText: 'BUNNY BUNDLE',
    tagline: 'Golden Star 3D Bunny Bundle + Moving Lips & Head Pose',
  },
  {
    id: 'model_3d_3',
    name: 'Ajju Bhai 94 (Total Gaming 3D)',
    category: 'Gaming Legends',
    primaryColor: '#1E293B',
    secondaryColor: '#FF5722',
    accentColor: '#38BDF8',
    eyeStyle: 'visor',
    headgear: 'hoodie-headset',
    maskStyle: 'cyber-visor',
    badgeText: 'AJJU BHAI 3D',
    tagline: '3D Pro Gamer Hoodie + RGB Headset & Lip-Sync Mouth',
  },
  {
    id: 'model_3d_4',
    name: 'Mr. Bean 3D Expressive Toon',
    category: 'Comedy & Icons',
    primaryColor: '#FDBA74',
    secondaryColor: '#78350F',
    accentColor: '#DC2626',
    eyeStyle: 'bean-expressive',
    headgear: 'none',
    maskStyle: 'full-toon',
    badgeText: 'MR. BEAN 3D',
    tagline: '3D Expressive Cartoon Rig + Moving Lips & Eyebrows',
  },
];

// Export alias for backward compatibility
export const ALL_3D_FACE_MODELS: Face3DModelPreset[] = INITIAL_4_3D_FACE_MODELS;

export type OverlayCornerPosition = 'bottom-left' | 'bottom-right' | 'top-left' | 'top-right';
export type SubTrackerPosition = 'top-center' | 'top-left' | 'top-right' | 'center';
export type LiveStreamAspectMode = 'long' | 'quickBurst';

export interface GamingLiveState {
  isScreencasting: boolean;
  isFloatingBallActive: boolean;
  isMicEnabled: boolean;
  isFaceCamEnabled: boolean;
  active3DFaceModelId: string;
  renderMode3D: 'full-3d-avatar' | 'ar-mask-overlay';
  selectedGameName: string;
  streamResolution: '1080p 60fps' | '1440p 60fps' | '720p Ultra-Low Latency';
  screenOptimizerHud: boolean;
  liveFps: number;
  liveBitrateKbps: number;
  detectedScreenActivity: string;
  // New Real-Time Screen Sharing Layout & Tracking Properties
  streamAspectMode?: LiveStreamAspectMode;
  chatBoxPos?: OverlayCornerPosition;
  avatarCornerPos?: OverlayCornerPosition;
  subTrackerPos?: SubTrackerPosition;
  showTitleDescBanner?: boolean;
  streamCustomTitle?: string;
  streamCustomDescription?: string;
  userPosture?: 'standing' | 'sitting';
  headYaw?: number; // -1 (left) to +1 (right)
  headPitch?: number; // -1 (up) to +1 (down)
}

/**
 * Speaks subscriber alert aloud using Web Speech API ("Aman ने आपको सब्सक्राइब किया है!")
 */
export function speakSubscriberVoiceAlert(subscriberName: string) {
  try {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(
        `${subscriberName} ने आपको सब्सक्राइब किया है! ${subscriberName} subscribed to your live stream!`,
      );
      utterance.lang = 'hi-IN';
      utterance.rate = 1.02;
      utterance.pitch = 1.08;
      window.speechSynthesis.speak(utterance);
    }
  } catch {
    // Ignore speech synthesis errors if browser blocks audio without gesture
  }
}

/**
 * Draws the 3D Character Avatar with:
 * - Real-time Head Direction (`headYaw`, `headPitch`) matching the person in front of the camera
 * - Real-time Sitting vs Standing posture (`posture === 'sitting' | 'standing'`)
 * - Real-time Lip-Sync (`micVolume`) with moving upper & lower lips ("होंठ हिलना")
 */
export function draw3DAvatarFaceFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  model: Face3DModelPreset,
  tick: number,
  micVolume: number,
  sourceVideo: HTMLVideoElement | null,
  renderMode: 'full-3d-avatar' | 'ar-mask-overlay',
  headYaw = 0,
  headPitch = 0,
  posture: 'standing' | 'sitting' = 'standing',
) {
  ctx.clearRect(0, 0, width, height);

  // 1. Background or Live Front Camera Feed
  if (renderMode === 'ar-mask-overlay' && sourceVideo && sourceVideo.readyState >= 2) {
    ctx.save();
    ctx.translate(width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(sourceVideo, 0, 0, width, height);
    ctx.restore();
    const vig = ctx.createRadialGradient(
      width / 2,
      height / 2,
      width * 0.2,
      width / 2,
      height / 2,
      width * 0.7,
    );
    vig.addColorStop(0, 'rgba(0,0,0,0.05)');
    vig.addColorStop(1, 'rgba(9,13,22,0.55)');
    ctx.fillStyle = vig;
    ctx.fillRect(0, 0, width, height);
  } else {
    const bgGrad = ctx.createRadialGradient(
      width / 2,
      height * 0.45,
      10,
      width / 2,
      height / 2,
      width * 0.75,
    );
    bgGrad.addColorStop(0, model.secondaryColor);
    bgGrad.addColorStop(1, '#090D16');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // 3D Cyber Grid Floor
    ctx.strokeStyle = `${model.accentColor}33`;
    ctx.lineWidth = 1;
    for (let i = -4; i <= 4; i++) {
      ctx.beginPath();
      ctx.moveTo(width / 2 + i * 16, height * 0.68);
      ctx.lineTo(width / 2 + i * 45, height);
      ctx.stroke();
    }
  }

  // Real-time posture offset: Sitting lowers the character into a gamer chair; Standing keeps torso tall
  const isSitting = posture === 'sitting';
  const postureYOffset = isSitting ? 14 : -4;
  const yawOffsetPx = headYaw * 18 + Math.sin(tick * 0.045) * 4;
  const pitchOffsetPx = headPitch * 12 + Math.cos(tick * 0.06) * 3;
  const headX = width / 2 + yawOffsetPx;
  const headY = height * 0.46 + postureYOffset + pitchOffsetPx;
  const headTilt = headYaw * 0.14 + Math.sin(tick * 0.03) * 0.035;
  const scale = Math.min(width, height) / 235;

  ctx.save();
  ctx.translate(headX, headY);
  ctx.scale(scale, scale);

  // Draw 3D Gamer Chair Backrest if Sitting
  if (isSitting) {
    ctx.save();
    ctx.fillStyle = '#1E293B';
    ctx.strokeStyle = model.accentColor;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(-54, -28, 108, 110, 18);
    ctx.fill();
    ctx.stroke();
    // Chair headrest pillow
    ctx.fillStyle = model.accentColor;
    ctx.beginPath();
    ctx.roundRect(-30, -18, 60, 16, 6);
    ctx.fill();
    ctx.restore();
  }

  // Draw 3D Upper Body / Torso & Shoulders (reacts to sitting vs standing & speaking)
  ctx.save();
  const torsoGrad = ctx.createLinearGradient(-50, 42, 50, 105);
  torsoGrad.addColorStop(0, model.primaryColor);
  torsoGrad.addColorStop(1, model.secondaryColor);
  ctx.fillStyle = torsoGrad;
  ctx.strokeStyle = model.accentColor;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  if (isSitting) {
    // Seated torso + desk/lap posture
    ctx.roundRect(-46, 40, 92, 54, 22);
  } else {
    // Standing tall heroic torso + animated shoulders
    ctx.roundRect(-52, 38, 104, 72, 24);
  }
  ctx.fill();
  ctx.stroke();

  // Animated 3D Hands/Arms when speaking
  const armWave = micVolume * 14 + Math.sin(tick * 0.12) * 3;
  ctx.fillStyle = model.secondaryColor;
  ctx.beginPath();
  ctx.roundRect(-64, 46 - armWave * 0.4, 16, 38, 8);
  ctx.roundRect(48, 46 - armWave * 0.4, 16, 38, 8);
  ctx.fill();
  ctx.restore();

  // Rotate head based on real-time headTilt / yaw
  ctx.rotate(headTilt);

  // Outer 3D Aura Ring
  ctx.save();
  ctx.shadowColor = model.accentColor;
  ctx.shadowBlur = 16 + micVolume * 24;
  ctx.strokeStyle = model.accentColor;
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.arc(0, -6, 64, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  // 2. Headgear Back / Ears (Bunny ears for Raistar/Star Bunny, Hoodie for Ajju Bhai, etc.)
  if (model.headgear === 'bunny-ears') {
    [-25, 25].forEach((offsetX, i) => {
      ctx.save();
      ctx.translate(offsetX + headYaw * 5, -56);
      ctx.rotate((i === 0 ? -0.18 : 0.18) + Math.sin(tick * 0.08 + i) * 0.06 + headYaw * 0.1);
      const earGrad = ctx.createLinearGradient(-12, -55, 12, 10);
      earGrad.addColorStop(0, model.primaryColor);
      earGrad.addColorStop(1, model.secondaryColor);
      ctx.fillStyle = earGrad;
      ctx.beginPath();
      ctx.ellipse(0, -24, 13, 36, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = model.accentColor;
      ctx.stroke();

      ctx.fillStyle = model.accentColor;
      ctx.beginPath();
      ctx.ellipse(0, -22, 6, 24, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
  } else if (model.headgear === 'hoodie-headset') {
    ctx.fillStyle = model.primaryColor;
    ctx.beginPath();
    ctx.arc(0, -6, 60, Math.PI * 0.85, Math.PI * 2.15);
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = model.accentColor;
    ctx.stroke();

    [-54, 54].forEach((cupX) => {
      ctx.fillStyle = model.secondaryColor;
      ctx.beginPath();
      ctx.roundRect(cupX - 9, -18, 18, 36, 8);
      ctx.fill();
      ctx.strokeStyle = model.accentColor;
      ctx.lineWidth = 2.5;
      ctx.stroke();
    });
  } else if (model.headgear === 'crown') {
    ctx.fillStyle = '#FACC15';
    ctx.strokeStyle = '#B45309';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(-36, -42);
    ctx.lineTo(-26, -72);
    ctx.lineTo(-10, -52);
    ctx.lineTo(0, -78);
    ctx.lineTo(10, -52);
    ctx.lineTo(26, -72);
    ctx.lineTo(36, -42);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else if (model.headgear === 'horns') {
    [-32, 32].forEach((hx, i) => {
      ctx.save();
      ctx.translate(hx, -44);
      ctx.rotate(i === 0 ? -0.35 : 0.35);
      ctx.fillStyle = model.accentColor;
      ctx.beginPath();
      ctx.moveTo(-10, 10);
      ctx.quadraticCurveTo(0, -36, i === 0 ? -18 : 18, -40);
      ctx.quadraticCurveTo(10, -10, 10, 10);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    });
  }

  // 3. 3D Shaded Main Head Sphere/Sculpt (shifts internal shading with headYaw & headPitch)
  const headGrad = ctx.createRadialGradient(
    -14 + headYaw * 16,
    -20 + headPitch * 12,
    8,
    0,
    0,
    54,
  );
  headGrad.addColorStop(0, '#FFFFFF');
  headGrad.addColorStop(0.28, model.primaryColor);
  headGrad.addColorStop(1, model.secondaryColor);

  ctx.fillStyle = renderMode === 'ar-mask-overlay' ? `${model.primaryColor}D9` : headGrad;
  ctx.beginPath();
  ctx.ellipse(0, -2, 46, 50, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = model.accentColor;
  ctx.stroke();

  // 4. Eyes (Shift horizontally & vertically with headYaw & headPitch)
  const eyeShiftX = headYaw * 10;
  const eyeShiftY = headPitch * 6;
  const isBlinking = tick % 105 > 99;

  if (model.eyeStyle === 'visor') {
    const visorGrad = ctx.createLinearGradient(-34 + eyeShiftX, -18, 34 + eyeShiftX, -4);
    visorGrad.addColorStop(0, model.accentColor);
    visorGrad.addColorStop(0.5, '#FFFFFF');
    visorGrad.addColorStop(1, model.secondaryColor);
    ctx.fillStyle = visorGrad;
    ctx.beginPath();
    ctx.roundRect(-34 + eyeShiftX, -20 + eyeShiftY, 68, 18, 8);
    ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 1.8;
    ctx.stroke();
  } else {
    [-17, 17].forEach((eyeX) => {
      ctx.save();
      ctx.translate(eyeX + eyeShiftX, -11 + eyeShiftY);
      if (isBlinking) {
        ctx.strokeStyle = model.accentColor;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-10, 0);
        ctx.lineTo(10, 0);
        ctx.stroke();
      } else if (model.eyeStyle === 'bean-expressive' || model.eyeStyle === 'cartoon-big') {
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.ellipse(0, 0, 10.5, 12.5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#0F172A';
        ctx.lineWidth = 2;
        ctx.stroke();

        const pupilX = headYaw * 4 + Math.sin(tick * 0.05) * 2;
        const pupilY = headPitch * 3;
        ctx.fillStyle = '#0F172A';
        ctx.beginPath();
        ctx.arc(pupilX, pupilY + 1, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(pupilX - 2, pupilY - 2, 2, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#0F172A';
        ctx.lineWidth = 3.2;
        ctx.beginPath();
        ctx.arc(0, -10 - micVolume * 5, 10, Math.PI * 1.15, Math.PI * 1.85);
        ctx.stroke();
      } else {
        const eyeColor =
          model.eyeStyle === 'glow-red'
            ? '#FF1744'
            : model.eyeStyle === 'glow-gold'
              ? '#FFD600'
              : '#00E5FF';
        ctx.shadowColor = eyeColor;
        ctx.shadowBlur = 14;
        ctx.fillStyle = eyeColor;
        ctx.beginPath();
        ctx.moveTo(-11, -2);
        ctx.lineTo(2, -7);
        ctx.lineTo(11, 1);
        ctx.lineTo(0, 6);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    });
  }

  // 5. Realistic Animated Upper & Lower Lips ("होंठ हिलना") synced with Microphone Voice!
  const mouthOpen = Math.min(20, 2 + micVolume * 36);
  const mouthX = eyeShiftX * 0.75;
  const mouthY = 20 + eyeShiftY * 0.6;

  if (model.maskStyle === 'warrior-mask' || model.maskStyle === 'skull-flame') {
    ctx.fillStyle = model.secondaryColor;
    ctx.beginPath();
    ctx.moveTo(-36 + mouthX * 0.3, 4);
    ctx.lineTo(mouthX, -2);
    ctx.lineTo(36 + mouthX * 0.3, 4);
    ctx.lineTo(26 + mouthX * 0.3, 38 + mouthOpen * 0.25);
    ctx.lineTo(mouthX, 46 + mouthOpen * 0.35);
    ctx.lineTo(-26 + mouthX * 0.3, 38 + mouthOpen * 0.25);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = model.accentColor;
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  // Always draw articulated 3D Moving Lips ("होंठ") so user clearly sees the character speaking like them!
  ctx.save();
  ctx.translate(mouthX, mouthY);

  // Inner mouth cavity when speaking
  ctx.fillStyle = '#450A0A';
  ctx.beginPath();
  ctx.ellipse(0, 0, 14, Math.max(2.5, mouthOpen * 0.65), 0, 0, Math.PI * 2);
  ctx.fill();

  // Upper teeth & tongue when mouth opens
  if (mouthOpen > 4) {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(-9, -mouthOpen * 0.45, 18, 3.5);
    ctx.fillStyle = '#FB7185';
    ctx.beginPath();
    ctx.ellipse(0, mouthOpen * 0.25, 8, Math.max(2, mouthOpen * 0.28), 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Animated Upper Lip
  ctx.strokeStyle = model.accentColor === '#FF5722' ? '#F43F5E' : model.accentColor;
  ctx.lineWidth = 3.2;
  ctx.beginPath();
  ctx.moveTo(-15, 0);
  ctx.quadraticCurveTo(0, -4 - mouthOpen * 0.45, 15, 0);
  ctx.stroke();

  // Animated Lower Lip
  ctx.beginPath();
  ctx.moveTo(-15, 0);
  ctx.quadraticCurveTo(0, 4 + mouthOpen * 0.65, 15, 0);
  ctx.stroke();
  ctx.restore();

  ctx.restore();

  // Bottom 3D Character Name + Posture & Lip-Sync Status Bar
  ctx.fillStyle = 'rgba(9, 13, 22, 0.86)';
  ctx.fillRect(4, height - 26, width - 8, 22);
  ctx.strokeStyle = model.accentColor;
  ctx.lineWidth = 1.2;
  ctx.strokeRect(4, height - 26, width - 8, 22);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 9.5px Inter, sans-serif';
  ctx.textAlign = 'center';
  const poseLabel = isSitting ? '🪑 Sitting' : '🧍 Standing';
  const talkLabel = micVolume > 0.08 ? '🗣️ Speaking' : '👂 Ready';
  ctx.fillText(`${model.badgeText} • ${poseLabel} • ${talkLabel}`, width / 2, height - 11);
}

interface GamingStudioPanelProps {
  gamingState: GamingLiveState;
  setGamingState: React.Dispatch<React.SetStateAction<GamingLiveState>>;
  onStartScreencast: () => Promise<void>;
  onStopScreencast: () => void;
  onToggleFloatingPip: () => Promise<void>;
  onOpenFaceSelector: () => void;
  screenVideoRef: React.RefObject<HTMLVideoElement | null>;
  simCanvasRef: React.RefObject<HTMLCanvasElement | null>;
  usingSimulatedScreen: boolean;
  onPublishHighlightToFeed: () => void;
  custom3DModels?: Face3DModelPreset[];
  liveChatMessages?: { id: string; user: string; text: string }[];
  onSendLiveChat?: (text: string) => void;
  userSpCoins?: number;
  superChats?: FismSuperChatMessage[];
  onSendSuperChat?: (opts: {
    kind: 'superchat' | 'sticker';
    text?: string;
    boxStyle?: FismSuperChatBoxStyle;
    stickerId?: string;
    stickerLabel?: string;
    stickerEmoji?: string;
  }) => Promise<boolean> | boolean;
  onJoinHostMembership?: () => Promise<void> | void;
  isHostMember?: boolean;
  onOpenBuySpCoins?: () => void;
}

export const FismOnFireGamingStudioPanel: React.FC<GamingStudioPanelProps> = ({
  gamingState,
  setGamingState,
  onStartScreencast,
  onStopScreencast,
  onToggleFloatingPip,
  onOpenFaceSelector,
  screenVideoRef,
  simCanvasRef,
  usingSimulatedScreen,
  onPublishHighlightToFeed,
  custom3DModels = [],
  liveChatMessages = [],
  onSendLiveChat,
  userSpCoins = 0,
  superChats = [],
  onSendSuperChat,
  onJoinHostMembership,
  isHostMember = false,
  onOpenBuySpCoins,
}) => {
  const allAvailableModels = useMemo(
    () => [...INITIAL_4_3D_FACE_MODELS, ...custom3DModels],
    [custom3DModels],
  );

  const activeModel = useMemo(
    () =>
      allAvailableModels.find((m) => m.id === gamingState.active3DFaceModelId) ||
      allAvailableModels[0],
    [allAvailableModels, gamingState.active3DFaceModelId],
  );

  // Format Choice Popup ("Long 16:9" vs "Quick Burst 9:16") before starting live
  const [formatChoiceModalOpen, setFormatChoiceModalOpen] = useState(false);
  // Edit Screen Layout Mode for Screen Sharing
  const [isEditingScreenLayout, setIsEditingScreenLayout] = useState(false);
  // Real-Time Subscriber Alert + 5-Second Dancing Sticker State
  const [subAlertSubscriberName, setSubAlertSubscriberName] = useState<string | null>(null);
  const [simSubscriberInput, setSimSubscriberInput] = useState<string>('Aman');
  const [inlineChatInput, setInlineChatInput] = useState<string>('');
  const [superChatMessage, setSuperChatMessage] = useState<string>('');
  const [selectedSuperBoxStyle, setSelectedSuperBoxStyle] =
    useState<FismSuperChatBoxStyle>('amber_flame');
  const subAlertTimeoutRef = useRef<number | null>(null);

  // Corner 3D Avatar Canvas inside the Live Stream Screen
  const cornerAvatarCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [screenShareDiagHint, setScreenShareDiagHint] = useState<string | null>(null);

  useEffect(() => {
    if (gamingState.isScreencasting && !usingSimulatedScreen && screenVideoRef.current) {
      screenVideoRef.current.play().catch(() => {});
    }
    if (gamingState.isScreencasting && usingSimulatedScreen) {
      setScreenShareDiagHint(
        'Browser iframe Permissions-Policy ("display-capture") blocked OS Screen Picker, so Interactive Studio Screen Mode is running. Open in a direct top-level browser tab (or Android APK with MediaProjection + FOREGROUND_SERVICE_MEDIA_PROJECTION) for full device screen capture!',
      );
    } else {
      setScreenShareDiagHint(null);
    }
  }, [gamingState.isScreencasting, usingSimulatedScreen]);

  const triggerSubscriberAlertWithDancingSticker = (subscriberName: string) => {
    const cleanName = subscriberName.trim() || 'Aman';
    setSubAlertSubscriberName(cleanName);
    speakSubscriberVoiceAlert(cleanName);

    if (subAlertTimeoutRef.current) {
      window.clearTimeout(subAlertTimeoutRef.current);
    }
    // Automatically hide the dancing sticker and alert after 5 seconds (5000ms)!
    subAlertTimeoutRef.current = window.setTimeout(() => {
      setSubAlertSubscriberName(null);
    }, 5000);
  };

  // Auto-render the Corner 3D Character inside the live stream view
  useEffect(() => {
    if (!gamingState.isScreencasting) return;
    let animId = 0;
    let tick = 0;
    const renderCorner = () => {
      tick += 1;
      const canvas = cornerAvatarCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const synthMic = gamingState.isMicEnabled
            ? (Math.sin(tick * 0.25) + 1) * 0.28
            : 0;
          draw3DAvatarFaceFrame(
            ctx,
            canvas.width,
            canvas.height,
            activeModel,
            tick,
            synthMic,
            null,
            gamingState.renderMode3D,
            gamingState.headYaw ?? Math.sin(tick * 0.04) * 0.45,
            gamingState.headPitch ?? Math.cos(tick * 0.05) * 0.25,
            gamingState.userPosture || 'standing',
          );
        }
      }
      animId = requestAnimationFrame(renderCorner);
    };
    animId = requestAnimationFrame(renderCorner);
    return () => cancelAnimationFrame(animId);
  }, [
    gamingState.isScreencasting,
    gamingState.isMicEnabled,
    gamingState.renderMode3D,
    gamingState.headYaw,
    gamingState.headPitch,
    gamingState.userPosture,
    activeModel,
  ]);

  const chatPos = gamingState.chatBoxPos || 'bottom-left';
  const avatarPos = gamingState.avatarCornerPos || 'bottom-right';
  const trackerPos = gamingState.subTrackerPos || 'top-center';
  const aspectMode = gamingState.streamAspectMode || 'long';

  const getCornerCssClass = (pos: OverlayCornerPosition) => {
    switch (pos) {
      case 'top-left':
        return 'top-14 left-3';
      case 'top-right':
        return 'top-14 right-3';
      case 'bottom-left':
        return 'bottom-16 left-3';
      case 'bottom-right':
      default:
        return 'bottom-16 right-3';
    }
  };

  const getTrackerCssClass = (pos: SubTrackerPosition) => {
    switch (pos) {
      case 'top-left':
        return 'top-14 left-4';
      case 'top-right':
        return 'top-14 right-4';
      case 'center':
        return 'top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2';
      case 'top-center':
      default:
        return 'top-14 left-1/2 -translate-x-1/2';
    }
  };

  return (
    <div className="fism-card p-5 border-2 border-[#FF5722] space-y-5">
      {/* FORMAT SELECTOR MODAL: LONG (16:9) vs QUICK BURST (9:16 VERTICAL) */}
      {formatChoiceModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-3xl bg-[#101426] border-2 border-[#FF5722] p-6 text-white shadow-2xl space-y-5">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-full bg-[#FF5722]/20 border border-[#FF5722] text-[#FFB300] text-xs font-extrabold uppercase">
                Choose Live Stream Format
              </span>
              <button
                onClick={() => setFormatChoiceModalOpen(false)}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-extrabold">
                आप किस फॉर्मेट में लाइव स्ट्रीम करना चाहते हैं?
              </h3>
              <p className="text-xs text-slate-300">
                <strong>Long (16:9)</strong> चुनने पर फुल वाइडस्क्रीन में चलेगा, और{' '}
                <strong>Quick Burst (9:16)</strong> चुनने पर स्क्रीन Shorts के साइज में एनिमेट होकर एडजस्ट हो जाएगी और स्क्रॉल करने पर Quick Burst में बीच-बीच में आती रहेगी!
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <button
                onClick={async () => {
                  setGamingState((prev) => ({ ...prev, streamAspectMode: 'long' }));
                  setFormatChoiceModalOpen(false);
                  await onStartScreencast();
                }}
                className="p-4 rounded-2xl bg-[#181F36] hover:bg-[#FF5722]/20 border-2 border-[#FF5722] text-left space-y-2 transition-all group"
              >
                <Monitor className="w-8 h-8 text-[#FF5722] group-hover:scale-110 transition-transform" />
                <div className="font-extrabold text-sm text-white">
                  1. Long Stream (16:9 Landscape)
                </div>
                <p className="text-[11px] text-slate-300">
                  Full widescreen gaming &amp; screen sharing for Main Blast &amp; On Fire.
                </p>
              </button>

              <button
                onClick={async () => {
                  setGamingState((prev) => ({ ...prev, streamAspectMode: 'quickBurst' }));
                  setFormatChoiceModalOpen(false);
                  await onStartScreencast();
                }}
                className="p-4 rounded-2xl bg-[#181F36] hover:bg-[#FFB300]/20 border-2 border-[#FFB300] text-left space-y-2 transition-all group"
              >
                <Smartphone className="w-8 h-8 text-[#FFB300] group-hover:scale-110 transition-transform" />
                <div className="font-extrabold text-sm text-[#FFB300]">
                  2. Quick Burst (9:16 Vertical)
                </div>
                <p className="text-[11px] text-slate-300">
                  Animates to vertical 9:16 Shorts size &amp; appears inside Quick Burst scroll feed!
                </p>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl fism-gradient-flame flex items-center justify-center text-white shadow-lg">
            <Gamepad2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-extrabold">
                On Fire — Screen Sharing (Real-Time Screen Track) &amp; 3D Studio
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-[#FF5722]/15 text-[#FF5722] border border-[#FF5722]/40 text-[11px] font-extrabold">
                SCREEN SHARING • EDITABLE HUD
              </span>
            </div>
            <p className="text-xs text-[#52607A] dark:text-slate-300">
              Real-Time Screen Sharing with <strong>Edit Screen</strong> layout controls, Subscriber Voice
              Alert + 5s Dancing Sticker, &amp; Real-Time 3D Character (Head/Pose/Lip-Sync).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {!gamingState.isScreencasting ? (
            <button
              onClick={() => setFormatChoiceModalOpen(true)}
              className="fism-btn-primary px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-lg"
            >
              <Monitor className="w-4 h-4" /> Start Screen Sharing / Gaming Live
            </button>
          ) : (
            <button
              onClick={onStopScreencast}
              className="px-4 py-2.5 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold flex items-center gap-2 shadow-lg"
            >
              <X className="w-4 h-4" /> Stop Screen Sharing
            </button>
          )}

          {/* Edit Screen Button (Customize Chat Box, 3D Avatar, Subscriber Alert Positions & Format) */}
          <button
            onClick={() => setIsEditingScreenLayout((v) => !v)}
            className={`px-3.5 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border ${
              isEditingScreenLayout
                ? 'bg-[#FF5722] text-white border-[#FF5722] shadow-lg'
                : 'bg-[#101426] text-[#FFB300] border-[#FF5722]'
            }`}
          >
            <Sliders className="w-4 h-4" />
            {isEditingScreenLayout ? 'Done Editing Screen' : 'Edit Screen (एडिट स्क्रीन)'}
          </button>

          <button
            onClick={() =>
              setGamingState((prev) => ({
                ...prev,
                isFloatingBallActive: !prev.isFloatingBallActive,
              }))
            }
            className={`px-3.5 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border ${
              gamingState.isFloatingBallActive
                ? 'bg-[#16A34A] text-white border-[#16A34A]'
                : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#0F172A] dark:text-white border-[#CBD5E1] dark:border-slate-700'
            }`}
          >
            <Disc className="w-4 h-4" />
            {gamingState.isFloatingBallActive ? 'Floating Gend: ON' : 'Floating Gend'}
          </button>

          <button
            onClick={onToggleFloatingPip}
            className="px-3.5 py-2.5 rounded-xl bg-[#0F172A] text-white border border-[#FF5722] text-xs font-extrabold flex items-center gap-1.5"
          >
            <PictureInPicture2 className="w-4 h-4 text-[#FFB300]" />
            Float Window (PiP)
          </button>
        </div>
      </div>

      {/* EDIT SCREEN LAYOUT CUSTOMIZER PANEL */}
      {isEditingScreenLayout && (
        <div className="p-4 rounded-2xl bg-[#101426] text-white border-2 border-[#FFB300] space-y-4 shadow-xl">
          <div className="flex items-center justify-between flex-wrap gap-2 border-b border-white/15 pb-3">
            <div>
              <span className="px-2.5 py-0.5 rounded-full bg-[#FFB300] text-[#101426] text-[10px] font-black uppercase">
                Edit Screen Layout • Real-Time Screen Sharing HUD
              </span>
              <h3 className="text-sm sm:text-base font-extrabold mt-1">
                Customize Chat Box, Subscriber Voice Tracker, 3D Avatar Corner &amp; Stream Size
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() =>
                  setGamingState((prev) => ({
                    ...prev,
                    streamAspectMode: prev.streamAspectMode === 'quickBurst' ? 'long' : 'quickBurst',
                  }))
                }
                className="px-3 py-1.5 rounded-xl bg-[#FF5722] text-white text-xs font-extrabold"
              >
                Format: {aspectMode === 'quickBurst' ? '⚡ Quick Burst (9:16)' : '📺 Long (16:9)'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            {/* 1. Chat Box Position */}
            <div className="p-3 rounded-xl bg-[#181F36] border border-slate-700 space-y-1.5">
              <label className="font-extrabold text-[#FFB300] block">
                1. Live Chat Box कहां रहेगा?
              </label>
              <select
                value={chatPos}
                onChange={(e) =>
                  setGamingState((prev) => ({
                    ...prev,
                    chatBoxPos: e.target.value as OverlayCornerPosition,
                  }))
                }
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#101426] border border-slate-600 text-white font-bold"
              >
                <option value="bottom-left">Bottom-Left (नीचे बाएं)</option>
                <option value="bottom-right">Bottom-Right (नीचे दाएं)</option>
                <option value="top-left">Top-Left (ऊपर बाएं)</option>
                <option value="top-right">Top-Right (ऊपर दाएं)</option>
              </select>
            </div>

            {/* 2. Subscriber Tracker Alert Position */}
            <div className="p-3 rounded-xl bg-[#181F36] border border-slate-700 space-y-1.5">
              <label className="font-extrabold text-[#FFB300] block">
                2. Subscriber Alert &amp; Dancing Sticker कहां दिखेगा?
              </label>
              <select
                value={trackerPos}
                onChange={(e) =>
                  setGamingState((prev) => ({
                    ...prev,
                    subTrackerPos: e.target.value as SubTrackerPosition,
                  }))
                }
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#101426] border border-slate-600 text-white font-bold"
              >
                <option value="top-center">Top-Center (ऊपर बीच में)</option>
                <option value="center">Center Screen (स्क्रीन के बीच में)</option>
                <option value="top-left">Top-Left (ऊपर बाएं)</option>
                <option value="top-right">Top-Right (ऊपर दाएं)</option>
              </select>
            </div>

            {/* 3. 3D Character Corner Position */}
            <div className="p-3 rounded-xl bg-[#181F36] border border-slate-700 space-y-1.5">
              <label className="font-extrabold text-[#FFB300] block">
                3. 3D Character (कोने में) कहां दिखेगा?
              </label>
              <select
                value={avatarPos}
                onChange={(e) =>
                  setGamingState((prev) => ({
                    ...prev,
                    avatarCornerPos: e.target.value as OverlayCornerPosition,
                  }))
                }
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#101426] border border-slate-600 text-white font-bold"
              >
                <option value="bottom-right">Bottom-Right (नीचे दाएं कोने में)</option>
                <option value="bottom-left">Bottom-Left (नीचे बाएं कोने में)</option>
                <option value="top-right">Top-Right (ऊपर दाएं कोने में)</option>
                <option value="top-left">Top-Left (ऊपर बाएं कोने में)</option>
              </select>
            </div>

            {/* 4. 3D Character Posture & Head Pose Controls */}
            <div className="p-3 rounded-xl bg-[#181F36] border border-slate-700 space-y-1.5">
              <label className="font-extrabold text-[#FFB300] block">
                4. 3D Character Posture (बैठा / खड़ा)
              </label>
              <div className="flex gap-1.5">
                <button
                  onClick={() =>
                    setGamingState((prev) => ({ ...prev, userPosture: 'standing' }))
                  }
                  className={`flex-1 py-1.5 rounded-lg font-extrabold ${
                    (gamingState.userPosture || 'standing') === 'standing'
                      ? 'bg-[#FF5722] text-white'
                      : 'bg-[#101426] text-slate-300'
                  }`}
                >
                  🧍 खड़ा (Standing)
                </button>
                <button
                  onClick={() =>
                    setGamingState((prev) => ({ ...prev, userPosture: 'sitting' }))
                  }
                  className={`flex-1 py-1.5 rounded-lg font-extrabold ${
                    gamingState.userPosture === 'sitting'
                      ? 'bg-[#FF5722] text-white'
                      : 'bg-[#101426] text-slate-300'
                  }`}
                >
                  🪑 बैठा (Sitting)
                </button>
              </div>
            </div>
          </div>

          {/* Stream Title, Description & Test Subscriber Voice Alert */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-1">
            <input
              type="text"
              value={gamingState.streamCustomTitle ?? gamingState.selectedGameName}
              onChange={(e) =>
                setGamingState((prev) => ({ ...prev, streamCustomTitle: e.target.value }))
              }
              placeholder="Live Stream Title..."
              className="md:col-span-4 px-3 py-2 rounded-xl bg-[#181F36] border border-slate-700 text-xs font-bold text-white"
            />
            <input
              type="text"
              value={
                gamingState.streamCustomDescription ??
                'Live Screen Sharing with 3D Character Lip-Sync & Real-Time Subscriber Alerts!'
              }
              onChange={(e) =>
                setGamingState((prev) => ({
                  ...prev,
                  streamCustomDescription: e.target.value,
                }))
              }
              placeholder="Live Stream Description..."
              className="md:col-span-4 px-3 py-2 rounded-xl bg-[#181F36] border border-slate-700 text-xs text-white"
            />
            <div className="md:col-span-4 flex items-center gap-1.5">
              <input
                type="text"
                value={simSubscriberInput}
                onChange={(e) => setSimSubscriberInput(e.target.value)}
                placeholder="Subscriber name (e.g. Aman)"
                className="flex-1 px-3 py-2 rounded-xl bg-[#181F36] border border-[#FF5722] text-xs font-bold text-white"
              />
              <button
                onClick={() => triggerSubscriberAlertWithDancingSticker(simSubscriberInput)}
                className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#16A34A] to-[#059669] text-white text-xs font-extrabold shrink-0 flex items-center gap-1 shadow-lg"
              >
                <Volume2 className="w-3.5 h-3.5" /> Test Sub Alert
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Control Bar: Format Switcher, Mic, Face Cam, 3D Face Changer */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="p-3 rounded-xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800">
          <label className="text-[10px] font-extrabold text-[#52607A] uppercase block mb-1">
            Stream Format (Long / Quick Burst)
          </label>
          <div className="flex gap-1">
            <button
              onClick={() => setGamingState((prev) => ({ ...prev, streamAspectMode: 'long' }))}
              className={`flex-1 py-1.5 rounded-lg text-[11px] font-extrabold ${
                aspectMode === 'long'
                  ? 'bg-[#FF5722] text-white'
                  : 'bg-white dark:bg-slate-800 text-[#52607A]'
              }`}
            >
              📺 Long 16:9
            </button>
            <button
              onClick={() =>
                setGamingState((prev) => ({ ...prev, streamAspectMode: 'quickBurst' }))
              }
              className={`flex-1 py-1.5 rounded-lg text-[11px] font-extrabold ${
                aspectMode === 'quickBurst'
                  ? 'bg-[#FFB300] text-[#101426]'
                  : 'bg-white dark:bg-slate-800 text-[#52607A]'
              }`}
            >
              ⚡ Quick Burst
            </button>
          </div>
        </div>

        <button
          onClick={() =>
            setGamingState((prev) => ({ ...prev, isMicEnabled: !prev.isMicEnabled }))
          }
          className={`p-3 rounded-xl border text-left flex items-center justify-between ${
            gamingState.isMicEnabled
              ? 'bg-[#16A34A]/15 border-[#16A34A] text-[#16A34A]'
              : 'bg-[#F8FAFE] dark:bg-slate-900 border-[#D8E1F0] dark:border-slate-800 text-[#52607A]'
          }`}
        >
          <div>
            <div className="text-[10px] font-extrabold uppercase">Live Mic &amp; Lips</div>
            <div className="text-xs font-black mt-0.5">
              {gamingState.isMicEnabled ? 'MIC + LIP-SYNC ON' : 'MIC MUTED'}
            </div>
          </div>
          {gamingState.isMicEnabled ? (
            <Mic className="w-5 h-5" />
          ) : (
            <MicOff className="w-5 h-5 text-[#DC2626]" />
          )}
        </button>

        <button
          onClick={() =>
            setGamingState((prev) => ({ ...prev, isFaceCamEnabled: !prev.isFaceCamEnabled }))
          }
          className={`p-3 rounded-xl border text-left flex items-center justify-between ${
            gamingState.isFaceCamEnabled
              ? 'bg-[#FF5722]/15 border-[#FF5722] text-[#FF5722]'
              : 'bg-[#F8FAFE] dark:bg-slate-900 border-[#D8E1F0] dark:border-slate-800 text-[#52607A]'
          }`}
        >
          <div>
            <div className="text-[10px] font-extrabold uppercase">3D Corner &amp; Cam</div>
            <div className="text-xs font-black mt-0.5">
              {gamingState.isFaceCamEnabled ? '3D RIG ACTIVE' : 'FACE CAM OFF'}
            </div>
          </div>
          {gamingState.isFaceCamEnabled ? (
            <Camera className="w-5 h-5" />
          ) : (
            <CameraOff className="w-5 h-5" />
          )}
        </button>

        <button
          onClick={() => triggerSubscriberAlertWithDancingSticker(simSubscriberInput || 'Aman')}
          className="p-3 rounded-xl bg-emerald-500/15 border border-[#16A34A] text-[#16A34A] text-left flex items-center justify-between"
        >
          <div>
            <div className="text-[10px] font-extrabold uppercase">Voice Sub Tracker</div>
            <div className="text-xs font-black mt-0.5">🔊 Test &quot;{simSubscriberInput}&quot; Sub</div>
          </div>
          <UserPlus className="w-5 h-5 shrink-0" />
        </button>

        <button
          onClick={onOpenFaceSelector}
          className="p-3 rounded-xl fism-gradient-flame text-white text-left flex items-center justify-between shadow-md"
        >
          <div className="min-w-0">
            <div className="text-[10px] font-extrabold uppercase text-white/90">
              Change 3D Model ({allAvailableModels.length} Models)
            </div>
            <div className="text-xs font-black truncate mt-0.5">{activeModel.name}</div>
          </div>
          <Sparkles className="w-5 h-5 shrink-0" />
        </button>
      </div>

      {/* LIVE SCREEN SHARING + EDITABLE OVERLAYS (Animates smoothly between 16:9 Long and 9:16 Quick Burst!) */}
      <div
        className={`relative rounded-2xl overflow-hidden bg-[#090D16] border-2 border-[#FF5722] transition-all duration-500 mx-auto ${
          aspectMode === 'quickBurst'
            ? 'max-w-[380px] aspect-[9/16] shadow-[0_0_40px_rgba(255,179,0,0.35)]'
            : 'w-full aspect-video'
        }`}
      >
        {/* Real DisplayMedia Video */}
        <video
          ref={screenVideoRef}
          autoPlay
          muted
          playsInline
          onLoadedMetadata={(e) => {
            e.currentTarget.play().catch(() => {});
          }}
          className={`w-full h-full object-contain bg-black ${
            gamingState.isScreencasting && !usingSimulatedScreen ? 'block' : 'hidden'
          }`}
        />

        {/* High-FPS Optimized Live Game / Screen Canvas Stream */}
        <canvas
          ref={simCanvasRef}
          width={1280}
          height={720}
          className={`w-full h-full object-cover ${
            gamingState.isScreencasting && usingSimulatedScreen ? 'block' : 'hidden'
          }`}
        />

        {screenShareDiagHint && gamingState.isScreencasting && (
          <div className="absolute bottom-14 left-3 right-3 z-25 p-2.5 rounded-xl bg-amber-950/90 border border-[#FFB300] text-[11px] text-amber-100 flex items-center justify-between gap-2 flex-wrap shadow-lg">
            <span>
              ⚠️ <strong>Screen Share Note:</strong> {screenShareDiagHint}
            </span>
            <button
              type="button"
              onClick={() => onStartScreencast()}
              className="px-2.5 py-1 rounded-lg bg-[#FFB300] text-slate-950 font-extrabold shrink-0"
            >
              🔄 Retry OS Screen Picker
            </button>
          </div>
        )}

        {!gamingState.isScreencasting && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 text-white space-y-3 bg-gradient-to-br from-[#090D16] via-[#111827] to-[#1E1B4B]">
            <Monitor className="w-12 h-12 text-[#FF5722]" />
            <div className="px-3 py-1 rounded-full bg-[#FF5722]/20 border border-[#FF5722] text-[#FFB300] text-[11px] font-extrabold">
              SCREEN SHARING • REAL-TIME SCREEN TRACK
            </div>
            <h3 className="text-lg font-extrabold">
              Screen Sharing &amp; 3D Avatar Live Studio Ready
            </h3>
            <p className="text-xs text-slate-300 max-w-lg">
              Click <strong>&quot;Start Screen Sharing / Gaming Live&quot;</strong> to choose{' '}
              <strong>Long (16:9)</strong> or <strong>Quick Burst (9:16)</strong>. Includes{' '}
              <strong>Edit Screen</strong> layout controls, voice subscriber alerts with a 5-second
              dancing sticker, and your real-time 3D character in the corner!
            </p>
            <div className="flex flex-wrap justify-center gap-2 pt-1">
              <button
                onClick={() => setFormatChoiceModalOpen(true)}
                className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2"
              >
                <Gamepad2 className="w-4 h-4" /> Start Screen Sharing Now
              </button>
              <button
                onClick={() => setIsEditingScreenLayout(true)}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-[#FFB300] text-xs font-extrabold flex items-center gap-1.5 border border-[#FFB300]/40"
              >
                <Sliders className="w-4 h-4" /> Edit Screen Layout
              </button>
            </div>
          </div>
        )}

        {/* TOP BAR: SCREEN SHARING BADGE + EDIT SCREEN BUTTON */}
        {gamingState.isScreencasting && (
          <div className="absolute top-3 left-3 right-3 flex items-center justify-between flex-wrap gap-2 z-20">
            <div className="flex items-center gap-2 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-[#FF5722] text-white text-[11px] font-extrabold">
              <span className="w-2.5 h-2.5 rounded-full bg-[#E53935] animate-ping" />
              <span>SCREEN SHARING (REAL-TIME TRACK)</span>
              <span className="px-1.5 py-0.5 rounded bg-[#FFB300] text-[#101426] text-[9px] font-black uppercase">
                {aspectMode === 'quickBurst' ? '9:16 QUICK BURST' : '16:9 LONG'}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setIsEditingScreenLayout((v) => !v)}
                className="px-2.5 py-1.5 rounded-xl bg-[#FF5722] text-white text-[11px] font-extrabold flex items-center gap-1 shadow-lg"
              >
                <Sliders className="w-3.5 h-3.5" /> Edit Screen
              </button>
              <div className="hidden sm:flex items-center gap-1.5 bg-black/75 px-2.5 py-1.5 rounded-xl border border-emerald-500/50 text-emerald-400 text-[10px] font-bold">
                <Cpu className="w-3.5 h-3.5" />
                <span>{gamingState.liveFps} FPS</span>
              </div>
            </div>
          </div>
        )}

        {/* REAL-TIME SUBSCRIBER VOICE ALERT + 5-SECOND FLOATING DANCING STICKER */}
        {subAlertSubscriberName && (
          <div
            className={`absolute z-30 ${getTrackerCssClass(
              trackerPos,
            )} pointer-events-none flex flex-col items-center animate-bounce`}
          >
            {/* 5-Second Floating Dancing Sticker */}
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#FF5722] via-[#FFB300] to-[#EC4899] p-1 shadow-[0_0_35px_rgba(255,179,0,0.95)] flex items-center justify-center mb-2">
              <div className="w-full h-full rounded-[20px] bg-[#101426] flex flex-col items-center justify-center text-center p-1">
                <div className="text-3xl animate-spin">🕺</div>
                <span className="text-[9px] font-black text-[#FFB300] uppercase tracking-wider mt-0.5">
                  5s Dance!
                </span>
              </div>
            </div>
            <div className="px-4 py-2 rounded-2xl bg-[#101426]/95 border-2 border-[#FFB300] text-white shadow-2xl text-center">
              <div className="text-xs sm:text-sm font-black text-[#FFB300] flex items-center justify-center gap-1.5">
                <Bell className="w-4 h-4 text-[#FF5722]" /> {subAlertSubscriberName} ने आपको सब्सक्राइब किया है!
              </div>
              <div className="text-[10px] text-emerald-400 font-bold">
                🔊 Voice Announced • Dancing Sticker Disappears in 5s
              </div>
            </div>
          </div>
        )}

        {/* CORNER 3D CHARACTER AVATAR OVERLAY (Head Tracking + Posture + Lip-Sync) */}
        {gamingState.isScreencasting && gamingState.isFaceCamEnabled && (
          <div
            className={`absolute z-20 ${getCornerCssClass(
              avatarPos,
            )} w-36 sm:w-44 rounded-2xl overflow-hidden bg-[#090D16]/90 border-2 border-[#FF5722] shadow-2xl`}
          >
            <div className="px-2 py-1 bg-black/85 flex items-center justify-between text-[9px] font-extrabold text-white">
              <span className="truncate text-[#FFB300]">{activeModel.badgeText}</span>
              <button
                onClick={() =>
                  setGamingState((prev) => ({
                    ...prev,
                    userPosture: prev.userPosture === 'sitting' ? 'standing' : 'sitting',
                  }))
                }
                className="px-1.5 py-0.5 rounded bg-[#FF5722] text-white"
              >
                {gamingState.userPosture === 'sitting' ? '🪑 Sit' : '🧍 Stand'}
              </button>
            </div>
            <canvas
              ref={cornerAvatarCanvasRef}
              width={176}
              height={176}
              className="w-full h-36 sm:h-40 block"
            />
          </div>
        )}

        {/* PINNED SUPER CHAT BOXES INSIDE LIVE STREAM */}
        {gamingState.isScreencasting && superChats.length > 0 && (
          <div className="absolute top-14 left-3 z-25 flex flex-col gap-1.5 max-w-[270px] pointer-events-none">
            {superChats.slice(-2).map((sc) => {
              const tier =
                SUPER_CHAT_BOX_TIERS.find((t) => t.id === sc.boxStyle) ||
                SUPER_CHAT_BOX_TIERS[0];
              return (
                <div
                  key={sc.id}
                  className={`px-3 py-2 rounded-xl border shadow-xl ${tier.cardClass}`}
                >
                  <div className="flex items-center justify-between gap-2 text-[10px] font-black">
                    <span>@{sc.senderUsername}</span>
                    <span className="tabular-nums">{sc.spCost} SP</span>
                  </div>
                  <div className="text-xs font-extrabold mt-0.5 leading-snug">
                    {sc.kind === 'sticker'
                      ? `${sc.stickerEmoji || '🔥'} ${sc.stickerLabel || 'Super Sticker'}`
                      : sc.text}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* LIVE STREAM INTERACTIVE CHAT BOX OVERLAY (Positioned via Edit Screen) */}
        {gamingState.isScreencasting && (
          <div
            className={`absolute z-20 ${getCornerCssClass(
              chatPos,
            )} w-60 sm:w-72 rounded-2xl bg-black/80 backdrop-blur-md border border-white/20 p-2.5 text-white space-y-2 shadow-2xl`}
          >
            <div className="flex items-center justify-between border-b border-white/15 pb-1 text-[10px] font-extrabold text-[#FFB300]">
              <span>💬 Live Stream Chat ({chatPos})</span>
              <span>● Live</span>
            </div>
            <div className="max-h-24 overflow-y-auto space-y-1 text-[11px]">
              {liveChatMessages.slice(-5).map((m) => (
                <div key={m.id} className="leading-tight">
                  <span className="font-extrabold text-[#FF5722]">@{m.user}: </span>
                  <span className="text-slate-100">{m.text}</span>
                </div>
              ))}
            </div>
            {onSendLiveChat && (
              <div className="flex gap-1 pt-1">
                <input
                  type="text"
                  value={inlineChatInput}
                  onChange={(e) => setInlineChatInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && inlineChatInput.trim()) {
                      onSendLiveChat(inlineChatInput.trim());
                      setInlineChatInput('');
                    }
                  }}
                  placeholder="Chat in stream..."
                  className="flex-1 px-2 py-1 rounded-lg bg-white/10 border border-white/20 text-[11px] text-white placeholder:text-slate-400"
                />
                <button
                  onClick={() => {
                    if (!inlineChatInput.trim()) return;
                    onSendLiveChat(inlineChatInput.trim());
                    setInlineChatInput('');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-[#FF5722] text-white text-[10px] font-extrabold"
                >
                  <Send className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* STREAM TITLE & DESCRIPTION BOTTOM BAR */}
        {gamingState.isScreencasting && (
          <div className="absolute bottom-2.5 left-3 right-3 z-20 flex items-center justify-between flex-wrap gap-2 bg-black/85 backdrop-blur-md px-3.5 py-2 rounded-xl border border-white/15 text-white">
            <div className="min-w-0">
              <div className="text-xs font-extrabold text-[#FFB300] truncate">
                {gamingState.streamCustomTitle || gamingState.selectedGameName}
              </div>
              <div className="text-[10px] text-slate-300 truncate">
                {gamingState.streamCustomDescription ||
                  'Screen Sharing Live • 3D Avatar Lip-Sync & Real-Time Subscriber Alerts'}
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={onPublishHighlightToFeed}
                className="fism-btn-primary px-3 py-1.5 rounded-lg text-[11px] font-extrabold flex items-center gap-1"
              >
                <Share2 className="w-3.5 h-3.5" /> Share
              </button>
              <button
                onClick={onStopScreencast}
                className="px-3 py-1.5 rounded-lg bg-[#DC2626] text-white text-[11px] font-extrabold flex items-center gap-1"
              >
                <X className="w-3.5 h-3.5" /> End Live
              </button>
            </div>
          </div>
        )}
      </div>

      {/* SP COIN SUPER CHAT BOXES, SUPER STICKERS (50 SP), & 500 SP CHANNEL MEMBERSHIP */}
      <div className="rounded-2xl bg-[#101426] text-white border border-white/15 p-4 space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3 border-b border-white/15 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#FFB300]/20 border border-[#FFB300]/40 flex items-center justify-center text-[#FFB300]">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-extrabold text-[#FFB300] uppercase tracking-wider">
                SP Coins · Super Chat &amp; Super Stickers
              </div>
              <div className="text-sm font-black tabular-nums">
                Balance: {userSpCoins.toLocaleString()} SP Coins
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {onJoinHostMembership && (
              <button
                type="button"
                onClick={() => onJoinHostMembership()}
                disabled={isHostMember}
                className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 ${
                  isHostMember
                    ? 'bg-[#16A34A] text-white'
                    : 'bg-[#7C3AED] hover:bg-[#6D28D9] text-white'
                }`}
              >
                <Crown className="w-4 h-4" />
                {isHostMember
                  ? '✓ Channel Member Linked'
                  : `Join Membership (${CHANNEL_MEMBERSHIP_SP_COST} SP)`}
              </button>
            )}
            {onOpenBuySpCoins && (
              <button
                type="button"
                onClick={onOpenBuySpCoins}
                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#FFB300] text-[#0B0E17] text-xs font-black"
              >
                + Buy SP Coins
              </button>
            )}
          </div>
        </div>

        {/* 1. SUPER CHAT BOX STYLES + SEND */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="space-y-2.5 bg-white/5 p-3.5 rounded-2xl border border-white/10">
            <div className="text-xs font-extrabold text-white">
              💬 Super Chat Box ({SP_SUPER_CHAT_COST} SP Coins)
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {SUPER_CHAT_BOX_TIERS.map((tier) => (
                <button
                  key={tier.id}
                  type="button"
                  onClick={() => setSelectedSuperBoxStyle(tier.id)}
                  className={`px-2 py-2 rounded-xl text-[11px] font-black ${tier.cardClass} border-2 transition-all ${
                    selectedSuperBoxStyle === tier.id
                      ? 'border-white scale-[1.03] shadow-lg'
                      : 'border-transparent opacity-75 hover:opacity-100'
                  }`}
                >
                  {tier.label}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={superChatMessage}
                onChange={(e) => setSuperChatMessage(e.target.value)}
                placeholder="Type highlighted Super Chat message..."
                className="flex-1 px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-xs text-white"
              />
              <button
                type="button"
                onClick={async () => {
                  if (!onSendSuperChat) return;
                  const ok = await onSendSuperChat({
                    kind: 'superchat',
                    text: superChatMessage.trim() || '🔥 Let’s Go On Fire!',
                    boxStyle: selectedSuperBoxStyle,
                  });
                  if (ok) setSuperChatMessage('');
                }}
                className="min-h-[40px] px-4 py-2 rounded-xl fism-gradient-flame text-white text-xs font-black shrink-0 tabular-nums"
              >
                Send ({SP_SUPER_CHAT_COST} SP)
              </button>
            </div>
          </div>

          {/* 2. SUPER STICKERS (50 SP EACH) */}
          <div className="space-y-2.5 bg-white/5 p-3.5 rounded-2xl border border-white/10">
            <div className="text-xs font-extrabold text-white">
              🎯 Super Stickers ({SP_SUPER_CHAT_COST} SP Coins each)
            </div>
            <div className="grid grid-cols-3 gap-2">
              {SUPER_STICKER_OPTIONS.map((stk) => (
                <button
                  key={stk.id}
                  type="button"
                  onClick={() =>
                    onSendSuperChat?.({
                      kind: 'sticker',
                      boxStyle: selectedSuperBoxStyle,
                      stickerId: stk.id,
                      stickerLabel: stk.label,
                      stickerEmoji: stk.emoji,
                    })
                  }
                  className={`p-2 rounded-xl bg-gradient-to-br ${stk.cardGradient} hover:brightness-110 border border-white/20 flex flex-col items-center gap-0.5 text-center transition-all`}
                >
                  <span className="text-xl">{stk.emoji}</span>
                  <span className="text-[10px] font-extrabold text-white truncate w-full">
                    {stk.label}
                  </span>
                  <span className="text-[9px] font-black text-[#FDE047] tabular-nums">
                    {SP_SUPER_CHAT_COST} SP
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface FloatingGamingOverlayProps {
  gamingState: GamingLiveState;
  setGamingState: React.Dispatch<React.SetStateAction<GamingLiveState>>;
  onOpenOnFireScreen: () => void;
  onStopLiveAndHideAll?: () => void;
  faceSelectorOpen: boolean;
  setFaceSelectorOpen: React.Dispatch<React.SetStateAction<boolean>>;
  onToggleFloatingPip: () => Promise<void>;
  triggerToast: (msg: string) => void;
  custom3DModels?: Face3DModelPreset[];
}

export const FismFloatingGamingLiveOverlay: React.FC<FloatingGamingOverlayProps> = ({
  gamingState,
  setGamingState,
  onOpenOnFireScreen,
  onStopLiveAndHideAll,
  faceSelectorOpen,
  setFaceSelectorOpen,
  onToggleFloatingPip,
  triggerToast,
  custom3DModels = [],
}) => {
  const [ballPos, setBallPos] = useState<{ x: number; y: number }>({ x: 20, y: 120 });
  const [isDraggingBall, setIsDraggingBall] = useState(false);
  const dragOffsetRef = useRef<{ dx: number; dy: number }>({ dx: 0, dy: 0 });
  const longPressTimerRef = useRef<number | null>(null);
  const [radialMenuOpen, setRadialMenuOpen] = useState(false);

  // Face Cam + 3D Avatar + Webcam Head/Pose Tracking + OS Picture-in-Picture refs
  const faceVideoRef = useRef<HTMLVideoElement | null>(null);
  const faceCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const pipFloatingVideoRef = useRef<HTMLVideoElement | null>(null);
  const pipStreamInitializedRef = useRef<boolean>(false);
  const [isOsPipActive, setIsOsPipActive] = useState<boolean>(false);
  const motionSampleCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const faceStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const micVolumeRef = useRef<number>(0);
  const trackedHeadYawRef = useRef<number>(0);
  const trackedHeadPitchRef = useRef<number>(0);

  // 3D Face Modal search & category
  const [faceSearchQuery, setFaceSearchQuery] = useState('');
  const [faceCategory, setFaceCategory] = useState<'All' | Face3DModelPreset['category']>('All');

  const allAvailableModels = useMemo(
    () => [...INITIAL_4_3D_FACE_MODELS, ...custom3DModels],
    [custom3DModels],
  );

  const activeModel = useMemo(
    () =>
      allAvailableModels.find((m) => m.id === gamingState.active3DFaceModelId) ||
      allAvailableModels[0],
    [allAvailableModels, gamingState.active3DFaceModelId],
  );

  const filteredFaceModels = useMemo(() => {
    return allAvailableModels.filter((m) => {
      if (faceCategory !== 'All' && m.category !== faceCategory) return false;
      if (!faceSearchQuery.trim()) return true;
      const q = faceSearchQuery.toLowerCase();
      return (
        m.name.toLowerCase().includes(q) ||
        m.category.toLowerCase().includes(q) ||
        m.tagline.toLowerCase().includes(q) ||
        m.badgeText.toLowerCase().includes(q)
      );
    });
  }, [allAvailableModels, faceCategory, faceSearchQuery]);

  // Start / Stop Front Camera & Microphone Audio Analyser when FaceCam or Mic changes
  useEffect(() => {
    let active = true;

    async function syncMediaDevices() {
      const shouldRunMedia =
        (gamingState.isScreencasting || gamingState.isFloatingBallActive) &&
        (gamingState.isFaceCamEnabled || gamingState.isMicEnabled);
      if (shouldRunMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: gamingState.isFaceCamEnabled
              ? { facingMode: 'user', width: 320, height: 320 }
              : false,
            audio: gamingState.isMicEnabled,
          });
          if (!active) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          faceStreamRef.current = stream;
          if (faceVideoRef.current && gamingState.isFaceCamEnabled) {
            faceVideoRef.current.srcObject = stream;
            await faceVideoRef.current.play().catch(() => {});
          }

          if (gamingState.isMicEnabled && stream.getAudioTracks().length > 0) {
            const AudioCtx =
              window.AudioContext ||
              (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
            const audioCtx = new AudioCtx();
            const source = audioCtx.createMediaStreamSource(stream);
            const analyser = audioCtx.createAnalyser();
            analyser.fftSize = 64;
            source.connect(analyser);
            audioContextRef.current = audioCtx;
            analyserRef.current = analyser;
          }
        } catch {
          // If camera/mic permission denied in preview iframe, keep 3D Face Cam running with synthetic voice & head tracking
        }
      } else {
        if (faceStreamRef.current) {
          faceStreamRef.current.getTracks().forEach((t) => t.stop());
          faceStreamRef.current = null;
        }
      }
    }

    syncMediaDevices();

    return () => {
      active = false;
    };
  }, [
    gamingState.isScreencasting,
    gamingState.isFloatingBallActive,
    gamingState.isFaceCamEnabled,
    gamingState.isMicEnabled,
  ]);

  // 60 FPS 3D Face Avatar Render Loop with Real-Time Webcam Centroid Head Tracking + Lip-Sync
  useEffect(() => {
    if (
      !gamingState.isFaceCamEnabled ||
      (!gamingState.isScreencasting && !gamingState.isFloatingBallActive)
    )
      return;
    let animId = 0;
    let tick = 0;
    const dataArray = new Uint8Array(32);

    if (!motionSampleCanvasRef.current) {
      const c = document.createElement('canvas');
      c.width = 32;
      c.height = 32;
      motionSampleCanvasRef.current = c;
    }

    const renderLoop = () => {
      tick += 1;
      if (analyserRef.current && gamingState.isMicEnabled) {
        analyserRef.current.getByteFrequencyData(dataArray);
        const avg = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
        micVolumeRef.current = Math.min(1, avg / 95);
      } else if (gamingState.isMicEnabled) {
        micVolumeRef.current = (Math.sin(tick * 0.25) + 1) * 0.28;
      } else {
        micVolumeRef.current = 0;
      }

      // Compute real-time face direction (headYaw & headPitch) from front webcam video if available
      const vid = faceVideoRef.current;
      const sampleCanvas = motionSampleCanvasRef.current;
      if (vid && vid.readyState >= 2 && sampleCanvas && tick % 3 === 0) {
        const sCtx = sampleCanvas.getContext('2d');
        if (sCtx) {
          sCtx.drawImage(vid, 0, 0, 32, 32);
          const frame = sCtx.getImageData(0, 0, 32, 32).data;
          let sumX = 0;
          let sumY = 0;
          let weightTotal = 0;
          for (let y = 4; y < 28; y++) {
            for (let x = 4; x < 28; x++) {
              const idx = (y * 32 + x) * 4;
              const lum = frame[idx] * 0.35 + frame[idx + 1] * 0.45 + frame[idx + 2] * 0.2;
              if (lum > 75) {
                sumX += x * lum;
                sumY += y * lum;
                weightTotal += lum;
              }
            }
          }
          if (weightTotal > 0) {
            const cx = sumX / weightTotal; // 0..32
            const cy = sumY / weightTotal; // 0..32
            // Mirror X so turning head left/right moves 3D model in same direction
            const targetYaw = Math.max(-1, Math.min(1, (16 - cx) / 7));
            const targetPitch = Math.max(-1, Math.min(1, (cy - 16) / 7));
            trackedHeadYawRef.current = trackedHeadYawRef.current * 0.75 + targetYaw * 0.25;
            trackedHeadPitchRef.current = trackedHeadPitchRef.current * 0.75 + targetPitch * 0.25;
          }
        }
      } else {
        trackedHeadYawRef.current = Math.sin(tick * 0.04) * 0.45;
        trackedHeadPitchRef.current = Math.cos(tick * 0.05) * 0.2;
      }

      const canvas = faceCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          draw3DAvatarFaceFrame(
            ctx,
            canvas.width,
            canvas.height,
            activeModel,
            tick,
            micVolumeRef.current,
            faceVideoRef.current,
            gamingState.renderMode3D,
            trackedHeadYawRef.current,
            trackedHeadPitchRef.current,
            gamingState.userPosture || 'standing',
          );
        }

        // Pre-warm OS-level Picture-in-Picture video stream so it can pop out across the entire screen anytime
        const pipVid = pipFloatingVideoRef.current;
        if (pipVid && !pipStreamInitializedRef.current && typeof canvas.captureStream === 'function') {
          try {
            const canvasStream = canvas.captureStream(30);
            pipVid.srcObject = canvasStream;
            (pipVid as HTMLVideoElement & { autoPictureInPicture?: boolean }).autoPictureInPicture =
              true;
            pipStreamInitializedRef.current = true;
            pipVid.play().catch(() => {});
          } catch {
            // ignore
          }
        }
      }
      animId = requestAnimationFrame(renderLoop);
    };

    animId = requestAnimationFrame(renderLoop);
    return () => {
      cancelAnimationFrame(animId);
      pipStreamInitializedRef.current = false;
    };
  }, [
    gamingState.isScreencasting,
    gamingState.isFloatingBallActive,
    gamingState.isFaceCamEnabled,
    gamingState.isMicEnabled,
    gamingState.renderMode3D,
    gamingState.userPosture,
    activeModel,
  ]);

  // Launch True Browser / OS-Level Floating Picture-in-Picture Window (floats across entire screen even when app/tab is cut or minimized)
  const launchFullScreenOsFloatingWindow = async () => {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setIsOsPipActive(false);
        triggerToast('Closed OS Full-Screen Floating Window (Returned to in-app floating view).');
        return;
      }

      const canvas = faceCanvasRef.current;
      const pipVid = pipFloatingVideoRef.current;
      if (canvas && pipVid && typeof canvas.captureStream === 'function') {
        if (!pipVid.srcObject) {
          pipVid.srcObject = canvas.captureStream(30);
        }
        (pipVid as HTMLVideoElement & { autoPictureInPicture?: boolean }).autoPictureInPicture =
          true;
        await pipVid.play().catch(() => {});

        if (pipVid.readyState < 1) {
          await new Promise<void>((resolve) => {
            const onLoaded = () => {
              pipVid.removeEventListener('loadedmetadata', onLoaded);
              resolve();
            };
            pipVid.addEventListener('loadedmetadata', onLoaded);
            setTimeout(resolve, 350);
          });
        }

        if (typeof pipVid.requestPictureInPicture === 'function') {
          await pipVid.requestPictureInPicture();
          setIsOsPipActive(true);
          triggerToast(
            '🪟 Full-Screen OS Floating Window Active! अब आप ऐप कट/मिनिमाइज करें या टैब बदलें, यह पूरी स्क्रीन के ऊपर फ्लोट करेगा!',
          );
          return;
        }
      }
      onToggleFloatingPip();
    } catch {
      onToggleFloatingPip();
    }
  };

  useEffect(() => {
    (
      window as unknown as { __fismLaunchOsFloatingPip?: () => Promise<void> }
    ).__fismLaunchOsFloatingPip = launchFullScreenOsFloatingWindow;
    return () => {
      delete (window as unknown as { __fismLaunchOsFloatingPip?: () => Promise<void> })
        .__fismLaunchOsFloatingPip;
    };
  });

  // Long-press & Drag handlers for both the Floating Face Cam AND the Circular Gend Ball
  const handleBallPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture?.(e.pointerId);
    dragOffsetRef.current = {
      dx: e.clientX - ballPos.x,
      dy: e.clientY - ballPos.y,
    };
    setIsDraggingBall(true);

    if (longPressTimerRef.current) window.clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = window.setTimeout(() => {
      setRadialMenuOpen((prev) => !prev);
      triggerToast(
        'Floating Screen Sharing Gend & 3D Cam Unlocked: Drag anywhere on screen!',
      );
    }, 420);
  };

  const handleBallPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingBall) return;
    const movedDist =
      Math.hypot(
        e.clientX - dragOffsetRef.current.dx - ballPos.x,
        e.clientY - dragOffsetRef.current.dy - ballPos.y,
      ) > 10;
    if (movedDist && longPressTimerRef.current) {
      window.clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    const nextX = Math.max(
      8,
      Math.min(window.innerWidth - 90, e.clientX - dragOffsetRef.current.dx),
    );
    const nextY = Math.max(
      68,
      Math.min(window.innerHeight - 100, e.clientY - dragOffsetRef.current.dy),
    );
    setBallPos({ x: nextX, y: nextY });
  };

  const handleBallPointerUp = () => {
    if (longPressTimerRef.current) {
      window.clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    setIsDraggingBall(false);
  };

  if (!gamingState.isFloatingBallActive && !gamingState.isScreencasting && !faceSelectorOpen) {
    return null;
  }

  return (
    <>
      {/* Hidden video element for front camera capture */}
      <video ref={faceVideoRef} muted playsInline className="hidden" />
      {/* Pre-warmed video element for OS-Level Full-Screen Picture-in-Picture Floating Window */}
      <video
        ref={pipFloatingVideoRef}
        muted
        playsInline
        autoPlay
        className="fixed -left-[9999px] top-0 w-48 h-48 opacity-0 pointer-events-none"
      />

      {/* 1. PERSISTENT FLOATING BALL ("GEND") + DRAGGABLE 3D FACE CAM + SCREEN SHARING CONTROLS */}
      {(gamingState.isFloatingBallActive || gamingState.isScreencasting) && (
        <div
          style={{ left: `${ballPos.x}px`, top: `${ballPos.y}px` }}
          className="fixed z-50 select-none touch-none"
        >
          {/* Floating Live Face Cam + 3D Character Avatar Window */}
          {gamingState.isFaceCamEnabled && (
            <div
              onPointerDown={handleBallPointerDown}
              onPointerMove={handleBallPointerMove}
              onPointerUp={handleBallPointerUp}
              title="Long-press & drag to move 3D Face Cam anywhere on screen"
              className="mb-2.5 w-52 rounded-2xl overflow-hidden bg-[#090D16] border-2 border-[#FF5722] shadow-2xl cursor-grab active:cursor-grabbing"
            >
              <div className="px-2 py-1 bg-black/90 flex items-center justify-between text-[9px] font-extrabold text-white gap-1">
                <span className="truncate text-[#FFB300] flex items-center gap-1">
                  <Move className="w-3 h-3 text-[#FF5722]" /> {isOsPipActive ? 'OS PiP ON' : 'Float'}
                </span>
                <div
                  className="flex items-center gap-1"
                  onPointerDown={(e) => e.stopPropagation()}
                >
                  <button
                    onClick={launchFullScreenOsFloatingWindow}
                    title="Pop-Out Full Screen Floating Window Outside Browser/App (OS PiP)"
                    className={`px-1.5 py-0.5 rounded text-[8.5px] font-black ${
                      isOsPipActive
                        ? 'bg-[#16A34A] text-white'
                        : 'bg-[#2563EB] text-white'
                    }`}
                  >
                    {isOsPipActive ? 'In-App' : '🪟 Full Screen'}
                  </button>
                  <button
                    onClick={onOpenOnFireScreen}
                    title="Edit Screen Layout in On Fire Studio"
                    className="px-1.5 py-0.5 rounded bg-[#FF5722] text-white text-[8.5px]"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => setFaceSelectorOpen(true)}
                    title="Change 3D Model"
                    className="px-1.5 py-0.5 rounded bg-white/15 text-white text-[8.5px]"
                  >
                    3D
                  </button>
                </div>
              </div>
              <canvas
                ref={faceCanvasRef}
                width={208}
                height={208}
                className="w-52 h-52 block pointer-events-none"
              />
            </div>
          )}

          {/* Long-Press Radial Quick Action Menu */}
          {radialMenuOpen && (
            <div className="mb-2.5 p-3 rounded-2xl bg-[#090D16]/95 backdrop-blur-xl border-2 border-[#FF5722] shadow-2xl w-64 space-y-2 text-white">
              <div className="flex items-center justify-between border-b border-white/10 pb-1.5">
                <span className="text-[11px] font-extrabold text-[#FFB300] flex items-center gap-1">
                  <Gamepad2 className="w-3.5 h-3.5" /> Screen Sharing Controls
                </span>
                <div className="flex items-center gap-1">
                  {onStopLiveAndHideAll && (
                    <button
                      onClick={() => {
                        setRadialMenuOpen(false);
                        onStopLiveAndHideAll();
                      }}
                      title="End Live & Hide Floating Ball"
                      className="px-2 py-0.5 rounded bg-[#DC2626] text-white text-[9px] font-extrabold"
                    >
                      End Live
                    </button>
                  )}
                  <button
                    onClick={() => setRadialMenuOpen(false)}
                    className="p-0.5 rounded hover:bg-white/10"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1.5">
                <button
                  onClick={() => {
                    setGamingState((prev) => ({ ...prev, isMicEnabled: !prev.isMicEnabled }));
                    triggerToast(
                      !gamingState.isMicEnabled
                        ? 'Microphone ON (Live Voice + 3D Lip-Sync Active)'
                        : 'Microphone Muted',
                    );
                  }}
                  className={`p-2 rounded-xl flex flex-col items-center gap-1 text-[10px] font-extrabold border ${
                    gamingState.isMicEnabled
                      ? 'bg-[#16A34A]/25 border-[#16A34A] text-emerald-300'
                      : 'bg-white/5 border-white/15 text-slate-300'
                  }`}
                >
                  {gamingState.isMicEnabled ? (
                    <Mic className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <MicOff className="w-4 h-4 text-rose-400" />
                  )}
                  <span>{gamingState.isMicEnabled ? 'Mic ON' : 'Mic OFF'}</span>
                </button>

                <button
                  onClick={() => {
                    setGamingState((prev) => ({
                      ...prev,
                      isFaceCamEnabled: !prev.isFaceCamEnabled,
                    }));
                  }}
                  className={`p-2 rounded-xl flex flex-col items-center gap-1 text-[10px] font-extrabold border ${
                    gamingState.isFaceCamEnabled
                      ? 'bg-[#FF5722]/25 border-[#FF5722] text-[#FFB300]'
                      : 'bg-white/5 border-white/15 text-slate-300'
                  }`}
                >
                  {gamingState.isFaceCamEnabled ? (
                    <Camera className="w-4 h-4 text-[#FF5722]" />
                  ) : (
                    <CameraOff className="w-4 h-4 text-slate-400" />
                  )}
                  <span>{gamingState.isFaceCamEnabled ? '3D Cam ON' : '3D Cam'}</span>
                </button>

                <button
                  onClick={() => {
                    setGamingState((prev) => ({ ...prev, isFaceCamEnabled: true }));
                    setFaceSelectorOpen(true);
                  }}
                  className="p-2 rounded-xl fism-gradient-flame text-white flex flex-col items-center gap-1 text-[10px] font-extrabold shadow"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>3D Models</span>
                </button>
              </div>

              <div className="flex items-center justify-between gap-1.5 pt-1">
                <button
                  onClick={launchFullScreenOsFloatingWindow}
                  className="flex-1 py-1.5 px-2 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-[10px] font-extrabold flex items-center justify-center gap-1 shadow"
                >
                  <PictureInPicture2 className="w-3.5 h-3.5 text-[#FFB300]" />{' '}
                  {isOsPipActive ? 'Close OS PiP' : 'Float Full Screen'}
                </button>
                <button
                  onClick={onOpenOnFireScreen}
                  className="flex-1 py-1.5 px-2 rounded-lg bg-[#FF5722] text-white text-[10px] font-extrabold flex items-center justify-center gap-1"
                >
                  <Sliders className="w-3.5 h-3.5" /> Edit Screen
                </button>
              </div>
            </div>
          )}

          {/* The Floating Ball ("Gend") Itself */}
          <div
            onPointerDown={handleBallPointerDown}
            onPointerMove={handleBallPointerMove}
            onPointerUp={handleBallPointerUp}
            onClick={() => setRadialMenuOpen((prev) => !prev)}
            title="Long-press or tap Floating Gend for Screen Sharing, Edit Screen & 3D Models"
            className="w-16 h-16 rounded-full fism-gradient-flame p-0.5 shadow-[0_0_25px_rgba(255,87,34,0.85)] cursor-grab active:cursor-grabbing relative flex items-center justify-center"
          >
            <div className="w-full h-full rounded-full bg-[#090D16] flex flex-col items-center justify-center text-white relative overflow-hidden">
              <Gamepad2 className="w-5 h-5 text-[#FF5722]" />
              <span className="text-[7.5px] font-black tracking-tighter text-[#FFB300] uppercase">
                {gamingState.isScreencasting ? 'SHARING' : 'GEND 3D'}
              </span>
              <div className="flex items-center gap-1 mt-0.5">
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    gamingState.isMicEnabled ? 'bg-emerald-400' : 'bg-rose-500'
                  }`}
                />
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    gamingState.isFaceCamEnabled ? 'bg-[#FFB300]' : 'bg-slate-600'
                  }`}
                />
              </div>
            </div>
            <span className="absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full bg-[#E53935] text-white text-[8px] font-black border border-white">
              HOLD
            </span>
          </div>
        </div>
      )}

      {/* 2. 3D CHARACTER MODEL SELECTOR MODAL (Starts with 4 Default Models + Admin Uploaded 3D Models!) */}
      {faceSelectorOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="fism-card max-w-4xl w-full max-h-[88vh] flex flex-col overflow-hidden border-2 border-[#FF5722]">
            <div className="p-4 fism-gradient-flame text-white flex items-center justify-between gap-3">
              <div>
                <h3 className="text-base sm:text-lg font-extrabold flex items-center gap-2">
                  <Sparkles className="w-5 h-5" /> 3D Character Model Selector ({allAvailableModels.length} Active Models)
                </h3>
                <p className="text-xs text-white/90">
                  4 Built-in Models (Raistar 3D, Star Bunny Bundle, Ajju Bhai, Mr. Bean) + Any 3D
                  Models uploaded by Admin in <strong>Admin File → 3D Models Upload</strong>!
                </p>
              </div>
              <button
                onClick={() => setFaceSelectorOpen(false)}
                className="p-1.5 rounded-xl bg-black/25 hover:bg-black/40 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 border-b border-[#D8E1F0] dark:border-slate-800 space-y-3 bg-white dark:bg-[#0F172A]">
              <div className="flex flex-col sm:flex-row gap-2.5">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-[#FF5722] absolute left-3.5 top-3 pointer-events-none" />
                  <input
                    type="text"
                    value={faceSearchQuery}
                    onChange={(e) => setFaceSearchQuery(e.target.value)}
                    placeholder="Search 3D models (Raistar, Bunny Bundle, Ajju Bhai, Mr. Bean, Admin uploads)..."
                    className="w-full pl-10 pr-4 py-2 rounded-xl bg-white dark:bg-slate-800 text-[#0F172A] dark:text-white border-2 border-[#CBD5E1] dark:border-slate-700 text-xs font-bold"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() =>
                      setGamingState((prev) => ({
                        ...prev,
                        userPosture: prev.userPosture === 'sitting' ? 'standing' : 'sitting',
                      }))
                    }
                    className="px-3 py-2 rounded-xl bg-[#101426] text-[#FFB300] border border-[#FF5722] text-xs font-extrabold"
                  >
                    Pose: {gamingState.userPosture === 'sitting' ? '🪑 Sitting' : '🧍 Standing'}
                  </button>
                  <button
                    onClick={() =>
                      setGamingState((prev) => ({
                        ...prev,
                        renderMode3D:
                          prev.renderMode3D === 'full-3d-avatar'
                            ? 'ar-mask-overlay'
                            : 'full-3d-avatar',
                      }))
                    }
                    className="px-3 py-2 rounded-xl fism-btn-primary text-xs font-extrabold"
                  >
                    {gamingState.renderMode3D === 'full-3d-avatar' ? 'Full 3D Rig' : 'AR Camera'}
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    'All',
                    'Gaming Legends',
                    'Comedy & Icons',
                    'Admin Custom 3D',
                  ] as const
                ).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setFaceCategory(cat)}
                    className={`px-3 py-1 rounded-lg text-xs font-extrabold ${
                      faceCategory === cat
                        ? 'bg-[#FF5722] text-white'
                        : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#0F172A] dark:text-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Grid of Active 3D Character Models */}
            <div className="p-4 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-3 bg-[#F8FAFE] dark:bg-[#090D16]">
              {filteredFaceModels.map((model) => {
                const isSelected = model.id === gamingState.active3DFaceModelId;
                return (
                  <div
                    key={model.id}
                    onClick={() => {
                      setGamingState((prev) => ({
                        ...prev,
                        active3DFaceModelId: model.id,
                        isFaceCamEnabled: true,
                      }));
                      triggerToast(
                        `3D Model Active: ${model.name} (Head Tracking + Posture + Lip-Sync Ready)`,
                      );
                      setFaceSelectorOpen(false);
                    }}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'border-[#FF5722] bg-[#FF5722]/10 shadow-md'
                        : 'border-[#D8E1F0] dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-[#FF5722]'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        style={{
                          background: `radial-gradient(circle at 30% 30%, ${model.primaryColor}, ${model.secondaryColor})`,
                          borderColor: model.accentColor,
                        }}
                        className="w-14 h-14 rounded-2xl border-2 flex flex-col items-center justify-center shrink-0 text-white shadow-inner"
                      >
                        <span className="text-[10px] font-black leading-none uppercase">3D</span>
                        <span className="text-[10px] font-extrabold mt-0.5">
                          {model.badgeText.slice(0, 5)}
                        </span>
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-extrabold truncate flex items-center gap-1.5">
                          <span>{model.name}</span>
                          {model.uploadedByAdmin && (
                            <span className="px-1.5 py-0.5 rounded bg-[#7C3AED] text-white text-[9px] font-black">
                              ADMIN 3D
                            </span>
                          )}
                          {isSelected && (
                            <CheckCircle2 className="w-4 h-4 text-[#16A34A] shrink-0" />
                          )}
                        </div>
                        <div className="text-[11px] font-bold text-[#FF5722]">{model.category}</div>
                        <div className="text-[11px] text-[#52607A] dark:text-slate-400 truncate">
                          {model.tagline}
                        </div>
                      </div>
                    </div>
                    <span className="px-3 py-1.5 rounded-xl fism-btn-primary text-xs font-extrabold shrink-0">
                      Select 3D
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
