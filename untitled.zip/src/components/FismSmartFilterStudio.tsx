import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Camera,
  Check,
  FolderOpen,
  Gamepad2,
  Image as ImageIcon,
  Layers,
  Lock,
  Pause,
  Play,
  RotateCw,
  Search,
  Sparkles,
  Trash2,
  Unlock,
  Upload,
  Video,
  X,
} from 'lucide-react';
import {
  FismArFilterAsset,
  FismCameraChromaPlacement,
  FismGameItem,
  FismSavedStudioFilter,
  FismStudioSmartFilterMode,
  GENERATED_ASSETS,
} from '../types';
import {
  applyChromaKeyToCanvas,
  createBuiltInChromaElementDataUrl,
  drawCoverFitted,
  InteractiveGreenScreenGameRuntime,
  SmartPersonSegmenter,
} from '../utils/smartFilterEngine';

export interface SmartFilterStudioState {
  mode: FismStudioSmartFilterMode;
  activePresetId?: string | null;
  // 1. Photo Filter
  photoBgUrl: string;
  photoBgName: string;
  segSensitivity: number;
  // 2. Camera Filter (Custom Chroma-Key Element Placement)
  elementUrl: string;
  elementType: 'image' | 'video';
  elementName: string;
  chromaColor: string;
  chromaSensitivity: number;
  chromaSmoothness: number;
  autoSampleCorner: boolean;
  placement: FismCameraChromaPlacement;
  // 3. Game Filter (Green Screen / Interactive Gameplay + Live Camera)
  selectedGameId: string;
  selectedGameName: string;
  gameEngineType: FismGameItem['engineType'];
  gameAssetUrl: string;
  gameAssetType: 'engine' | 'image' | 'video';
  gameFolderName: string;
  gameChromaColor: string;
  gameChromaSensitivity: number;
  gameChromaSmoothness: number;
}

export const DEFAULT_SMART_FILTER_STATE: SmartFilterStudioState = {
  mode: 'off',
  activePresetId: null,
  photoBgUrl: GENERATED_ASSETS.studioThumb,
  photoBgName: 'Booyah Studio Scene',
  segSensitivity: 58,
  elementUrl: '',
  elementType: 'image',
  elementName: '',
  chromaColor: '#00FF00',
  chromaSensitivity: 48,
  chromaSmoothness: 28,
  autoSampleCorner: false,
  placement: { x: 0.5, y: 0.38, scale: 0.85, rotationDeg: 0, locked: false },
  selectedGameId: 'gs_starfighter_default',
  selectedGameName: 'Starfighter AR Blaster',
  gameEngineType: 'customAdmin2D',
  gameAssetUrl: '',
  gameAssetType: 'engine',
  gameFolderName: '',
  gameChromaColor: '#00FF00',
  gameChromaSensitivity: 56,
  gameChromaSmoothness: 24,
};

export function studioFilterPresetToState(
  flt: FismSavedStudioFilter,
  prev: SmartFilterStudioState = DEFAULT_SMART_FILTER_STATE,
): SmartFilterStudioState {
  return {
    ...prev,
    mode: flt.mode,
    activePresetId: flt.id,
    photoBgUrl: flt.photoBgUrl ?? prev.photoBgUrl,
    photoBgName: flt.mode === 'photo_bg' ? flt.name : prev.photoBgName,
    segSensitivity: flt.segSensitivity ?? prev.segSensitivity,
    elementUrl: flt.elementUrl ?? prev.elementUrl,
    elementType: flt.elementType ?? prev.elementType,
    elementName: flt.elementName ?? flt.name,
    chromaColor: flt.chromaColor ?? prev.chromaColor,
    chromaSensitivity: flt.chromaSensitivity ?? prev.chromaSensitivity,
    chromaSmoothness: flt.chromaSmoothness ?? prev.chromaSmoothness,
    placement: flt.placement ?? prev.placement,
    selectedGameId: flt.gameId ?? prev.selectedGameId,
    selectedGameName: flt.mode === 'game_chroma' ? flt.name : prev.selectedGameName,
    gameEngineType: flt.gameEngineType ?? prev.gameEngineType,
    gameAssetUrl: flt.gameAssetUrl ?? '',
    gameAssetType: flt.gameAssetType ?? 'engine',
    gameFolderName: flt.gameFolderName ?? '',
    gameChromaColor: flt.chromaColor ?? prev.gameChromaColor,
    gameChromaSensitivity: flt.chromaSensitivity ?? prev.gameChromaSensitivity,
    gameChromaSmoothness: flt.chromaSmoothness ?? prev.gameChromaSmoothness,
  };
}

interface FismSmartFilterViewportProps {
  open: boolean;
  state: SmartFilterStudioState;
  onUpdateState?: React.Dispatch<React.SetStateAction<SmartFilterStudioState>>;
  cameraVideoRef: React.RefObject<HTMLVideoElement | null>;
  compositeCanvasRef: React.RefObject<HTMLCanvasElement | null>;
  mirrorCamera: boolean;
  allowPlacementDrag?: boolean;
  onTriggerToast: (msg: string) => void;
  onStatusChange?: (status: {
    personDetected: boolean;
    segEngine: 'mediapipe' | 'adaptive';
    gameScore: number;
    gamePaused: boolean;
  }) => void;
  calibrateSignal?: number;
  gameActionSignal?: { seq: number; type: 'reset' | 'togglePause' };
}

export const FismSmartFilterViewport: React.FC<FismSmartFilterViewportProps> = ({
  open,
  state,
  onUpdateState,
  cameraVideoRef,
  compositeCanvasRef,
  mirrorCamera,
  allowPlacementDrag = false,
  onTriggerToast,
  onStatusChange,
  calibrateSignal = 0,
  gameActionSignal = { seq: 0, type: 'reset' },
}) => {
  const segmenterRef = useRef<SmartPersonSegmenter | null>(null);
  const gameRuntimeRef = useRef<InteractiveGreenScreenGameRuntime | null>(null);
  const chromaOffscreenRef = useRef<HTMLCanvasElement | null>(null);

  const bgImageElRef = useRef<HTMLImageElement | null>(null);
  const elementImgElRef = useRef<HTMLImageElement | null>(null);
  const elementVideoElRef = useRef<HTMLVideoElement | null>(null);
  const gameImgElRef = useRef<HTMLImageElement | null>(null);
  const gameVideoElRef = useRef<HTMLVideoElement | null>(null);

  const stateRef = useRef(state);
  stateRef.current = state;
  const mirrorRef = useRef(mirrorCamera);
  mirrorRef.current = mirrorCamera;

  const dragStateRef = useRef<{
    active: boolean;
    startClientX: number;
    startClientY: number;
    origX: number;
    origY: number;
  }>({ active: false, startClientX: 0, startClientY: 0, origX: 0.5, origY: 0.5 });

  useEffect(() => {
    if (!state.photoBgUrl) {
      bgImageElRef.current = null;
      return;
    }
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      bgImageElRef.current = img;
    };
    img.src = state.photoBgUrl;
  }, [state.photoBgUrl]);

  useEffect(() => {
    if (!state.elementUrl) {
      elementImgElRef.current = null;
      if (elementVideoElRef.current) {
        elementVideoElRef.current.pause();
        elementVideoElRef.current = null;
      }
      return;
    }
    if (state.elementType === 'video') {
      elementImgElRef.current = null;
      const vid = document.createElement('video');
      vid.crossOrigin = 'anonymous';
      vid.src = state.elementUrl;
      vid.loop = true;
      vid.muted = true;
      vid.playsInline = true;
      vid.autoplay = true;
      vid.play().catch(() => {});
      elementVideoElRef.current = vid;
      return () => {
        vid.pause();
      };
    } else {
      if (elementVideoElRef.current) {
        elementVideoElRef.current.pause();
        elementVideoElRef.current = null;
      }
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        elementImgElRef.current = img;
      };
      img.src = state.elementUrl;
    }
  }, [state.elementUrl, state.elementType]);

  useEffect(() => {
    if (state.gameAssetType === 'engine' || !state.gameAssetUrl) {
      gameImgElRef.current = null;
      if (gameVideoElRef.current) {
        gameVideoElRef.current.pause();
        gameVideoElRef.current = null;
      }
      return;
    }
    if (state.gameAssetType === 'video') {
      gameImgElRef.current = null;
      const vid = document.createElement('video');
      vid.crossOrigin = 'anonymous';
      vid.src = state.gameAssetUrl;
      vid.loop = true;
      vid.muted = true;
      vid.playsInline = true;
      vid.autoplay = true;
      vid.play().catch(() => {});
      gameVideoElRef.current = vid;
      return () => {
        vid.pause();
      };
    } else {
      if (gameVideoElRef.current) {
        gameVideoElRef.current.pause();
        gameVideoElRef.current = null;
      }
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        gameImgElRef.current = img;
      };
      img.src = state.gameAssetUrl;
    }
  }, [state.gameAssetUrl, state.gameAssetType]);

  useEffect(() => {
    if (!gameRuntimeRef.current) {
      gameRuntimeRef.current = new InteractiveGreenScreenGameRuntime(360, 640);
    }
    gameRuntimeRef.current.reset(
      state.gameEngineType,
      state.selectedGameName || 'FISM AR Game',
    );
  }, [state.selectedGameId, state.gameEngineType, state.selectedGameName]);

  useEffect(() => {
    if (calibrateSignal <= 0) return;
    const vid = cameraVideoRef.current;
    if (vid && segmenterRef.current) {
      const ok = segmenterRef.current.calibrateEmptyBackground(vid);
      if (ok) {
        onTriggerToast('Empty background calibrated! Step into frame to test cutout.');
      }
    }
  }, [calibrateSignal]);

  useEffect(() => {
    if (gameActionSignal.seq <= 0 || !gameRuntimeRef.current) return;
    if (gameActionSignal.type === 'reset') {
      gameRuntimeRef.current.reset(
        stateRef.current.gameEngineType,
        stateRef.current.selectedGameName || 'FISM AR Game',
      );
      onTriggerToast('Game restarted!');
    } else if (gameActionSignal.type === 'togglePause') {
      gameRuntimeRef.current.isPaused = !gameRuntimeRef.current.isPaused;
    }
  }, [gameActionSignal]);

  useEffect(() => {
    if (!open || state.mode !== 'game_chroma' || state.gameAssetType !== 'engine') return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', ' '].includes(e.key)) {
        const activeTag = document.activeElement?.tagName;
        if (activeTag === 'INPUT' || activeTag === 'TEXTAREA') return;
        gameRuntimeRef.current?.handleKey(e.key);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, state.mode, state.gameAssetType]);

  useEffect(() => {
    if (!open || state.mode === 'off') return;

    if (!segmenterRef.current) {
      segmenterRef.current = new SmartPersonSegmenter();
    }
    if (!chromaOffscreenRef.current) {
      chromaOffscreenRef.current = document.createElement('canvas');
    }
    if (!gameRuntimeRef.current) {
      gameRuntimeRef.current = new InteractiveGreenScreenGameRuntime(360, 640);
    }

    let rafId = 0;
    let lastFrameMs = 0;
    let lastStatusPush = 0;

    const tick = (now: number) => {
      rafId = requestAnimationFrame(tick);
      if (now - lastFrameMs < 32) return;
      lastFrameMs = now;

      const canvas = compositeCanvasRef.current;
      const vid = cameraVideoRef.current;
      if (!canvas) return;

      const rect = canvas.getBoundingClientRect();
      const targetW = Math.max(320, Math.min(720, Math.round(rect.width || 420)));
      const targetH = Math.max(240, Math.min(1080, Math.round(rect.height || 640)));
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const cur = stateRef.current;
      const vidReady = Boolean(vid && vid.readyState >= 2 && vid.videoWidth > 0);

      if (cur.mode === 'photo_bg') {
        const bgEl = bgImageElRef.current;
        const seg = segmenterRef.current!.segmentAndComposite(
          ctx,
          targetW,
          targetH,
          vidReady ? vid : null,
          bgEl,
          bgEl?.naturalWidth || 0,
          bgEl?.naturalHeight || 0,
          cur.segSensitivity,
          mirrorRef.current,
        );
        if (now - lastStatusPush > 240) {
          lastStatusPush = now;
          onStatusChange?.({
            personDetected: seg.personDetected,
            segEngine: seg.engine,
            gameScore: 0,
            gamePaused: false,
          });
        }
        return;
      }

      ctx.clearRect(0, 0, targetW, targetH);
      if (vidReady && vid) {
        drawCoverFitted(
          ctx,
          vid,
          vid.videoWidth,
          vid.videoHeight,
          targetW,
          targetH,
          mirrorRef.current,
        );
      } else {
        const bgGrad = ctx.createLinearGradient(0, 0, 0, targetH);
        bgGrad.addColorStop(0, '#0F172A');
        bgGrad.addColorStop(1, '#1E293B');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, targetW, targetH);
        ctx.fillStyle = 'rgba(255,255,255,0.48)';
        ctx.font = '700 13px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Live Camera Feed', targetW / 2, targetH / 2);
      }

      if (cur.mode === 'camera_chroma') {
        const srcEl =
          cur.elementType === 'video' ? elementVideoElRef.current : elementImgElRef.current;
        const keyCanvas = chromaOffscreenRef.current!;
        if (srcEl) {
          const { ready } = applyChromaKeyToCanvas(srcEl, keyCanvas, {
            keyColorHex: cur.chromaColor,
            sensitivity: cur.chromaSensitivity,
            smoothness: cur.chromaSmoothness,
            spillSuppression: 75,
            autoSampleCorner: cur.autoSampleCorner,
          });
          if (ready && keyCanvas.width > 0 && keyCanvas.height > 0) {
            const baseBox = Math.min(targetW, targetH) * 0.48 * cur.placement.scale;
            const aspect = keyCanvas.width / keyCanvas.height;
            const drawW = aspect >= 1 ? baseBox : baseBox * aspect;
            const drawH = aspect >= 1 ? baseBox / aspect : baseBox;
            ctx.save();
            ctx.translate(cur.placement.x * targetW, cur.placement.y * targetH);
            ctx.rotate((cur.placement.rotationDeg * Math.PI) / 180);
            ctx.drawImage(keyCanvas, -drawW / 2, -drawH / 2, drawW, drawH);
            ctx.restore();
          }
        }
      } else if (cur.mode === 'game_chroma') {
        const keyCanvas = chromaOffscreenRef.current!;
        let src: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement | null = null;
        if (cur.gameAssetType === 'engine') {
          src = gameRuntimeRef.current!.stepAndRender(now);
        } else if (cur.gameAssetType === 'video') {
          src = gameVideoElRef.current;
        } else {
          src = gameImgElRef.current;
        }

        if (src) {
          const { ready } = applyChromaKeyToCanvas(
            src,
            keyCanvas,
            {
              keyColorHex: cur.gameChromaColor,
              sensitivity: cur.gameChromaSensitivity,
              smoothness: cur.gameChromaSmoothness,
              spillSuppression: 80,
            },
            440,
          );
          if (ready) {
            ctx.drawImage(keyCanvas, 0, 0, targetW, targetH);
          }
        }

        if (now - lastStatusPush > 240) {
          lastStatusPush = now;
          onStatusChange?.({
            personDetected: true,
            segEngine: 'adaptive',
            gameScore: gameRuntimeRef.current?.score || 0,
            gamePaused: Boolean(gameRuntimeRef.current?.isPaused),
          });
        }
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [open, state.mode]);

  useEffect(() => {
    return () => {
      segmenterRef.current?.dispose();
    };
  }, []);

  if (!open || state.mode === 'off') return null;

  const canDragElement =
    allowPlacementDrag &&
    state.mode === 'camera_chroma' &&
    !state.placement.locked &&
    Boolean(state.elementUrl);

  const handleViewportPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / Math.max(1, rect.width);
    const ny = (e.clientY - rect.top) / Math.max(1, rect.height);

    if (canDragElement) {
      e.currentTarget.setPointerCapture?.(e.pointerId);
      dragStateRef.current = {
        active: true,
        startClientX: e.clientX,
        startClientY: e.clientY,
        origX: state.placement.x,
        origY: state.placement.y,
      };
    } else if (state.mode === 'game_chroma' && state.gameAssetType === 'engine') {
      gameRuntimeRef.current?.handlePointer(nx, ny, true);
    }
  };

  const handleViewportPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    if (canDragElement && dragStateRef.current.active && onUpdateState) {
      const dx = (e.clientX - dragStateRef.current.startClientX) / Math.max(1, rect.width);
      const dy = (e.clientY - dragStateRef.current.startClientY) / Math.max(1, rect.height);
      const nextX = Math.max(0.08, Math.min(0.92, dragStateRef.current.origX + dx));
      const nextY = Math.max(0.1, Math.min(0.88, dragStateRef.current.origY + dy));
      onUpdateState((prev) => ({
        ...prev,
        placement: { ...prev.placement, x: nextX, y: nextY },
      }));
    } else if (
      state.mode === 'game_chroma' &&
      state.gameAssetType === 'engine' &&
      e.buttons > 0
    ) {
      const nx = (e.clientX - rect.left) / Math.max(1, rect.width);
      const ny = (e.clientY - rect.top) / Math.max(1, rect.height);
      gameRuntimeRef.current?.handlePointer(nx, ny, false);
    }
  };

  const handleViewportPointerUp = () => {
    dragStateRef.current.active = false;
  };

  return (
    <div
      onPointerDown={handleViewportPointerDown}
      onPointerMove={handleViewportPointerMove}
      onPointerUp={handleViewportPointerUp}
      onPointerCancel={handleViewportPointerUp}
      className={`absolute inset-0 z-12 select-none touch-none ${
        canDragElement
          ? 'cursor-move'
          : state.mode === 'game_chroma'
            ? 'cursor-crosshair'
            : ''
      }`}
    >
      <canvas ref={compositeCanvasRef} className="w-full h-full block" />

      {/* Edit Bounding Guide shown ONLY inside Admin Builder when unlocked */}
      {canDragElement && (
        <div
          style={{
            left: `${state.placement.x * 100}%`,
            top: `${state.placement.y * 100}%`,
            transform: `translate(-50%, -50%) rotate(${state.placement.rotationDeg}deg)`,
            width: `${Math.round(130 * state.placement.scale)}px`,
            height: `${Math.round(130 * state.placement.scale)}px`,
          }}
          className="pointer-events-none absolute border-2 border-dashed border-[#00F5D4] rounded-2xl shadow-[0_0_0_1px_rgba(0,0,0,0.45)] flex items-end justify-center pb-1"
        >
          <span className="px-2 py-0.5 rounded bg-black/75 text-[10px] font-extrabold text-[#00F5D4]">
            Drag • Lock before Publish
          </span>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   1. ADMIN-ONLY SMART FILTER STUDIO BUILDER & LIVE TRY SANDBOX
   (Photo Filter, Camera Chroma Element Placement, Green-Screen Game Filter)
   ============================================================================ */
interface FismAdminSmartFilterBuilderProps {
  gamesList: FismGameItem[];
  publishedStudioFilters: FismSavedStudioFilter[];
  onPublishStudioFilter: (filter: FismSavedStudioFilter) => void;
  onDeleteStudioFilter: (id: string) => void;
  onTriggerToast: (msg: string) => void;
}

export const FismAdminSmartFilterBuilder: React.FC<FismAdminSmartFilterBuilderProps> = ({
  gamesList,
  publishedStudioFilters,
  onPublishStudioFilter,
  onDeleteStudioFilter,
  onTriggerToast,
}) => {
  const [studioState, setStudioState] = useState<SmartFilterStudioState>(() => ({
    ...DEFAULT_SMART_FILTER_STATE,
    mode: 'photo_bg',
  }));
  const [filterTitleInput, setFilterTitleInput] = useState('');
  const [camActive, setCamActive] = useState(false);
  const [camError, setCamError] = useState<string | null>(null);
  const [liveStatus, setLiveStatus] = useState<{
    personDetected: boolean;
    segEngine: 'mediapipe' | 'adaptive';
    gameScore: number;
    gamePaused: boolean;
  }>({
    personDetected: false,
    segEngine: 'adaptive',
    gameScore: 0,
    gamePaused: false,
  });
  const [calibrateSignal, setCalibrateSignal] = useState(0);
  const [gameActionSignal, setGameActionSignal] = useState<{
    seq: number;
    type: 'reset' | 'togglePause';
  }>({ seq: 0, type: 'reset' });

  const adminVideoRef = useRef<HTMLVideoElement | null>(null);
  const adminCompositeCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const adminStreamRef = useRef<MediaStream | null>(null);

  const startAdminSandboxCamera = async () => {
    setCamError(null);
    try {
      if (adminStreamRef.current) {
        adminStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } },
        audio: false,
      });
      adminStreamRef.current = stream;
      setCamActive(true);
      setTimeout(() => {
        if (adminVideoRef.current) {
          adminVideoRef.current.srcObject = stream;
          adminVideoRef.current.play().catch(() => {});
        }
      }, 60);
    } catch {
      setCamActive(false);
      setCamError(
        'Camera permission unavailable — Live Game & Overlay preview still runs directly in the Try Sandbox!',
      );
    }
  };

  const stopAdminSandboxCamera = () => {
    if (adminStreamRef.current) {
      adminStreamRef.current.getTracks().forEach((t) => t.stop());
      adminStreamRef.current = null;
    }
    setCamActive(false);
  };

  useEffect(() => {
    return () => stopAdminSandboxCamera();
  }, []);

  const readFileAsDataUrl = (file: File, cb: (url: string) => void) => {
    if (file.size <= 3_500_000) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') cb(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      cb(URL.createObjectURL(file));
    }
  };

  const handleFolderOrGameFiles = (fileList: FileList | null, isFolder: boolean) => {
    const files = Array.from(fileList || []);
    if (files.length === 0) return;

    const mediaCandidate =
      files.find((f) => f.type.startsWith('video/')) ||
      files.find((f) => f.type.startsWith('image/'));

    const first = files[0];
    const relPath =
      (first as File & { webkitRelativePath?: string }).webkitRelativePath || first.name;
    const folderName = isFolder ? relPath.split('/')[0] || 'Custom Game Folder' : first.name;

    if (mediaCandidate) {
      const isVid = mediaCandidate.type.startsWith('video/');
      readFileAsDataUrl(mediaCandidate, (url) => {
        setStudioState((prev) => ({
          ...prev,
          mode: 'game_chroma',
          selectedGameId: `admin_custom_game_${Date.now()}`,
          selectedGameName: folderName.replace(/\.[^/.]+$/, ''),
          gameAssetUrl: url,
          gameAssetType: isVid ? 'video' : 'image',
          gameFolderName: `${folderName} (${files.length} file${files.length > 1 ? 's' : ''})`,
        }));
        if (!filterTitleInput.trim()) {
          setFilterTitleInput(folderName.replace(/\.[^/.]+$/, ''));
        }
      });
      onTriggerToast(
        `Loaded ${mediaCandidate.name} into Admin Try Sandbox! Test live & click Publish Filter.`,
      );
      return;
    }

    const joinedNames = files.map((f) => f.name.toLowerCase()).join(' ');
    const inferredEngine: FismGameItem['engineType'] = joinedNames.includes('runner')
      ? 'flameRunner2D'
      : joinedNames.includes('brick')
        ? 'brickBreaker2D'
        : joinedNames.includes('snake')
          ? 'cyberSnake2D'
          : joinedNames.includes('ball')
            ? 'redBallDefense2D'
            : 'customAdmin2D';

    const cleanTitle = folderName.replace(/\.[^/.]+$/, '');
    setStudioState((prev) => ({
      ...prev,
      mode: 'game_chroma',
      selectedGameId: `admin_folder_${Date.now()}`,
      selectedGameName: cleanTitle,
      gameEngineType: inferredEngine,
      gameAssetUrl: '',
      gameAssetType: 'engine',
      gameFolderName: `${folderName} (${files.length} files)`,
    }));
    if (!filterTitleInput.trim()) setFilterTitleInput(cleanTitle);
    onTriggerToast(`Loaded folder "${cleanTitle}" (${files.length} files) into Admin Try Sandbox!`);
  };

  const handlePublishToUsers = () => {
    if (studioState.mode === 'off') return;
    const trimmedTitle = filterTitleInput.trim();
    if (!trimmedTitle) {
      onTriggerToast('Please enter a Filter Title before uploading so users can search by title!');
      return;
    }

    const newPreset: FismSavedStudioFilter = {
      id: `studio_flt_${Date.now()}`,
      name: trimmedTitle.slice(0, 60),
      mode: studioState.mode,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      ...(studioState.mode === 'photo_bg'
        ? {
            photoBgUrl: studioState.photoBgUrl,
            segSensitivity: studioState.segSensitivity,
          }
        : {}),
      ...(studioState.mode === 'camera_chroma'
        ? {
            elementUrl: studioState.elementUrl,
            elementType: studioState.elementType,
            elementName: studioState.elementName || trimmedTitle,
            chromaColor: studioState.chromaColor,
            chromaSensitivity: studioState.chromaSensitivity,
            chromaSmoothness: studioState.chromaSmoothness,
            placement: studioState.placement,
          }
        : {}),
      ...(studioState.mode === 'game_chroma'
        ? {
            gameId: studioState.selectedGameId,
            gameEngineType: studioState.gameEngineType,
            gameAssetUrl: studioState.gameAssetUrl,
            gameAssetType: studioState.gameAssetType,
            gameFolderName: studioState.gameFolderName,
            chromaColor: studioState.gameChromaColor,
            chromaSensitivity: studioState.gameChromaSensitivity,
            chromaSmoothness: studioState.gameChromaSmoothness,
          }
        : {}),
    };

    onPublishStudioFilter(newPreset);
    setFilterTitleInput('');
  };

  return (
    <div className="fism-card p-6 border-2 border-[#FF5722] space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <span className="px-2.5 py-0.5 rounded bg-[#FF5722] text-white text-[10px] font-black uppercase">
            Admin-Only Filter Creation &amp; Live Try Studio
          </span>
          <h2 className="text-xl font-extrabold mt-1 flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#FF5722]" /> Photo BG, Chroma Element &amp;
            Green-Screen Game Filter Builder
          </h2>
          <p className="text-xs text-[#52607A]">
            Only Admins can build and upload filters here. Try and test every filter live in the
            Admin Sandbox below, set a clear Title, and publish so users can browse &amp; search by
            title in Camera!
          </p>
        </div>
        <span className="px-3 py-1 rounded-xl bg-[#16A34A]/15 text-[#16A34A] text-xs font-extrabold">
          {publishedStudioFilters.length} Smart Filters Live
        </span>
      </div>

      {/* Mode Switcher */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 bg-[#F1F5F9] dark:bg-slate-800 p-1.5 rounded-2xl">
        {[
          { id: 'photo_bg' as const, label: '1. Photo Filter (BG Cutout)', icon: ImageIcon },
          {
            id: 'camera_chroma' as const,
            label: '2. Camera Filter (Chroma / Drag / Lock)',
            icon: Layers,
          },
          {
            id: 'game_chroma' as const,
            label: '3. Green-Screen Game Filter',
            icon: Gamepad2,
          },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = studioState.mode === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setStudioState((prev) => ({
                  ...prev,
                  mode: tab.id,
                  ...(tab.id === 'camera_chroma' && !prev.elementUrl
                    ? {
                        elementUrl: createBuiltInChromaElementDataUrl('neon_wings'),
                        elementType: 'image' as const,
                        elementName: 'Cyber Neon Wings',
                      }
                    : {}),
                }));
              }}
              className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-colors ${
                active
                  ? 'fism-btn-primary shadow'
                  : 'text-[#52607A] dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-700'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Two-Column Builder: Left = Admin Live Try Sandbox, Right = Controls & Title Publish */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* LEFT: LIVE ADMIN TRY SANDBOX */}
        <div className="lg:col-span-6 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold flex items-center gap-1.5">
              <Camera className="w-4 h-4 text-[#00F5D4]" /> Admin Live Try Sandbox
            </h3>
            {!camActive ? (
              <button
                type="button"
                onClick={startAdminSandboxCamera}
                className="px-3 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
              >
                <Camera className="w-3.5 h-3.5" /> Start Live Test Camera
              </button>
            ) : (
              <button
                type="button"
                onClick={stopAdminSandboxCamera}
                className="px-3 py-1.5 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold"
              >
                Stop Camera
              </button>
            )}
          </div>

          <div className="relative w-full aspect-[4/5] max-h-[440px] rounded-2xl overflow-hidden bg-slate-950 border-2 border-[#FF5722] shadow-xl">
            <video
              ref={adminVideoRef}
              muted
              playsInline
              autoPlay
              className="w-full h-full object-cover opacity-0 pointer-events-none"
            />
            <FismSmartFilterViewport
              open={true}
              state={studioState}
              onUpdateState={setStudioState}
              cameraVideoRef={adminVideoRef}
              compositeCanvasRef={adminCompositeCanvasRef}
              mirrorCamera={true}
              allowPlacementDrag={true}
              onTriggerToast={onTriggerToast}
              onStatusChange={setLiveStatus}
              calibrateSignal={calibrateSignal}
              gameActionSignal={gameActionSignal}
            />
            {studioState.mode === 'photo_bg' && (
              <div className="pointer-events-none absolute top-3 left-3 z-20 px-3 py-1 rounded-xl bg-black/75 text-white text-[11px] font-bold">
                {liveStatus.personDetected
                  ? 'Person Detected: Cutout Active'
                  : 'No Person Detected: Clean Photo Shown'}
              </div>
            )}
            {studioState.mode === 'game_chroma' && studioState.gameAssetType === 'engine' && (
              <div className="pointer-events-none absolute bottom-3 left-3 z-20 px-3 py-1 rounded-xl bg-black/75 text-[#FFB300] text-[11px] font-extrabold">
                Live Test Active — Tap / Drag viewport to play game!
              </div>
            )}
          </div>
          {camError && <p className="text-[11px] font-bold text-[#F59E0B]">{camError}</p>}
        </div>

        {/* RIGHT: FILTER BUILDER CONTROLS & TITLE PUBLISH */}
        <div className="lg:col-span-6 p-4 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-4">
          {studioState.mode === 'photo_bg' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <label className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" /> Upload Scene Photo
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const clean = file.name.replace(/\.[^/.]+$/, '');
                        readFileAsDataUrl(file, (url) => {
                          setStudioState((prev) => ({
                            ...prev,
                            photoBgUrl: url,
                            photoBgName: clean,
                          }));
                          if (!filterTitleInput.trim()) setFilterTitleInput(clean);
                        });
                        onTriggerToast(`Loaded Photo BG "${clean}" in Try Sandbox!`);
                      }
                      e.target.value = '';
                    }}
                  />
                </label>

                <button
                  type="button"
                  onClick={() => setCalibrateSignal((s) => s + 1)}
                  className="min-h-[40px] px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                >
                  Calibrate Empty BG
                </button>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {[
                  { label: 'Neon Studio', url: GENERATED_ASSETS.studioThumb },
                  { label: 'Alpine Peak', url: GENERATED_ASSETS.mountainPost },
                  { label: 'Night Skyline', url: GENERATED_ASSETS.heroCover },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setStudioState((prev) => ({
                        ...prev,
                        photoBgUrl: preset.url,
                        photoBgName: preset.label,
                      }));
                      if (!filterTitleInput.trim()) setFilterTitleInput(preset.label);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border ${
                      studioState.photoBgUrl === preset.url
                        ? 'border-[#FF5722] bg-[#FF5722]/10 text-[#FF5722]'
                        : 'border-[#D8E1F0] dark:border-slate-700'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span>Segmentation Cutout Sensitivity</span>
                  <span>{studioState.segSensitivity}%</span>
                </div>
                <input
                  type="range"
                  min={15}
                  max={90}
                  value={studioState.segSensitivity}
                  onChange={(e) =>
                    setStudioState((prev) => ({
                      ...prev,
                      segSensitivity: Number(e.target.value),
                    }))
                  }
                  className="w-full accent-[#FF5722]"
                />
              </div>
            </div>
          )}

          {studioState.mode === 'camera_chroma' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 flex-wrap">
                <label className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" /> Upload Overlay (Green Screen / PNG / Video)
                  <input
                    type="file"
                    accept="image/*,video/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const isVid = file.type.startsWith('video/');
                        const clean = file.name.replace(/\.[^/.]+$/, '');
                        readFileAsDataUrl(file, (url) => {
                          setStudioState((prev) => ({
                            ...prev,
                            elementUrl: url,
                            elementType: isVid ? 'video' : 'image',
                            elementName: clean,
                            placement: { ...prev.placement, locked: false },
                          }));
                          if (!filterTitleInput.trim()) setFilterTitleInput(clean);
                        });
                        onTriggerToast(`Loaded "${clean}". Drag on sandbox, resize, rotate & lock!`);
                      }
                      e.target.value = '';
                    }}
                  />
                </label>

                <button
                  type="button"
                  onClick={() =>
                    setStudioState((prev) => ({
                      ...prev,
                      placement: { ...prev.placement, locked: !prev.placement.locked },
                    }))
                  }
                  className={`min-h-[40px] px-3 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 ${
                    studioState.placement.locked
                      ? 'bg-[#16A34A] text-white'
                      : 'bg-[#FFB300] text-slate-950'
                  }`}
                >
                  {studioState.placement.locked ? (
                    <>
                      <Lock className="w-3.5 h-3.5" /> Position Locked
                    </>
                  ) : (
                    <>
                      <Unlock className="w-3.5 h-3.5" /> Unlocked (Drag)
                    </>
                  )}
                </button>
              </div>

              <div className="flex items-center gap-1.5 flex-wrap">
                {[
                  { id: 'neon_wings' as const, label: 'Neon Wings (GS)' },
                  { id: 'flame_badge' as const, label: 'FISM Badge (GS)' },
                  { id: 'cyber_frame' as const, label: 'Creator HUD (GS)' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setStudioState((prev) => ({
                        ...prev,
                        elementUrl: createBuiltInChromaElementDataUrl(item.id),
                        elementType: 'image',
                        elementName: item.label,
                        chromaColor: '#00FF00',
                        chromaSensitivity: Math.max(35, prev.chromaSensitivity),
                      }));
                      if (!filterTitleInput.trim()) setFilterTitleInput(item.label);
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-bold"
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs font-bold">
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Size</span>
                    <span>{Math.round(studioState.placement.scale * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.25}
                    max={2.2}
                    step={0.05}
                    disabled={studioState.placement.locked}
                    value={studioState.placement.scale}
                    onChange={(e) =>
                      setStudioState((prev) => ({
                        ...prev,
                        placement: { ...prev.placement, scale: Number(e.target.value) },
                      }))
                    }
                    className="w-full accent-[#FFB300]"
                  />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="flex items-center gap-1">
                      <RotateCw className="w-3 h-3" /> Rotate
                    </span>
                    <span>{studioState.placement.rotationDeg}°</span>
                  </div>
                  <input
                    type="range"
                    min={-180}
                    max={180}
                    step={1}
                    disabled={studioState.placement.locked}
                    value={studioState.placement.rotationDeg}
                    onChange={(e) =>
                      setStudioState((prev) => ({
                        ...prev,
                        placement: { ...prev.placement, rotationDeg: Number(e.target.value) },
                      }))
                    }
                    className="w-full accent-[#FFB300]"
                  />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Green Screen Removal</span>
                    <span>{studioState.chromaSensitivity}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={studioState.chromaSensitivity}
                    onChange={(e) =>
                      setStudioState((prev) => ({
                        ...prev,
                        chromaSensitivity: Number(e.target.value),
                      }))
                    }
                    className="w-full accent-[#16A34A]"
                  />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Edge Smoothness</span>
                    <span>{studioState.chromaSmoothness}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={studioState.chromaSmoothness}
                    onChange={(e) =>
                      setStudioState((prev) => ({
                        ...prev,
                        chromaSmoothness: Number(e.target.value),
                      }))
                    }
                    className="w-full accent-[#16A34A]"
                  />
                </div>
              </div>
            </div>
          )}

          {studioState.mode === 'game_chroma' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 flex-wrap">
                <label className="min-h-[40px] px-3 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer">
                  <Video className="w-3.5 h-3.5" /> Open File (Game Asset)
                  <input
                    type="file"
                    accept="video/*,image/*,.html,.zip"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      handleFolderOrGameFiles(e.target.files, false);
                      e.target.value = '';
                    }}
                  />
                </label>

                <label className="min-h-[40px] px-3 py-2 rounded-xl bg-[#7C3AED] hover:bg-[#6D28D9] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer">
                  <FolderOpen className="w-3.5 h-3.5" /> Select Game Folder
                  <input
                    type="file"
                    multiple
                    {...({
                      webkitdirectory: '',
                      directory: '',
                    } as React.InputHTMLAttributes<HTMLInputElement>)}
                    className="hidden"
                    onChange={(e) => {
                      handleFolderOrGameFiles(e.target.files, true);
                      e.target.value = '';
                    }}
                  />
                </label>

                {studioState.gameAssetType === 'engine' && (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        setGameActionSignal((g) => ({ seq: g.seq + 1, type: 'togglePause' }))
                      }
                      className="min-h-[36px] px-2.5 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold flex items-center gap-1"
                    >
                      {liveStatus.gamePaused ? (
                        <>
                          <Play className="w-3.5 h-3.5" /> Resume
                        </>
                      ) : (
                        <>
                          <Pause className="w-3.5 h-3.5" /> Pause
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setGameActionSignal((g) => ({ seq: g.seq + 1, type: 'reset' }))
                      }
                      className="min-h-[36px] px-2.5 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                    >
                      Restart Test
                    </button>
                  </>
                )}
              </div>

              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-[#52607A]">
                  Or pick from Admin Uploaded Games ({gamesList.length}):
                </div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {gamesList.map((g) => (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        setStudioState((prev) => ({
                          ...prev,
                          selectedGameId: g.id,
                          selectedGameName: g.name,
                          gameEngineType: g.engineType,
                          gameAssetUrl: g.overlayMediaUrl || '',
                          gameAssetType:
                            g.overlayMediaType && g.overlayMediaUrl
                              ? g.overlayMediaType
                              : 'engine',
                          gameFolderName: g.folderName,
                          gameChromaColor: g.chromaColor || '#00FF00',
                          gameChromaSensitivity:
                            typeof g.chromaSensitivity === 'number' ? g.chromaSensitivity : 56,
                        }));
                        if (!filterTitleInput.trim()) setFilterTitleInput(g.name);
                      }}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border ${
                        studioState.selectedGameId === g.id
                          ? 'bg-[#FF5722]/15 border-[#FF5722] text-[#FF5722]'
                          : 'bg-white dark:bg-slate-800 border-[#D8E1F0] dark:border-slate-700'
                      }`}
                    >
                      {g.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs font-bold">
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Chroma Sensitivity</span>
                    <span>{studioState.gameChromaSensitivity}%</span>
                  </div>
                  <input
                    type="range"
                    min={10}
                    max={95}
                    value={studioState.gameChromaSensitivity}
                    onChange={(e) =>
                      setStudioState((prev) => ({
                        ...prev,
                        gameChromaSensitivity: Number(e.target.value),
                      }))
                    }
                    className="w-full accent-[#16A34A]"
                  />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Edge Smoothness</span>
                    <span>{studioState.gameChromaSmoothness}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={studioState.gameChromaSmoothness}
                    onChange={(e) =>
                      setStudioState((prev) => ({
                        ...prev,
                        gameChromaSmoothness: Number(e.target.value),
                      }))
                    }
                    className="w-full accent-[#16A34A]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Filter Title & Publish Action */}
          <div className="pt-3 border-t border-[#D8E1F0] dark:border-slate-800 space-y-2.5">
            <div>
              <label className="block text-xs font-extrabold mb-1">
                Filter Title (Users will search by this Title)
              </label>
              <input
                type="text"
                value={filterTitleInput}
                onChange={(e) => setFilterTitleInput(e.target.value)}
                placeholder="Enter Filter Title (e.g. Neon Studio BG, Wing Overlay, Starfighter Game)..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm font-bold"
              />
            </div>

            <button
              type="button"
              onClick={handlePublishToUsers}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#16A34A] to-[#0EA5E9] text-white text-xs sm:text-sm font-black flex items-center justify-center gap-2 shadow-lg hover:opacity-95 cursor-pointer"
            >
              <Upload className="w-4 h-4" /> Upload &amp; Publish Filter to All Users
            </button>
          </div>
        </div>
      </div>

      {/* Published Smart Filters Library (Admin can Test or Delete) */}
      <div className="pt-3 border-t border-[#D8E1F0] dark:border-slate-800 space-y-2.5">
        <div className="text-xs font-extrabold uppercase text-[#52607A]">
          Published Photo, Camera &amp; Game Filters ({publishedStudioFilters.length})
        </div>
        {publishedStudioFilters.length === 0 ? (
          <p className="text-xs text-[#52607A]">
            No custom Photo/Chroma/Game filters published yet. Configure above, try in Sandbox,
            enter a Title, and click Upload &amp; Publish!
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {publishedStudioFilters.map((flt) => (
              <div
                key={flt.id}
                className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <div className="text-xs font-extrabold truncate">{flt.name}</div>
                  <div className="text-[10px] text-[#52607A]">
                    {flt.mode === 'photo_bg'
                      ? 'Photo BG Filter'
                      : flt.mode === 'camera_chroma'
                        ? `Camera Chroma${flt.placement?.locked ? ' · Locked' : ''}`
                        : 'Green-Screen Game Filter'}{' '}
                    · {flt.createdAt}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setStudioState((prev) => studioFilterPresetToState(flt, prev));
                      setFilterTitleInput(flt.name);
                      onTriggerToast(`Loaded "${flt.name}" into Admin Sandbox to try!`);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-[#2563EB]/15 text-[#2563EB] text-[10px] font-extrabold"
                  >
                    Try
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteStudioFilter(flt.id)}
                    aria-label={`Delete ${flt.name}`}
                    className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-[#DC2626] hover:text-white text-slate-600 dark:text-slate-300"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

/* ============================================================================
   2. USER CAMERA FILTER BROWSER (READ-ONLY DISCOVERY + SEARCH BY TITLE + USE LIVE)
   Users CANNOT create/upload/edit filters — they browse ALL published Admin filters,
   search by Title, apply & play Game/Photo/AR filters, and Record Live!
   ============================================================================ */
interface FismUserFilterBrowserSheetProps {
  open: boolean;
  onClose: () => void;
  smartState: SmartFilterStudioState;
  publishedStudioFilters: FismSavedStudioFilter[];
  publishedArFilters: FismArFilterAsset[];
  activeArFilterId: string | null;
  onSelectArFilter: (filter: FismArFilterAsset | null) => void;
  onSelectStudioFilter: (filter: FismSavedStudioFilter | null) => void;
  liveStatus: {
    personDetected: boolean;
    segEngine: 'mediapipe' | 'adaptive';
    gameScore: number;
    gamePaused: boolean;
  };
  onGameReset: () => void;
  onGameTogglePause: () => void;
  isRecording: boolean;
  onToggleRecord: () => void;
}

export const FismUserFilterBrowserSheet: React.FC<FismUserFilterBrowserSheetProps> = ({
  open,
  onClose,
  smartState,
  publishedStudioFilters,
  publishedArFilters,
  activeArFilterId,
  onSelectArFilter,
  onSelectStudioFilter,
  liveStatus,
  onGameReset,
  onGameTogglePause,
  isRecording,
  onToggleRecord,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryTab, setCategoryTab] = useState<
    'all' | 'photo_bg' | 'camera_chroma' | 'game_chroma' | 'ar'
  >('all');

  const queryLower = searchQuery.trim().toLowerCase();

  const filteredStudio = useMemo(() => {
    return publishedStudioFilters.filter((f) => {
      const catMatch = categoryTab === 'all' || categoryTab === f.mode;
      const textMatch =
        !queryLower ||
        f.name.toLowerCase().includes(queryLower) ||
        (f.mode === 'photo_bg' && 'photo background'.includes(queryLower)) ||
        (f.mode === 'camera_chroma' && 'camera chroma'.includes(queryLower)) ||
        (f.mode === 'game_chroma' && 'game green screen'.includes(queryLower));
      return catMatch && textMatch;
    });
  }, [publishedStudioFilters, categoryTab, queryLower]);

  const filteredAr = useMemo(() => {
    return publishedArFilters.filter((f) => {
      if (!f.publishedToUsers) return false;
      const catMatch = categoryTab === 'all' || categoryTab === 'ar';
      const textMatch =
        !queryLower ||
        f.name.toLowerCase().includes(queryLower) ||
        f.badgeText.toLowerCase().includes(queryLower);
      return catMatch && textMatch;
    });
  }, [publishedArFilters, categoryTab, queryLower]);

  if (!open) return null;

  const hasActiveAny = smartState.mode !== 'off' || Boolean(activeArFilterId);

  return (
    <div className="absolute inset-x-0 bottom-0 z-40 bg-[#0D111C]/96 backdrop-blur-xl border-t border-white/15 rounded-t-3xl p-4 text-white space-y-3 max-h-[68vh] overflow-y-auto shadow-[0_-18px_45px_rgba(0,0,0,0.85)]">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Sparkles className="w-4 h-4 text-[#00F5D4] shrink-0" />
          <span className="font-extrabold text-sm truncate">
            All App Filters ({publishedStudioFilters.length + filteredAr.length})
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {hasActiveAny && (
            <>
              <button
                type="button"
                onClick={onToggleRecord}
                className={`min-h-[36px] px-3 rounded-xl text-xs font-extrabold flex items-center gap-1.5 ${
                  isRecording
                    ? 'bg-[#E53935] text-white animate-pulse'
                    : 'bg-[#FF5722] hover:bg-[#F4511E] text-white'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-white" />
                {isRecording ? 'Stop Rec' : 'Record Live'}
              </button>
              <button
                type="button"
                onClick={() => {
                  onSelectStudioFilter(null);
                  onSelectArFilter(null);
                }}
                className="min-h-[36px] px-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold"
              >
                Turn Off
              </button>
            </>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Filters Drawer"
            className="min-h-[36px] min-w-[36px] rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Search Bar by Filter Title */}
      <div className="relative">
        <Search className="w-4 h-4 text-white/50 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="search"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search filters by title..."
          className="w-full min-h-[42px] pl-10 pr-4 py-2 rounded-xl bg-black/55 border border-white/20 text-xs sm:text-sm text-white placeholder:text-white/50"
        />
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {[
          { id: 'all' as const, label: 'All Filters' },
          { id: 'photo_bg' as const, label: 'Photo BG' },
          { id: 'camera_chroma' as const, label: 'Chroma Effects' },
          { id: 'game_chroma' as const, label: 'Game Filters' },
          { id: 'ar' as const, label: 'AR Face' },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setCategoryTab(tab.id)}
            className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-extrabold shrink-0 transition-colors ${
              categoryTab === tab.id
                ? 'bg-[#FF5722] text-white'
                : 'bg-white/10 text-white/75 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Active Game Play Controls (Play / Pause / Restart only when using a Game Filter) */}
      {smartState.mode === 'game_chroma' && smartState.gameAssetType === 'engine' && (
        <div className="p-2.5 rounded-2xl bg-[#16A34A]/15 border border-[#16A34A]/40 flex items-center justify-between gap-2">
          <div className="text-xs font-bold text-[#86EFAC]">
            Playing: {smartState.selectedGameName} · Score {liveStatus.gameScore}
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onGameTogglePause}
              className="px-2.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-xs font-bold flex items-center gap-1"
            >
              {liveStatus.gamePaused ? (
                <>
                  <Play className="w-3 h-3" /> Resume
                </>
              ) : (
                <>
                  <Pause className="w-3 h-3" /> Pause
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onGameReset}
              className="px-2.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-xs font-bold"
            >
              Restart
            </button>
          </div>
        </div>
      )}

      {/* Search Results Grid */}
      {filteredStudio.length === 0 && filteredAr.length === 0 ? (
        <div className="p-6 text-center rounded-2xl bg-white/5 border border-white/10 text-xs text-white/65">
          {searchQuery.trim()
            ? `No filters found matching "${searchQuery}". Try another title!`
            : 'No filters available in this category yet.'}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {filteredStudio.map((flt) => {
            const isSelected = smartState.mode !== 'off' && smartState.activePresetId === flt.id;
            return (
              <button
                key={flt.id}
                type="button"
                onClick={() => {
                  if (isSelected) {
                    onSelectStudioFilter(null);
                  } else {
                    onSelectArFilter(null);
                    onSelectStudioFilter(flt);
                  }
                }}
                className={`min-h-[60px] p-2.5 rounded-2xl border text-left flex items-center gap-2.5 transition-all ${
                  isSelected
                    ? 'bg-[#00F5D4]/20 border-[#00F5D4] shadow-lg'
                    : 'bg-white/5 border-white/15 hover:bg-white/10'
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-black/45 border border-white/15 flex items-center justify-center shrink-0">
                  {flt.mode === 'photo_bg' ? (
                    <ImageIcon className="w-5 h-5 text-[#38BDF8]" />
                  ) : flt.mode === 'camera_chroma' ? (
                    <Layers className="w-5 h-5 text-[#FFB300]" />
                  ) : (
                    <Gamepad2 className="w-5 h-5 text-[#16A34A]" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-extrabold truncate">{flt.name}</div>
                  <div className="text-[10px] text-white/60 truncate">
                    {flt.mode === 'photo_bg'
                      ? 'Photo BG'
                      : flt.mode === 'camera_chroma'
                        ? 'Camera Effect'
                        : 'Game Filter'}
                  </div>
                </div>
                {isSelected && <Check className="w-4 h-4 text-[#00F5D4] shrink-0" />}
              </button>
            );
          })}

          {filteredAr.map((ar) => {
            const isSelected = activeArFilterId === ar.id && smartState.mode === 'off';
            return (
              <button
                key={ar.id}
                type="button"
                onClick={() => {
                  onSelectStudioFilter(null);
                  onSelectArFilter(isSelected ? null : ar);
                }}
                className={`min-h-[60px] p-2.5 rounded-2xl border text-left flex items-center gap-2.5 transition-all ${
                  isSelected
                    ? 'bg-[#00F5D4]/20 border-[#00F5D4] shadow-lg'
                    : 'bg-white/5 border-white/15 hover:bg-white/10'
                }`}
              >
                <div
                  className="w-10 h-10 rounded-xl border border-white/25 flex items-center justify-center shrink-0"
                  style={{
                    background: `linear-gradient(135deg, ${ar.primaryColor}, ${ar.secondaryColor})`,
                  }}
                >
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-extrabold truncate">{ar.name}</div>
                  <div className="text-[10px] text-white/60 truncate">{ar.badgeText}</div>
                </div>
                {isSelected && <Check className="w-4 h-4 text-[#00F5D4] shrink-0" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
