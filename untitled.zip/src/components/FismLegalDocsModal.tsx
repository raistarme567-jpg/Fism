import React, { useState } from 'react';
import {
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  FileText,
  Flame,
  Scale,
  ShieldCheck,
  X,
} from 'lucide-react';

interface LegalSection {
  id: string;
  number: string;
  title: string;
  plainSummary: string;
  clauses: { heading: string; body: string }[];
}

const LEGAL_SECTIONS: LegalSection[] = [
  {
    id: 'sec-1',
    number: '01',
    title: 'Acceptance of Terms & Eligibility (Age & Account Rules)',
    plainSummary:
      'By creating an account or browsing FISM, you agree to follow these rules, keep your password private, use honest identity details, and complete safety or age checks when prompted.',
    clauses: [
      {
        heading: '1.1 Agreement & Minimum Age',
        body: 'You must meet the minimum legal age required in your region (at least 13 years old, or the higher digital-consent age in your country) to register an account on FISM. Certain monetization, payout, and public-channel tools require AI-assisted or verified 18+ age verification.',
      },
      {
        heading: '1.2 Account Security, Profile & Private IDs',
        body: 'You are responsible for safeguarding your login credentials, secondary passwords, and any Sub-IDs created under your master profile. You may customize your display name, theme colors, bio, and set accounts to Private ID mode so only approved followers can view private posts.',
      },
      {
        heading: '1.3 AI-Assisted Age & Safety Verification',
        body: 'To protect younger creators and keep public discovery safe, FISM uses automated and AI-assisted checks during verification. Submitting falsified identity information or circumventing safety locks may result in immediate account restriction.',
      },
    ],
  },
  {
    id: 'sec-2',
    number: '02',
    title: 'User-Generated Content, Feeds & Ownership (Flame Feed, Quick Burst & Branded Downloads)',
    plainSummary:
      'You always own the videos, photos, and reels you create. Uploading lets FISM display and stream your content across feeds, and everyone must respect creator watermarks on Branded Downloads.',
    clauses: [
      {
        heading: '2.1 Creator Ownership & Platform License',
        body: 'You retain 100% ownership and intellectual property rights in the videos, Quick Burst reels, photos, comments, and audio tracks you post. By publishing on Flame Feed, Main Blast, Quick Burst, or Stories, you grant FISM a worldwide, non-exclusive, royalty-free license to host, encode, cache, stream, and display your content inside the platform.',
      },
      {
        heading: '2.2 Branded Video Downloads & Watermark Integrity',
        body: 'When Branded Downloading is enabled, exported clips carry the original creator handle and official FISM watermark. You may share downloaded clips for personal viewing or fair attribution, but cropping out creator watermarks, re-uploading someone else’s content as your own, or commercial redistribution without written creator consent is strictly prohibited.',
      },
      {
        heading: '2.3 Copyright & Originality',
        body: 'Do not upload music, full films, or copyrighted clips you do not own or hold permission to use. Repeated copyright strikes trigger automated content restrictions and potential channel suspension.',
      },
    ],
  },
  {
    id: 'sec-3',
    number: '03',
    title: 'AI Features & Custom Filters (AI Clone Studio, Photo/Camera/Green-Screen & Game Filters)',
    plainSummary:
      'Never use AI Clone Studio to impersonate anyone or create deceptive deepfakes. Only official or approved assets may be published through Custom Filter Studio and interactive camera filters.',
    clauses: [
      {
        heading: '3.1 AI Clone Studio Ethics & Consent',
        body: 'AI Clone tools are strictly for creative expression with your own likeness or voices for which you hold explicit, verifiable permission. Creating deceptive deepfakes, impersonating public figures or private individuals, or generating non-consensual synthetic media is grounds for permanent termination.',
      },
      {
        heading: '3.2 Photo Filters, Chroma Elements & Green-Screen Game Filters',
        body: 'FISM provides real-time foreground/background Photo Filters, Chroma-Key overlays, and interactive Green-Screen Game Filters created and curated by platform Administrators. Users may apply published filters to camera captures and live recordings, while uploaded remix backgrounds must remain lawful, non-infringing, and free of harmful imagery.',
      },
    ],
  },
  {
    id: 'sec-4',
    number: '04',
    title: 'Monetization, Gifts, Virtual Coins & Digital Locker (Gift Drops, SP Coins, Loyalty Cards & Earnings)',
    plainSummary:
      'SP Coins, Gift Drops, watch-time rewards, and Loyalty Cards are tracked transparently. Attempting fake views, bots, or self-gifting manipulation forfeits rewards and locks payouts.',
    clauses: [
      {
        heading: '4.1 SP Coins, Gift Drops & Loyalty Milestones',
        body: 'Creators can attach Gift Drops (such as SP Coins or creator rewards) to posts, and users can earn SP Coins and annual tenure Loyalty Cards (including Exegesis Meta-Raid / Year 1–5+ milestone status) through genuine community activity and real-time streak rules. Virtual coins and badges hold value strictly within FISM ecosystem rules unless converted via verified creator payout tiers.',
      },
      {
        heading: '4.2 Digital Locker, Verification & Anti-Fraud Checks',
        body: 'Creator earnings and reward balances are held inside your in-app Digital Locker. Withdrawals require verified identity, valid payment details (such as verified UPI or bank credentials), and passing automated anti-fraud checks. Bot traffic, automated view loops, fake engagement farms, and circular self-gifting are strictly prohibited and void all pending earnings.',
      },
      {
        heading: '4.3 Platform Fees & Applicable Taxes',
        body: 'Payouts may be subject to transparent platform service fees, payment gateway charges, and local tax obligations depending on your jurisdiction.',
      },
    ],
  },
  {
    id: 'sec-5',
    number: '05',
    title: 'In-App Marketplace & Shopping Terms (Buying & Selling)',
    plainSummary:
      'Sellers must list real, lawful items accurately and ship orders on time. Prohibited goods are banned, and FISM helps review verified order disputes fairly.',
    clauses: [
      {
        heading: '5.1 Seller Obligations & Authentic Listings',
        body: 'Sellers and verified affiliate stores listing products on FISM Shopping must provide honest descriptions, clear pricing, authentic photos/videos, and fulfill paid orders promptly.',
      },
      {
        heading: '5.2 Prohibited Items & Buyer Protection',
        body: 'Counterfeit goods, illegal substances, weapons, stolen property, and deceptive financial schemes are strictly banned. Buyers should keep all order communications and payment proofs inside official FISM checkout channels so our support team can assist with order disputes.',
      },
    ],
  },
  {
    id: 'sec-6',
    number: '06',
    title: 'Gaming & Interactive Modes',
    plainSummary:
      'Play in-app 2D games and green-screen camera games fairly—no hacks, cheats, exploit scripts, or tampered builds.',
    clauses: [
      {
        heading: '6.1 Fair Play & Anti-Exploit Policy',
        body: 'Interactive 2D arcade games, live chat emoji mini-games, and green-screen camera game filters operate under strict fair-play rules. Using modified clients, memory injectors, automated macros, or score-spoofing scripts to manipulate leaderboards or coin rewards is forbidden.',
      },
    ],
  },
  {
    id: 'sec-7',
    number: '07',
    title: 'Location & Google Maps Platform Integration',
    plainSummary:
      'Location access is optional and only used to power nearby discovery, Daily Check-In pins, and directions via Google Maps Platform.',
    clauses: [
      {
        heading: '7.1 How Location Features Work',
        body: 'If you grant location permission, FISM uses approximate or live coordinates for features such as Daily Check-In map pins, local creator/product discovery, nearby place search, and turn-by-turn store or chat meet-up directions.',
      },
      {
        heading: '7.2 Google Maps Platform Terms Notice',
        body: 'Interactive maps, geocoding, and place search within FISM are powered by Google Maps Platform. By using map and location features inside FISM, you also agree to comply with the Google Maps / Google Earth Additional Terms of Service and Google Privacy Policy.',
      },
    ],
  },
  {
    id: 'sec-8',
    number: '08',
    title: 'Privacy Policy & Data Protection',
    plainSummary:
      'We only use your camera/mic when you actively record or call, never sell your personal data, protect accounts with layered AI security, and let you clear history or delete your account.',
    clauses: [
      {
        heading: '8.1 Information We Collect',
        body: 'FISM collects information you provide directly (email, username, profile customization, marketplace orders) alongside technical activity signals needed to operate the app—including watch history for Flame Feed recommendations, coin/locker transaction logs, and optional location coordinates.',
      },
      {
        heading: '8.2 Camera & Microphone Permissions',
        body: 'Your camera and microphone are accessed strictly when you open the Create Camera Studio, record Quick Burst / Main Blast clips, use real-time Photo/Camera/Game filters, or join Audio/Video Calls. Background recording without your active session never occurs.',
      },
      {
        heading: '8.3 Security, Your Controls & No Data Selling',
        body: 'FISM protects user accounts using cryptographic session verification and multi-layer AI intrusion monitoring. We do NOT sell your personal data to third-party data brokers. You can enable Private ID visibility, clear local watch history, or request permanent account deletion through Settings at any time.',
      },
    ],
  },
  {
    id: 'sec-9',
    number: '09',
    title: "Community Guidelines, Safety & Live Support ('On Fire')",
    plainSummary:
      'Hate speech, harassment, scams, illegal content, and violence are strictly banned. Report bad actors anytime or message On Fire Live Support for help.',
    clauses: [
      {
        heading: '9.1 Zero-Tolerance Safety Rules',
        body: 'Hate speech, targeted harassment, bullying, graphic violence, explicit exploitation, phishing scams, and illegal activity have zero tolerance across posts, comments, Ember Chats, and live broadcasts.',
      },
      {
        heading: '9.2 Reporting, Live Support & Enforcement',
        body: 'Use the in-app Smother/Report button on any post, profile, or message, or contact our team directly through On Fire Live Support. Violations result in content removal, temporary feature locks, earning forfeitures, or permanent account ejection.',
      },
    ],
  },
  {
    id: 'sec-10',
    number: '10',
    title: 'Updates to Terms & Contact Information',
    plainSummary:
      'When we update these policies, we post the new date here and notify active users in the app. You can always reach our legal and support desk for questions.',
    clauses: [
      {
        heading: '10.1 Policy Revisions',
        body: 'As FISM introduces new social, AI, gaming, or marketplace tools, we may revise these Terms of Service and Privacy Policy. Material changes will be announced inside the app with an updated revision date prior to taking effect.',
      },
      {
        heading: '10.2 Contact Legal & Support Team',
        body: 'Questions regarding your privacy, copyright takedowns, Digital Locker verification, or these Terms can be sent to support@fism.social or submitted directly inside the On Fire Live Support hub.',
      },
    ],
  },
];

interface FismLegalDocsModalProps {
  open: boolean;
  returnLabel: 'Back to Login' | 'Back to Settings' | 'Close';
  onClose: () => void;
}

export const FismLegalDocsModal: React.FC<FismLegalDocsModalProps> = ({
  open,
  returnLabel,
  onClose,
}) => {
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>(() => {
    const initial: Record<string, boolean> = {};
    LEGAL_SECTIONS.forEach((s) => {
      initial[s.id] = true;
    });
    return initial;
  });

  if (!open) return null;

  const allExpanded = LEGAL_SECTIONS.every((s) => expandedIds[s.id]);

  const toggleAll = () => {
    const nextVal = !allExpanded;
    const next: Record<string, boolean> = {};
    LEGAL_SECTIONS.forEach((s) => {
      next[s.id] = nextVal;
    });
    setExpandedIds(next);
  };

  const toggleOne = (id: string) => {
    setExpandedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const scrollToSection = (id: string) => {
    setExpandedIds((prev) => ({ ...prev, [id]: true }));
    requestAnimationFrame(() => {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="fism-legal-modal-title"
      className="fixed inset-0 z-[80] bg-white dark:bg-[#0B1120] text-slate-900 dark:text-slate-100 flex flex-col overflow-hidden"
    >
      {/* Top Bar */}
      <header className="shrink-0 sticky top-0 z-20 bg-white/95 dark:bg-[#0B1120]/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-8 py-3">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-[#2563EB] dark:text-[#3B82F6]" />
            <span>{returnLabel}</span>
          </button>

          <div className="flex items-center gap-2 min-w-0">
            <Flame className="w-5 h-5 text-[#FF5722] shrink-0 hidden sm:block" />
            <span className="font-extrabold text-sm sm:text-base truncate">
              FISM Legal &amp; Privacy Center
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Legal Documentation"
            className="min-h-[44px] min-w-[44px] rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center shrink-0 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Scrollable Legal Body */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6 sm:py-10">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Document Hero */}
          <div className="space-y-3 pb-6 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
              <Scale className="w-4 h-4 text-[#2563EB] dark:text-[#3B82F6]" />
              <span>FISM Platform Governance</span>
              <span aria-hidden="true">·</span>
              <span>Last Updated: November 20, 2026</span>
            </div>
            <h1
              id="fism-legal-modal-title"
              className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white"
            >
              Terms of Service, Terms &amp; Conditions, and Privacy Policy
            </h1>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl">
              Welcome to FISM—your all-in-one social media, creator studio, gaming, marketplace,
              monetization, and AI-powered platform. Every section below pairs clear rules with a
              plain-English summary so you always know your rights and responsibilities.
            </p>
            <div className="pt-2 flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
                <ShieldCheck className="w-4 h-4 text-[#16A34A]" />
                <span>Covers Accounts, Feeds, AI &amp; Filters, Coins/Locker, Marketplace, Maps &amp; Privacy</span>
              </div>
              <button
                type="button"
                onClick={toggleAll}
                className="min-h-[40px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold cursor-pointer"
              >
                {allExpanded ? 'Collapse All Sections' : 'Expand All Sections'}
              </button>
            </div>
          </div>

          {/* Quick-Navigation Table of Contents */}
          <nav
            aria-label="Legal Table of Contents"
            className="p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 space-y-3"
          >
            <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              <FileText className="w-4 h-4 text-[#2563EB] dark:text-[#3B82F6]" />
              <span>Quick Navigation (Table of Contents)</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {LEGAL_SECTIONS.map((sec) => (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => scrollToSection(sec.id)}
                  className="min-h-[40px] px-3 py-2 rounded-xl text-left text-xs font-semibold text-[#2563EB] dark:text-[#60A5FA] hover:bg-blue-50 dark:hover:bg-slate-800 hover:underline flex items-start gap-2 transition-colors cursor-pointer"
                >
                  <span className="font-mono font-bold shrink-0">{sec.number}.</span>
                  <span>{sec.title}</span>
                </button>
              ))}
            </div>
          </nav>

          {/* Numbered Legal Sections */}
          <div className="space-y-4">
            {LEGAL_SECTIONS.map((sec) => {
              const isOpen = Boolean(expandedIds[sec.id]);
              return (
                <section
                  key={sec.id}
                  id={sec.id}
                  className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/50 overflow-hidden scroll-mt-20"
                >
                  <button
                    type="button"
                    onClick={() => toggleOne(sec.id)}
                    aria-expanded={isOpen}
                    className="w-full min-h-[56px] px-4 sm:px-6 py-4 flex items-center justify-between gap-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                  >
                    <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white flex items-baseline gap-2.5">
                      <span className="font-mono text-xs sm:text-sm text-[#2563EB] dark:text-[#60A5FA] shrink-0">
                        {sec.number}.
                      </span>
                      <span>{sec.title}</span>
                    </h2>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-slate-500 shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                    )}
                  </button>

                  {isOpen && (
                    <div className="px-4 sm:px-6 pb-5 pt-1 space-y-4 border-t border-slate-100 dark:border-slate-800">
                      {/* Plain-English Summary Callout (clean hairline border, no thick left bar) */}
                      <div className="p-3.5 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-900/60 space-y-1">
                        <div className="text-[11px] font-extrabold uppercase tracking-wider text-[#2563EB] dark:text-[#60A5FA]">
                          Plain-English Summary
                        </div>
                        <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
                          {sec.plainSummary}
                        </p>
                      </div>

                      <div className="space-y-3.5">
                        {sec.clauses.map((clause) => (
                          <div key={clause.heading} className="space-y-1">
                            <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100">
                              {clause.heading}
                            </h3>
                            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                              {clause.body}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </section>
              );
            })}
          </div>

          {/* Bottom Confirmation & Return Footer */}
          <div className="pt-4 pb-8 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-xs text-slate-500 dark:text-slate-400 text-center sm:text-left">
              Effective Date: November 20, 2026 · FISM Social, Gaming, Shopping &amp; AI Platform
            </div>
            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-initial min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs sm:text-sm font-bold cursor-pointer"
              >
                {returnLabel}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-initial min-h-[44px] px-5 py-2.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs sm:text-sm font-extrabold shadow-md cursor-pointer"
              >
                I Understand &amp; Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
