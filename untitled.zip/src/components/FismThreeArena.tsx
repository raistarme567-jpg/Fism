import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  Film,
  Maximize2,
  Minimize2,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Search,
  Eye,
  Compass,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  Tv,
} from 'lucide-react';

export interface FismVrVideoOption {
  id: string;
  title: string;
  creatorName: string;
  category?: string;
  videoUrl: string;
  thumbnailUrl?: string;
  viewsLabel?: string;
}

export interface FismThreeArenaProps {
  activeVideoUrl?: string;
  activeVideoTitle?: string;
  availableVideos?: FismVrVideoOption[];
  onVideoLoaded?: (url: string, title: string) => void;
}

type SeatPreset = 'vipCenter' | 'frontRow' | 'balcony' | 'stageSide';

const DEFAULT_IN_APP_VR_VIDEOS: FismVrVideoOption[] = [
  {
    id: 'vr_vid_1',
    title: 'FISM 8K Spatial Cinema Premiere — Alpine & Studio Master',
    creatorName: 'Aarav Inferno (@aarav_inferno)',
    category: '8K Cinema & Tech',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    viewsLabel: '2.4M Sparks',
  },
  {
    id: 'vr_vid_2',
    title: 'Free Fire & BGMI Ultra Squad Booyah — Pro Esports Highlights',
    creatorName: 'SRMINT Gaming (@SRMINT482)',
    category: 'Esports & Gaming',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    viewsLabel: '1.8M Sparks',
  },
  {
    id: 'vr_vid_3',
    title: 'Full-Stack Web Development & AI Architecture Masterclass',
    creatorName: 'Kabir Tech (@kabir_tech)',
    category: 'Web Development & Full-Stack',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    viewsLabel: '940K Sparks',
  },
  {
    id: 'vr_vid_4',
    title: 'Sarkari Naukri & UPSC Complete Strategy Session — Live Hall',
    creatorName: 'FISM Education Hub (@fism_edu)',
    category: 'Sarkari Naukri (Government Jobs)',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    viewsLabel: '1.5M Sparks',
  },
  {
    id: 'vr_vid_5',
    title: 'Midnight Cyberpunk Synthwave Concert — Spatial 3D Audio',
    creatorName: 'Zoya Beats (@zoya_beats)',
    category: 'Music & Concerts',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    viewsLabel: '3.1M Sparks',
  },
];

export const FismThreeArena: React.FC<FismThreeArenaProps> = ({
  activeVideoUrl,
  activeVideoTitle,
  availableVideos,
  onVideoLoaded,
}) => {
  const wrapperRef = useRef<HTMLDivElement | null>(null);
  const mountRef = useRef<HTMLDivElement | null>(null);
  const videoElRef = useRef<HTMLVideoElement | null>(null);

  const catalogVideos = useMemo<FismVrVideoOption[]>(() => {
    const merged: FismVrVideoOption[] = [];
    const seen = new Set<string>();
    for (const v of [...(availableVideos || []), ...DEFAULT_IN_APP_VR_VIDEOS]) {
      if (!v.videoUrl || seen.has(v.title)) continue;
      seen.add(v.title);
      merged.push(v);
    }
    return merged;
  }, [availableVideos]);

  const [videoTitle, setVideoTitle] = useState<string>(
    activeVideoTitle || catalogVideos[0]?.title || 'FISM 8K Spatial Cinema Premiere',
  );
  const [customVideoUrl, setCustomVideoUrl] = useState<string>(
    activeVideoUrl || catalogVideos[0]?.videoUrl || '',
  );
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showVideoCatalog, setShowVideoCatalog] = useState<boolean>(false);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [vrStereoMode, setVrStereoMode] = useState<boolean>(false);
  const [cinemaScreenMode, setCinemaScreenMode] = useState<'curvedImax' | 'vrDome180'>('curvedImax');
  const [seatPreset, setSeatPreset] = useState<SeatPreset>('vipCenter');
  const [ambientDimming, setAmbientDimming] = useState<number>(0.82);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [xrStatus, setXrStatus] = useState<string>(
    '3D VR Cinema Ready • Realistic 3D Human Audience & In-App Video Search Active',
  );

  const filteredVideos = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return catalogVideos;
    return catalogVideos.filter(
      (v) =>
        v.title.toLowerCase().includes(q) ||
        v.creatorName.toLowerCase().includes(q) ||
        (v.category && v.category.toLowerCase().includes(q)),
    );
  }, [catalogVideos, searchQuery]);

  // Refs synced into the animation loop
  const vrStereoRef = useRef<boolean>(false);
  vrStereoRef.current = vrStereoMode;

  const isPlayingRef = useRef<boolean>(true);
  isPlayingRef.current = isPlaying;

  const ambientDimRef = useRef<number>(0.82);
  ambientDimRef.current = ambientDimming;

  const seatPresetTargetRef = useRef<{
    pos: THREE.Vector3;
    lookAt: THREE.Vector3;
    needsMove: boolean;
  }>({
    pos: new THREE.Vector3(0, 3.6, 13.5),
    lookAt: new THREE.Vector3(0, 4.2, -8.5),
    needsMove: false,
  });

  useEffect(() => {
    if (activeVideoUrl) {
      setCustomVideoUrl(activeVideoUrl);
    }
    if (activeVideoTitle) {
      setVideoTitle(activeVideoTitle);
    }
  }, [activeVideoUrl, activeVideoTitle]);

  const handleSelectInAppVideo = (vid: FismVrVideoOption) => {
    setCustomVideoUrl(vid.videoUrl);
    setVideoTitle(vid.title);
    setIsPlaying(true);
    setShowVideoCatalog(false);
    setXrStatus(`Playing In-App Video in 3D VR Cinema: ${vid.title}`);
    setTimeout(() => {
      if (videoElRef.current) {
        videoElRef.current.src = vid.videoUrl;
        videoElRef.current.play().catch(() => {});
      }
    }, 60);
    onVideoLoaded?.(vid.videoUrl, vid.title);
  };

  // Apply seat preset camera transition
  const handleSelectSeat = (preset: SeatPreset) => {
    setSeatPreset(preset);
    if (preset === 'frontRow') {
      seatPresetTargetRef.current = {
        pos: new THREE.Vector3(0, 2.2, 5.8),
        lookAt: new THREE.Vector3(0, 4.5, -8.5),
        needsMove: true,
      };
    } else if (preset === 'vipCenter') {
      seatPresetTargetRef.current = {
        pos: new THREE.Vector3(0, 3.6, 13.2),
        lookAt: new THREE.Vector3(0, 4.3, -8.5),
        needsMove: true,
      };
    } else if (preset === 'balcony') {
      seatPresetTargetRef.current = {
        pos: new THREE.Vector3(0, 6.8, 19.5),
        lookAt: new THREE.Vector3(0, 4.1, -8.5),
        needsMove: true,
      };
    } else {
      seatPresetTargetRef.current = {
        pos: new THREE.Vector3(-8.5, 4.0, 10.5),
        lookAt: new THREE.Vector3(0, 4.2, -8.5),
        needsMove: true,
      };
    }
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 860;
    const height = container.clientHeight || 520;

    // 1. Renderer with ACESFilmicToneMapping & Scissor support for VR Stereo Split View
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.22;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 2. Scene & RoomEnvironment PBR Lighting
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070a14);
    scene.fog = new THREE.FogExp2(0x070a14, 0.014);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;

    // 3. Main Camera + Left/Right VR Stereo Eye Cameras
    const camera = new THREE.PerspectiveCamera(58, width / height, 0.1, 150);
    camera.position.set(0, 3.6, 13.2);

    const leftEyeCam = new THREE.PerspectiveCamera(65, (width * 0.5) / height, 0.1, 150);
    const rightEyeCam = new THREE.PerspectiveCamera(65, (width * 0.5) / height, 0.1, 150);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 + 0.12;
    controls.minDistance = 2.5;
    controls.maxDistance = 32;
    controls.target.set(0, 4.3, -8.5);

    // 4. Cinema Hall Lighting
    const ambientLight = new THREE.AmbientLight(0x273549, 0.72);
    scene.add(ambientLight);

    const screenBounceLight = new THREE.PointLight(0xff5722, 4.5, 36);
    screenBounceLight.position.set(0, 4.8, -5.0);
    scene.add(screenBounceLight);

    const warmHallFillLight = new THREE.PointLight(0xf59e0b, 1.8, 30);
    warmHallFillLight.position.set(0, 7.2, 10.5);
    scene.add(warmHallFillLight);

    const projectorBeamLight = new THREE.SpotLight(0x8b5cf6, 3.2, 42, Math.PI / 5, 0.45, 1.2);
    projectorBeamLight.position.set(0, 9.8, 12);
    projectorBeamLight.target.position.set(0, 4.5, -8.5);
    projectorBeamLight.castShadow = true;
    scene.add(projectorBeamLight);
    scene.add(projectorBeamLight.target);

    // 5. Dynamic 2D Canvas Video Generator
    const screenCanvas = document.createElement('canvas');
    screenCanvas.width = 1280;
    screenCanvas.height = 720;
    const screenCtx = screenCanvas.getContext('2d');

    const canvasTexture = new THREE.CanvasTexture(screenCanvas);
    canvasTexture.colorSpace = THREE.SRGBColorSpace;
    canvasTexture.minFilter = THREE.LinearFilter;
    canvasTexture.magFilter = THREE.LinearFilter;

    // 6. LUXURY CARPETED THEATER FLOOR (JAMEEN) & ILLUMINATED TIERED RISERS
    const carpetCanvas = document.createElement('canvas');
    carpetCanvas.width = 512;
    carpetCanvas.height = 512;
    const carpetCtx = carpetCanvas.getContext('2d');
    if (carpetCtx) {
      carpetCtx.fillStyle = '#140c1c';
      carpetCtx.fillRect(0, 0, 512, 512);
      // Plush royal crimson & gold cinema carpet pattern
      carpetCtx.strokeStyle = '#3b152a';
      carpetCtx.lineWidth = 4;
      for (let y = 0; y < 512; y += 32) {
        for (let x = 0; x < 512; x += 32) {
          carpetCtx.strokeRect(x + 4, y + 4, 24, 24);
          carpetCtx.fillStyle = (x + y) % 64 === 0 ? '#4c1d3d' : '#291224';
          carpetCtx.fillRect(x + 10, y + 10, 12, 12);
        }
      }
      // Subtle gold diamond accents
      carpetCtx.fillStyle = 'rgba(245, 158, 11, 0.22)';
      for (let y = 16; y < 512; y += 64) {
        for (let x = 16; x < 512; x += 64) {
          carpetCtx.beginPath();
          carpetCtx.arc(x, y, 4, 0, Math.PI * 2);
          carpetCtx.fill();
        }
      }
    }
    const carpetTex = new THREE.CanvasTexture(carpetCanvas);
    carpetTex.wrapS = THREE.RepeatWrapping;
    carpetTex.wrapT = THREE.RepeatWrapping;
    carpetTex.repeat.set(14, 14);
    carpetTex.colorSpace = THREE.SRGBColorSpace;

    const floorMat = new THREE.MeshStandardMaterial({
      map: carpetTex,
      roughness: 0.82,
      metalness: 0.08,
    });
    const mainFloor = new THREE.Mesh(new THREE.PlaneGeometry(48, 54), floorMat);
    mainFloor.rotation.x = -Math.PI / 2;
    mainFloor.receiveShadow = true;
    scene.add(mainFloor);

    // Center Velvet Red-Gold VIP Aisle Runner Carpet with Glowing LED Edge Strips
    const runnerMat = new THREE.MeshStandardMaterial({
      color: 0x7f1d1d,
      roughness: 0.75,
      metalness: 0.12,
    });
    const centerRunner = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.04, 28), runnerMat);
    centerRunner.position.set(0, 0.02, 8.0);
    centerRunner.receiveShadow = true;
    scene.add(centerRunner);

    const aisleLedMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0xff5722,
      emissiveIntensity: 1.8,
    });
    [-1.12, 1.12].forEach((aisleX) => {
      const strip = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 28), aisleLedMat);
      strip.position.set(aisleX, 0.04, 8.0);
      scene.add(strip);
    });

    // Tiered seating platforms with warm carpet top & LED step nosing
    const riserMat = new THREE.MeshStandardMaterial({
      map: carpetTex,
      color: 0x261733,
      roughness: 0.78,
      metalness: 0.12,
    });

    for (let tier = 0; tier < 4; tier++) {
      const riserHeight = 0.55 * (tier + 1);
      const riserZ = 6.5 + tier * 3.6;
      const riser = new THREE.Mesh(new THREE.BoxGeometry(24, riserHeight, 3.45), riserMat);
      riser.position.set(0, riserHeight / 2, riserZ);
      riser.receiveShadow = true;
      scene.add(riser);

      // Glowing amber step edge strip along front of each tier
      const stepGlow = new THREE.Mesh(
        new THREE.BoxGeometry(24.05, 0.06, 0.08),
        aisleLedMat,
      );
      stepGlow.position.set(0, riserHeight + 0.01, riserZ - 1.7);
      scene.add(stepGlow);
    }

    // 7. Curved 3D IMAX Cinema Screen & Stage Assembly
    const screenAssembly = new THREE.Group();
    const radius = 19;
    const arcAngle = cinemaScreenMode === 'vrDome180' ? Math.PI * 0.85 : Math.PI * 0.48;
    const screenHeight = cinemaScreenMode === 'vrDome180' ? 10.5 : 8.6;

    const screenGeo = new THREE.CylinderGeometry(
      radius,
      radius,
      screenHeight,
      64,
      1,
      true,
      Math.PI - arcAngle / 2,
      arcAngle,
    );
    screenGeo.scale(-1, 1, 1);

    const screenMat = new THREE.MeshBasicMaterial({
      map: canvasTexture,
      side: THREE.DoubleSide,
    });
    const curvedScreenMesh = new THREE.Mesh(screenGeo, screenMat);
    curvedScreenMesh.position.set(0, 5.1, 8.5);
    screenAssembly.add(curvedScreenMesh);

    const trimMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      emissive: 0xff5722,
      emissiveIntensity: 0.85,
      metalness: 0.8,
      roughness: 0.2,
    });
    const topTrim = new THREE.Mesh(
      new THREE.TorusGeometry(radius, 0.14, 12, 64, arcAngle),
      trimMat,
    );
    topTrim.rotation.x = Math.PI / 2;
    topTrim.rotation.z = Math.PI / 2 - arcAngle / 2;
    topTrim.position.set(0, 5.1 + screenHeight / 2, 8.5);
    screenAssembly.add(topTrim);

    const bottomTrim = topTrim.clone();
    bottomTrim.position.set(0, 5.1 - screenHeight / 2, 8.5);
    screenAssembly.add(bottomTrim);

    // Polished Hardwood & Velvet Stage Deck beneath the screen
    const stageDeck = new THREE.Mesh(
      new THREE.BoxGeometry(25, 0.9, 5.8),
      new THREE.MeshStandardMaterial({
        color: 0x1c1917,
        roughness: 0.32,
        metalness: 0.45,
      }),
    );
    stageDeck.position.set(0, 0.45, -8.5);
    stageDeck.receiveShadow = true;
    screenAssembly.add(stageDeck);

    const stageLip = new THREE.Mesh(
      new THREE.BoxGeometry(25.1, 0.12, 0.18),
      new THREE.MeshStandardMaterial({
        color: 0xff5722,
        emissive: 0xff5722,
        emissiveIntensity: 2.2,
      }),
    );
    stageLip.position.set(0, 0.88, -5.62);
    screenAssembly.add(stageLip);

    scene.add(screenAssembly);

    // 8. Left & Right Line-Array Cinema Speaker Towers
    const createSpeakerTower = (side: -1 | 1) => {
      const tower = new THREE.Group();
      const cabinetMat = new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        metalness: 0.75,
        roughness: 0.25,
      });
      const coneMat = new THREE.MeshStandardMaterial({
        color: 0xf59e0b,
        emissive: 0xff5722,
        emissiveIntensity: 0.6,
        metalness: 0.85,
        roughness: 0.2,
      });

      const subBox = new THREE.Mesh(new THREE.BoxGeometry(2.1, 2.2, 1.8), cabinetMat);
      subBox.position.y = 1.1;
      tower.add(subBox);

      for (let i = 0; i < 4; i++) {
        const mod = new THREE.Mesh(new THREE.BoxGeometry(1.7, 1.05, 1.4), cabinetMat);
        mod.position.set(0, 2.9 + i * 1.18, 0);
        mod.rotation.x = 0.06 * (i - 1);
        tower.add(mod);

        const driver = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.22, 0.18, 20), coneMat);
        driver.rotation.x = Math.PI / 2;
        driver.position.set(0, 2.9 + i * 1.18, 0.72);
        tower.add(driver);
      }

      tower.position.set(side * 11.4, 0.85, -7.8);
      tower.rotation.y = -side * 0.28;
      return tower;
    };

    scene.add(createSpeakerTower(-1));
    scene.add(createSpeakerTower(1));

    // 9. Overhead VR Holodeck Projector Rig
    const projectorGroup = new THREE.Group();
    const projBody = new THREE.Mesh(
      new THREE.CylinderGeometry(1.2, 1.6, 0.9, 24),
      new THREE.MeshStandardMaterial({ color: 0x1e1b4b, metalness: 0.85, roughness: 0.2 }),
    );
    const projRing = new THREE.Mesh(
      new THREE.TorusGeometry(2.1, 0.09, 16, 48),
      new THREE.MeshStandardMaterial({
        color: 0x7c3aed,
        emissive: 0x7c3aed,
        emissiveIntensity: 1.8,
      }),
    );
    projRing.rotation.x = Math.PI / 2;
    const projLens = new THREE.Mesh(
      new THREE.SphereGeometry(0.55, 24, 24),
      new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x2563eb,
        emissiveIntensity: 2.0,
      }),
    );
    projLens.position.set(0, -0.35, -1.1);
    projectorGroup.add(projBody, projRing, projLens);
    projectorGroup.position.set(0, 9.8, 12);
    scene.add(projectorGroup);

    // 10. LUXURY CONTOURED CINEMA RECLINER SEATS + REALISTIC 3D ARTICULATED HUMAN CHARACTERS
    const seatLeatherMat = new THREE.MeshStandardMaterial({
      color: 0x991b1b,
      roughness: 0.42,
      metalness: 0.15,
    });
    const seatDarkTrimMat = new THREE.MeshStandardMaterial({
      color: 0x1f2937,
      roughness: 0.5,
      metalness: 0.4,
    });

    const skinTones = [0xf1c27d, 0xe0ac69, 0xc68642, 0x8d5524, 0xffdbac];
    const outfitColors = [
      0x2563eb, // Royal Blue Hoodie
      0xdc2626, // Crimson Jacket
      0x10b981, // Emerald Varsity
      0x7c3aed, // Violet Sweater
      0xf59e0b, // Amber Streetwear
      0x0ea5e9, // Cyan Track Jacket
      0xec4899, // Rose Hoodie
      0xe2e8f0, // White Crisp Tee
    ];
    const hairColors = [0x111827, 0x27272a, 0x451a03, 0x713f12, 0x1e1b4b];
    const pantsColors = [0x1e293b, 0x0f172a, 0x334155, 0x1e3a8a, 0x27272a];

    const animatedHeads: { headGroup: THREE.Group; torso: THREE.Mesh; phase: number }[] = [];

    const createPlushSeatAndHuman = (
      x: number,
      tierFloorY: number,
      z: number,
      hasHuman: boolean,
      seed: number,
    ) => {
      const unit = new THREE.Group();
      unit.position.set(x, tierFloorY, z);
      unit.lookAt(x * 0.25, tierFloorY, -8.5);

      // --- A. Contoured Luxury Cinema Recliner Chair ---
      // Seat Base Cushion (rounded capsule/box hybrid)
      const cushion = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.42, 0.42, 8, 16),
        seatLeatherMat,
      );
      cushion.rotation.z = Math.PI / 2;
      cushion.scale.set(0.55, 1, 1.05);
      cushion.position.set(0, 0.46, 0.05);
      cushion.castShadow = true;
      cushion.receiveShadow = true;
      unit.add(cushion);

      // Contoured High Backrest (tilted slightly back for realism)
      const backrest = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.44, 0.72, 8, 16),
        seatLeatherMat,
      );
      backrest.scale.set(1.05, 1, 0.38);
      backrest.position.set(0, 1.05, -0.38);
      backrest.rotation.x = -0.14;
      backrest.castShadow = true;
      unit.add(backrest);

      // Plush Headrest Pillow
      const headrest = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.22, 0.36, 8, 16),
        seatLeatherMat,
      );
      headrest.rotation.z = Math.PI / 2;
      headrest.position.set(0, 1.56, -0.44);
      unit.add(headrest);

      // Left & Right Padded Armrests + Cupholders
      [-0.58, 0.58].forEach((armX) => {
        const armPillar = new THREE.Mesh(
          new THREE.BoxGeometry(0.14, 0.55, 0.72),
          seatDarkTrimMat,
        );
        armPillar.position.set(armX, 0.45, 0.02);
        unit.add(armPillar);

        const armPad = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.08, 0.58, 6, 12),
          seatDarkTrimMat,
        );
        armPad.rotation.x = Math.PI / 2;
        armPad.position.set(armX, 0.76, 0.05);
        unit.add(armPad);
      });

      if (!hasHuman) {
        return unit;
      }

      // --- B. Realistic Smooth-Shaded 3D Seated Human Character ---
      const human = new THREE.Group();
      const skinMat = new THREE.MeshStandardMaterial({
        color: skinTones[seed % skinTones.length],
        roughness: 0.55,
        metalness: 0.05,
      });
      const shirtMat = new THREE.MeshStandardMaterial({
        color: outfitColors[seed % outfitColors.length],
        roughness: 0.65,
        metalness: 0.08,
      });
      const pantsMat = new THREE.MeshStandardMaterial({
        color: pantsColors[seed % pantsColors.length],
        roughness: 0.75,
        metalness: 0.05,
      });
      const hairMat = new THREE.MeshStandardMaterial({
        color: hairColors[seed % hairColors.length],
        roughness: 0.8,
        metalness: 0.05,
      });
      const shoeMat = new THREE.MeshStandardMaterial({
        color: 0xf8fafc,
        roughness: 0.4,
        metalness: 0.1,
      });

      // 1. Torso & Rounded Shoulders (Seated against backrest)
      const torso = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.28, 0.48, 12, 24),
        shirtMat,
      );
      torso.scale.set(1.18, 1, 0.78);
      torso.position.set(0, 1.02, -0.1);
      torso.rotation.x = -0.1;
      torso.castShadow = true;
      human.add(torso);

      // Collar / Hoodie Neck Ring
      const hoodRing = new THREE.Mesh(
        new THREE.TorusGeometry(0.18, 0.055, 10, 24),
        shirtMat,
      );
      hoodRing.rotation.x = Math.PI / 2 - 0.1;
      hoodRing.position.set(0, 1.38, -0.14);
      human.add(hoodRing);

      // 2. Neck & Articulated Head Group
      const headGroup = new THREE.Group();
      headGroup.position.set(0, 1.44, -0.13);

      const neck = new THREE.Mesh(
        new THREE.CylinderGeometry(0.085, 0.1, 0.18, 16),
        skinMat,
      );
      neck.position.set(0, 0.05, 0);
      headGroup.add(neck);

      // Sculpted Human Head
      const cranium = new THREE.Mesh(
        new THREE.SphereGeometry(0.21, 24, 24),
        skinMat,
      );
      cranium.scale.set(0.92, 1.08, 0.98);
      cranium.position.set(0, 0.24, 0.02);
      cranium.castShadow = true;
      headGroup.add(cranium);

      // Realistic 3D Hairstyle (layered crown + side volume)
      const hairCrown = new THREE.Mesh(
        new THREE.SphereGeometry(0.222, 24, 24),
        hairMat,
      );
      hairCrown.scale.set(0.96, 1.05, 1.02);
      hairCrown.position.set(0, 0.28, -0.02);
      headGroup.add(hairCrown);

      // Ears
      [-0.19, 0.19].forEach((earX) => {
        const ear = new THREE.Mesh(new THREE.SphereGeometry(0.042, 12, 12), skinMat);
        ear.scale.set(0.5, 1.1, 0.8);
        ear.position.set(earX, 0.23, 0.01);
        headGroup.add(ear);
      });

      // Nose & Eyes facing forward (+Z of the unit, which looks at the IMAX screen)
      const nose = new THREE.Mesh(new THREE.ConeGeometry(0.032, 0.09, 12), skinMat);
      nose.rotation.x = Math.PI / 2;
      nose.position.set(0, 0.23, 0.22);
      headGroup.add(nose);

      const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
      [-0.07, 0.07].forEach((eyeX) => {
        const eye = new THREE.Mesh(new THREE.SphereGeometry(0.022, 12, 12), eyeMat);
        eye.position.set(eyeX, 0.26, 0.195);
        headGroup.add(eye);
      });

      human.add(headGroup);

      // 3. Upper Arms, Forearms & Hands Resting Naturally on Armrests
      [-1, 1].forEach((side) => {
        // Upper Arm from shoulder down to elbow
        const upperArm = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.085, 0.34, 8, 16),
          shirtMat,
        );
        upperArm.position.set(side * 0.39, 1.05, -0.06);
        upperArm.rotation.z = -side * 0.25;
        upperArm.rotation.x = 0.22;
        human.add(upperArm);

        // Forearm resting forward on the armrest pad
        const forearm = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.072, 0.34, 8, 16),
          skinMat,
        );
        forearm.rotation.x = Math.PI / 2;
        forearm.position.set(side * 0.48, 0.84, 0.16);
        human.add(forearm);

        // Hand
        const hand = new THREE.Mesh(new THREE.SphereGeometry(0.075, 14, 14), skinMat);
        hand.scale.set(0.85, 0.65, 1.15);
        hand.position.set(side * 0.48, 0.84, 0.36);
        human.add(hand);
      });

      // 4. Seated Thighs, Bent Knees, Calves & Sneakers on Floor
      [-0.17, 0.17].forEach((legX) => {
        // Thigh extending forward on seat cushion
        const thigh = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.115, 0.44, 10, 16),
          pantsMat,
        );
        thigh.rotation.x = Math.PI / 2 - 0.08;
        thigh.position.set(legX, 0.66, 0.18);
        thigh.castShadow = true;
        human.add(thigh);

        // Lower Leg / Calf going down to floor
        const calf = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.095, 0.46, 10, 16),
          pantsMat,
        );
        calf.position.set(legX, 0.36, 0.46);
        calf.rotation.x = 0.12;
        calf.castShadow = true;
        human.add(calf);

        // Sneaker / Shoe resting on the carpeted tier floor
        const shoe = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.085, 0.18, 8, 16),
          shoeMat,
        );
        shoe.rotation.x = Math.PI / 2;
        shoe.position.set(legX, 0.1, 0.56);
        human.add(shoe);
      });

      unit.add(human);
      animatedHeads.push({ headGroup, torso, phase: seed * 1.37 });
      return unit;
    };

    // Populate 4 Tiers of Plush Seats & Realistic Seated Audience Members
    let seatCounter = 0;
    for (let row = 0; row < 4; row++) {
      const tierFloorY = 0.55 * (row + 1);
      const z = 6.5 + row * 3.6;
      for (let col = -4; col <= 4; col++) {
        // Leave center aisle clear at col === 0
        if (col === 0) continue;
        const x = col * 2.15 + (col > 0 ? 0.55 : -0.55);
        // Leave the VIP camera seat open so the camera view is unobstructed, put humans in most other seats
        const isCameraSeat = row === 1 && (col === -1 || col === 1);
        const hasHuman = !isCameraSeat && (row + Math.abs(col)) % 4 !== 0;
        const seatGroup = createPlushSeatAndHuman(x, tierFloorY, z, hasHuman, seatCounter++);
        scene.add(seatGroup);
      }
    }

    // Instanced Glowing Aisle Wall Pillars
    const pillarCount = 24;
    const pillarGeo = new THREE.CylinderGeometry(0.12, 0.12, 4.8, 12);
    const pillarMat = new THREE.MeshStandardMaterial({
      color: 0xff5722,
      emissive: 0xff5722,
      emissiveIntensity: 1.4,
    });
    const instancedPillars = new THREE.InstancedMesh(pillarGeo, pillarMat, pillarCount);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < pillarCount; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const step = Math.floor(i / 2);
      dummy.position.set(side * 14.5, 2.4, -6 + step * 2.5);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      instancedPillars.setMatrixAt(i, dummy.matrix);
    }
    instancedPillars.instanceMatrix.needsUpdate = true;
    scene.add(instancedPillars);

    // 11. Animation Loop
    const clock = new THREE.Clock();
    let frameId = 0;

    const renderScreenFrame = (elapsed: number) => {
      if (!screenCtx) return;
      const vid = videoElRef.current;

      if (vid && vid.readyState >= 2 && customVideoUrl) {
        screenCtx.drawImage(vid, 0, 0, screenCanvas.width, screenCanvas.height);
        screenCtx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        screenCtx.fillRect(28, 24, 380, 44);
        screenCtx.fillStyle = '#FF5722';
        screenCtx.font = 'bold 20px sans-serif';
        screenCtx.fillText('🔥 FISM 3D VR CINEMA LIVE', 44, 52);
        canvasTexture.needsUpdate = true;
        return;
      }

      const w = screenCanvas.width;
      const h = screenCanvas.height;
      const grad = screenCtx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, '#0F172A');
      grad.addColorStop(0.45, '#31102F');
      grad.addColorStop(1, '#7C2D12');
      screenCtx.fillStyle = grad;
      screenCtx.fillRect(0, 0, w, h);

      screenCtx.strokeStyle = 'rgba(255, 87, 34, 0.45)';
      screenCtx.lineWidth = 2;
      for (let i = 0; i < 16; i++) {
        const y = h * 0.55 + ((i * 28 + elapsed * 60) % (h * 0.45));
        screenCtx.beginPath();
        screenCtx.moveTo(0, y);
        screenCtx.lineTo(w, y);
        screenCtx.stroke();
      }

      const sunY = h * 0.42 + Math.sin(elapsed * 1.4) * 18;
      const sunGrad = screenCtx.createRadialGradient(w / 2, sunY, 10, w / 2, sunY, 165);
      sunGrad.addColorStop(0, '#FEF08A');
      sunGrad.addColorStop(0.5, '#FF5722');
      sunGrad.addColorStop(1, 'rgba(255, 87, 34, 0)');
      screenCtx.fillStyle = sunGrad;
      screenCtx.beginPath();
      screenCtx.arc(w / 2, sunY, 165, 0, Math.PI * 2);
      screenCtx.fill();

      for (let bar = 0; bar < 48; bar++) {
        const barH =
          28 +
          Math.abs(Math.sin(elapsed * 5 + bar * 0.45)) * 95 +
          Math.abs(Math.cos(elapsed * 3 - bar * 0.2)) * 45;
        screenCtx.fillStyle = bar % 2 === 0 ? '#FF5722' : '#F59E0B';
        screenCtx.fillRect(90 + bar * 23, h - 40 - barH, 15, barH);
      }

      screenCtx.fillStyle = '#FFFFFF';
      screenCtx.font = '900 42px sans-serif';
      screenCtx.textAlign = 'center';
      screenCtx.fillText(videoTitle.slice(0, 44), w / 2, 110);

      screenCtx.fillStyle = '#FDE68A';
      screenCtx.font = 'bold 24px sans-serif';
      screenCtx.fillText(
        '3D VR SPATIAL CINEMA • SEARCH ANY FISM APP VIDEO TO WATCH IN VR',
        w / 2,
        158,
      );
      screenCtx.textAlign = 'start';

      canvasTexture.needsUpdate = true;
    };

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      if (isPlayingRef.current) {
        renderScreenFrame(elapsed);
      }

      // Animate realistic seated 3D human audience (subtle head look + breathing)
      for (let i = 0; i < animatedHeads.length; i++) {
        const item = animatedHeads[i];
        item.headGroup.rotation.y = Math.sin(elapsed * 0.85 + item.phase) * 0.14;
        item.headGroup.rotation.x = Math.cos(elapsed * 0.6 + item.phase) * 0.05 - 0.04;
        item.torso.scale.z = 0.78 + Math.sin(elapsed * 2.1 + item.phase) * 0.025;
      }

      if (seatPresetTargetRef.current.needsMove) {
        camera.position.lerp(seatPresetTargetRef.current.pos, 0.08);
        controls.target.lerp(seatPresetTargetRef.current.lookAt, 0.08);
        if (camera.position.distanceTo(seatPresetTargetRef.current.pos) < 0.12) {
          seatPresetTargetRef.current.needsMove = false;
        }
      }

      ambientLight.intensity = Math.max(0.22, 1.15 - ambientDimRef.current);
      screenBounceLight.intensity = 3.8 + Math.sin(elapsed * 3.2) * 0.65;
      projRing.rotation.z = elapsed * 0.9;

      controls.update();

      const cW = container.clientWidth || width;
      const cH = container.clientHeight || height;

      if (vrStereoRef.current) {
        renderer.setScissorTest(true);
        const halfW = Math.floor(cW / 2);

        camera.updateMatrixWorld();
        leftEyeCam.aspect = halfW / cH;
        leftEyeCam.updateProjectionMatrix();
        leftEyeCam.matrixWorld.copy(camera.matrixWorld);
        leftEyeCam.position.copy(camera.position).add(new THREE.Vector3(-0.18, 0, 0));
        leftEyeCam.quaternion.copy(camera.quaternion);

        rightEyeCam.aspect = halfW / cH;
        rightEyeCam.updateProjectionMatrix();
        rightEyeCam.matrixWorld.copy(camera.matrixWorld);
        rightEyeCam.position.copy(camera.position).add(new THREE.Vector3(0.18, 0, 0));
        rightEyeCam.quaternion.copy(camera.quaternion);

        renderer.setViewport(0, 0, halfW, cH);
        renderer.setScissor(0, 0, halfW, cH);
        renderer.render(scene, leftEyeCam);

        renderer.setViewport(halfW, 0, cW - halfW, cH);
        renderer.setScissor(halfW, 0, cW - halfW, cH);
        renderer.render(scene, rightEyeCam);

        renderer.setScissorTest(false);
      } else {
        renderer.setScissorTest(false);
        renderer.setViewport(0, 0, cW, cH);
        renderer.render(scene, camera);
      }
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const nw = container.clientWidth || 860;
      const nh = container.clientHeight || 520;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameId);
      controls.dispose();
      pmremGenerator.dispose();
      carpetTex.dispose();
      canvasTexture.dispose();
      renderer.dispose();
    };
  }, [cinemaScreenMode, customVideoUrl, videoTitle]);

  const handleTogglePlay = () => {
    const vid = videoElRef.current;
    if (vid && customVideoUrl) {
      if (vid.paused) {
        vid.play().catch(() => {});
        setIsPlaying(true);
      } else {
        vid.pause();
        setIsPlaying(false);
      }
    } else {
      setIsPlaying((p) => !p);
    }
  };

  const handleToggleMute = () => {
    const vid = videoElRef.current;
    if (vid) {
      vid.muted = !vid.muted;
      setIsMuted(vid.muted);
    } else {
      setIsMuted((m) => !m);
    }
  };

  const handleToggleFullscreen = () => {
    if (!wrapperRef.current) return;
    if (!document.fullscreenElement) {
      wrapperRef.current.requestFullscreen?.().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  };

  return (
    <div ref={wrapperRef} className="space-y-4">
      {/* Hidden HTML5 Video Element feeding the Three.js 3D Curved IMAX Screen */}
      <video
        ref={videoElRef}
        src={customVideoUrl || undefined}
        crossOrigin="anonymous"
        playsInline
        loop
        autoPlay
        muted={isMuted}
        className="hidden"
      />

      {/* Top 3D VR Cinema Control Header & In-App Video Search Bar (No File Upload!) */}
      <div className="fism-card p-4 sm:p-5 space-y-4 border-2 border-[#FF5722]">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl fism-gradient-flame text-white flex items-center justify-center shadow-lg">
              <Film className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg sm:text-xl font-extrabold">
                  FISM 3D VR Cinema &amp; Spatial Video Theater
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-[#7C3AED] text-white text-[10px] font-extrabold uppercase">
                  Realistic 3D Audience • In-App Video Search
                </span>
              </div>
              <p className="text-xs text-[#52607A] dark:text-slate-300 mt-0.5">
                Search and watch any video available inside the FISM app inside a 3D Curved IMAX
                Theater with realistic seated audience &amp; luxury carpeted floor!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setShowVideoCatalog((s) => !s)}
              className="fism-btn-primary px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-lg"
            >
              <Tv className="w-4 h-4" />
              {showVideoCatalog ? 'Hide In-App Videos' : `Browse App Videos (${catalogVideos.length})`}
            </button>

            <button
              onClick={() => {
                setVrStereoMode((v) => !v);
                setXrStatus(
                  !vrStereoMode
                    ? 'VR Headset Stereoscopic Split-Screen ACTIVE (Left + Right Eye)'
                    : 'Single 3D Cinema Screen Mode ACTIVE',
                );
              }}
              className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-lg transition-all ${
                vrStereoMode
                  ? 'bg-[#16A34A] text-white ring-2 ring-white'
                  : 'bg-[#7C3AED] text-white'
              }`}
            >
              <Eye className="w-4 h-4" />
              {vrStereoMode ? '🥽 VR Headset Split-View: ON' : '🥽 Enter VR Headset Mode'}
            </button>
          </div>
        </div>

        {/* In-App Video Search Bar & Instant Selector */}
        <div className="space-y-3 pt-1 border-t border-[#D8E1F0] dark:border-slate-800">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="w-4 h-4 text-[#FF5722] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setShowVideoCatalog(true)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowVideoCatalog(true);
                }}
                placeholder="Search FISM App Videos to watch in 3D VR Theater (e.g. Free Fire, Web Dev, 8K Cinema, Music)..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold focus:outline-none focus:border-[#FF5722]"
              />
            </div>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="px-3 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 text-xs font-bold text-[#52607A]"
              >
                Clear
              </button>
            )}
          </div>

          {(showVideoCatalog || searchQuery.trim().length > 0) && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-60 overflow-y-auto p-1">
              {filteredVideos.map((vid) => {
                const isSelected = vid.title === videoTitle;
                return (
                  <button
                    key={vid.id}
                    onClick={() => handleSelectInAppVideo(vid)}
                    className={`p-3 rounded-xl border text-left transition-all flex items-start justify-between gap-2 ${
                      isSelected
                        ? 'border-[#FF5722] bg-orange-500/10 ring-1 ring-[#FF5722]'
                        : 'border-[#D8E1F0] dark:border-slate-700 bg-[#F8FAFE] dark:bg-slate-900 hover:border-[#FF5722]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-extrabold line-clamp-1">{vid.title}</div>
                      <div className="text-[11px] text-[#52607A] dark:text-slate-400 truncate mt-0.5">
                        {vid.creatorName}
                      </div>
                      <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                        {vid.category && (
                          <span className="px-2 py-0.5 rounded bg-[#7C3AED]/15 text-[#7C3AED] text-[10px] font-bold">
                            {vid.category}
                          </span>
                        )}
                        {vid.viewsLabel && (
                          <span className="text-[10px] font-bold text-[#FF5722]">
                            {vid.viewsLabel}
                          </span>
                        )}
                      </div>
                    </div>
                    <span
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold shrink-0 flex items-center gap-1 ${
                        isSelected ? 'bg-[#16A34A] text-white' : 'bg-[#FF5722] text-white'
                      }`}
                    >
                      {isSelected ? (
                        <>
                          <CheckCircle2 className="w-3 h-3" /> Playing
                        </>
                      ) : (
                        <>
                          <Play className="w-3 h-3" /> Watch VR
                        </>
                      )}
                    </span>
                  </button>
                );
              })}
              {filteredVideos.length === 0 && (
                <div className="col-span-full p-4 text-center text-xs font-bold text-[#52607A]">
                  No matching video found in FISM App catalog. Try another search keyword!
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main 3D WebGL Cinema Viewport */}
      <div className="fism-card overflow-hidden relative border-2 border-[#D8E1F0] dark:border-slate-800">
        {/* Top Floating HUD inside 3D Theater */}
        <div className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between flex-wrap gap-2 pointer-events-none">
          <div className="px-3 py-1.5 rounded-xl bg-black/75 backdrop-blur-md border border-white/15 text-white flex items-center gap-2 pointer-events-auto">
            <span className="w-2.5 h-2.5 rounded-full bg-[#16A34A] animate-ping" />
            <span className="text-xs font-extrabold truncate max-w-[260px] sm:max-w-md">
              Now Playing in 3D VR: {videoTitle}
            </span>
          </div>

          <div className="flex items-center gap-1.5 pointer-events-auto flex-wrap">
            <button
              onClick={() =>
                setCinemaScreenMode((m) => (m === 'curvedImax' ? 'vrDome180' : 'curvedImax'))
              }
              className="px-3 py-1.5 rounded-xl bg-black/75 hover:bg-[#FF5722] text-white text-xs font-bold border border-white/15 flex items-center gap-1"
            >
              <Compass className="w-3.5 h-3.5" />
              {cinemaScreenMode === 'curvedImax' ? 'Screen: Curved IMAX' : 'Screen: 180° VR Dome'}
            </button>

            <button
              onClick={handleToggleFullscreen}
              className="p-2 rounded-xl bg-black/75 hover:bg-white/20 text-white border border-white/15"
              title="Toggle Fullscreen VR Theater"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Center Stereoscopic VR Divider Line when VR Headset Mode is ON */}
        {vrStereoMode && (
          <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 z-10 w-1 bg-[#FF5722]/80 pointer-events-none flex flex-col items-center justify-center">
            <span className="px-2 py-0.5 rounded bg-black/80 text-[10px] font-extrabold text-white whitespace-nowrap">
              ◀ LEFT EYE | RIGHT EYE ▶
            </span>
          </div>
        )}

        {/* Three.js Canvas Mount */}
        <div
          ref={mountRef}
          className="w-full h-[460px] sm:h-[540px] bg-[#060913] cursor-grab active:cursor-grabbing"
        />

        {/* Bottom Interactive Theater Controls & Seat Selector Bar */}
        <div className="p-3.5 bg-[#0F172A] text-white border-t border-slate-800 flex items-center justify-between flex-wrap gap-3">
          {/* Playback Controls */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleTogglePlay}
              className="px-3.5 py-2 rounded-xl bg-[#FF5722] hover:bg-[#F4511E] text-white text-xs font-extrabold flex items-center gap-1.5"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isPlaying ? 'Pause 3D Screen' : 'Play 3D Screen'}
            </button>

            <button
              onClick={handleToggleMute}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-1.5"
            >
              {isMuted ? (
                <VolumeX className="w-4 h-4 text-[#EF4444]" />
              ) : (
                <Volume2 className="w-4 h-4 text-[#16A34A]" />
              )}
              {isMuted ? 'Unmute' : 'Spatial Audio ON'}
            </button>

            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800 text-xs">
              <Sparkles className="w-3.5 h-3.5 text-[#F59E0B]" />
              <span>Theater Lights:</span>
              <input
                type="range"
                min={0.2}
                max={0.95}
                step={0.05}
                value={ambientDimming}
                onChange={(e) => setAmbientDimming(Number(e.target.value))}
                className="w-20 accent-[#FF5722]"
              />
            </div>
          </div>

          {/* Seat Position Camera Presets */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-bold text-slate-400 mr-1">Camera Seat:</span>
            {(
              [
                { id: 'frontRow', label: 'Front Row' },
                { id: 'vipCenter', label: 'VIP Center' },
                { id: 'balcony', label: 'Balcony' },
                { id: 'stageSide', label: 'Side Box' },
              ] as { id: SeatPreset; label: string }[]
            ).map((s) => (
              <button
                key={s.id}
                onClick={() => handleSelectSeat(s.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all ${
                  seatPreset === s.id
                    ? 'bg-[#2563EB] text-white shadow'
                    : 'bg-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                {s.label}
              </button>
            ))}

            <button
              onClick={() => handleSelectSeat('vipCenter')}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
              title="Reset Seat View"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Status Footer */}
      <div className="p-3 rounded-xl bg-[#EEF3FB] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 flex items-center justify-between flex-wrap gap-2 text-xs">
        <span className="font-bold text-[#172033] dark:text-white">🎬 {xrStatus}</span>
        <span className="text-[#52607A]">
          Drag mouse / touch to look around 360° at the seated audience &amp; carpeted hall • Scroll to zoom
        </span>
      </div>
    </div>
  );
};
