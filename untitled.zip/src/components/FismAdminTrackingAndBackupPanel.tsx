import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Download,
  Eye,
  FileKey2,
  FolderOpen,
  HardDriveDownload,
  Lock,
  RefreshCw,
  Search,
  ShieldCheck,
  Smartphone,
  Unlock,
  Usb,
  Users,
  Video,
  X,
} from 'lucide-react';
import { FismAdminUserFolder, FismBackupManifestFile } from '../types';

export interface FismAdminExportBackupModalProps {
  open: boolean;
  onClose: () => void;
  onTriggerToast: (msg: string) => void;
}

export const FismAdminExportBackupModal: React.FC<FismAdminExportBackupModalProps> = ({
  open,
  onClose,
  onTriggerToast,
}) => {
  const [transferBusy, setTransferBusy] = useState(false);
  const [transferLog, setTransferLog] = useState<string | null>(null);
  const [transferError, setTransferError] = useState<string | null>(null);
  const [manifestPreview, setManifestPreview] = useState<{
    backupFolderName: string;
    totalUsers: number;
    totalEncryptedIds: number;
    fileCount: number;
  } | null>(null);

  useEffect(() => {
    if (!open) return;
    let active = true;
    fetch('/api/admin/export-backup-manifest')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (active && data) {
          setManifestPreview({
            backupFolderName: String(data.backupFolderName || 'FISM_Admin_Vault_Backup'),
            totalUsers: Number(data.totalUsers || 0),
            totalEncryptedIds: Number(data.totalEncryptedIds || 0),
            fileCount: Array.isArray(data.files) ? data.files.length : 0,
          });
        }
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [open]);

  if (!open) return null;

  const handleWriteDirectToUsbOtg = async () => {
    setTransferError(null);
    setTransferLog(null);

    const picker = (
      window as unknown as {
        showDirectoryPicker?: (opts?: { mode?: 'read' | 'readwrite' }) => Promise<FileSystemDirectoryHandle>;
      }
    ).showDirectoryPicker;

    if (!picker) {
      setTransferError(
        'Direct OTG Folder Picker is blocked in this browser/iframe context — use the One-Click ZIP Backup button below to save all folders directly to your connected Computer or Pen Drive.',
      );
      return;
    }

    setTransferBusy(true);
    try {
      const rootDir = await picker({ mode: 'readwrite' });
      const res = await fetch('/api/admin/export-backup-manifest');
      if (!res.ok) throw new Error('Could not fetch backup manifest.');
      const bundle = (await res.json()) as {
        backupFolderName: string;
        files: FismBackupManifestFile[];
      };

      const targetRoot = await rootDir.getDirectoryHandle(bundle.backupFolderName, {
        create: true,
      });

      let writtenCount = 0;
      for (const file of bundle.files) {
        const parts = file.relativePath.split('/').filter(Boolean);
        let dirCursor = targetRoot;
        for (let i = 0; i < parts.length - 1; i++) {
          dirCursor = await dirCursor.getDirectoryHandle(parts[i], { create: true });
        }
        const fileName = parts[parts.length - 1];
        const fh = await dirCursor.getFileHandle(fileName, { create: true });
        const writable = await fh.createWritable();
        await writable.write(file.content);
        await writable.close();
        writtenCount += 1;
      }

      const msg = `Backup completed: ${writtenCount} files saved inside "${bundle.backupFolderName}" on your selected USB Pen Drive / Computer folder.`;
      setTransferLog(msg);
      onTriggerToast(msg);
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        setTransferError('Folder selection cancelled. Please pick your connected USB OTG / PC folder.');
      } else {
        setTransferError(
          err instanceof Error
            ? `${err.message} — Use One-Click ZIP Archive below for instant transfer.`
            : 'USB OTG write restricted here — use One-Click ZIP Archive below.',
        );
      }
    } finally {
      setTransferBusy(false);
    }
  };

  const handleDownloadZipArchive = async () => {
    setTransferBusy(true);
    setTransferError(null);
    setTransferLog(null);
    try {
      const res = await fetch('/api/admin/export-backup');
      if (!res.ok) throw new Error('Failed to generate Admin Vault ZIP backup.');
      const blob = await res.blob();
      const cd = res.headers.get('Content-Disposition') || '';
      const fnMatch = /filename="?([^";\n]+)"?/i.exec(cd);
      const filename = fnMatch?.[1] || 'FISM_Admin_Vault_Backup.zip';
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 15000);
      const msg = `Complete Vault Backup "${filename}" (${Math.round(blob.size / 1024)} KB) saved for your Pen Drive / Computer!`;
      setTransferLog(msg);
      onTriggerToast(msg);
    } catch (err) {
      setTransferError(err instanceof Error ? err.message : 'Backup download failed.');
    } finally {
      setTransferBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[105] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-xl rounded-2xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-6 space-y-5 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-slate-900 dark:bg-slate-800 text-white flex items-center justify-center shrink-0">
              <Usb className="w-5 h-5 text-[#FF5722]" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
                Admin Data Backup &amp; Export
              </h3>
              <p className="text-xs font-bold text-[#FF5722] mt-0.5">
                🔗 कृपया पेन ड्राइव (USB OTG) या कंप्यूटर कनेक्ट करें।
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Export Backup Prompt"
            className="min-w-[44px] min-h-[44px] rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          Save every user&apos;s tracking folder (IP addresses, device names, watch-time logs, likes,
          comments, saved/downloaded videos, follower rosters) and AES-256-GCM encrypted 18+ ID
          verification documents onto your connected USB OTG pen drive or computer.
        </p>

        {manifestPreview && (
          <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
            <div>
              <div className="text-sm font-black font-mono tabular-nums text-slate-900 dark:text-white">
                {manifestPreview.totalUsers}
              </div>
              <div className="text-[11px] text-slate-500">User Folders</div>
            </div>
            <div>
              <div className="text-sm font-black font-mono tabular-nums text-slate-900 dark:text-white">
                {manifestPreview.totalEncryptedIds}
              </div>
              <div className="text-[11px] text-slate-500">Encrypted 18+ IDs</div>
            </div>
            <div>
              <div className="text-sm font-black font-mono tabular-nums text-slate-900 dark:text-white">
                {manifestPreview.fileCount}
              </div>
              <div className="text-[11px] text-slate-500">Archive Files</div>
            </div>
          </div>
        )}

        {transferError && (
          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 font-semibold">
            {transferError}
          </div>
        )}

        {transferLog && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-200 font-semibold flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{transferLog}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            type="button"
            disabled={transferBusy}
            onClick={handleWriteDirectToUsbOtg}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 text-xs font-extrabold flex items-center justify-center gap-2 whitespace-nowrap shrink-0 hover:opacity-90 disabled:opacity-60"
          >
            <FolderOpen className="w-4 h-4" />
            {transferBusy ? 'Writing...' : 'Select USB OTG / PC Folder'}
          </button>

          <button
            type="button"
            disabled={transferBusy}
            onClick={handleDownloadZipArchive}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#FF5722] hover:bg-[#E64A19] text-white text-xs font-extrabold flex items-center justify-center gap-2 whitespace-nowrap shrink-0 shadow disabled:opacity-60"
          >
            <HardDriveDownload className="w-4 h-4" />
            {transferBusy ? 'Packaging...' : 'Download Full Backup (.ZIP)'}
          </button>
        </div>
      </div>
    </div>
  );
};

interface DecryptedIdPreview {
  docId: string;
  userId: string;
  username: string;
  displayName: string;
  docType: string;
  status: string;
  calculatedAge?: number;
  extractedDob?: string;
  uploadedAt: string;
  uploaderIp: string;
  deviceName: string;
  ciphertextHash: string;
  byteLength: number;
  decryptedDataUrl: string;
}

export interface FismAdminTrackingFoldersBoardProps {
  onTriggerToast: (msg: string) => void;
  onOpenExportModal: () => void;
}

export const FismAdminTrackingFoldersBoard: React.FC<FismAdminTrackingFoldersBoardProps> = ({
  onTriggerToast,
  onOpenExportModal,
}) => {
  const [folders, setFolders] = useState<FismAdminUserFolder[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedUid, setSelectedUid] = useState<string | null>(null);
  const [engagementFilter, setEngagementFilter] = useState<
    'all' | 'liked' | 'notLiked' | 'commented' | 'notCommented' | 'saved' | 'downloaded'
  >('all');
  const [decryptingDocId, setDecryptingDocId] = useState<string | null>(null);
  const [decryptedPreview, setDecryptedPreview] = useState<DecryptedIdPreview | null>(null);

  const loadFolders = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/user-folders');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.folders)) {
          setFolders(data.folders);
          if (!selectedUid && data.folders.length > 0) {
            setSelectedUid(data.folders[0].uid);
          }
        }
      }
    } catch {
      // keep existing
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadFolders();
  }, []);

  // Real-time WebSocket updates for Admin Tracking Folders
  useEffect(() => {
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${window.location.host}/ws/community-chat`);
    ws.onmessage = (evt) => {
      try {
        const msg = JSON.parse(String(evt.data || '{}'));
        if (msg?.type === 'admin_folder:updated' && msg.folder) {
          const updated = msg.folder as FismAdminUserFolder;
          setFolders((prev) => {
            const exists = prev.some((f) => f.uid === updated.uid);
            return exists
              ? prev.map((f) => (f.uid === updated.uid ? updated : f))
              : [updated, ...prev];
          });
        }
      } catch {
        // ignore malformed WS events
      }
    };
    return () => {
      try {
        ws.close();
      } catch {
        // ignore
      }
    };
  }, []);

  const filteredFolders = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return folders;
    return folders.filter(
      (f) =>
        f.displayName.toLowerCase().includes(q) ||
        f.username.toLowerCase().includes(q) ||
        f.uid.toLowerCase().includes(q) ||
        f.ipAddress.toLowerCase().includes(q) ||
        f.deviceName.toLowerCase().includes(q),
    );
  }, [folders, searchQuery]);

  const activeFolder = useMemo(
    () => folders.find((f) => f.uid === selectedUid) || filteredFolders[0] || null,
    [folders, filteredFolders, selectedUid],
  );

  const filteredWatchLogs = useMemo(() => {
    if (!activeFolder) return [];
    return activeFolder.watchLogs.filter((w) => {
      if (engagementFilter === 'liked') return w.liked;
      if (engagementFilter === 'notLiked') return !w.liked;
      if (engagementFilter === 'commented') return w.commented;
      if (engagementFilter === 'notCommented') return !w.commented;
      if (engagementFilter === 'saved') return w.saved;
      if (engagementFilter === 'downloaded') return w.downloaded;
      return true;
    });
  }, [activeFolder, engagementFilter]);

  const handleDecryptId = async (userId: string, docId: string) => {
    setDecryptingDocId(docId);
    try {
      const res = await fetch(`/api/admin/user-folders/${encodeURIComponent(userId)}/decrypt-id`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ docId }),
      });
      const data = await res.json();
      if (!res.ok) {
        onTriggerToast(data?.error || 'Could not decrypt verified ID document.');
        return;
      }
      setDecryptedPreview(data as DecryptedIdPreview);
    } catch {
      onTriggerToast('Network error decrypting ID document.');
    } finally {
      setDecryptingDocId(null);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header Toolbar */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-[#FF5722]" /> User Tracking Folders &amp; Encrypted ID
            Vault
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
            Per-user folder audit covering live IP addresses, device names, watch-time logs,
            liked vs unliked videos, comments, saves, branded downloads, followers, and AES-256-GCM
            encrypted 18+ ID documents.
          </p>
        </div>
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            type="button"
            onClick={() => void loadFolders()}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>
          <button
            type="button"
            onClick={onOpenExportModal}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-[#FF5722] hover:bg-[#E64A19] text-white text-xs font-extrabold flex items-center gap-1.5 whitespace-nowrap shrink-0 shadow"
          >
            <Usb className="w-4 h-4" /> Export / Transfer Data
          </button>
        </div>
      </div>

      {/* Main Split: Left User Folder Directory | Right Active Folder Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left: User Folders Sidebar */}
        <div className="lg:col-span-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search user folder (e.g. Aman, IP, UID)..."
              className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-[#FF5722]"
            />
          </div>

          {loading && folders.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">Loading user folders...</div>
          ) : filteredFolders.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No matching user folder found.
            </div>
          ) : (
            <div className="space-y-2 max-h-[620px] overflow-y-auto pr-1">
              {filteredFolders.map((f) => {
                const isSelected = activeFolder?.uid === f.uid;
                return (
                  <button
                    key={f.uid}
                    type="button"
                    onClick={() => setSelectedUid(f.uid)}
                    className={`w-full text-left p-3 rounded-xl border transition-colors flex items-center gap-3 ${
                      isSelected
                        ? 'border-[#FF5722] bg-orange-50/60 dark:bg-orange-950/25'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <img
                      src={f.avatarUrl}
                      alt={f.displayName}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-xl object-cover shrink-0 bg-slate-200 dark:bg-slate-800"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="font-extrabold text-xs text-slate-900 dark:text-white truncate">
                        {f.displayName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 truncate">
                        @{f.username} · {f.ipAddress}
                      </div>
                      <div className="text-[11px] text-slate-500 tabular-nums mt-0.5">
                        {f.watchLogs.length} watched · {f.downloadedVideos.length} downloads ·{' '}
                        {f.encryptedIdDocuments.length} ID vault
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: Active User Folder Inspection */}
        <div className="lg:col-span-8 space-y-4">
          {!activeFolder ? (
            <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center text-xs text-slate-500">
              Select a user folder on the left to inspect complete live telemetry, video engagement
              history, followers, and encrypted 18+ ID documents.
            </div>
          ) : (
            <>
              {/* Identity, IP, Device & Followers Overview */}
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
                <div className="flex items-start justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={activeFolder.avatarUrl}
                      alt={activeFolder.displayName}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-2xl object-cover shrink-0 bg-slate-200 dark:bg-slate-800"
                    />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
                          /{activeFolder.username}_folder
                        </h3>
                        <span className="text-xs font-mono text-slate-500">
                          ({activeFolder.displayName} · {activeFolder.uid})
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                        {activeFolder.email} · {activeFolder.phoneNumber} ·{' '}
                        {activeFolder.accountAgeLabel}
                      </div>
                    </div>
                  </div>

                  <span className="text-xs font-mono text-slate-500 tabular-nums">
                    Last Active: {activeFolder.lastActiveAt}
                  </span>
                </div>

                {/* Network & Device Details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200 dark:border-slate-800 text-xs">
                  <div className="space-y-1">
                    <div className="text-[11px] font-bold text-slate-500">
                      Captured IP Address
                    </div>
                    <div className="font-mono font-bold text-slate-900 dark:text-white">
                      {activeFolder.ipAddress}
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
                      <Smartphone className="w-3.5 h-3.5" /> Device Name &amp; OS
                    </div>
                    <div className="font-mono font-bold text-slate-900 dark:text-white truncate">
                      {activeFolder.deviceName}
                    </div>
                  </div>
                </div>

                {/* Key Tabular Metrics Row */}
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                  <div>
                    <div className="text-sm font-black font-mono tabular-nums text-slate-900 dark:text-white">
                      {activeFolder.totalWatchSeconds}s
                    </div>
                    <div className="text-[11px] text-slate-500">Total Watch Time</div>
                  </div>
                  <div>
                    <div className="text-sm font-black font-mono tabular-nums text-[#16A34A]">
                      {activeFolder.likedCount} / {activeFolder.unlikedWatchedCount}
                    </div>
                    <div className="text-[11px] text-slate-500">Liked / Not Liked</div>
                  </div>
                  <div>
                    <div className="text-sm font-black font-mono tabular-nums text-[#2563EB]">
                      {activeFolder.commentedCount} / {activeFolder.uncommentedWatchedCount}
                    </div>
                    <div className="text-[11px] text-slate-500">Commented / No</div>
                  </div>
                  <div>
                    <div className="text-sm font-black font-mono tabular-nums text-[#D97706]">
                      {activeFolder.savedCount}
                    </div>
                    <div className="text-[11px] text-slate-500">Saved Videos</div>
                  </div>
                  <div>
                    <div className="text-sm font-black font-mono tabular-nums text-[#FF5722]">
                      {activeFolder.downloadedVideos.length}
                    </div>
                    <div className="text-[11px] text-slate-500">Branded Downloads</div>
                  </div>
                  <div>
                    <div className="text-sm font-black font-mono tabular-nums text-slate-900 dark:text-white">
                      {activeFolder.followersCount.toLocaleString()}
                    </div>
                    <div className="text-[11px] text-slate-500">Real-Time Followers</div>
                  </div>
                </div>
              </div>

              {/* Watch-Time & Liked / Commented / Saved / Downloaded Matrix */}
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Video className="w-4 h-4 text-[#FF5722]" /> Video Watch-Time &amp; Action Matrix
                  </h4>
                  <div className="flex items-center gap-1 flex-wrap p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
                    {(
                      [
                        { id: 'all', label: 'All' },
                        { id: 'liked', label: 'Liked' },
                        { id: 'notLiked', label: 'Not Liked' },
                        { id: 'commented', label: 'Commented' },
                        { id: 'notCommented', label: 'No Comment' },
                        { id: 'saved', label: 'Saved' },
                        { id: 'downloaded', label: 'Downloaded' },
                      ] as const
                    ).map((fOpt) => (
                      <button
                        key={fOpt.id}
                        type="button"
                        onClick={() => setEngagementFilter(fOpt.id)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap shrink-0 transition-colors ${
                          engagementFilter === fOpt.id
                            ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-white shadow-sm'
                            : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {fOpt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {filteredWatchLogs.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-500">
                    No watch entries match the selected filter yet.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] text-slate-500">
                          <th className="py-2 pr-3 font-bold">Video Title</th>
                          <th className="py-2 px-2 font-bold text-right">Watch Time</th>
                          <th className="py-2 px-2 font-bold">Liked</th>
                          <th className="py-2 px-2 font-bold">Comment</th>
                          <th className="py-2 px-2 font-bold">Saved</th>
                          <th className="py-2 pl-2 font-bold text-right">Downloaded</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                        {filteredWatchLogs.map((w) => (
                          <tr
                            key={w.postId}
                            className="hover:bg-slate-50 dark:hover:bg-slate-800/40"
                          >
                            <td className="py-2.5 pr-3 max-w-[220px]">
                              <div className="font-bold text-slate-900 dark:text-white truncate">
                                {w.videoTitle}
                              </div>
                              <div className="text-[11px] font-mono text-slate-500">
                                {w.watchedAt}
                              </div>
                            </td>
                            <td className="py-2.5 px-2 text-right font-mono tabular-nums whitespace-nowrap">
                              {w.watchSeconds}s / {w.durationSeconds}s ({w.completionPct}%)
                            </td>
                            <td className="py-2.5 px-2 whitespace-nowrap">
                              <span
                                className={`font-bold ${
                                  w.liked ? 'text-[#16A34A]' : 'text-slate-400'
                                }`}
                              >
                                {w.liked ? 'Yes' : 'No'}
                              </span>
                            </td>
                            <td className="py-2.5 px-2 max-w-[160px]">
                              {w.commented ? (
                                <span className="text-[#2563EB] font-bold truncate block">
                                  Yes: &quot;{w.commentText || 'Commented'}&quot;
                                </span>
                              ) : (
                                <span className="text-slate-400 font-semibold">No</span>
                              )}
                            </td>
                            <td className="py-2.5 px-2 whitespace-nowrap">
                              <span
                                className={`font-bold ${
                                  w.saved ? 'text-[#D97706]' : 'text-slate-400'
                                }`}
                              >
                                {w.saved ? 'Yes' : 'No'}
                              </span>
                            </td>
                            <td className="py-2.5 pl-2 text-right whitespace-nowrap">
                              <span
                                className={`font-bold ${
                                  w.downloaded ? 'text-[#FF5722]' : 'text-slate-400'
                                }`}
                              >
                                {w.downloaded ? 'Yes' : 'No'}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Branded Video Downloads Log */}
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
                <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-[#FF5722]" /> Branded Watermarked Downloads (
                  {activeFolder.downloadedVideos.length})
                </h4>
                {activeFolder.downloadedVideos.length === 0 ? (
                  <div className="text-xs text-slate-500">
                    No watermarked downloads recorded yet for this user.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 dark:divide-slate-800">
                    {activeFolder.downloadedVideos.map((dl) => (
                      <div
                        key={dl.downloadId}
                        className="py-2.5 flex items-center justify-between gap-3 flex-wrap text-xs"
                      >
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 dark:text-white truncate">
                            {dl.videoTitle}
                          </div>
                          <div className="font-mono text-[11px] text-slate-500 truncate">
                            {dl.filename} · Stamp: {dl.watermarkLabel} · {dl.ffmpegEngine}
                          </div>
                        </div>
                        <div className="font-mono tabular-nums text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap">
                          {Math.max(1, Math.round(dl.sizeBytes / 1024))} KB · {dl.downloadedAt}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Real-Time Followers & Account Roster */}
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
                <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-[#2563EB]" /> Real-Time Followers &amp; Following
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <div className="text-[11px] font-bold text-slate-500 mb-1">
                      Followers ({activeFolder.followersCount.toLocaleString()})
                    </div>
                    <div className="font-mono text-slate-700 dark:text-slate-300">
                      {activeFolder.followersList.length > 0
                        ? activeFolder.followersList.join(' · ')
                        : 'No follower handles recorded'}
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] font-bold text-slate-500 mb-1">
                      Following ({activeFolder.followingCount.toLocaleString()})
                    </div>
                    <div className="font-mono text-slate-700 dark:text-slate-300">
                      {activeFolder.followingList.length > 0
                        ? activeFolder.followingList.join(' · ')
                        : 'No following handles recorded'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Encrypted 18+ Age Verification ID Vault */}
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <FileKey2 className="w-4 h-4 text-[#16A34A]" /> Encrypted 18+ Age Verification
                    ID Vault ({activeFolder.encryptedIdDocuments.length})
                  </h4>
                  <span className="text-[11px] font-mono text-slate-500 flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5 text-[#16A34A]" /> AES-256-GCM Encrypted at Rest
                  </span>
                </div>

                {activeFolder.encryptedIdDocuments.length === 0 ? (
                  <div className="text-xs text-slate-500">
                    No 18+ Government ID documents uploaded for this user yet.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 dark:divide-slate-800">
                    {activeFolder.encryptedIdDocuments.map((idDoc) => (
                      <div
                        key={idDoc.docId}
                        className="py-3 flex items-center justify-between gap-3 flex-wrap"
                      >
                        <div className="min-w-0 space-y-0.5 text-xs">
                          <div className="font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                            <ShieldCheck className="w-4 h-4 text-[#16A34A] shrink-0" />
                            <span>{idDoc.docType}</span>
                            <span className="text-[11px] font-mono text-slate-500">
                              · Status: {idDoc.status.toUpperCase()}
                              {typeof idDoc.calculatedAge === 'number'
                                ? ` · Age ${idDoc.calculatedAge} yrs`
                                : ''}
                            </span>
                          </div>
                          <div className="text-[11px] font-mono text-slate-500 truncate">
                            {idDoc.encryptionAlgorithm} · {idDoc.ciphertextHash} · IV: {idDoc.ivHex.slice(0, 12)}
                            ...
                          </div>
                          <div className="text-[11px] text-slate-500">
                            Uploaded: {idDoc.uploadedAt} · IP: {idDoc.uploaderIp} · {idDoc.deviceName}
                          </div>
                        </div>

                        <button
                          type="button"
                          disabled={decryptingDocId === idDoc.docId}
                          onClick={() => handleDecryptId(activeFolder.uid, idDoc.docId)}
                          className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 text-xs font-extrabold flex items-center gap-1.5 whitespace-nowrap shrink-0 hover:opacity-90 disabled:opacity-60"
                        >
                          {decryptingDocId === idDoc.docId ? (
                            'Decrypting...'
                          ) : (
                            <>
                              <Eye className="w-4 h-4" /> Decrypt &amp; View ID
                            </>
                          )}
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Decrypted ID Document Viewer Modal */}
      {decryptedPreview && (
        <div className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xl rounded-2xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <Unlock className="w-4 h-4 text-[#16A34A]" /> Decrypted 18+ ID Document —{' '}
                  {decryptedPreview.displayName}
                </h3>
                <p className="text-xs font-mono text-slate-500 mt-0.5">
                  @{decryptedPreview.username} · {decryptedPreview.docType} · DOB:{' '}
                  {decryptedPreview.extractedDob || 'Verified'} · Age:{' '}
                  {decryptedPreview.calculatedAge ?? '18+'} yrs
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDecryptedPreview(null)}
                aria-label="Close Decrypted ID Preview"
                className="min-w-[44px] min-h-[44px] rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center p-2 max-h-[380px]">
              <img
                src={decryptedPreview.decryptedDataUrl}
                alt={`${decryptedPreview.docType} for ${decryptedPreview.displayName}`}
                referrerPolicy="no-referrer"
                className="max-w-full max-h-[340px] object-contain rounded-lg"
              />
            </div>

            <div className="text-[11px] font-mono text-slate-500 flex items-center justify-between flex-wrap gap-2">
              <span>Hash: {decryptedPreview.ciphertextHash}</span>
              <span>
                IP: {decryptedPreview.uploaderIp} · {decryptedPreview.uploadedAt}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
