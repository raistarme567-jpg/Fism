import React, { useState, useMemo } from 'react';
import {
  Crown,
  Flame,
  Globe,
  Lock,
  CheckCircle2,
  Sparkles,
  Eye,
  Play,
  Zap,
  CreditCard,
  Smartphone,
  Wallet,
  Upload,
  AlertTriangle,
  Copy,
  X,
  ArrowUpRight,
  RotateCcw,
} from 'lucide-react';
import { FismPostItem, FismWithdrawalRequest, FismSubAccount } from '../types';

export interface WorldCurrencyRate {
  code: string;
  country: string;
  flag: string;
  name: string;
  symbol: string;
  ratePerUsd: number;
}

export const MIN_WITHDRAWAL_USD = 500;

export const WORLD_CURRENCIES: WorldCurrencyRate[] = [
  {
    code: 'INR',
    country: 'India (भारत)',
    flag: '🇮🇳',
    name: 'Indian Rupee (रुपया / पैसे)',
    symbol: '₹',
    ratePerUsd: 84.5,
  },
  {
    code: 'USD',
    country: 'United States',
    flag: '🇺🇸',
    name: 'US Dollar',
    symbol: '$',
    ratePerUsd: 1.0,
  },
  {
    code: 'CNY',
    country: 'China (Chinese Yuan)',
    flag: '🇨🇳',
    name: 'Chinese Yuan (RMB)',
    symbol: '¥',
    ratePerUsd: 7.24,
  },
  {
    code: 'JPY',
    country: 'Japan (जापान)',
    flag: '🇯🇵',
    name: 'Japanese Yen',
    symbol: '¥',
    ratePerUsd: 154.8,
  },
  {
    code: 'PKR',
    country: 'Pakistan (पाकिस्तान)',
    flag: '🇵🇰',
    name: 'Pakistani Rupee',
    symbol: '₨',
    ratePerUsd: 278.5,
  },
  {
    code: 'AED',
    country: 'UAE (Dubai)',
    flag: '🇦🇪',
    name: 'UAE Dirham',
    symbol: 'د.إ',
    ratePerUsd: 3.67,
  },
  {
    code: 'SAR',
    country: 'Saudi Arabia',
    flag: '🇸🇦',
    name: 'Saudi Riyal',
    symbol: '﷼',
    ratePerUsd: 3.75,
  },
  {
    code: 'BDT',
    country: 'Bangladesh',
    flag: '🇧🇩',
    name: 'Bangladeshi Taka',
    symbol: '৳',
    ratePerUsd: 119.5,
  },
  {
    code: 'NPR',
    country: 'Nepal (नेपाल)',
    flag: '🇳🇵',
    name: 'Nepali Rupee',
    symbol: 'रू',
    ratePerUsd: 135.2,
  },
  {
    code: 'EUR',
    country: 'Europe (Eurozone)',
    flag: '🇪🇺',
    name: 'Euro',
    symbol: '€',
    ratePerUsd: 0.93,
  },
  {
    code: 'GBP',
    country: 'United Kingdom',
    flag: '🇬🇧',
    name: 'British Pound',
    symbol: '£',
    ratePerUsd: 0.79,
  },
  {
    code: 'RUB',
    country: 'Russia',
    flag: '🇷🇺',
    name: 'Russian Ruble',
    symbol: '₽',
    ratePerUsd: 97.4,
  },
  {
    code: 'KRW',
    country: 'South Korea',
    flag: '🇰🇷',
    name: 'South Korean Won',
    symbol: '₩',
    ratePerUsd: 1395.0,
  },
  {
    code: 'IDR',
    country: 'Indonesia',
    flag: '🇮🇩',
    name: 'Indonesian Rupiah',
    symbol: 'Rp',
    ratePerUsd: 15850.0,
  },
  {
    code: 'BRL',
    country: 'Brazil',
    flag: '🇧🇷',
    name: 'Brazilian Real',
    symbol: 'R$',
    ratePerUsd: 5.75,
  },
];

interface FismCreatorEarningHubProps {
  sparksCount: number;
  onSetSparksCount: (val: number) => void;
  posts: FismPostItem[];
  selectedCurrencyCode: string;
  onSelectCurrencyCode: (code: string) => void;
  onTriggerToast: (msg: string) => void;
  userProfileId: string;
  userProfileName: string;
  userMainUsername: string;
  userAvatar: string;
  subAccounts?: FismSubAccount[];
  withdrawalRequests: FismWithdrawalRequest[];
  onSubmitWithdrawalRequest: (req: FismWithdrawalRequest) => void;
}

export const FismCreatorEarningHub: React.FC<FismCreatorEarningHubProps> = ({
  sparksCount,
  onSetSparksCount,
  posts,
  selectedCurrencyCode,
  onSelectCurrencyCode,
  onTriggerToast,
  userProfileId,
  userProfileName,
  userMainUsername,
  userAvatar,
  subAccounts = [],
  withdrawalRequests,
  onSubmitWithdrawalRequest,
}) => {
  // Simulator views in Lakhs (1 Lakh = 100,000 views -> $0.0001 USD; 50,000 Crore = $500 USD)
  // Default simulated views set so user can test both < $500 waiting and >= $500 withdrawal
  const [simulatedExtraViews, setSimulatedExtraViews] = useState<number>(650_000_000_000); // $650.00 USD ready for $500+ withdrawal test
  const [customCalculatorViews, setCustomCalculatorViews] = useState<string>('100000');

  // Withdrawal Form Modal & Inputs
  const [withdrawModalOpen, setWithdrawModalOpen] = useState<boolean>(false);
  const [pendingPopupMessage, setPendingPopupMessage] = useState<string | null>(null);
  const [withdrawAmountUsdInput, setWithdrawAmountUsdInput] = useState<string>('500');
  const [wdFullName, setWdFullName] = useState<string>(userProfileName);
  const [wdProfileId, setWdProfileId] = useState<string>(
    subAccounts[0]?.id || userProfileId || 'fism_id_main_1',
  );
  const [wdUsername] = useState<string>(userMainUsername);
  const [wdProfileName, setWdProfileName] = useState<string>(userProfileName);

  // Payment Method Selection: 1) International Card, 2) UPI, 3) Other Wallet (Amazon Pay etc.)
  const [paymentCategory, setPaymentCategory] = useState<
    'international_card' | 'upi' | 'other_wallet'
  >('upi');

  // International Debit/Credit Card Fields
  const [cardHolderName, setCardHolderName] = useState<string>(userProfileName);
  const [cardNumber, setCardNumber] = useState<string>('');
  const [cardExpiry, setCardExpiry] = useState<string>('');
  const [bankSwiftCode, setBankSwiftCode] = useState<string>('');

  // UPI Method Fields
  const [upiIdInput, setUpiIdInput] = useState<string>('');
  const [upiMobileInput, setUpiMobileInput] = useState<string>('');

  // Another Method (Amazon Pay / PayPal / Paytm / Global Wallet) Fields
  const [walletProvider, setWalletProvider] = useState<string>('Amazon Pay');
  const [walletIdInput, setWalletIdInput] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);

  const isEarningUnlocked = sparksCount >= 5000;

  // Calculate total views across channel videos + simulated milestone views
  const totalPostViews = useMemo(
    () => posts.reduce((acc, p) => acc + (p.viewsCount || 0), 0),
    [posts],
  );

  const effectiveTotalViews = totalPostViews + simulatedExtraViews;

  // Core Formula: 1 Lakh (100,000) Views = $0.0001 USD
  const calculateUsdFromViews = (views: number): number => {
    if (views < 100_000) return 0;
    return (views / 100_000) * 0.0001;
  };

  const totalGrossUsdEarned = calculateUsdFromViews(effectiveTotalViews);

  // Sum of Pending + Accepted withdrawals is deducted from the user's Wallet.
  // If Admin clicks Decline ('declined'), it is NO LONGER in this sum -> automatically refunded to user's Wallet!
  const deductedUsd = useMemo(
    () =>
      withdrawalRequests
        .filter((r) => r.status === 'pending' || r.status === 'accepted')
        .reduce((sum, r) => sum + r.amountUsd, 0),
    [withdrawalRequests],
  );

  const availableWalletUsd = Math.max(0, totalGrossUsdEarned - deductedUsd);
  const canWithdrawNow = availableWalletUsd >= MIN_WITHDRAWAL_USD;
  const progressTowardMinLimit = Math.min(100, (availableWalletUsd / MIN_WITHDRAWAL_USD) * 100);

  const activeCurrency =
    WORLD_CURRENCIES.find((c) => c.code === selectedCurrencyCode) || WORLD_CURRENCIES[0];

  const formatCurrencyAmount = (usdAmount: number, currency: WorldCurrencyRate): string => {
    const converted = usdAmount * currency.ratePerUsd;
    if (converted === 0) return `${currency.symbol}0.00`;
    if (converted < 0.01) return `${currency.symbol}${converted.toFixed(6)}`;
    if (converted < 1) return `${currency.symbol}${converted.toFixed(4)}`;
    return `${currency.symbol}${converted.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  };

  const minLimitInActiveCurrency = formatCurrencyAmount(MIN_WITHDRAWAL_USD, activeCurrency);
  const walletInActiveCurrency = formatCurrencyAmount(availableWalletUsd, activeCurrency);

  const parsedCustomViews = Math.max(0, Number(customCalculatorViews.replace(/,/g, '')) || 0);
  const customCalcUsd = (parsedCustomViews / 100_000) * 0.0001;

  const handleOpenWithdrawModal = () => {
    setFormError(null);
    if (!canWithdrawNow) {
      onTriggerToast(
        `⏳ Minimum withdrawal limit is $${MIN_WITHDRAWAL_USD} USD (${minLimitInActiveCurrency} ${activeCurrency.code}). Please wait until your wallet reaches the limit!`,
      );
      return;
    }
    setWdFullName(userProfileName);
    setWdProfileName(userProfileName);
    setWdProfileId(subAccounts[0]?.id || userProfileId || 'fism_id_main_1');
    setWithdrawAmountUsdInput(String(Math.floor(availableWalletUsd)));
    setWithdrawModalOpen(true);
  };

  const handleUploadAndSubmitWithdrawal = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const amountUsd = Number(withdrawAmountUsdInput);
    if (Number.isNaN(amountUsd) || amountUsd < MIN_WITHDRAWAL_USD) {
      setFormError(
        `Minimum withdrawal limit is $${MIN_WITHDRAWAL_USD} USD (${minLimitInActiveCurrency} ${activeCurrency.code})!`,
      );
      return;
    }
    if (amountUsd > availableWalletUsd) {
      setFormError(
        `Insufficient Wallet Balance! Your available wallet balance is $${availableWalletUsd.toFixed(2)} USD (${walletInActiveCurrency}).`,
      );
      return;
    }
    if (!wdFullName.trim() || !wdProfileId.trim() || !wdProfileName.trim()) {
      setFormError('कृपया अपना Name, Profile ID और Profile Name भरें!');
      return;
    }

    let methodLabel = '';
    let accountSummary = '';

    if (paymentCategory === 'international_card') {
      if (!cardNumber.trim() || cardNumber.replace(/\s+/g, '').length < 12) {
        setFormError('कृपया अपना सही International Debit / Credit Card नंबर डालें!');
        return;
      }
      if (!cardHolderName.trim()) {
        setFormError('कृपया Card Holder का नाम डालें!');
        return;
      }
      methodLabel = 'International Debit / Credit Card';
      accountSummary = `Card: ${cardNumber.trim()} | Holder: ${cardHolderName.trim()}${
        cardExpiry.trim() ? ` | Exp: ${cardExpiry.trim()}` : ''
      }${bankSwiftCode.trim() ? ` | SWIFT/IBAN: ${bankSwiftCode.trim()}` : ''}`;
    } else if (paymentCategory === 'upi') {
      if (!upiIdInput.trim() || !upiIdInput.includes('@')) {
        setFormError('कृपया अपना सही UPI ID डालें (उदाहरण: yourname@okaxis या 9876543210@ybl)!');
        return;
      }
      methodLabel = 'UPI Instant Payout';
      accountSummary = `UPI ID: ${upiIdInput.trim()}${
        upiMobileInput.trim() ? ` | Mobile: ${upiMobileInput.trim()}` : ''
      }`;
    } else {
      if (!walletIdInput.trim()) {
        setFormError(`कृपया अपना ${walletProvider} UPI ID / Mobile / Email डिटेल भरें!`);
        return;
      }
      methodLabel = `${walletProvider} (Other Method)`;
      accountSummary = `${walletProvider} ID/UPI: ${walletIdInput.trim()}`;
    }

    const convertedStr = formatCurrencyAmount(amountUsd, activeCurrency);

    const newRequest: FismWithdrawalRequest = {
      id: `wd_req_${Date.now()}`,
      userId: userProfileId,
      userFullName: wdFullName.trim(),
      profileId: wdProfileId.trim(),
      username: userMainUsername,
      profileName: wdProfileName.trim(),
      userAvatar,
      amountUsd,
      convertedAmountLabel: `${convertedStr} ${activeCurrency.code} ($${amountUsd.toFixed(2)} USD)`,
      currencyCode: activeCurrency.code,
      countryName: `${activeCurrency.flag} ${activeCurrency.country}`,
      paymentMethodCategory: paymentCategory,
      paymentMethodLabel: methodLabel,
      paymentAccountDetails: accountSummary,
      cardNumber: paymentCategory === 'international_card' ? cardNumber.trim() : undefined,
      cardExpiry: paymentCategory === 'international_card' ? cardExpiry.trim() : undefined,
      cardHolderName: paymentCategory === 'international_card' ? cardHolderName.trim() : undefined,
      bankSwiftCode: paymentCategory === 'international_card' ? bankSwiftCode.trim() : undefined,
      upiId: paymentCategory === 'upi' ? upiIdInput.trim() : undefined,
      walletProvider: paymentCategory === 'other_wallet' ? walletProvider : undefined,
      walletId: paymentCategory === 'other_wallet' ? walletIdInput.trim() : undefined,
      status: 'pending',
      submittedAt: new Date().toLocaleString(),
    };

    onSubmitWithdrawalRequest(newRequest);
    setWithdrawModalOpen(false);
    setPendingPopupMessage(
      `Your withdrawal is pending (${convertedStr} ${activeCurrency.code} / $${amountUsd.toFixed(2)} USD deducted from your wallet).`,
    );
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* "Your withdrawal is pending" Confirmation Popup Modal */}
      {pendingPopupMessage && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#101426] border-2 border-[#FFB300] p-6 text-white shadow-2xl space-y-4 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF5722] to-[#FFB300] flex items-center justify-center mx-auto shadow-lg">
              <CheckCircle2 className="w-9 h-9 text-white" />
            </div>
            <span className="px-3 py-1 rounded-full bg-[#FFB300]/20 border border-[#FFB300] text-[#FFB300] text-[11px] font-extrabold uppercase">
              Wallet Deducted • Sent to Admin File
            </span>
            <h3 className="text-xl font-extrabold text-white leading-snug">
              Your withdrawal is pending
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              {pendingPopupMessage}
              <br />
              आपकी विड्रॉल रिक्वेस्ट एडमिन फाइल में भेज दी गई है। एडमिन के <strong>Accept</strong> करते ही यहाँ{' '}
              <strong className="text-[#4ADE80]">Successful</strong> लिखकर आ जाएगा, और यदि एडमिन{' '}
              <strong>Decline</strong> करते हैं तो आपके पैसे वापस आपके वॉलेट में आ जाएंगे।
            </p>
            <button
              onClick={() => setPendingPopupMessage(null)}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#E53935] via-[#FF5722] to-[#FFB300] text-white text-sm font-extrabold shadow-lg"
            >
              ठीक है (OK, Got It)
            </button>
          </div>
        </div>
      )}

      {/* Header Banner */}
      <div className="fism-card p-5 sm:p-6 border-2 border-[#FFB300] bg-gradient-to-r from-[#101426] via-[#1E1B4B] to-[#31102F] text-white">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-0.5 rounded-full bg-[#FFB300] text-[#101426] text-[11px] font-extrabold uppercase flex items-center gap-1">
                <Crown className="w-3.5 h-3.5" /> 5,000 Sparks Creator Monetization
              </span>
              <span className="px-3 py-0.5 rounded-full bg-[#16A34A] text-white text-[11px] font-extrabold uppercase">
                Min Withdrawal: $500 USD ({minLimitInActiveCurrency} {activeCurrency.code})
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold flex items-center gap-2">
              💰 FISM Creator Earning &amp; $500 Global Withdrawal Hub
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Minimum Withdrawal Limit is <strong>$500 USD</strong> (automatically converted into{' '}
              <strong>
                {activeCurrency.flag} {minLimitInActiveCurrency} {activeCurrency.code}
              </strong>{' '}
              and 15+ world currencies). Withdraw via <strong>International Debit/Credit Card</strong>,{' '}
              <strong>UPI</strong>, or <strong>Amazon Pay / Global Wallets</strong> with live Admin
              Accept &amp; Decline refund protection!
            </p>
          </div>

          <div className="flex flex-col items-end gap-2">
            <div className="px-3.5 py-2 rounded-2xl bg-white/10 border border-white/20 text-right">
              <div className="text-[10px] uppercase tracking-wider text-amber-300 font-bold">
                Your Channel Sparks
              </div>
              <div className="text-lg font-extrabold font-mono flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-[#FF5722] fill-[#FF5722]" />
                {sparksCount.toLocaleString()} / 5,000
              </div>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                onClick={() => {
                  onSetSparksCount(5500);
                  onTriggerToast(
                    '🎉 Boosted to 5,500 Sparks! Creator Earning Section is now ENABLED!',
                  );
                }}
                className="px-3 py-1.5 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white text-xs font-extrabold shadow"
              >
                ✓ Enable (Set 5,500 Sparks)
              </button>
              <button
                onClick={() => {
                  onSetSparksCount(1200);
                  onTriggerToast('🔒 Set to 1,200 Sparks (< 5,000 Sparks Lock Test)');
                }}
                className="px-2.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold"
              >
                Test &lt;5K Lock
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* If < 5,000 Sparks: Locked Gate Card */}
      {!isEarningUnlocked ? (
        <div className="fism-card p-8 text-center space-y-4 border-2 border-[#FF5722]">
          <div className="w-16 h-16 rounded-2xl bg-[#FF5722]/15 text-[#FF5722] flex items-center justify-center mx-auto">
            <Lock className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-extrabold">Creator Earning Unlocks at 5,000 Sparks</h2>
          <p className="text-xs sm:text-sm text-[#52607A] max-w-lg mx-auto">
            Your channel currently has <strong>{sparksCount.toLocaleString()} Sparks</strong>. You
            need <strong>{Math.max(0, 5000 - sparksCount).toLocaleString()} more Sparks</strong> to
            enable the Creator Earning &amp; $500 Withdrawal section.
          </p>
          <div className="max-w-md mx-auto w-full bg-[#F1F5F9] dark:bg-slate-800 h-3 rounded-full overflow-hidden">
            <div
              className="h-full fism-gradient-flame transition-all"
              style={{ width: `${Math.min(100, (sparksCount / 5000) * 100)}%` }}
            />
          </div>
          <button
            onClick={() => {
              onSetSparksCount(5500);
              onTriggerToast('🎉 5,500 Sparks reached! Creator Earning Hub is now unlocked!');
            }}
            className="fism-btn-primary px-6 py-3 rounded-2xl text-sm font-extrabold shadow-xl"
          >
            ⚡ Unlock 5,000 Sparks Now (Test Creator Earning)
          </button>
        </div>
      ) : (
        <>
          {/* Live Status Banner if Latest Request was Declined or Accepted */}
          {withdrawalRequests.length > 0 && (
            <div
              className={`p-4 rounded-2xl text-white text-xs sm:text-sm font-extrabold flex items-center justify-between gap-3 shadow-lg border-2 ${
                withdrawalRequests[0].status === 'declined'
                  ? 'bg-[#DC2626] border-red-300'
                  : withdrawalRequests[0].status === 'accepted'
                  ? 'bg-[#16A34A] border-emerald-300'
                  : 'bg-gradient-to-r from-[#FF5722] to-[#E53935] border-[#FFB300]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {withdrawalRequests[0].status === 'declined' ? (
                  <RotateCcw className="w-5 h-5 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                )}
                <span>
                  {withdrawalRequests[0].status === 'pending' &&
                    `⏳ Your withdrawal is pending (${withdrawalRequests[0].convertedAmountLabel}) — Sent to Admin File for review.`}
                  {withdrawalRequests[0].status === 'accepted' &&
                    `✓ Successful! Your withdrawal of ${withdrawalRequests[0].convertedAmountLabel} has been accepted by Admin.`}
                  {withdrawalRequests[0].status === 'declined' &&
                    `✕ Your payment is declined — ${withdrawalRequests[0].convertedAmountLabel} has been refunded back into your Wallet Balance!`}
                </span>
              </div>
            </div>
          )}

          {/* TOP EARNING & WALLET SUMMARY CARDS */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Card 1: Available Wallet Balance (USD) */}
            <div className="fism-card p-5 space-y-2 border-l-4 border-[#16A34A]">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase text-[#52607A]">
                  Available Wallet Balance (USD)
                </span>
                <Wallet className="w-4 h-4 text-[#16A34A]" />
              </div>
              <div className="text-2xl font-extrabold font-mono text-[#16A34A]">
                ${availableWalletUsd.toFixed(2)} USD
              </div>
              <div className="text-[11px] text-[#52607A]">
                Gross Earned: ${totalGrossUsdEarned.toFixed(2)} • Withdrawn/Pending: $
                {deductedUsd.toFixed(2)}
              </div>
            </div>

            {/* Card 2: Wallet Balance in Selected Country Currency (Rupees / Paisa / etc.) */}
            <div className="fism-card p-5 space-y-2 border-l-4 border-[#7C3AED] bg-gradient-to-br from-[#F8FAFE] to-[#EEF3FB] dark:from-slate-900 dark:to-slate-800">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase text-[#7C3AED]">
                  {activeCurrency.flag} Wallet in {activeCurrency.country} ({activeCurrency.code})
                </span>
                <Globe className="w-4 h-4 text-[#7C3AED]" />
              </div>
              <div className="text-2xl font-extrabold font-mono text-[#7C3AED]">
                {walletInActiveCurrency}
              </div>
              <div className="text-[11px] text-[#52607A] font-semibold">
                {activeCurrency.code === 'INR'
                  ? `= ${Math.round(availableWalletUsd * activeCurrency.ratePerUsd * 100).toLocaleString()} पैसे (Paisa)`
                  : `1 USD = ${activeCurrency.symbol}${activeCurrency.ratePerUsd} ${activeCurrency.code}`}
              </div>
            </div>

            {/* Card 3: Minimum Withdrawal Limit ($500 USD Converted) + Withdraw Action */}
            <div className="fism-card p-5 space-y-2.5 border-l-4 border-[#FF5722]">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase text-[#FF5722]">
                  Minimum Withdrawal Limit ($500 USD)
                </span>
                <Crown className="w-4 h-4 text-[#FF5722]" />
              </div>
              <div className="text-xl font-extrabold font-mono">
                $500.00 = {minLimitInActiveCurrency} {activeCurrency.code}
              </div>
              <div className="w-full bg-[#F1F5F9] dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all ${
                    canWithdrawNow ? 'bg-[#16A34A]' : 'fism-gradient-flame'
                  }`}
                  style={{ width: `${progressTowardMinLimit}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] font-bold">
                <span className={canWithdrawNow ? 'text-[#16A34A]' : 'text-[#D97706]'}>
                  {canWithdrawNow
                    ? '✓ $500 Limit Completed! Ready to Withdraw'
                    : `⏳ Wait for Limit: Need $${Math.max(0, MIN_WITHDRAWAL_USD - availableWalletUsd).toFixed(2)} more`}
                </span>
                <span>{progressTowardMinLimit.toFixed(0)}%</span>
              </div>
            </div>
          </div>

          {/* WITHDRAWAL LAUNCHPAD BAR (WAIT FOR $500 OR CLICK WITHDRAW WHEN LIMIT REACHED) */}
          <div className="rounded-2xl p-5 bg-gradient-to-r from-[#101426] via-[#1E1B4B] to-[#1A2038] text-white border-2 border-[#FF5722] shadow-xl flex items-center justify-between flex-wrap gap-4">
            <div className="space-y-1 max-w-2xl">
              <div className="flex items-center gap-2 flex-wrap">
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                    canWithdrawNow
                      ? 'bg-[#16A34A] text-white'
                      : 'bg-[#FFB300] text-[#101426]'
                  }`}
                >
                  {canWithdrawNow
                    ? '✓ Minimum $500 Limit Reached'
                    : '⏳ Waiting for $500 Minimum Limit'}
                </span>
                <span className="text-xs font-mono text-amber-300">
                  Limit in {activeCurrency.country}: {minLimitInActiveCurrency} {activeCurrency.code}
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold">
                {canWithdrawNow
                  ? `Withdraw Your Earnings Now (${walletInActiveCurrency} / $${availableWalletUsd.toFixed(2)} USD Available)`
                  : `Wait Until Your Earnings Reach $500 USD (${minLimitInActiveCurrency} ${activeCurrency.code}) to Withdraw`}
              </h2>
              <p className="text-xs text-slate-300">
                लिमिट पूरा होने पर <strong>Withdraw</strong> पर क्लिक करें — आपका Name, Profile ID,
                Username, Profile Name और Payment Method (International Card / UPI / Amazon Pay)
                मांगा जाएगा।
              </p>
            </div>

            <div className="flex items-center gap-2.5 flex-wrap">
              {/* Simulator buttons to test both Waiting (< $500) and Limit Completed ($500+) */}
              <button
                type="button"
                onClick={() => {
                  setSimulatedExtraViews(120_000_000_000); // $120 USD (< $500 limit)
                  onTriggerToast(
                    '⏳ Wallet set to $120.00 USD (< $500 limit) to test waiting state!',
                  );
                }}
                className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/15"
              >
                ⏳ Test Wait (&lt;$500)
              </button>
              <button
                type="button"
                onClick={() => {
                  setSimulatedExtraViews(650_000_000_000 + deductedUsd * 1_000_000_000); // Ensures $650+ available wallet
                  onTriggerToast(
                    `🎉 Wallet reached $650.00 USD (${formatCurrencyAmount(650, activeCurrency)})! You can now click Withdraw!`,
                  );
                }}
                className="px-3 py-2 rounded-xl bg-[#FFB300] text-[#101426] text-xs font-extrabold shadow"
              >
                ⚡ Complete $500+ Limit
              </button>
              <button
                type="button"
                onClick={handleOpenWithdrawModal}
                disabled={!canWithdrawNow}
                className={`px-6 py-3 rounded-xl text-xs sm:text-sm font-black uppercase tracking-wider flex items-center gap-2 shadow-xl transition-all ${
                  canWithdrawNow
                    ? 'bg-gradient-to-r from-[#16A34A] via-[#FF5722] to-[#FFB300] text-white hover:scale-[1.02] cursor-pointer'
                    : 'bg-slate-700 text-slate-400 cursor-not-allowed opacity-75'
                }`}
              >
                <ArrowUpRight className="w-4 h-4" />
                {canWithdrawNow
                  ? `💸 Withdraw Now (${walletInActiveCurrency})`
                  : `🔒 Withdraw Locked (Min $500 / ${minLimitInActiveCurrency})`}
              </button>
            </div>
          </div>

          {/* MULTI-COUNTRY LIVE CURRENCY CONVERTER GRID (SHOWS $500 LIMIT & WALLET IN EVERY COUNTRY CURRENCY) */}
          <div className="fism-card p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h2 className="text-base sm:text-lg font-extrabold flex items-center gap-2">
                  <Globe className="w-5 h-5 text-[#2563EB]" /> Global Multi-Country Currency &amp;
                  $500 Limit Converter (India ₹/पैसे, China Yuan, Japan Yen, Pakistan ₨ &amp; 15+ Countries)
                </h2>
                <p className="text-xs text-[#52607A]">
                  Click any country below to convert your <strong>Wallet Balance</strong> and the{' '}
                  <strong>$500 USD Minimum Withdrawal Limit</strong> into that country&apos;s
                  currency!
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {WORLD_CURRENCIES.map((curr) => {
                const isSelected = curr.code === activeCurrency.code;
                const min500Converted = formatCurrencyAmount(MIN_WITHDRAWAL_USD, curr);
                return (
                  <button
                    key={curr.code}
                    type="button"
                    onClick={() => {
                      onSelectCurrencyCode(curr.code);
                      onTriggerToast(
                        `🌍 Switched Currency to ${curr.flag} ${curr.name} (${curr.code}) • $500 Limit = ${min500Converted}`,
                      );
                    }}
                    className={`p-3.5 rounded-2xl border-2 text-left transition-all flex items-center justify-between gap-2 ${
                      isSelected
                        ? 'border-[#FF5722] bg-orange-500/10 shadow-md'
                        : 'border-[#D8E1F0] dark:border-slate-800 hover:border-[#2563EB]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-lg">{curr.flag}</span>
                        <span className="font-extrabold text-xs sm:text-sm truncate">
                          {curr.country}
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-black/10 dark:bg-white/10 text-[10px] font-mono font-bold">
                          {curr.code}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#FF5722] font-bold mt-0.5">
                        Min $500 Limit = {min500Converted}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-extrabold font-mono text-xs sm:text-sm text-[#16A34A]">
                        {formatCurrencyAmount(availableWalletUsd, curr)}
                      </div>
                      <div className="text-[10px] text-[#52607A]">Wallet Balance</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* USER WITHDRAWAL REQUESTS & LIVE STATUS TRACKER (PENDING / SUCCESSFUL / DECLINED + REFUND) */}
          <div className="fism-card p-5 sm:p-6 space-y-4 border-2 border-[#FF5722]/50">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3 className="font-extrabold text-base sm:text-lg flex items-center gap-2">
                  <Wallet className="w-5 h-5 text-[#FF5722]" /> Your Withdrawal History &amp; Live
                  Admin Status
                </h3>
                <p className="text-xs text-[#52607A]">
                  जैसे ही आप विड्रॉल अपलोड करते हैं, स्टेटस <strong>Your withdrawal is pending</strong>{' '}
                  दिखता है। एडमिन के <strong>Accept</strong> करने पर <strong>Successful</strong> और{' '}
                  <strong>Decline</strong> करने पर <strong>Your payment is declined</strong> (पैसे वापस वॉलेट में) हो जाता है।
                </p>
              </div>
              <button
                type="button"
                onClick={handleOpenWithdrawModal}
                className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold"
              >
                + New Withdrawal Request
              </button>
            </div>

            {withdrawalRequests.length === 0 ? (
              <div className="p-6 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 text-center text-xs text-[#52607A] font-semibold">
                No withdrawal requests submitted yet. Click <strong>Withdraw Now</strong> above once
                your wallet reaches $500 USD ({minLimitInActiveCurrency} {activeCurrency.code}).
              </div>
            ) : (
              <div className="space-y-3">
                {withdrawalRequests.map((req) => (
                  <div
                    key={req.id}
                    className={`p-4 rounded-2xl border-2 flex items-center justify-between flex-wrap gap-3 ${
                      req.status === 'accepted'
                        ? 'border-[#16A34A] bg-emerald-500/10'
                        : req.status === 'declined'
                        ? 'border-[#DC2626] bg-red-500/10'
                        : 'border-[#FFB300] bg-amber-500/10'
                    }`}
                  >
                    <div className="space-y-1 text-xs">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-sm">{req.convertedAmountLabel}</span>
                        <span className="px-2 py-0.5 rounded bg-black/10 dark:bg-white/10 font-mono text-[11px] font-bold">
                          {req.paymentMethodLabel}
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                            req.status === 'accepted'
                              ? 'bg-[#16A34A] text-white'
                              : req.status === 'declined'
                              ? 'bg-[#DC2626] text-white'
                              : 'bg-[#FFB300] text-[#101426]'
                          }`}
                        >
                          {req.status === 'pending'
                            ? '⏳ Your withdrawal is pending'
                            : req.status === 'accepted'
                            ? '✓ Successful'
                            : '✕ Your payment is declined'}
                        </span>
                      </div>
                      <div className="text-[#52607A] dark:text-slate-300 font-mono text-[11px]">
                        Name: <strong>{req.userFullName}</strong> • Profile:{' '}
                        <strong>{req.profileName}</strong> (@{req.username} • ID: {req.profileId})
                      </div>
                      <div className="text-[#52607A] dark:text-slate-300 font-mono text-[11px]">
                        Account Details: <strong>{req.paymentAccountDetails}</strong> •{' '}
                        {req.submittedAt}
                      </div>
                      {req.status === 'pending' && (
                        <div className="font-extrabold text-[#D97706] dark:text-[#FFB300]">
                          Your withdrawal is pending — Amount deducted from wallet &amp; awaiting
                          Admin verification.
                        </div>
                      )}
                      {req.status === 'accepted' && (
                        <div className="font-extrabold text-[#16A34A]">
                          ✓ Successful — Admin accepted your withdrawal and transferred funds to your{' '}
                          {req.paymentMethodLabel}!
                        </div>
                      )}
                      {req.status === 'declined' && (
                        <div className="font-extrabold text-[#DC2626] dark:text-red-400">
                          ✕ Your payment is declined — ${req.amountUsd.toFixed(2)} USD (
                          {req.convertedAmountLabel}) has been refunded back to your Wallet!
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* CUSTOM VIEWS -> MULTI-COUNTRY CALCULATOR & VIDEO BREAKDOWN */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="fism-card p-5 space-y-4">
              <h3 className="font-extrabold text-base flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#FF5722]" /> Custom Views Earning Calculator
                (1,00,000 Views = $0.0001)
              </h3>
              <div className="space-y-2">
                <label className="text-xs font-bold text-[#52607A] block">
                  Enter Video Views (e.g. 100000 for 1 Lakh):
                </label>
                <input
                  type="number"
                  min={0}
                  step={100000}
                  value={customCalculatorViews}
                  onChange={(e) => setCustomCalculatorViews(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 font-mono text-sm font-bold"
                />
              </div>

              <div className="p-4 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-[#52607A] font-semibold">Views Entered:</span>
                  <span className="font-mono font-extrabold">
                    {parsedCustomViews.toLocaleString()} Views (
                    {(parsedCustomViews / 100_000).toFixed(2)} Lakh)
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#52607A] font-semibold">🇺🇸 US Dollar (USD):</span>
                  <span className="font-mono font-extrabold text-[#16A34A]">
                    ${customCalcUsd.toFixed(6)} USD
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#52607A] font-semibold">🇮🇳 Indian Rupee (INR):</span>
                  <span className="font-mono font-extrabold text-[#FF5722]">
                    ₹{(customCalcUsd * 84.5).toFixed(6)} INR
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#52607A] font-semibold">🇨🇳 Chinese Yuan (CNY):</span>
                  <span className="font-mono font-extrabold text-[#2563EB]">
                    ¥{(customCalcUsd * 7.24).toFixed(6)} CNY
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#52607A] font-semibold">🇯🇵 Japanese Yen (JPY):</span>
                  <span className="font-mono font-extrabold text-[#7C3AED]">
                    ¥{(customCalcUsd * 154.8).toFixed(6)} JPY
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#52607A] font-semibold">🇵🇰 Pakistani Rupee (PKR):</span>
                  <span className="font-mono font-extrabold text-emerald-600">
                    ₨{(customCalcUsd * 278.5).toFixed(6)} PKR
                  </span>
                </div>
              </div>
            </div>

            {/* Video-by-Video Monetization Breakdown */}
            <div className="fism-card p-5 space-y-3">
              <h3 className="font-extrabold text-sm sm:text-base flex items-center gap-2">
                <Play className="w-4 h-4 text-[#FF5722]" /> Video-by-Video Earning Breakdown (1 Lakh
                Views = $0.0001 USD)
              </h3>
              <div className="space-y-2">
                {posts.slice(0, 4).map((post) => {
                  const vidUsd = calculateUsdFromViews(post.viewsCount);
                  return (
                    <div
                      key={post.id}
                      className="p-3 rounded-xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 flex items-center justify-between gap-3 flex-wrap text-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Zap className="w-4 h-4 text-[#FF5722] shrink-0" />
                        <div className="min-w-0">
                          <div className="font-bold truncate max-w-xs">{post.title}</div>
                          <div className="text-[11px] text-[#52607A]">
                            @{post.authorUsername} • {post.viewsCount.toLocaleString()} views
                          </div>
                        </div>
                      </div>
                      <div className="text-right font-mono">
                        <div className="font-extrabold text-[#16A34A]">
                          {formatCurrencyAmount(vidUsd, activeCurrency)} ({activeCurrency.code})
                        </div>
                        <div className="text-[10px] text-[#52607A]">${vidUsd.toFixed(6)} USD</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </>
      )}

      {/* WITHDRAWAL FORM MODAL (NAME, PROFILE ID, USERNAME, PROFILE NAME + INTERNATIONAL CARD / UPI / AMAZON PAY) */}
      {withdrawModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handleUploadAndSubmitWithdrawal}
            className="w-full max-w-2xl rounded-3xl bg-[#101426] border-2 border-[#FF5722] text-white p-5 sm:p-6 shadow-2xl space-y-4 my-8"
          >
            <div className="flex items-center justify-between border-b border-white/15 pb-3">
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-[#16A34A] text-white text-[10px] font-black uppercase">
                  Minimum $500 Limit Verified • Wallet: ${availableWalletUsd.toFixed(2)} USD
                </span>
                <h2 className="text-lg sm:text-xl font-black mt-1">
                  💸 Withdraw Creator Earnings ({activeCurrency.flag} {activeCurrency.code})
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setWithdrawModalOpen(false)}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Step 1: User Identity Details (Name, Profile ID, Username, Profile Name) */}
            <div className="p-4 rounded-2xl bg-[#181F36] border border-white/15 space-y-3">
              <div className="text-xs font-extrabold uppercase text-[#FFB300]">
                1. Your Profile &amp; Identity Details (आपका नाम, प्रोफाइल ID और यूजरनेम)
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">
                    Your Full Name (आपका नाम) *
                  </label>
                  <input
                    type="text"
                    value={wdFullName}
                    onChange={(e) => setWdFullName(e.target.value)}
                    placeholder="Enter your full name..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-slate-700 text-white text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">
                    Select / Enter Profile ID (प्रोफाइल ID) *
                  </label>
                  {subAccounts.length > 0 ? (
                    <select
                      value={wdProfileId}
                      onChange={(e) => {
                        setWdProfileId(e.target.value);
                        const found = subAccounts.find((a) => a.id === e.target.value);
                        if (found) setWdProfileName(found.displayName);
                      }}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-[#FF5722] text-white text-xs font-mono font-bold"
                    >
                      {subAccounts.map((acc) => (
                        <option key={acc.id} value={acc.id}>
                          ID: {acc.id} — {acc.displayName} (@{userMainUsername})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type="text"
                      value={wdProfileId}
                      onChange={(e) => setWdProfileId(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-slate-700 text-white text-xs font-mono font-bold"
                    />
                  )}
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">
                    Username (@यूजरनेम — Locked to Main Profile)
                  </label>
                  <input
                    type="text"
                    value={`@${wdUsername}`}
                    readOnly
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-slate-700 text-amber-300 text-xs font-mono font-extrabold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">
                    Profile Name (प्रोफाइल का नाम) *
                  </label>
                  <input
                    type="text"
                    value={wdProfileName}
                    onChange={(e) => setWdProfileName(e.target.value)}
                    placeholder="Enter your profile name..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-slate-700 text-white text-xs font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Step 2: Withdrawal Amount (Minimum $500 USD, Auto-Converted in Selected Country Currency) */}
            <div className="p-4 rounded-2xl bg-[#181F36] border border-[#FFB300]/50 space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <label className="text-xs font-extrabold uppercase text-[#FFB300]">
                  2. Withdrawal Amount (Minimum $500 USD = {minLimitInActiveCurrency}{' '}
                  {activeCurrency.code})
                </label>
                <span className="text-xs font-mono text-emerald-400 font-bold">
                  Max Available: ${availableWalletUsd.toFixed(2)} USD ({walletInActiveCurrency})
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                <div className="relative">
                  <input
                    type="number"
                    min={MIN_WITHDRAWAL_USD}
                    max={availableWalletUsd}
                    step="1"
                    value={withdrawAmountUsdInput}
                    onChange={(e) => setWithdrawAmountUsdInput(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-[#101426] border-2 border-[#FF5722] text-white font-mono text-sm font-black"
                  />
                  <span className="absolute right-3 top-2.5 text-xs font-bold text-amber-300">
                    USD ($)
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#101426] border border-slate-700 text-xs font-mono">
                  <div className="text-[10px] text-slate-400">
                    Converted in {activeCurrency.flag} {activeCurrency.country}:
                  </div>
                  <div className="text-sm font-black text-[#4ADE80]">
                    {formatCurrencyAmount(Number(withdrawAmountUsdInput) || 0, activeCurrency)}{' '}
                    {activeCurrency.code}
                  </div>
                </div>
              </div>
            </div>

            {/* Step 3: Select Payment Method (International Card / UPI / Amazon Pay & Others) */}
            <div className="p-4 rounded-2xl bg-[#181F36] border border-white/15 space-y-3">
              <div className="text-xs font-extrabold uppercase text-[#FFB300]">
                3. Select Payment Method (अपना पेमेंट मेथड चुनें)
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <button
                  type="button"
                  onClick={() => setPaymentCategory('international_card')}
                  className={`p-3 rounded-xl border-2 text-left transition-all flex items-center gap-2 ${
                    paymentCategory === 'international_card'
                      ? 'border-[#FF5722] bg-[#FF5722]/20 text-white'
                      : 'border-slate-700 bg-[#101426] text-slate-300'
                  }`}
                >
                  <CreditCard className="w-5 h-5 text-[#FFB300] shrink-0" />
                  <div>
                    <div className="text-xs font-extrabold">International / Debit Card</div>
                    <div className="text-[10px] opacity-80">Visa, MasterCard, SWIFT</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentCategory('upi')}
                  className={`p-3 rounded-xl border-2 text-left transition-all flex items-center gap-2 ${
                    paymentCategory === 'upi'
                      ? 'border-[#16A34A] bg-[#16A34A]/20 text-white'
                      : 'border-slate-700 bg-[#101426] text-slate-300'
                  }`}
                >
                  <Smartphone className="w-5 h-5 text-[#4ADE80] shrink-0" />
                  <div>
                    <div className="text-xs font-extrabold">UPI Method</div>
                    <div className="text-[10px] opacity-80">GPay, PhonePe, Paytm UPI</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentCategory('other_wallet')}
                  className={`p-3 rounded-xl border-2 text-left transition-all flex items-center gap-2 ${
                    paymentCategory === 'other_wallet'
                      ? 'border-[#2563EB] bg-[#2563EB]/20 text-white'
                      : 'border-slate-700 bg-[#101426] text-slate-300'
                  }`}
                >
                  <Wallet className="w-5 h-5 text-sky-400 shrink-0" />
                  <div>
                    <div className="text-xs font-extrabold">Amazon Pay &amp; Others</div>
                    <div className="text-[10px] opacity-80">Amazon Pay, PayPal, Wallet</div>
                  </div>
                </button>
              </div>

              {/* Dynamic Fields Based on Selected Payment Method */}
              {paymentCategory === 'international_card' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-[11px] font-bold text-amber-300 mb-1">
                      Card Holder Name *
                    </label>
                    <input
                      type="text"
                      value={cardHolderName}
                      onChange={(e) => setCardHolderName(e.target.value)}
                      placeholder="Name on Debit / Credit Card"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-slate-700 text-white text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-amber-300 mb-1">
                      Debit / Credit Card Number (16 Digits) *
                    </label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="4532 •••• •••• 8891"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-[#FF5722] text-white text-xs font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      Card Expiry Date (MM/YY)
                    </label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      placeholder="08/29"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-slate-700 text-white text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      International Bank SWIFT / IBAN Code (Optional)
                    </label>
                    <input
                      type="text"
                      value={bankSwiftCode}
                      onChange={(e) => setBankSwiftCode(e.target.value)}
                      placeholder="e.g. SBININBB / CHASUS33"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-slate-700 text-white text-xs font-mono"
                    />
                  </div>
                </div>
              )}

              {paymentCategory === 'upi' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-[11px] font-bold text-[#4ADE80] mb-1">
                      Enter Your UPI ID (आपका UPI ID) *
                    </label>
                    <input
                      type="text"
                      value={upiIdInput}
                      onChange={(e) => setUpiIdInput(e.target.value)}
                      placeholder="e.g. yourname@okaxis or 9876543210@ybl"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-[#16A34A] text-white text-xs font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      UPI Linked Mobile Number (Optional)
                    </label>
                    <input
                      type="tel"
                      value={upiMobileInput}
                      onChange={(e) => setUpiMobileInput(e.target.value)}
                      placeholder="+91 9876543210"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-slate-700 text-white text-xs font-mono"
                    />
                  </div>
                </div>
              )}

              {paymentCategory === 'other_wallet' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-[11px] font-bold text-sky-400 mb-1">
                      Select Wallet / Payment App
                    </label>
                    <select
                      value={walletProvider}
                      onChange={(e) => setWalletProvider(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-[#2563EB] text-white text-xs font-bold"
                    >
                      <option value="Amazon Pay">Amazon Pay (UPI / Wallet)</option>
                      <option value="PayPal Global">PayPal International</option>
                      <option value="Paytm Wallet / UPI">Paytm Wallet / UPI</option>
                      <option value="PhonePe Wallet">PhonePe Wallet</option>
                      <option value="Alipay / WeChat Pay">Alipay / WeChat Pay (Yuan)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-sky-400 mb-1">
                      {walletProvider} UPI ID / Mobile / Account ID *
                    </label>
                    <input
                      type="text"
                      value={walletIdInput}
                      onChange={(e) => setWalletIdInput(e.target.value)}
                      placeholder="e.g. 9876543210@apl or email@domain.com"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#101426] border border-[#2563EB] text-white text-xs font-mono font-bold"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setWithdrawModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-white/10 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#16A34A] via-[#FF5722] to-[#FFB300] text-white text-xs sm:text-sm font-black uppercase tracking-wider shadow-xl flex items-center gap-2"
              >
                <Upload className="w-4 h-4" /> Upload &amp; Submit Withdrawal (अपलोड करें)
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
