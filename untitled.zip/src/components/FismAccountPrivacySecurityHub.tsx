import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Lock,
  Globe,
  KeyRound,
  UserPlus,
  Users,
  CheckCircle2,
  XCircle,
  Upload,
  Eye,
  EyeOff,
  ScanFace,
  Sparkles,
  UserCheck,
  UserX,
  AlertTriangle,
  Edit3,
  RefreshCw,
} from 'lucide-react';
import {
  FismAccountPrivacyMode,
  FismAgeVerificationResult,
  FismPrivateFollowRequest,
  FismSubAccount,
  GENERATED_ASSETS,
} from '../types';

interface FismAccountPrivacySecurityHubProps {
  subAccounts: FismSubAccount[];
  activeSubAccount: FismSubAccount;
  followRequests: FismPrivateFollowRequest[];
  creatingSubId: boolean;
  verifyingAge: boolean;
  lastAgeResult: FismAgeVerificationResult | null;
  onRequestSwitchSubAccount: (account: FismSubAccount) => void;
  onCreateSubAccount: (payload: {
    username: string;
    displayName: string;
    password: string;
    phoneNumber: string;
    avatarUrl: string;
    bio: string;
  }) => Promise<boolean>;
  onUpdateActiveAccountPrivacy: (mode: FismAccountPrivacyMode) => Promise<void>;
  onOpenEditActiveProfile: () => void;
  onSetAccountPassword: (
    accountId: string,
    currentPassword: string,
    newPassword: string,
  ) => Promise<boolean>;
  onVerifyAadhaarImage: (imageBase64: string, mimeType: string) => Promise<void>;
  onRespondFollowRequest: (requestId: string, action: 'accept' | 'decline') => Promise<void>;
  onSendFollowRequestToTarget: (targetAccount: FismSubAccount) => Promise<void>;
}

function renderSampleAadhaarCanvasBase64(mode: 'adult' | 'minor' | 'blurry'): {
  dataUrl: string;
  mimeType: string;
} {
  const canvas = document.createElement('canvas');
  canvas.width = 760;
  canvas.height = 460;
  const ctx = canvas.getContext('2d');
  if (!ctx) return { dataUrl: '', mimeType: 'image/png' };

  // Card background
  ctx.fillStyle = '#FFFDF7';
  ctx.fillRect(0, 0, 760, 460);

  // Tricolor top ribbon
  ctx.fillStyle = '#FF9933';
  ctx.fillRect(0, 0, 760, 18);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 18, 760, 18);
  ctx.fillStyle = '#138808';
  ctx.fillRect(0, 36, 760, 18);

  // Card border
  ctx.strokeStyle = '#1E293B';
  ctx.lineWidth = 4;
  ctx.strokeRect(12, 62, 736, 384);

  if (mode === 'blurry') {
    ctx.filter = 'blur(9px)';
  }

  // Header text
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 26px sans-serif';
  ctx.fillText('GOVERNMENT OF INDIA • SAMPLE AADHAAR CARD', 36, 108);

  ctx.fillStyle = '#DC2626';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText('UNIQUE IDENTIFICATION AUTHORITY OF INDIA (SAMPLE)', 36, 136);

  // Photo box
  ctx.fillStyle = '#CBD5E1';
  ctx.fillRect(42, 168, 150, 185);
  ctx.fillStyle = '#334155';
  ctx.beginPath();
  ctx.arc(117, 232, 34, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillRect(68, 276, 98, 62);

  // Details
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 24px sans-serif';
  ctx.fillText(
    mode === 'minor' ? 'Name: Aarav Sharma (Minor)' : 'Name: Rohan Verma',
    225,
    205,
  );

  ctx.font = 'bold 26px monospace';
  ctx.fillStyle = mode === 'minor' ? '#B91C1C' : '#065F46';
  const dobLabel =
    mode === 'adult'
      ? 'DOB: 14/05/1998'
      : mode === 'minor'
        ? 'DOB: 20/08/2012'
        : 'DOB: ??/??/????';
  ctx.fillText(dobLabel, 225, 255);

  ctx.fillStyle = '#1E293B';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('Gender: MALE', 225, 300);

  ctx.font = 'bold 28px monospace';
  ctx.fillText('XXXX XXXX 4821', 225, 378);

  ctx.font = 'bold 14px sans-serif';
  ctx.fillStyle = '#475569';
  ctx.fillText('Mera Aadhaar, Meri Pehchaan (Masked Sample Verification Card)', 225, 415);

  return {
    dataUrl: canvas.toDataURL('image/png'),
    mimeType: 'image/png',
  };
}

export const FismAccountPrivacySecurityHub: React.FC<FismAccountPrivacySecurityHubProps> = ({
  subAccounts,
  activeSubAccount,
  followRequests,
  creatingSubId,
  verifyingAge,
  lastAgeResult,
  onRequestSwitchSubAccount,
  onCreateSubAccount,
  onUpdateActiveAccountPrivacy,
  onOpenEditActiveProfile,
  onSetAccountPassword,
  onVerifyAadhaarImage,
  onRespondFollowRequest,
  onSendFollowRequestToTarget,
}) => {
  const [newUsername, setNewUsername] = useState('');
  const [newDisplayName, setNewDisplayName] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [newPhone, setNewPhone] = useState('+91 ');
  const [newBio, setNewBio] = useState('');
  const [newAvatar, setNewAvatar] = useState<string>(GENERATED_ASSETS.avatar2);
  const [showCreatePwd, setShowCreatePwd] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Set/Rotate Password state for active account
  const [pwdEditorId, setPwdEditorId] = useState<string | null>(null);
  const [currentPwdDraft, setCurrentPwdDraft] = useState('');
  const [nextPwdDraft, setNextPwdDraft] = useState('');
  const [pwdEditorMsg, setPwdEditorMsg] = useState<string | null>(null);

  // Preview image (transient only — never stored permanently)
  const [transientPreviewUrl, setTransientPreviewUrl] = useState<string>('');
  const [transientMime, setTransientMime] = useState<string>('image/png');

  const activeIsVerified = Boolean(activeSubAccount.isAgeVerified);
  const activePrivacy: FismAccountPrivacyMode =
    activeSubAccount.privacyMode === 'public' && activeIsVerified ? 'public' : 'private';

  const incomingRequestsForActive = followRequests.filter(
    (r) => r.targetUid === activeSubAccount.id,
  );
  const pendingIncoming = incomingRequestsForActive.filter((r) => r.status === 'pending');

  const handleSubmitCreateSubId = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    const cleanedUser = newUsername.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_');
    if (cleanedUser.length < 3) {
      setFormError('Sub-ID @username must be at least 3 characters (letters, numbers, _).');
      return;
    }
    if (!newDisplayName.trim()) {
      setFormError('Display Name is required for the new Sub-ID.');
      return;
    }
    if (newPassword.length < 6) {
      setFormError('Custom Sub-ID Password is mandatory (minimum 6 characters).');
      return;
    }
    if (newPassword !== confirmPassword) {
      setFormError('Sub-ID Password and Confirm Password do not match.');
      return;
    }

    const ok = await onCreateSubAccount({
      username: cleanedUser,
      displayName: newDisplayName.trim(),
      password: newPassword,
      phoneNumber: newPhone.trim() || '+91 98765 43210',
      avatarUrl: newAvatar || GENERATED_ASSETS.avatar2,
      bio: newBio.trim(),
    });
    if (ok) {
      setNewUsername('');
      setNewDisplayName('');
      setNewPassword('');
      setConfirmPassword('');
      setNewBio('');
    }
  };

  return (
    <div className="space-y-5">
      {/* 1. MASTER & SUB-ID HIERARCHY + ISOLATED PASSWORD-PROTECTED SWITCHING */}
      <div className="fism-card p-5 border-2 border-[#2563EB] space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <span className="px-2.5 py-0.5 rounded-full bg-[#2563EB] text-white text-[10px] font-extrabold uppercase">
              Master → Sub-ID Isolation Architecture
            </span>
            <h2 className="font-extrabold text-base sm:text-lg mt-1 flex items-center gap-2">
              <Users className="w-5 h-5 text-[#2563EB]" /> Master Account &amp; Password-Locked
              Sub-IDs
            </h2>
            <p className="text-xs text-[#52607A] dark:text-slate-400">
              Each Sub-ID has its own isolated <strong>@username</strong>,{' '}
              <strong>privacy settings</strong>, <strong>followers</strong>, and{' '}
              <strong>salted scrypt password hash</strong>. Changes in one Sub-ID never affect the
              Master Account or sibling Sub-IDs.
            </p>
          </div>
          <span className="px-3 py-1 rounded-full bg-[#2563EB]/15 text-[#2563EB] text-xs font-extrabold">
            {subAccounts.length} Linked Profile{subAccounts.length > 1 ? 's' : ''}
          </span>
        </div>

        {/* Linked Accounts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {subAccounts.map((acc, idx) => {
            const isCurrent = acc.id === activeSubAccount.id;
            const accPrivacy: FismAccountPrivacyMode =
              acc.privacyMode === 'public' && acc.isAgeVerified ? 'public' : 'private';
            return (
              <div
                key={acc.id}
                className={`p-3.5 rounded-2xl border-2 flex flex-col justify-between gap-3 transition-all ${
                  isCurrent
                    ? 'border-[#FF5722] bg-orange-500/5 shadow-md'
                    : 'border-[#D8E1F0] dark:border-slate-700 bg-white dark:bg-slate-900'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={acc.avatarUrl}
                      alt={acc.displayName}
                      className="w-11 h-11 rounded-full object-cover ring-2 ring-[#2563EB] shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1 flex-wrap">
                        <span className="font-extrabold text-xs truncate">
                          {acc.displayName}
                        </span>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-black uppercase ${
                            acc.isMaster || idx === 0
                              ? 'bg-[#FFB300] text-[#101426]'
                              : 'bg-[#7C3AED] text-white'
                          }`}
                        >
                          {acc.isMaster || idx === 0 ? 'MASTER' : `SUB-ID #${idx}`}
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-[#2563EB] font-bold truncate">
                        @{acc.username}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Isolated Status Chips */}
                <div className="flex flex-wrap gap-1.5 text-[10px] font-extrabold">
                  <span
                    className={`px-2 py-0.5 rounded-md flex items-center gap-1 ${
                      accPrivacy === 'public'
                        ? 'bg-emerald-500/15 text-[#16A34A]'
                        : 'bg-slate-200 dark:bg-slate-800 text-[#52607A] dark:text-slate-300'
                    }`}
                  >
                    {accPrivacy === 'public' ? (
                      <>
                        <Globe className="w-3 h-3" /> Public
                      </>
                    ) : (
                      <>
                        <Lock className="w-3 h-3" /> Private
                      </>
                    )}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-md flex items-center gap-1 ${
                      acc.isAgeVerified
                        ? 'bg-emerald-500/15 text-[#16A34A]'
                        : 'bg-amber-500/15 text-[#D97706]'
                    }`}
                  >
                    {acc.isAgeVerified ? '✓ 18+ Verified' : 'ID Unverified'}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-md flex items-center gap-1 ${
                      acc.hasPassword
                        ? 'bg-purple-500/15 text-[#7C3AED]'
                        : 'bg-slate-200 dark:bg-slate-800 text-[#52607A]'
                    }`}
                  >
                    <KeyRound className="w-3 h-3" />
                    {acc.hasPassword ? 'Password Locked' : 'No Lock'}
                  </span>
                </div>

                <div className="text-[10px] text-[#52607A] flex items-center justify-between">
                  <span>Sparks: {acc.sparksCount ?? 0}</span>
                  <span>Flames: {acc.flamesCount ?? 0}</span>
                </div>

                {/* Actions */}
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() =>
                      isCurrent ? onOpenEditActiveProfile() : onRequestSwitchSubAccount(acc)
                    }
                    className={`py-2 px-2 rounded-xl text-[11px] font-extrabold flex items-center justify-center gap-1 ${
                      isCurrent ? 'bg-[#16A34A] text-white' : 'fism-btn-primary'
                    }`}
                  >
                    {isCurrent ? (
                      <>
                        <Edit3 className="w-3 h-3" /> Active • Edit
                      </>
                    ) : (
                      <>
                        <KeyRound className="w-3 h-3" /> Switch ID
                      </>
                    )}
                  </button>

                  {isCurrent ? (
                    <button
                      type="button"
                      onClick={() => {
                        setPwdEditorId(pwdEditorId === acc.id ? null : acc.id);
                        setPwdEditorMsg(null);
                      }}
                      className="py-2 px-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-extrabold"
                    >
                      🔐 {acc.hasPassword ? 'Change Pwd' : 'Set Pwd'}
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onSendFollowRequestToTarget(acc)}
                      className="py-2 px-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-extrabold hover:border-[#7C3AED]"
                    >
                      <UserPlus className="w-3 h-3 inline mr-1" />
                      Follow ID
                    </button>
                  )}
                </div>

                {pwdEditorId === acc.id && (
                  <div className="p-2.5 rounded-xl bg-[#F8FAFE] dark:bg-slate-800 border border-[#7C3AED]/40 space-y-2">
                    {acc.hasPassword && (
                      <input
                        type="password"
                        value={currentPwdDraft}
                        onChange={(e) => setCurrentPwdDraft(e.target.value)}
                        placeholder="Current Password..."
                        className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                      />
                    )}
                    <input
                      type="password"
                      value={nextPwdDraft}
                      onChange={(e) => setNextPwdDraft(e.target.value)}
                      placeholder="New Password (min 6 chars)..."
                      className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                    />
                    {pwdEditorMsg && (
                      <div className="text-[10px] font-bold text-[#DC2626]">{pwdEditorMsg}</div>
                    )}
                    <button
                      type="button"
                      onClick={async () => {
                        setPwdEditorMsg(null);
                        if (nextPwdDraft.length < 6) {
                          setPwdEditorMsg('Password must be at least 6 characters.');
                          return;
                        }
                        const saved = await onSetAccountPassword(
                          acc.id,
                          currentPwdDraft,
                          nextPwdDraft,
                        );
                        if (saved) {
                          setPwdEditorId(null);
                          setCurrentPwdDraft('');
                          setNextPwdDraft('');
                        } else {
                          setPwdEditorMsg('Failed to update password. Check current password.');
                        }
                      }}
                      className="w-full py-1.5 rounded-lg bg-[#7C3AED] text-white text-xs font-extrabold"
                    >
                      Save Hash-Protected Password
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Create New Isolated Sub-ID Form */}
        <form
          onSubmit={handleSubmitCreateSubId}
          className="p-4 rounded-2xl bg-[#F1F5F9] dark:bg-slate-800/90 border border-[#2563EB]/40 space-y-3"
        >
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-xs sm:text-sm font-extrabold text-[#2563EB] flex items-center gap-1.5">
              <UserPlus className="w-4 h-4" /> Create New Isolated Sub-ID (Mandatory Password
              Protection)
            </h3>
            <span className="text-[10px] font-bold text-[#52607A]">
              Salted Scrypt Password Hash • Starts Private until 18+ Verified
            </span>
          </div>

          {formError && (
            <div className="p-2.5 rounded-xl bg-[#DC2626] text-white text-xs font-bold">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            <div>
              <label className="block text-[10px] font-extrabold uppercase text-[#52607A] mb-1">
                Independent @Username *
              </label>
              <input
                type="text"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder="e.g. gaming_nova_alt"
                className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-[10px] font-extrabold uppercase text-[#52607A] mb-1">
                Sub-ID Display Name *
              </label>
              <input
                type="text"
                value={newDisplayName}
                onChange={(e) => setNewDisplayName(e.target.value)}
                placeholder="e.g. Nova Esports Alt"
                className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              />
            </div>
            <div>
              <label className="block text-[10px] font-extrabold uppercase text-[#52607A] mb-1">
                Mobile Number
              </label>
              <input
                type="tel"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                placeholder="+91 9876543210"
                className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-[10px] font-extrabold uppercase text-[#DC2626] mb-1 flex items-center gap-1">
                <KeyRound className="w-3 h-3" /> Sub-ID Password * (Min 6 chars)
              </label>
              <div className="relative">
                <input
                  type={showCreatePwd ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Required to switch/login..."
                  className="w-full px-3 py-2 pr-9 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                />
                <button
                  type="button"
                  onClick={() => setShowCreatePwd((s) => !s)}
                  className="absolute right-2.5 top-2 text-[#52607A]"
                >
                  {showCreatePwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-[10px] font-extrabold uppercase text-[#DC2626] mb-1">
                Confirm Sub-ID Password *
              </label>
              <input
                type={showCreatePwd ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter password..."
                className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              />
            </div>
            <div>
              <label className="block text-[10px] font-extrabold uppercase text-[#52607A] mb-1">
                Sub-ID Bio (Isolated)
              </label>
              <input
                type="text"
                value={newBio}
                onChange={(e) => setNewBio(e.target.value)}
                placeholder="Short isolated bio..."
                className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
              />
            </div>
          </div>

          <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
            <label className="px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold cursor-pointer flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>{newAvatar ? '✓ Sub-ID Photo Ready' : 'Upload Sub-ID Avatar'}</span>
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => {
                    if (typeof reader.result === 'string') setNewAvatar(reader.result);
                  };
                  reader.readAsDataURL(file);
                }}
              />
            </label>
            <button
              type="submit"
              disabled={creatingSubId}
              className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-md disabled:opacity-60"
            >
              <ShieldCheck className="w-4 h-4" />
              {creatingSubId
                ? 'Creating & Hashing Password...'
                : '+ Create Password-Locked Sub-ID'}
            </button>
          </div>
        </form>
      </div>

      {/* 2. ACCOUNT PRIVACY MODE (PUBLIC vs PRIVATE) + FOLLOW REQUESTS */}
      <div className="fism-card p-5 border-2 border-[#7C3AED] space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <span className="px-2.5 py-0.5 rounded-full bg-[#7C3AED] text-white text-[10px] font-extrabold uppercase">
              Active Account Privacy Gate (@{activeSubAccount.username})
            </span>
            <h2 className="font-extrabold text-base sm:text-lg mt-1 flex items-center gap-2">
              {activePrivacy === 'public' ? (
                <Globe className="w-5 h-5 text-[#16A34A]" />
              ) : (
                <Lock className="w-5 h-5 text-[#7C3AED]" />
              )}
              Account Privacy Mode: {activePrivacy === 'public' ? 'PUBLIC' : 'PRIVATE'}
            </h2>
            <p className="text-xs text-[#52607A] dark:text-slate-400">
              {activePrivacy === 'public'
                ? 'Public Account active (18+ Verified): Videos, posts & Sparks are visible to everyone and users can follow instantly.'
                : 'Private Account active: Profile videos, posts, and Sparks are hidden from non-followers until you accept their follow request.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onUpdateActiveAccountPrivacy('private')}
              className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border-2 ${
                activePrivacy === 'private'
                  ? 'bg-[#7C3AED] text-white border-[#7C3AED]'
                  : 'bg-[#F1F5F9] dark:bg-slate-800 border-[#D8E1F0] dark:border-slate-700'
              }`}
            >
              <Lock className="w-3.5 h-3.5" /> Private Account
            </button>
            <button
              type="button"
              onClick={() => onUpdateActiveAccountPrivacy('public')}
              className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border-2 ${
                activePrivacy === 'public'
                  ? 'bg-[#16A34A] text-white border-[#16A34A]'
                  : activeIsVerified
                    ? 'bg-[#F1F5F9] dark:bg-slate-800 border-[#16A34A] text-[#16A34A]'
                    : 'bg-amber-500/10 border-amber-500/60 text-[#D97706]'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              {activeIsVerified ? 'Public Account' : '🔒 Public (18+ ID Required)'}
            </button>
          </div>
        </div>

        {/* Pending Follow Requests for Active ID */}
        <div className="p-4 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-xs font-extrabold uppercase text-[#7C3AED] flex items-center gap-1.5">
              <UserCheck className="w-4 h-4" /> Private Follow Requests for @{activeSubAccount.username} (
              {pendingIncoming.length} Pending)
            </h3>
          </div>

          {incomingRequestsForActive.length === 0 ? (
            <p className="text-xs text-[#52607A]">
              No follow requests targeting @{activeSubAccount.username} yet. Follow a Private ID
              from Find Flame or another Sub-ID to send a formal request here &amp; in Warm Sparks.
            </p>
          ) : (
            <div className="space-y-2">
              {incomingRequestsForActive.map((req) => (
                <div
                  key={req.id}
                  className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between gap-3 flex-wrap"
                >
                  <div className="flex items-center gap-2.5">
                    <img
                      src={req.requesterAvatar}
                      alt={req.requesterDisplayName}
                      className="w-9 h-9 rounded-full object-cover"
                    />
                    <div className="text-xs">
                      <div className="font-extrabold">
                        {req.requesterDisplayName}{' '}
                        <span className="font-mono text-[#2563EB]">@{req.requesterUsername}</span>
                      </div>
                      <div className="text-[10px] text-[#52607A]">
                        Requested access to @{req.targetUsername} • {req.createdAt}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {req.status === 'pending' ? (
                      <>
                        <button
                          type="button"
                          onClick={() => onRespondFollowRequest(req.id, 'accept')}
                          className="px-3 py-1.5 rounded-lg bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1"
                        >
                          <UserCheck className="w-3.5 h-3.5" /> Accept
                        </button>
                        <button
                          type="button"
                          onClick={() => onRespondFollowRequest(req.id, 'decline')}
                          className="px-3 py-1.5 rounded-lg bg-[#DC2626] text-white text-xs font-extrabold flex items-center gap-1"
                        >
                          <UserX className="w-3.5 h-3.5" /> Decline
                        </button>
                      </>
                    ) : (
                      <span
                        className={`px-2.5 py-1 rounded-lg text-xs font-extrabold uppercase ${
                          req.status === 'accepted'
                            ? 'bg-emerald-500/15 text-[#16A34A]'
                            : 'bg-red-500/15 text-[#DC2626]'
                        }`}
                      >
                        {req.status === 'accepted' ? '✓ Accepted — Unlocked' : '✕ Declined'}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 3. AI-POWERED AADHAAR / GOVERNMENT ID AGE VERIFICATION PROTOCOL */}
      <div
        id="fism-aadhaar-verification-panel"
        className={`fism-card p-5 border-2 space-y-4 ${
          activeIsVerified
            ? 'border-[#16A34A]'
            : activeSubAccount.ageVerificationStatus === 'rejected'
              ? 'border-[#DC2626]'
              : 'border-[#F59E0B]'
        }`}
      >
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <span
              className={`px-2.5 py-0.5 rounded-full text-white text-[10px] font-extrabold uppercase ${
                activeIsVerified
                  ? 'bg-[#16A34A]'
                  : activeSubAccount.ageVerificationStatus === 'rejected'
                    ? 'bg-[#DC2626]'
                    : 'bg-[#F59E0B]'
              }`}
            >
              Gemini Vision AI Age Audit • Zero Raw PII Stored
            </span>
            <h2 className="font-extrabold text-base sm:text-lg mt-1 flex items-center gap-2">
              <ScanFace className="w-5 h-5 text-[#FF5722]" /> AI Aadhaar &amp; Government ID
              Verification (18+ Required)
            </h2>
            <p className="text-xs text-[#52607A] dark:text-slate-400">
              Mandatory for unlocking <strong>Public Account status</strong> and{' '}
              <strong>Public Publishing</strong> on <strong>@{activeSubAccount.username}</strong>.
              Our Vision AI reads only the Date of Birth &amp; document authenticity against today&apos;s
              date. Raw ID numbers and document images are never saved.
            </p>
          </div>

          <div
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 ${
              activeIsVerified
                ? 'bg-[#16A34A] text-white'
                : 'bg-[#DC2626]/15 text-[#DC2626] border border-[#DC2626]/40'
            }`}
          >
            {activeIsVerified ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                is_age_verified = true ({activeSubAccount.verifiedAge ?? 18}+ yrs)
              </>
            ) : (
              <>
                <ShieldAlert className="w-4 h-4" />
                is_age_verified = false (Public Locked)
              </>
            )}
          </div>
        </div>

        {!activeIsVerified && (
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/50 text-xs font-bold text-[#B45309] dark:text-amber-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>
              Public publishing &amp; Public Account mode are currently restricted for @
              {activeSubAccount.username}. Upload a clear Government ID / Aadhaar showing age 18+ to
              verify.
            </span>
          </div>
        )}

        {/* Verification Status Result Banner */}
        {(lastAgeResult?.accountId === activeSubAccount.id || activeSubAccount.ageVerificationNote) && (
          <div
            className={`p-3.5 rounded-xl border text-xs space-y-1 ${
              activeIsVerified
                ? 'bg-emerald-500/10 border-[#16A34A]/50 text-[#15803D] dark:text-emerald-300'
                : activeSubAccount.ageVerificationStatus === 'rejected'
                  ? 'bg-red-500/10 border-[#DC2626]/50 text-[#DC2626] dark:text-red-300'
                  : 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700'
            }`}
          >
            <div className="font-extrabold flex items-center gap-1.5">
              {activeIsVerified ? (
                <CheckCircle2 className="w-4 h-4" />
              ) : (
                <XCircle className="w-4 h-4" />
              )}
              <span>
                {lastAgeResult?.accountId === activeSubAccount.id
                  ? `${lastAgeResult.documentType} • ${lastAgeResult.reason}`
                  : activeSubAccount.ageVerificationNote}
              </span>
            </div>
          </div>
        )}

        {/* Upload ID Controls + Canvas Test Card Generators */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
          <div className="p-4 rounded-2xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 space-y-3">
            <label className="w-full py-3 px-4 rounded-xl fism-btn-primary text-xs font-extrabold flex items-center justify-center gap-2 cursor-pointer shadow">
              <Upload className="w-4 h-4" />
              <span>
                {verifyingAge
                  ? 'Analyzing ID with Vision AI...'
                  : 'Upload Aadhaar / Government ID Photo'}
              </span>
              <input
                type="file"
                accept="image/*"
                disabled={verifyingAge}
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => {
                    if (typeof reader.result === 'string') {
                      setTransientPreviewUrl(reader.result);
                      setTransientMime(file.type || 'image/jpeg');
                      void onVerifyAadhaarImage(reader.result, file.type || 'image/jpeg');
                    }
                  };
                  reader.readAsDataURL(file);
                }}
              />
            </label>

            <div className="space-y-1.5">
              <div className="text-[10px] font-extrabold uppercase text-[#52607A]">
                Test Vision AI ID Pipeline (Canvas-Rendered ID → Server Gemini Vision)
              </div>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  disabled={verifyingAge}
                  onClick={() => {
                    const { dataUrl, mimeType } = renderSampleAadhaarCanvasBase64('adult');
                    setTransientPreviewUrl(dataUrl);
                    setTransientMime(mimeType);
                    void onVerifyAadhaarImage(dataUrl, mimeType);
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-[#16A34A] text-white text-[11px] font-extrabold disabled:opacity-50"
                >
                  <Sparkles className="w-3 h-3 inline mr-1" />
                  18+ Adult Aadhaar (1998)
                </button>
                <button
                  type="button"
                  disabled={verifyingAge}
                  onClick={() => {
                    const { dataUrl, mimeType } = renderSampleAadhaarCanvasBase64('minor');
                    setTransientPreviewUrl(dataUrl);
                    setTransientMime(mimeType);
                    void onVerifyAadhaarImage(dataUrl, mimeType);
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-[#DC2626] text-white text-[11px] font-extrabold disabled:opacity-50"
                >
                  Under-18 Aadhaar (2012)
                </button>
                <button
                  type="button"
                  disabled={verifyingAge}
                  onClick={() => {
                    const { dataUrl, mimeType } = renderSampleAadhaarCanvasBase64('blurry');
                    setTransientPreviewUrl(dataUrl);
                    setTransientMime(mimeType);
                    void onVerifyAadhaarImage(dataUrl, mimeType);
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-700 text-white text-[11px] font-extrabold disabled:opacity-50"
                >
                  Blurry / Unreadable Card
                </button>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 flex flex-col items-center justify-center min-h-[150px] text-center gap-2">
            {verifyingAge ? (
              <div className="flex flex-col items-center gap-2 text-xs font-extrabold text-[#FF5722]">
                <RefreshCw className="w-7 h-7 animate-spin" />
                <span>Scanning Document Authenticity &amp; Computing DOB via Gemini Vision...</span>
              </div>
            ) : transientPreviewUrl ? (
              <>
                <img
                  src={transientPreviewUrl}
                  alt="Transient ID scan preview"
                  className="max-h-32 rounded-xl object-contain border border-slate-300 dark:border-slate-700"
                />
                <span className="text-[10px] text-[#52607A]">
                  Transient Session Preview Only ({transientMime}) • Not persisted to database
                </span>
              </>
            ) : (
              <div className="text-xs text-[#52607A] space-y-1">
                <ScanFace className="w-8 h-8 mx-auto text-[#7C3AED]" />
                <div className="font-extrabold">Ready for Government ID / Aadhaar Scan</div>
                <div className="text-[11px]">
                  Raw Aadhaar digits &amp; ID photos are discarded immediately after Vision AI DOB
                  verification.
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

interface FismSubIdPasswordModalProps {
  targetAccount: FismSubAccount | null;
  verifying: boolean;
  errorMsg: string | null;
  onVerifyAndSwitch: (account: FismSubAccount, password: string) => Promise<void>;
  onClose: () => void;
}

export const FismSubIdPasswordModal: React.FC<FismSubIdPasswordModalProps> = ({
  targetAccount,
  verifying,
  errorMsg,
  onVerifyAndSwitch,
  onClose,
}) => {
  const [password, setPassword] = useState('');
  const [showPwd, setShowPwd] = useState(false);

  if (!targetAccount) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-[#101426] border-2 border-[#FF5722] p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <span className="px-2.5 py-0.5 rounded-full bg-[#FF5722]/15 text-[#FF5722] text-[10px] font-extrabold uppercase flex items-center gap-1">
            <KeyRound className="w-3 h-3" /> Sub-ID Password Verification
          </span>
          <button
            type="button"
            onClick={() => {
              setPassword('');
              onClose();
            }}
            className="p-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
          >
            ✕
          </button>
        </div>

        <div className="flex items-center gap-3 p-3 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700">
          <img
            src={targetAccount.avatarUrl}
            alt={targetAccount.displayName}
            className="w-12 h-12 rounded-full object-cover ring-2 ring-[#FF5722]"
          />
          <div className="min-w-0">
            <div className="font-extrabold text-sm truncate">{targetAccount.displayName}</div>
            <div className="text-xs font-mono text-[#2563EB] truncate">
              @{targetAccount.username}
            </div>
            <div className="text-[10px] font-bold text-[#52607A]">
              {targetAccount.privacyMode === 'public' && targetAccount.isAgeVerified
                ? '🌐 Public Account'
                : '🔒 Private Sub-ID'}{' '}
              • {targetAccount.isAgeVerified ? '✓ 18+ Verified' : 'ID Unverified'}
            </div>
          </div>
        </div>

        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await onVerifyAndSwitch(targetAccount, password);
            setPassword('');
          }}
          className="space-y-3"
        >
          <div>
            <label className="block text-xs font-extrabold mb-1">
              Enter Password for @{targetAccount.username}
            </label>
            <div className="relative">
              <input
                type={showPwd ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoFocus
                placeholder="Enter Sub-ID security password..."
                className="w-full px-3.5 py-2.5 pr-10 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm font-bold"
              />
              <button
                type="button"
                onClick={() => setShowPwd((s) => !s)}
                className="absolute right-3 top-2.5 text-[#52607A]"
              >
                {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-[#DC2626] text-white text-xs font-bold">
              {errorMsg}
            </div>
          )}

          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => {
                setPassword('');
                onClose();
              }}
              className="px-4 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={verifying || !password.trim()}
              className="fism-btn-primary px-5 py-2 rounded-xl text-xs font-extrabold disabled:opacity-50"
            >
              {verifying ? 'Verifying Hash...' : '🔓 Unlock & Switch ID'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
