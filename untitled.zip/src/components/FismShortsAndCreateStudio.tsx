import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Music,
  Sparkles,
  RefreshCw,
  Timer,
  Gauge,
  UserCheck,
  ChevronDown,
  ChevronUp,
  Upload,
  Scissors,
  Sliders,
  Type,
  Smile,
  Volume2,
  Play,
  Pause,
  Check,
  Film,
  Image as ImageIcon,
  Radio,
  Crown,
  Flame,
  Plus,
  Headphones,
  Layers,
  Wand2,
  Gift,
  Coins,
  ArrowLeft,
  ArrowRight,
  Link2,
  Users,
  Search,
} from 'lucide-react';
import {
  FismArFilterAsset,
  FismConnectedVideoRef,
  FismGameItem,
  FismGiftDropRewardType,
  FismMusicTrack,
  FismPostItem,
  FismSavedStudioFilter,
  FismShoppingProduct,
  FismTaggedCollaborator,
  GENERATED_ASSETS,
} from '../types';
import { drawArFilterOverlay } from '../utils/arFilterRenderer';
import {
  DEFAULT_SMART_FILTER_STATE,
  FismSmartFilterViewport,
  FismUserFilterBrowserSheet,
  SmartFilterStudioState,
  studioFilterPresetToState,
} from './FismSmartFilterStudio';

export type StudioFilterId =
  | 'none'
  | 'flameWarm'
  | 'cyberNeon'
  | 'tealOrange'
  | 'bwContrast'
  | 'goldenHour';

export const STUDIO_FILTERS: {
  id: StudioFilterId;
  label: string;
  thumb: string;
  css: string;
}[] = [
  {
    id: 'none',
    label: 'Original',
    thumb: GENERATED_ASSETS.avatar1,
    css: '',
  },
  {
    id: 'flameWarm',
    label: 'Portrait Glow',
    thumb: GENERATED_ASSETS.avatar2,
    css: 'saturate-150 contrast-110 sepia-[.15]',
  },
  {
    id: 'goldenHour',
    label: 'Mythic Gold',
    thumb: GENERATED_ASSETS.studioThumb,
    css: 'sepia-[.35] saturate-150 brightness-105',
  },
  {
    id: 'cyberNeon',
    label: 'Cyber Neon',
    thumb: GENERATED_ASSETS.heroCover,
    css: 'hue-rotate-30 saturate-200 contrast-125',
  },
  {
    id: 'tealOrange',
    label: 'Cinema HDR',
    thumb: GENERATED_ASSETS.mountainPost,
    css: 'contrast-125 saturate-150',
  },
  {
    id: 'bwContrast',
    label: 'Noir B&W',
    thumb: GENERATED_ASSETS.avatar1,
    css: 'grayscale contrast-150',
  },
];

interface FismCreateCameraYouCutModalProps {
  open: boolean;
  onClose: () => void;
  userSparksCount: number;
  shoppingProducts: FismShoppingProduct[];
  musicTracks: FismMusicTrack[];
  onUploadNewMusicTrack: (track: FismMusicTrack) => void;
  selectedMusicTrack: FismMusicTrack | null;
  onSelectMusicTrack: (track: FismMusicTrack | null) => void;
  greenScreenSourcePost: FismPostItem | null;
  onClearGreenScreenSource: () => void;
  onPublishCreatedMedia: (payload: {
    targetMode: 'quickBurst' | 'mainBlast' | 'photoPost';
    mediaUrl: string;
    thumbnailUrl: string;
    title: string;
    caption: string;
    hashtags: string;
    durationSec: number;
    filterId: StudioFilterId;
    textOverlay: string;
    stickerOverlay: string;
    musicTrack: FismMusicTrack | null;
    greenScreenBgUrl?: string;
    remixedFromId?: string;
    remixedFromAuthor?: string;
    isRealVideo: boolean;
    shoppingLinkUrl?: string;
    shoppingProductTitle?: string;
    shoppingProductImage?: string;
    shoppingStoreName?: string;
    affiliateKeywords?: string[];
    is3DVrVideo?: boolean;
    connectedVideo?: FismConnectedVideoRef;
    taggedCollaborators?: FismTaggedCollaborator[];
    giftDrop?: {
      rewardType: FismGiftDropRewardType;
      rewardTitle: string;
      rewardValue: string;
      coinsPerWinner: number;
      winnerLimit: number;
      totalCoinsDeducted: number;
    };
  }) => void;
  onSwitchToLiveStream: () => void;
  aiMusicPrompt: string;
  setAiMusicPrompt: (v: string) => void;
  aiMusicGenerating: boolean;
  onGenerateAiMusicAndCover: () => void;
  generatedMusicUrl: string;
  generatedMusicCover: string;
  onUploadAiMusicToChannel: () => void;
  currentUsername: string;
  onTriggerToast: (msg: string) => void;
  publishedArFilters?: FismArFilterAsset[];
  publishedStudioFilters?: FismSavedStudioFilter[];
  userCoinBalance?: number;
  onOpenWalletOrPremium?: () => void;
  userVideos?: FismPostItem[];
  availableUsers?: { uid: string; username: string; displayName: string; avatarUrl: string }[];
}

export const FismCreateCameraYouCutModal: React.FC<FismCreateCameraYouCutModalProps> = ({
  open,
  onClose,
  userSparksCount,
  shoppingProducts,
  musicTracks,
  onUploadNewMusicTrack,
  selectedMusicTrack,
  onSelectMusicTrack,
  greenScreenSourcePost,
  onClearGreenScreenSource,
  onPublishCreatedMedia,
  onSwitchToLiveStream,
  aiMusicPrompt,
  setAiMusicPrompt,
  aiMusicGenerating,
  onGenerateAiMusicAndCover,
  generatedMusicUrl,
  generatedMusicCover,
  onUploadAiMusicToChannel,
  currentUsername,
  onTriggerToast,
  publishedArFilters = [],
  publishedStudioFilters = [],
  userCoinBalance = 0,
  onOpenWalletOrPremium,
  userVideos = [],
  availableUsers = [],
}) => {
  // Bottom Mode Bar: 'mainBlast' (Main Blast) | 'quickBurst' (Quick Burst - default) | 'onFire' (On Fire Live) | 'photoPost' (Photo Post) | 'musicUpload' (Music)
  const [bottomMode, setBottomMode] = useState<
    'mainBlast' | 'quickBurst' | 'onFire' | 'photoPost' | 'musicUpload'
  >('quickBurst');
  // Two-step Create flow for Quick Burst & Main Blast: 'capture' (camera/edit) -> 'details' (title/desc/#/connect video/tag people/upload)
  const [studioStep, setStudioStep] = useState<'capture' | 'details'>('capture');

  // Camera & Recording State
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('user');
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [maxDurationSetting, setMaxDurationSetting] = useState<15 | 60 | 180>(15);
  const [countdownSetting, setCountdownSetting] = useState<0 | 3 | 10>(0);
  const [activeCountdown, setActiveCountdown] = useState<number | null>(null);
  const [playbackSpeed, setPlaybackSpeed] = useState<0.5 | 1 | 1.5 | 2>(1);

  // Uploaded or Recorded File State
  const [mediaFileUrl, setMediaFileUrl] = useState<string>('');
  const [mediaFileName, setMediaFileName] = useState<string>('');
  const [mediaIsVideo, setMediaIsVideo] = useState<boolean>(true);
  const [customThumbUrl, setCustomThumbUrl] = useState<string>(GENERATED_ASSETS.studioThumb);

  // Green Screen State
  const [greenScreenEnabled, setGreenScreenEnabled] = useState<boolean>(
    Boolean(greenScreenSourcePost),
  );
  const [greenScreenCustomBg, setGreenScreenCustomBg] = useState<string>(
    greenScreenSourcePost?.mediaUrl ||
      greenScreenSourcePost?.thumbnailUrl ||
      GENERATED_ASSETS.studioThumb,
  );

  // Filter & YouCut Editing Drawer State (Quick Burst only)
  const [activeFilter, setActiveFilter] = useState<StudioFilterId>('none');
  const [activeArFilterId, setActiveArFilterId] = useState<string | null>(null);
  const [sparkleVfxOn, setSparkleVfxOn] = useState<boolean>(false);
  const [youCutDrawerOpen, setYouCutDrawerOpen] = useState<boolean>(false);
  const [youCutTab, setYouCutTab] = useState<
    'trim' | 'greenscreen' | 'text' | 'filters' | 'speed' | 'audio'
  >('trim');
  const [trimStartPct, setTrimStartPct] = useState<number>(0);
  const [trimEndPct, setTrimEndPct] = useState<number>(100);
  const [splitPoints, setSplitPoints] = useState<number[]>([50]);
  const [textOverlay, setTextOverlay] = useState<string>('');
  const [stickerOverlay, setStickerOverlay] = useState<string>('');
  const [originalVolume, setOriginalVolume] = useState<number>(80);
  const [musicVolume, setMusicVolume] = useState<number>(100);

  // Post Metadata + Connect Another Video + Tag People + AI Shopping Link + 3D VR Video
  const [postTitle, setPostTitle] = useState<string>('');
  const [postCaption, setPostCaption] = useState<string>('');
  const [postHashtags, setPostHashtags] = useState<string>('#freefire #funny #quickburst #FISM');
  const [selectedConnectedVideo, setSelectedConnectedVideo] =
    useState<FismConnectedVideoRef | null>(null);
  const [showConnectVideoPicker, setShowConnectVideoPicker] = useState<boolean>(false);
  const [taggedCollaborators, setTaggedCollaborators] = useState<FismTaggedCollaborator[]>([]);
  const [tagPeopleSearch, setTagPeopleSearch] = useState<string>('');
  const [showTagPeoplePicker, setShowTagPeoplePicker] = useState<boolean>(false);
  const [showGiftDropConfigInDetails, setShowGiftDropConfigInDetails] = useState<boolean>(false);

  const [shoppingInputUrl, setShoppingInputUrl] = useState<string>('');
  const [aiVerifiedShoppingTitle, setAiVerifiedShoppingTitle] = useState<string>('');
  const [aiVerifiedShoppingImage, setAiVerifiedShoppingImage] = useState<string>('');
  const [aiVerifiedShoppingStore, setAiVerifiedShoppingStore] = useState<string>('');
  const [aiInspectingShoppingLink, setAiInspectingShoppingLink] = useState<boolean>(false);
  const [affiliateKeywordsInput, setAffiliateKeywordsInput] = useState<string>(
    'price, link, buy, headset',
  );
  const [uploadAs3DVrVideo, setUploadAs3DVrVideo] = useState<boolean>(false);

  // Advanced Video Upload Settings — Gift Drop System
  const [giftDropEnabled, setGiftDropEnabled] = useState<boolean>(false);
  const [giftDropType, setGiftDropType] = useState<FismGiftDropRewardType>('coins');
  const [giftDropTitle, setGiftDropTitle] = useState<string>('First-10 Viewers Lucky Gift Drop');
  const [giftDropValue, setGiftDropValue] = useState<string>('');
  const [giftDropWinnerLimit, setGiftDropWinnerLimit] = useState<number>(10);
  const [giftDropCoinsPerWinner, setGiftDropCoinsPerWinner] = useState<number>(100);

  // Music Picker & Music Uploader Sub-Modal inside Studio
  const [musicDrawerOpen, setMusicDrawerOpen] = useState<boolean>(false);
  const [newTrackTitle, setNewTrackTitle] = useState<string>('');
  const [newTrackArtist, setNewTrackArtist] = useState<string>(currentUsername);
  const [newTrackGenre, setNewTrackGenre] = useState<string>('Gaming Phonk / Bass');
  const [newTrackAudioUrl, setNewTrackAudioUrl] = useState<string>('');
  const [newTrackCoverUrl, setNewTrackCoverUrl] = useState<string>(GENERATED_ASSETS.studioThumb);

  const cameraVideoRef = useRef<HTMLVideoElement | null>(null);
  const arCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const smartCompositeCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const filterScrollRef = useRef<HTMLDivElement | null>(null);

  // Active Admin-Published Filter Preview State (Users browse & apply filters by Title; only Admins create/publish them)
  const [smartFilterState, setSmartFilterState] = useState<SmartFilterStudioState>(
    DEFAULT_SMART_FILTER_STATE,
  );
  const [smartFilterSheetOpen, setSmartFilterSheetOpen] = useState<boolean>(false);
  const [smartFilterStatus, setSmartFilterStatus] = useState<{
    personDetected: boolean;
    segEngine: 'mediapipe' | 'adaptive';
    gameScore: number;
    gamePaused: boolean;
  }>({
    personDetected: false,
    segEngine: 'adaptive',
    gameScore: 0,
    gamePaused: false,
  });
  const [gameActionSignal, setGameActionSignal] = useState<{
    seq: number;
    type: 'reset' | 'togglePause';
  }>({ seq: 0, type: 'reset' });

  const handleSelectUserStudioFilter = (flt: FismSavedStudioFilter | null) => {
    if (!flt) {
      setSmartFilterState(DEFAULT_SMART_FILTER_STATE);
      onTriggerToast('Smart Filter turned off.');
      return;
    }
    setSmartFilterState((prev) => studioFilterPresetToState(flt, prev));
    onTriggerToast(`Filter active: "${flt.name}"`);
  };

  const activeArFilter =
    publishedArFilters.find((f) => f.id === activeArFilterId) || null;

  useEffect(() => {
    if (!open || !activeArFilter) return;
    let rafId = 0;
    const renderLoop = (now: number) => {
      const canvas = arCanvasRef.current;
      if (canvas) {
        const rect = canvas.getBoundingClientRect();
        const w = Math.max(300, Math.round(rect.width || 420));
        const h = Math.max(400, Math.round(rect.height || 680));
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
        }
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, w, h);
          drawArFilterOverlay(ctx, w, h, activeArFilter, now);
        }
      }
      rafId = requestAnimationFrame(renderLoop);
    };
    rafId = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(rafId);
  }, [open, activeArFilter]);

  useEffect(() => {
    if (greenScreenSourcePost) {
      setGreenScreenEnabled(true);
      setGreenScreenCustomBg(
        greenScreenSourcePost.mediaUrl ||
          greenScreenSourcePost.thumbnailUrl ||
          GENERATED_ASSETS.studioThumb,
      );
    }
  }, [greenScreenSourcePost]);

  // Start / Stop Camera Preview
  const startCameraStream = async (facing: 'user' | 'environment' = cameraFacing) => {
    try {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing, width: { ideal: 720 }, height: { ideal: 1280 } },
        audio: true,
      });
      mediaStreamRef.current = stream;
      setCameraActive(true);
      setTimeout(() => {
        if (cameraVideoRef.current) {
          cameraVideoRef.current.srcObject = stream;
          cameraVideoRef.current.play().catch(() => {});
        }
      }, 80);
    } catch {
      setCameraActive(false);
    }
  };

  const stopCameraStream = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    setCameraActive(false);
    setIsRecording(false);
  };

  useEffect(() => {
    if (open) {
      setStudioStep('capture');
      setSelectedConnectedVideo(null);
      setTaggedCollaborators([]);
      setTagPeopleSearch('');
      setShowConnectVideoPicker(false);
      setShowTagPeoplePicker(false);
      setShowGiftDropConfigInDetails(false);
      startCameraStream(cameraFacing);
    } else {
      stopCameraStream();
    }
    return () => {
      stopCameraStream();
    };
  }, [open]);

  // Recording Timer Effect
  useEffect(() => {
    if (!isRecording) return;
    const interval = setInterval(() => {
      setRecordingSeconds((prev) => {
        if (prev + 1 >= maxDurationSetting) {
          handleStopRecording();
          return maxDurationSetting;
        }
        return prev + 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isRecording, maxDurationSetting]);

  const beginMediaRecordingNow = async () => {
    if (!mediaStreamRef.current) {
      await startCameraStream(cameraFacing);
    }
    setRecordingSeconds(0);
    setIsRecording(true);
    recordedChunksRef.current = [];

    // Use unified composite canvas stream when any Smart Camera Studio Filter is active
    let streamToRecord: MediaStream | null = mediaStreamRef.current;
    if (
      smartFilterState.mode !== 'off' &&
      smartCompositeCanvasRef.current &&
      typeof smartCompositeCanvasRef.current.captureStream === 'function'
    ) {
      try {
        const canvasStream = smartCompositeCanvasRef.current.captureStream(30);
        const audioTracks = mediaStreamRef.current?.getAudioTracks() || [];
        streamToRecord = new MediaStream([
          ...canvasStream.getVideoTracks(),
          ...audioTracks,
        ]);
      } catch {
        streamToRecord = mediaStreamRef.current;
      }
    }

    if (streamToRecord && typeof MediaRecorder !== 'undefined') {
      try {
        const recorder = new MediaRecorder(streamToRecord);
        mediaRecorderRef.current = recorder;
        recorder.ondataavailable = (ev) => {
          if (ev.data && ev.data.size > 0) {
            recordedChunksRef.current.push(ev.data);
          }
        };
        recorder.onstop = () => {
          if (recordedChunksRef.current.length > 0) {
            const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
            const url = URL.createObjectURL(blob);
            setMediaFileUrl(url);
            setMediaFileName(
              smartFilterState.mode === 'game_chroma'
                ? `Gameplay_Cam_${Date.now()}.webm`
                : `Camera_Clip_${Date.now()}.webm`,
            );
            setMediaIsVideo(true);
            if (bottomMode === 'quickBurst') {
              setSmartFilterSheetOpen(false);
              setYouCutDrawerOpen(true);
              setYouCutTab('trim');
              onTriggerToast('Clip recorded! Edit in YouCut or click Next.');
            } else {
              setSmartFilterSheetOpen(false);
              setYouCutDrawerOpen(false);
              setStudioStep('details');
              onTriggerToast('Video recorded! Add Title & Description to upload.');
            }
          }
        };
        recorder.start();
      } catch {
        // Fallback simulated recording timer
      }
    } else {
      onTriggerToast('Recording started in Studio Viewfinder...');
    }
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
        return;
      } catch {
        // fallback below
      }
    }
    if (bottomMode === 'quickBurst') {
      setYouCutDrawerOpen(true);
      setYouCutTab('trim');
      onTriggerToast('🎥 Quick Burst clip captured! Edit or tap Next → to add Title & Upload.');
    } else {
      setYouCutDrawerOpen(false);
      setStudioStep('details');
      onTriggerToast('🎥 Video captured! Add Title & Description to upload.');
    }
  };

  const handlePressWhiteRecordCircle = () => {
    if (isRecording) {
      handleStopRecording();
      return;
    }
    if (countdownSetting > 0) {
      let rem = countdownSetting;
      setActiveCountdown(rem);
      const timer = setInterval(() => {
        rem -= 1;
        if (rem <= 0) {
          clearInterval(timer);
          setActiveCountdown(null);
          beginMediaRecordingNow();
        } else {
          setActiveCountdown(rem);
        }
      }, 1000);
    } else {
      beginMediaRecordingNow();
    }
  };

  // Open File Select ("Add" button)
  const handleAddFileFromDevice = (file: File) => {
    const objUrl = URL.createObjectURL(file);
    const isVid = file.type.startsWith('video/');
    setMediaFileUrl(objUrl);
    setMediaFileName(file.name);
    setMediaIsVideo(isVid);
    if (!postTitle.trim()) {
      setPostTitle(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '));
    }

    if (isVid) {
      const probe = document.createElement('video');
      probe.preload = 'metadata';
      probe.onloadedmetadata = () => {
        const dur = Math.max(1, Math.round(probe.duration || 15));
        setRecordingSeconds(dur);
        if (dur > 60 && bottomMode === 'quickBurst') {
          setBottomMode('mainBlast');
          setYouCutDrawerOpen(false);
          setStudioStep('capture');
          onTriggerToast(
            `📂 Video selected (${dur}s > 60s): Switched to Main Blast! Preview & tap Next → to upload.`,
          );
        } else if (bottomMode === 'quickBurst') {
          setYouCutDrawerOpen(true);
          setYouCutTab('trim');
          onTriggerToast(
            `📂 Quick Burst "${file.name}" loaded (${dur}s)! Edit in YouCut or click Next →.`,
          );
        } else {
          setYouCutDrawerOpen(false);
          onTriggerToast(
            `📂 Main Blast "${file.name}" loaded (${dur}s)! Tap Next → to add Title & Upload.`,
          );
        }
      };
      probe.src = objUrl;
    } else {
      setBottomMode('photoPost');
      setYouCutDrawerOpen(false);
      setStudioStep('capture');
      onTriggerToast(`🖼️ Photo "${file.name}" loaded! Add Title & Description directly below.`);
    }
  };

  const handleUploadMusicInModal = () => {
    if (!newTrackTitle.trim()) {
      onTriggerToast('Please enter a song/music title.');
      return;
    }
    const createdTrack: FismMusicTrack = {
      id: `music_${Date.now()}`,
      title: newTrackTitle.trim(),
      artist: newTrackArtist.trim() || currentUsername,
      uploaderUsername: currentUsername,
      audioUrl: newTrackAudioUrl,
      coverUrl: newTrackCoverUrl || GENERATED_ASSETS.studioThumb,
      duration: '00:30',
      genre: newTrackGenre,
      usesCount: 1,
      createdAt: 'Just uploaded',
    };
    onUploadNewMusicTrack(createdTrack);
    onSelectMusicTrack(createdTrack);
    setNewTrackTitle('');
    setMusicDrawerOpen(false);
    if (bottomMode === 'musicUpload') {
      setBottomMode('quickBurst');
    }
    onTriggerToast(`🎵 Music "${createdTrack.title}" uploaded to FISM Music Hub & attached!`);
  };

  const handleAiInspectShoppingLink = (rawUrl: string) => {
    setShoppingInputUrl(rawUrl);
    const trimmed = rawUrl.trim();
    if (!trimmed) {
      setAiVerifiedShoppingTitle('');
      setAiVerifiedShoppingImage('');
      setAiVerifiedShoppingStore('');
      return;
    }
    if (userSparksCount < 500) {
      onTriggerToast('🔒 Shopping Link tagging requires at least 500 Sparks on your channel!');
      return;
    }
    const lower = trimmed.toLowerCase();
    // Match against FISM Shopping products or known e-commerce URLs
    const matchedProduct =
      shoppingProducts.find(
        (p) =>
          lower.includes(p.id.toLowerCase()) ||
          lower.includes(p.title.toLowerCase().split(' ')[0]),
      ) || shoppingProducts[0];

    let storeLabel = 'FISM Verified Store';
    if (lower.includes('amazon')) storeLabel = 'Amazon Verified Link';
    else if (lower.includes('flipkart')) storeLabel = 'Flipkart Verified Link';
    else if (lower.includes('myntra')) storeLabel = 'Myntra Verified Link';
    else if (lower.includes('meesho')) storeLabel = 'Meesho Verified Link';
    else if (lower.includes('fism')) storeLabel = 'FISM Official Store';

    const resolvedTitle = matchedProduct
      ? matchedProduct.title
      : 'Flame Pro Creator RGB Gear';
    const resolvedImage = matchedProduct
      ? matchedProduct.imageUrl ||
        matchedProduct.photos?.[0] ||
        GENERATED_ASSETS.shopHeadset
      : GENERATED_ASSETS.shopHeadset;

    setAiVerifiedShoppingTitle(resolvedTitle);
    setAiVerifiedShoppingImage(resolvedImage);
    setAiVerifiedShoppingStore(storeLabel);
    onTriggerToast(
      `🤖 AI Shopping Inspector Verified: "${resolvedTitle}" from ${storeLabel} — Product photo extracted!`,
    );
  };

  const handleFinalPublish = () => {
    const target =
      bottomMode === 'mainBlast'
        ? 'mainBlast'
        : bottomMode === 'photoPost'
          ? 'photoPost'
          : 'quickBurst';

    const finalDuration =
      recordingSeconds > 0
        ? Math.max(
            1,
            Math.round((recordingSeconds * (trimEndPct - trimStartPct)) / 100),
          )
        : target === 'mainBlast'
          ? 125
          : maxDurationSetting;

    const finalMedia =
      mediaFileUrl ||
      (greenScreenEnabled ? greenScreenCustomBg : GENERATED_ASSETS.studioThumb);

    const hasValidShopping =
      userSparksCount >= 500 &&
      Boolean(shoppingInputUrl.trim()) &&
      Boolean(aiVerifiedShoppingImage);

    const safeWinners = Math.max(1, Math.floor(Number(giftDropWinnerLimit || 1)));
    const safeCoinsPerWinner = Math.max(0, Math.floor(Number(giftDropCoinsPerWinner || 0)));
    const totalCoinsRequired = safeWinners * safeCoinsPerWinner;

    if (giftDropEnabled) {
      if (giftDropType === 'coins' && safeCoinsPerWinner <= 0) {
        onTriggerToast('Please enter Coins per Winner greater than 0 for a Coin Gift Drop.');
        setShowGiftDropConfigInDetails(true);
        return;
      }
      if (giftDropType !== 'coins' && !giftDropValue.trim()) {
        onTriggerToast('Please upload a Gift Photo or enter the Secret Text / Redeem Code!');
        setShowGiftDropConfigInDetails(true);
        return;
      }
      if (userCoinBalance < totalCoinsRequired) {
        onTriggerToast(
          'Insufficient coins in your wallet. Purchase a Premium subscription to get 10,000 coins or top up your wallet!',
        );
        setShowGiftDropConfigInDetails(true);
        return;
      }
    }

    onPublishCreatedMedia({
      targetMode: target,
      mediaUrl: finalMedia,
      thumbnailUrl: customThumbUrl || GENERATED_ASSETS.studioThumb,
      title:
        postTitle.trim() ||
        (greenScreenSourcePost
          ? `Remix with @${greenScreenSourcePost.authorUsername}`
          : selectedMusicTrack
            ? `${selectedMusicTrack.title} #quickburst`
            : target === 'mainBlast'
              ? 'New Main Blast Video 🔥'
              : target === 'photoPost'
                ? 'New Photo Post 📸'
                : 'Booyah Clutch Moment 🔥 #quickburst'),
      caption:
        postCaption.trim() ||
        `${postTitle.trim() || 'Created in FISM Studio'} ${postHashtags}`,
      hashtags: postHashtags,
      durationSec: finalDuration,
      filterId: target === 'quickBurst' ? activeFilter : 'none',
      textOverlay: target === 'quickBurst' ? textOverlay : '',
      stickerOverlay: target === 'quickBurst' ? stickerOverlay : '',
      musicTrack: target === 'quickBurst' ? selectedMusicTrack : null,
      greenScreenBgUrl:
        target === 'quickBurst' && greenScreenEnabled ? greenScreenCustomBg : undefined,
      remixedFromId: greenScreenSourcePost?.id,
      remixedFromAuthor: greenScreenSourcePost?.authorUsername,
      isRealVideo: Boolean(mediaFileUrl && mediaIsVideo),
      shoppingLinkUrl: hasValidShopping ? shoppingInputUrl.trim() : undefined,
      shoppingProductTitle: hasValidShopping ? aiVerifiedShoppingTitle : undefined,
      shoppingProductImage: hasValidShopping ? aiVerifiedShoppingImage : undefined,
      shoppingStoreName: hasValidShopping ? aiVerifiedShoppingStore : undefined,
      affiliateKeywords: hasValidShopping
        ? affiliateKeywordsInput
            .split(',')
            .map((k) => k.trim().toLowerCase())
            .filter(Boolean)
        : undefined,
      is3DVrVideo: userSparksCount >= 2000 && uploadAs3DVrVideo,
      connectedVideo: selectedConnectedVideo || undefined,
      taggedCollaborators: taggedCollaborators.length > 0 ? taggedCollaborators : undefined,
      giftDrop: giftDropEnabled
        ? {
            rewardType: giftDropType,
            rewardTitle: giftDropTitle.trim() || 'Creator Gift Drop',
            rewardValue:
              giftDropValue.trim() ||
              `Instant ${safeCoinsPerWinner.toLocaleString()} FISM Wallet Coins`,
            coinsPerWinner: safeCoinsPerWinner,
            winnerLimit: safeWinners,
            totalCoinsDeducted: totalCoinsRequired,
          }
        : undefined,
    });
  };

  if (!open) return null;

  const activeFilterObj =
    STUDIO_FILTERS.find((f) => f.id === activeFilter) || STUDIO_FILTERS[0];
  const progressPct = Math.min(
    100,
    Math.round(((recordingSeconds || (mediaFileUrl ? maxDurationSetting : 2)) / maxDurationSetting) * 100),
  );
  const isQuickBurstMode = bottomMode === 'quickBurst';
  const isMainBlastMode = bottomMode === 'mainBlast';
  const isPhotoPostMode = bottomMode === 'photoPost';

  const safeDropWinners = Math.max(1, Math.floor(Number(giftDropWinnerLimit || 1)));
  const safeDropCoins = Math.max(0, Math.floor(Number(giftDropCoinsPerWinner || 0)));
  const totalDropDeduction = safeDropWinners * safeDropCoins;
  const dropInsufficient = giftDropEnabled && userCoinBalance < totalDropDeduction;

  const matchingUsersForTag = availableUsers
    .filter((u) => {
      if (u.username.toLowerCase() === currentUsername.toLowerCase()) return false;
      const q = tagPeopleSearch.trim().toLowerCase();
      if (!q) return true;
      return (
        u.username.toLowerCase().includes(q) || u.displayName.toLowerCase().includes(q)
      );
    })
    .slice(0, 8);

  const renderModeBar = () => (
    <div className="space-y-1.5">
      <div className="flex items-center justify-center gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar py-1">
        {[
          { id: 'mainBlast', label: 'Main Blast' },
          { id: 'quickBurst', label: 'Quick Burst' },
          { id: 'onFire', label: 'On Fire' },
          { id: 'photoPost', label: 'Photo Post' },
          { id: 'musicUpload', label: 'Music' },
        ].map((item) => {
          const isSelected = bottomMode === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                if (item.id === 'onFire') {
                  if (userSparksCount < 50) {
                    onTriggerToast(
                      `🔒 On Fire unlocks at 50 Sparks! You currently have ${userSparksCount} Sparks.`,
                    );
                    return;
                  }
                  onClose();
                  onSwitchToLiveStream();
                  return;
                }
                if (item.id === 'musicUpload') {
                  setBottomMode('musicUpload');
                  setYouCutDrawerOpen(false);
                  setMusicDrawerOpen(true);
                  return;
                }
                const nextMode = item.id as
                  | 'mainBlast'
                  | 'quickBurst'
                  | 'onFire'
                  | 'photoPost'
                  | 'musicUpload';
                setBottomMode(nextMode);
                setStudioStep('capture');
                if (nextMode !== 'quickBurst') {
                  setYouCutDrawerOpen(false);
                }
                if (nextMode === 'mainBlast') {
                  setMaxDurationSetting(180);
                } else if (nextMode === 'quickBurst') {
                  setMaxDurationSetting(15);
                }
              }}
              className={`min-h-[40px] px-3.5 py-2 rounded-full text-xs sm:text-sm font-bold transition-all shrink-0 ${
                isSelected
                  ? 'bg-white/20 text-white shadow-md ring-1 ring-white/30'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </div>
      <div className="text-center text-[10px] text-white/50">
        🔥 <strong>Flame Feed</strong> is reserved exclusively for{' '}
        <span className="text-[#FFB300] font-bold">1M+ Viral Views</span> &amp;{' '}
        <span className="text-[#FFB300] font-bold">Premium Creators</span>.
      </div>
    </div>
  );

  const renderDetailsAndPublishFields = (submitLabel: string) => (
    <div className="space-y-3 text-white">
      <div className="space-y-2.5 bg-white/5 p-3.5 rounded-2xl border border-white/10">
        <div>
          <label className="block text-[11px] font-extrabold text-white/80 mb-1">
            Title <span className="text-[#FF5722]">*</span>
          </label>
          <input
            type="text"
            value={postTitle}
            onChange={(e) => setPostTitle(e.target.value)}
            placeholder={
              isPhotoPostMode
                ? 'Photo Post Title...'
                : isMainBlastMode
                  ? 'Main Blast Video Title...'
                  : 'Quick Burst Title (e.g., Booyah Clutch #quickburst)'
            }
            className="w-full px-3 py-2.5 rounded-xl bg-black/50 border border-white/20 text-xs sm:text-sm text-white font-bold"
          />
        </div>
        <div>
          <label className="block text-[11px] font-extrabold text-white/80 mb-1">
            Description / Caption
          </label>
          <textarea
            rows={2}
            value={postCaption}
            onChange={(e) => setPostCaption(e.target.value)}
            placeholder="Write your description..."
            className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-xs text-white"
          />
        </div>
        <div>
          <label className="block text-[11px] font-extrabold text-white/80 mb-1">
            Hashtags (#)
          </label>
          <input
            type="text"
            value={postHashtags}
            onChange={(e) => setPostHashtags(e.target.value)}
            placeholder="#freefire #gaming #quickburst #FISM"
            className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-xs text-[#FFB300] font-bold"
          />
        </div>
      </div>

      {/* CONNECT ANOTHER VIDEO (FROM PROFILE UPLOADED VIDEOS) */}
      <div className="p-3.5 rounded-2xl bg-white/5 border border-white/15 space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-xs font-extrabold text-[#38BDF8] flex items-center gap-1.5">
              <Link2 className="w-4 h-4 shrink-0" /> Connect Another Video
            </div>
            <div className="text-[11px] text-white/65">
              Link any video from your channel — viewers can tap to watch it directly!
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowConnectVideoPicker((v) => !v)}
            className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-extrabold shrink-0"
          >
            {showConnectVideoPicker ? 'Hide List' : selectedConnectedVideo ? 'Change Video' : 'Select Video'}
          </button>
        </div>

        {selectedConnectedVideo && (
          <div className="flex items-center justify-between gap-2.5 p-2.5 rounded-xl bg-[#0284C7]/20 border border-[#38BDF8]/40">
            <div className="flex items-center gap-2.5 min-w-0">
              <img
                src={selectedConnectedVideo.thumbnailUrl}
                alt={selectedConnectedVideo.title}
                className="w-12 h-9 rounded-lg object-cover shrink-0 border border-white/25"
              />
              <div className="min-w-0">
                <div className="text-[10px] font-black uppercase text-[#38BDF8]">
                  Connected {selectedConnectedVideo.postType === 'quickBurst' ? 'Quick Burst' : 'Main Blast'}
                </div>
                <div className="text-xs font-bold text-white truncate">
                  {selectedConnectedVideo.title}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setSelectedConnectedVideo(null)}
              className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-bold text-white/80 shrink-0"
            >
              Remove
            </button>
          </div>
        )}

        {showConnectVideoPicker && (
          <div className="space-y-1.5 max-h-44 overflow-y-auto pt-1">
            {userVideos.length === 0 ? (
              <div className="text-[11px] text-white/60 p-2.5 rounded-xl bg-black/40 border border-white/10">
                No uploaded videos on your profile yet. Upload your first video to connect it later!
              </div>
            ) : (
              userVideos.map((vid) => {
                const isLinked = selectedConnectedVideo?.id === vid.id;
                const linkedType: 'video' | 'quickBurst' =
                  vid.postType === 'quickBurst' ? 'quickBurst' : 'video';
                const displayTitle = vid.title || vid.caption || 'Connected Video';
                return (
                  <button
                    key={vid.id}
                    type="button"
                    onClick={() => {
                      setSelectedConnectedVideo({
                        id: vid.id,
                        title: displayTitle,
                        thumbnailUrl: vid.thumbnailUrl || vid.mediaUrl || GENERATED_ASSETS.studioThumb,
                        postType: linkedType,
                        authorUsername: vid.authorUsername,
                      });
                      setShowConnectVideoPicker(false);
                      onTriggerToast(`🔗 Connected video: "${displayTitle}"`);
                    }}
                    className={`w-full p-2 rounded-xl border flex items-center justify-between gap-2.5 text-left transition-all ${
                      isLinked
                        ? 'bg-[#0284C7]/25 border-[#38BDF8]'
                        : 'bg-black/45 border-white/10 hover:border-white/30'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={vid.thumbnailUrl || vid.mediaUrl || GENERATED_ASSETS.studioThumb}
                        alt={displayTitle}
                        className="w-12 h-9 rounded-lg object-cover shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white truncate">{displayTitle}</div>
                        <div className="text-[10px] text-white/65">
                          {linkedType === 'quickBurst' ? 'Quick Burst' : 'Main Blast'} ·{' '}
                          {vid.duration || 'Video'}
                        </div>
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-white/15 text-[10px] font-extrabold shrink-0">
                      {isLinked ? '✓ Linked' : 'Connect'}
                    </span>
                  </button>
                );
              })
            )}
          </div>
        )}
      </div>

      {/* TAG PEOPLE (COLLABORATORS) WITH SEARCH & PROFILE MATCH CARDS */}
      <div className="p-3.5 rounded-2xl bg-white/5 border border-white/15 space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-xs font-extrabold text-[#C084FC] flex items-center gap-1.5">
              <Users className="w-4 h-4 shrink-0" /> Tag People (Collab Channels)
            </div>
            <div className="text-[11px] text-white/65">
              Tagged creators get a Warm Sparks invite — accepting adds it to both channels!
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowTagPeoplePicker((v) => !v)}
            className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#7C3AED] hover:bg-[#6D28D9] text-white text-xs font-extrabold shrink-0"
          >
            {showTagPeoplePicker ? 'Done' : '+ Tag People'}
          </button>
        </div>

        {taggedCollaborators.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {taggedCollaborators.map((tc) => (
              <div
                key={tc.uid}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-[#7C3AED]/25 border border-[#C084FC]/45 text-xs font-bold"
              >
                <img
                  src={tc.avatarUrl}
                  alt={tc.displayName}
                  className="w-4 h-4 rounded-full object-cover"
                />
                <span>@{tc.username}</span>
                <button
                  type="button"
                  onClick={() =>
                    setTaggedCollaborators((prev) => prev.filter((x) => x.uid !== tc.uid))
                  }
                  className="text-white/70 hover:text-white ml-0.5"
                  aria-label={`Remove ${tc.username}`}
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        {(showTagPeoplePicker || tagPeopleSearch.trim().length > 0) && (
          <div className="space-y-2 pt-1">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-white/50 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={tagPeopleSearch}
                onChange={(e) => setTagPeopleSearch(e.target.value)}
                placeholder="Search @username or creator name..."
                className="w-full pl-8 pr-3 py-2 rounded-xl bg-black/50 border border-white/20 text-xs text-white"
              />
            </div>
            <div className="space-y-1.5 max-h-40 overflow-y-auto">
              {matchingUsersForTag.length === 0 ? (
                <div className="text-[11px] text-white/60 p-2">No matching profiles found.</div>
              ) : (
                matchingUsersForTag.map((u) => {
                  const isAdded = taggedCollaborators.some((tc) => tc.uid === u.uid);
                  return (
                    <button
                      key={u.uid}
                      type="button"
                      onClick={() => {
                        if (isAdded) {
                          setTaggedCollaborators((prev) => prev.filter((x) => x.uid !== u.uid));
                        } else {
                          setTaggedCollaborators((prev) => [
                            ...prev,
                            {
                              uid: u.uid,
                              username: u.username,
                              displayName: u.displayName,
                              avatarUrl: u.avatarUrl,
                              status: 'pending',
                            },
                          ]);
                          onTriggerToast(`👥 Tagged @${u.username} as collaborator`);
                        }
                      }}
                      className={`w-full p-2 rounded-xl border flex items-center justify-between gap-2.5 text-left ${
                        isAdded
                          ? 'bg-[#7C3AED]/25 border-[#C084FC]'
                          : 'bg-black/45 border-white/10 hover:border-white/30'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={u.avatarUrl}
                          alt={u.displayName}
                          className="w-8 h-8 rounded-full object-cover shrink-0 border border-white/20"
                        />
                        <div className="min-w-0">
                          <div className="text-xs font-extrabold text-white truncate">
                            {u.displayName}
                          </div>
                          <div className="text-[11px] text-[#C084FC] truncate">@{u.username}</div>
                        </div>
                      </div>
                      <span
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold shrink-0 ${
                          isAdded ? 'bg-[#16A34A] text-white' : 'bg-white/15 text-white'
                        }`}
                      >
                        {isAdded ? '✓ Tagged' : '+ Tag'}
                      </span>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>

      {/* SHOPPING LINK (500+ SPARKS) + 3D VR VIDEO (2000+ SPARKS) FOR VIDEO MODES */}
      {!isPhotoPostMode && (
        <>
          <div className="p-3 rounded-2xl bg-white/5 border border-white/15 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-extrabold text-[#FFB300] flex items-center gap-1.5">
                🛍️ Shopping Link (AI Verified)
              </span>
              <span
                className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold ${
                  userSparksCount >= 500
                    ? 'bg-[#16A34A] text-white'
                    : 'bg-red-500/20 text-red-300 border border-red-500/30'
                }`}
              >
                {userSparksCount >= 500
                  ? `✓ Unlocked`
                  : `🔒 500 Sparks (${userSparksCount}/500)`}
              </span>
            </div>

            {userSparksCount < 500 ? (
              <p className="text-[11px] text-white/60">
                Reach <strong>500 Sparks</strong> to tag Shopping Links in Quick Burst &amp; Main Blast.
              </p>
            ) : (
              <>
                <div className="flex items-center gap-1.5">
                  <input
                    type="url"
                    value={shoppingInputUrl}
                    onChange={(e) => handleAiInspectShoppingLink(e.target.value)}
                    placeholder="Paste shopping link (https://fism.shop/item or Amazon/Flipkart)..."
                    className="flex-1 px-2.5 py-1.5 rounded-lg bg-black/50 border border-white/20 text-xs text-white"
                  />
                  {shoppingInputUrl && (
                    <button
                      type="button"
                      onClick={() => handleAiInspectShoppingLink('')}
                      className="px-2 py-1.5 rounded-lg bg-white/10 text-[10px] text-white/70 hover:text-white"
                    >
                      Clear
                    </button>
                  )}
                </div>

                {shoppingProducts.length > 0 && (
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    <span className="text-[10px] text-white/50 shrink-0">Quick Tag:</span>
                    {shoppingProducts.slice(0, 3).map((prod) => (
                      <button
                        key={prod.id}
                        type="button"
                        onClick={() => {
                          const url = `https://fism.shop/product/${prod.id}`;
                          setShoppingInputUrl(url);
                          setAiVerifiedShoppingTitle(prod.title);
                          setAiVerifiedShoppingImage(
                            prod.imageUrl || prod.photos?.[0] || GENERATED_ASSETS.shopHeadset,
                          );
                          setAiVerifiedShoppingStore('FISM Official Store');
                          onTriggerToast(`🤖 AI Verified Shopping Link: "${prod.title}" ready!`);
                        }}
                        className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[10px] font-bold text-white flex items-center gap-1 shrink-0"
                      >
                        <img
                          src={prod.imageUrl || prod.photos?.[0] || GENERATED_ASSETS.shopHeadset}
                          alt={prod.title}
                          className="w-4 h-4 rounded object-cover"
                        />
                        <span className="truncate max-w-[95px]">{prod.title}</span>
                      </button>
                    ))}
                  </div>
                )}

                {aiVerifiedShoppingImage && shoppingInputUrl.trim() && (
                  <div className="flex items-center gap-2.5 p-2 rounded-lg bg-[#16A34A]/20 border border-[#16A34A]/40">
                    <img
                      src={aiVerifiedShoppingImage}
                      alt={aiVerifiedShoppingTitle}
                      className="w-10 h-10 rounded-lg object-cover border border-white/30 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-[10px] font-extrabold text-[#4ADE80]">
                        🤖 {aiVerifiedShoppingStore}
                      </div>
                      <div className="text-xs font-bold text-white truncate">
                        {aiVerifiedShoppingTitle}
                      </div>
                    </div>
                  </div>
                )}

                <input
                  type="text"
                  value={affiliateKeywordsInput}
                  onChange={(e) => setAffiliateKeywordsInput(e.target.value)}
                  placeholder="Auto-Comment keywords (e.g. price, link, buy)"
                  className="w-full px-2.5 py-1.5 rounded-lg bg-black/50 border border-white/20 text-xs text-white"
                />
              </>
            )}
          </div>

          <div className="p-2.5 rounded-2xl bg-white/5 border border-white/15 flex items-center justify-between gap-2">
            <div>
              <div className="text-[11px] font-extrabold text-white">
                🥽 Upload as 3D VR Spatial Video
              </div>
              <div className="text-[10px] text-white/60">
                {userSparksCount >= 2000
                  ? '2,000+ Sparks unlocked! Watchable in 360° VR Cinema.'
                  : `Requires 2,000 Sparks (${userSparksCount}/2,000)`}
              </div>
            </div>
            <button
              type="button"
              disabled={userSparksCount < 2000}
              onClick={() => setUploadAs3DVrVideo((prev) => !prev)}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold ${
                userSparksCount < 2000
                  ? 'bg-white/10 text-white/40 cursor-not-allowed'
                  : uploadAs3DVrVideo
                    ? 'bg-[#7C3AED] text-white shadow-md'
                    : 'bg-white/15 text-white'
              }`}
            >
              {userSparksCount < 2000
                ? '🔒 2,000 Sparks'
                : uploadAs3DVrVideo
                  ? '✓ 3D VR ON'
                  : 'Enable 3D VR'}
            </button>
          </div>
        </>
      )}

      {/* CREATOR GIFT DROP COLLAPSIBLE CONFIGURATOR */}
      <div className="p-3 rounded-2xl bg-[#FACC15]/10 border border-[#FACC15]/35 space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-xs font-extrabold text-[#FACC15] flex items-center gap-1.5">
              <Gift className="w-3.5 h-3.5" /> Gift Drop (Optional)
            </div>
            <div className="text-[10px] text-white/75 truncate tabular-nums">
              {giftDropEnabled
                ? `Active: ${safeDropWinners} winners × ${safeDropCoins} coins = ${totalDropDeduction.toLocaleString()} Coins`
                : `Wallet: ${userCoinBalance.toLocaleString()} Coins`}
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowGiftDropConfigInDetails((v) => !v)}
            className="px-3 py-1.5 rounded-lg bg-[#FACC15] text-[#0B0E17] text-[10px] font-black shrink-0"
          >
            {showGiftDropConfigInDetails
              ? 'Hide Gift Drop'
              : giftDropEnabled
                ? 'Edit Drop'
                : '🎁 Configure Gift Drop'}
          </button>
        </div>

        {showGiftDropConfigInDetails && (
          <div className="space-y-2.5 pt-2 border-t border-white/15">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-bold text-white/80">
                Enable First-Come-First-Serve Drop
              </span>
              <button
                type="button"
                onClick={() => setGiftDropEnabled((v) => !v)}
                className={`px-3 py-1 rounded-lg text-[11px] font-extrabold ${
                  giftDropEnabled ? 'bg-[#16A34A] text-white' : 'bg-white/15 text-white'
                }`}
              >
                {giftDropEnabled ? '✓ ON' : 'OFF'}
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {[
                { id: 'coins' as const, label: '🪙 Coins' },
                { id: 'photo' as const, label: '🖼️ Photo' },
                { id: 'secret_text' as const, label: '🔐 Secret' },
                { id: 'redeem_code' as const, label: '🎟️ Redeem' },
              ].map((rt) => (
                <button
                  key={rt.id}
                  type="button"
                  onClick={() => {
                    setGiftDropType(rt.id);
                    setGiftDropEnabled(true);
                    if (rt.id !== 'coins' && giftDropCoinsPerWinner === 100) {
                      setGiftDropCoinsPerWinner(0);
                    } else if (rt.id === 'coins' && giftDropCoinsPerWinner === 0) {
                      setGiftDropCoinsPerWinner(100);
                    }
                  }}
                  className={`px-2 py-1.5 rounded-xl text-[11px] font-extrabold border ${
                    giftDropType === rt.id
                      ? 'bg-[#FF5722] text-white border-[#FF5722]'
                      : 'bg-white/10 text-white/80 border-white/15'
                  }`}
                >
                  {rt.label}
                </button>
              ))}
            </div>

            <input
              type="text"
              value={giftDropTitle}
              onChange={(e) => setGiftDropTitle(e.target.value)}
              placeholder="Gift Drop Title..."
              className="w-full px-3 py-1.5 rounded-xl bg-black/50 border border-white/20 text-xs text-white font-bold"
            />

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-bold text-white/75 mb-1">
                  Winner Limit
                </label>
                <input
                  type="number"
                  min={1}
                  max={1000}
                  value={giftDropWinnerLimit}
                  onChange={(e) => setGiftDropWinnerLimit(Math.max(1, Number(e.target.value || 1)))}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-black/50 border border-white/20 text-xs text-white font-extrabold tabular-nums"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-white/75 mb-1">
                  Coins per Winner
                </label>
                <input
                  type="number"
                  min={giftDropType === 'coins' ? 1 : 0}
                  max={100000}
                  value={giftDropCoinsPerWinner}
                  onChange={(e) =>
                    setGiftDropCoinsPerWinner(Math.max(0, Number(e.target.value || 0)))
                  }
                  className="w-full px-2.5 py-1.5 rounded-xl bg-black/50 border border-white/20 text-xs text-white font-extrabold tabular-nums"
                />
              </div>
            </div>

            {giftDropType === 'photo' && (
              <input
                type="url"
                value={giftDropValue}
                onChange={(e) => setGiftDropValue(e.target.value)}
                placeholder="Paste reward photo URL..."
                className="w-full px-3 py-1.5 rounded-xl bg-black/50 border border-white/20 text-xs text-white"
              />
            )}
            {(giftDropType === 'secret_text' || giftDropType === 'redeem_code') && (
              <input
                type="text"
                value={giftDropValue}
                onChange={(e) => setGiftDropValue(e.target.value)}
                placeholder="Enter Redeem Code or Secret Text..."
                className="w-full px-3 py-1.5 rounded-xl bg-black/50 border border-white/20 text-xs text-[#FACC15] font-mono font-bold"
              />
            )}

            {giftDropEnabled && dropInsufficient && onOpenWalletOrPremium && (
              <button
                type="button"
                onClick={onOpenWalletOrPremium}
                className="w-full px-3 py-1.5 rounded-lg bg-[#FACC15] text-[#0B0E17] text-[11px] font-black"
              >
                Insufficient Coins — Purchase Fuel Up / Top Up →
              </button>
            )}
          </div>
        )}
      </div>

      <button
        type="button"
        onClick={handleFinalPublish}
        className="w-full min-h-[46px] py-3 rounded-xl fism-gradient-flame text-white text-sm font-black shadow-lg active:scale-[0.99] transition-transform"
      >
        {submitLabel}
      </button>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center overflow-hidden select-none">
      {/* Main Full-Screen Mobile/Studio Container */}
      <div className="relative w-full h-full max-w-[500px] mx-auto bg-[#0B0E14] flex flex-col justify-between overflow-hidden shadow-2xl border-x border-white/10">
        {/* ===================================================================
            VIEW A: PHOTO POST MODE (ZERO VIDEO EDITORS — DIRECT PHOTO + DETAILS)
            =================================================================== */}
        {isPhotoPostMode ? (
          <div className="flex flex-col h-full justify-between bg-[#0B0E14] text-white">
            <div className="px-4 pt-3 pb-2.5 flex items-center justify-between border-b border-white/10 shrink-0">
              <button
                onClick={onClose}
                aria-label="Close Studio"
                className="w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="text-center">
                <div className="text-sm font-black">Upload Photo Post</div>
                <div className="text-[10px] text-white/60">
                  Direct Photo · Title · Description · Tag People
                </div>
              </div>
              <div className="w-11" />
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {/* Photo Preview & Picker */}
              <div className="rounded-2xl overflow-hidden bg-black/50 border border-white/15 p-3 space-y-2.5">
                <div className="aspect-[16/10] w-full rounded-xl overflow-hidden bg-[#121725] flex items-center justify-center">
                  {mediaFileUrl && !mediaIsVideo ? (
                    <img
                      src={mediaFileUrl}
                      alt="Selected Photo"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <img
                      src={customThumbUrl || GENERATED_ASSETS.mountainPost}
                      alt="Default Photo Preview"
                      className="w-full h-full object-cover opacity-80"
                    />
                  )}
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-white/75 truncate">
                    {mediaFileUrl && !mediaIsVideo
                      ? mediaFileName || 'Selected Photo Ready'
                      : 'Choose a photo from your device'}
                  </span>
                  <label className="min-h-[38px] px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-xs font-extrabold cursor-pointer flex items-center gap-1.5 shrink-0">
                    <ImageIcon className="w-4 h-4 text-[#FFB300]" /> Select Photo
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleAddFileFromDevice(file);
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>
              </div>

              {renderDetailsAndPublishFields('🚀 Upload Photo Post')}
            </div>

            <div className="px-4 py-3 border-t border-white/10 bg-black/85 shrink-0">
              {renderModeBar()}
            </div>
          </div>
        ) : studioStep === 'details' ? (
          /* ===================================================================
             VIEW B: STEP 2 — DETAILS & PUBLISH SCREEN (AFTER CLICKING "Next →")
             =================================================================== */
          <div className="flex flex-col h-full justify-between bg-[#0B0E14] text-white">
            <div className="px-4 pt-3 pb-2.5 flex items-center justify-between border-b border-white/10 shrink-0">
              <button
                type="button"
                onClick={() => setStudioStep('capture')}
                className="min-h-[40px] px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-extrabold flex items-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <div className="text-center">
                <div className="text-sm font-black">
                  {isMainBlastMode ? 'Main Blast Details' : 'Quick Burst Details'}
                </div>
                <div className="text-[10px] text-[#FFB300] font-bold">
                  Title · Description · Connect Video · Tag People
                </div>
              </div>
              <button
                onClick={onClose}
                aria-label="Close Studio"
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {/* Compact Video Preview Strip */}
              <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-white/5 border border-white/15">
                <div className="w-16 h-20 rounded-xl overflow-hidden bg-black shrink-0 border border-white/20">
                  {mediaFileUrl && mediaIsVideo ? (
                    <video
                      src={mediaFileUrl}
                      muted
                      playsInline
                      className={`w-full h-full object-cover ${
                        isQuickBurstMode ? activeFilterObj.css : ''
                      }`}
                    />
                  ) : (
                    <img
                      src={mediaFileUrl || customThumbUrl || GENERATED_ASSETS.studioThumb}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-black text-[#FFB300]">
                    {isMainBlastMode ? '🎬 Main Blast Video Ready' : '⚡ Quick Burst Clip Ready'}
                  </div>
                  <div className="text-xs font-bold text-white truncate mt-0.5">
                    {mediaFileName || 'Recorded / Studio Clip'}
                  </div>
                  <div className="text-[11px] text-white/65 mt-0.5">
                    Duration: {recordingSeconds || (isMainBlastMode ? 125 : maxDurationSetting)}s
                    {isQuickBurstMode && selectedMusicTrack ? ` · 🎵 ${selectedMusicTrack.title}` : ''}
                  </div>
                </div>
              </div>

              {renderDetailsAndPublishFields(
                isMainBlastMode ? '🚀 Upload to Main Blast' : '🚀 Upload to Quick Burst',
              )}
            </div>
          </div>
        ) : (
          /* ===================================================================
             VIEW C: CAPTURE / PREVIEW VIEW
             - Quick Burst: Full YouCut Editing Tools + Filter Circles + Next →
             - Main Blast: Clean Video Preview / Recorder + Next → (NO editing tools!)
             =================================================================== */
          <>
            {/* LIVE CAMERA / GREEN SCREEN / UPLOADED VIDEO VIEWPORT */}
            <div className="absolute inset-0 bg-gradient-to-b from-[#111915] via-[#0B120E] to-[#07090C] overflow-hidden">
              {isQuickBurstMode && greenScreenEnabled && greenScreenCustomBg && (
                <div className="absolute inset-0 z-0">
                  {greenScreenCustomBg.startsWith('blob:') ||
                  greenScreenCustomBg.endsWith('.mp4') ||
                  greenScreenCustomBg.endsWith('.webm') ? (
                    <video
                      src={greenScreenCustomBg}
                      autoPlay
                      loop
                      muted
                      playsInline
                      className={`w-full h-full object-cover opacity-80 ${activeFilterObj.css}`}
                    />
                  ) : (
                    <img
                      src={greenScreenCustomBg}
                      alt="Green Screen Background"
                      className={`w-full h-full object-cover opacity-80 ${activeFilterObj.css}`}
                    />
                  )}
                  <div className="absolute top-24 left-4 px-2.5 py-1 rounded-full bg-[#16A34A]/90 text-white text-[11px] font-extrabold flex items-center gap-1 shadow-lg">
                    <UserCheck className="w-3.5 h-3.5" /> Green Screen BG Active
                    {greenScreenSourcePost && ` (@${greenScreenSourcePost.authorUsername})`}
                  </div>
                </div>
              )}

              {mediaFileUrl ? (
                <div className="relative z-10 w-full h-full flex items-center justify-center">
                  {mediaIsVideo ? (
                    <video
                      key={mediaFileUrl}
                      src={mediaFileUrl}
                      autoPlay
                      loop
                      playsInline
                      controls={isMainBlastMode}
                      className={`w-full h-full object-contain ${
                        isQuickBurstMode ? activeFilterObj.css : ''
                      }`}
                    />
                  ) : (
                    <img
                      src={mediaFileUrl}
                      alt="Uploaded Preview"
                      className={`w-full h-full object-contain ${
                        isQuickBurstMode ? activeFilterObj.css : ''
                      }`}
                    />
                  )}
                </div>
              ) : (
                <video
                  ref={cameraVideoRef}
                  muted
                  playsInline
                  autoPlay
                  style={
                    isQuickBurstMode && activeArFilter?.cssFilter
                      ? { filter: activeArFilter.cssFilter }
                      : undefined
                  }
                  className={`relative z-10 transition-all ${
                    isQuickBurstMode && greenScreenEnabled && smartFilterState.mode === 'off'
                      ? 'w-44 h-64 sm:w-52 sm:h-72 object-cover rounded-3xl border-2 border-[#16A34A] shadow-2xl absolute bottom-44 left-5'
                      : 'w-full h-full object-cover'
                  } ${isQuickBurstMode ? activeFilterObj.css : ''} ${
                    cameraActive && smartFilterState.mode === 'off'
                      ? 'opacity-100'
                      : 'opacity-0 pointer-events-none'
                  }`}
                />
              )}

              {!mediaFileUrl && smartFilterState.mode !== 'off' && (
                <FismSmartFilterViewport
                  open={open}
                  state={smartFilterState}
                  cameraVideoRef={cameraVideoRef}
                  compositeCanvasRef={smartCompositeCanvasRef}
                  mirrorCamera={cameraFacing === 'user'}
                  allowPlacementDrag={false}
                  onTriggerToast={onTriggerToast}
                  onStatusChange={setSmartFilterStatus}
                  gameActionSignal={gameActionSignal}
                />
              )}

              {isQuickBurstMode && activeArFilter && (
                <canvas
                  ref={arCanvasRef}
                  className="absolute inset-0 w-full h-full z-15 pointer-events-none"
                />
              )}

              {isQuickBurstMode && sparkleVfxOn && (
                <div className="absolute inset-0 z-10 pointer-events-none bg-[radial-gradient(circle_at_30%_25%,rgba(168,85,247,0.28),transparent_45%),radial-gradient(circle_at_75%_65%,rgba(255,87,34,0.25),transparent_50%)] animate-pulse" />
              )}

              {isQuickBurstMode && stickerOverlay && (
                <div className="absolute top-28 left-5 z-20 px-3 py-1 rounded-xl fism-gradient-flame text-white text-xs font-extrabold shadow-lg">
                  {stickerOverlay}
                </div>
              )}
              {isQuickBurstMode && textOverlay && (
                <div className="absolute bottom-48 inset-x-12 z-20 px-3.5 py-2 rounded-xl bg-black/75 border border-white/20 text-white text-sm font-extrabold text-center shadow-xl">
                  {textOverlay}
                </div>
              )}

              {activeCountdown !== null && (
                <div className="absolute inset-0 z-30 bg-black/50 flex items-center justify-center">
                  <span className="text-7xl font-black text-white animate-ping">
                    {activeCountdown}
                  </span>
                </div>
              )}
            </div>

            {/* TOP BAR */}
            <div className="relative z-30 pt-3 px-4 space-y-3">
              <div className="w-full h-2 rounded-full bg-white/25 overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    isRecording ? 'bg-[#E53935]' : 'bg-white/70'
                  }`}
                  style={{ width: `${progressPct}%` }}
                />
              </div>

              <div className="flex items-center justify-between gap-2">
                <button
                  onClick={onClose}
                  aria-label="Close Studio"
                  className="w-11 h-11 rounded-full bg-white/15 hover:bg-white/25 backdrop-blur-md text-white flex items-center justify-center transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>

                {isQuickBurstMode ? (
                  <button
                    onClick={() => setMusicDrawerOpen(true)}
                    className="px-5 py-2.5 rounded-full bg-white/15 hover:bg-white/25 backdrop-blur-md text-white text-sm font-bold flex items-center gap-2 shadow-lg max-w-[210px]"
                  >
                    <Music className="w-4 h-4 shrink-0" />
                    <span className="truncate">
                      {selectedMusicTrack ? selectedMusicTrack.title : 'Add sound'}
                    </span>
                  </button>
                ) : (
                  <div className="px-4 py-2 rounded-full bg-white/15 backdrop-blur-md text-white text-xs font-extrabold">
                    🎬 Main Blast Video Preview
                  </div>
                )}

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setYouCutDrawerOpen(false);
                      setSmartFilterSheetOpen((s) => !s);
                    }}
                    className={`min-h-[42px] px-3 py-2 rounded-full text-xs font-extrabold flex items-center gap-1.5 backdrop-blur-md border transition-colors ${
                      smartFilterState.mode !== 'off' || smartFilterSheetOpen
                        ? 'bg-[#00F5D4] border-[#00F5D4] text-slate-950 shadow-lg'
                        : 'bg-white/15 border-white/20 text-white hover:bg-white/25'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>
                      {smartFilterState.mode === 'photo_bg'
                        ? 'Photo BG'
                        : smartFilterState.mode === 'camera_chroma'
                          ? 'Chroma'
                          : smartFilterState.mode === 'game_chroma'
                            ? 'Game Filter'
                            : 'All Filters'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSmartFilterSheetOpen(false);
                      setYouCutDrawerOpen(false);
                      setStudioStep('details');
                    }}
                    className="min-h-[42px] px-4 py-2 rounded-full fism-gradient-flame text-white text-xs font-black flex items-center gap-1 shadow-lg"
                  >
                    Next <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Ready Bar — Clean separation for Quick Burst vs Main Blast */}
              {(mediaFileUrl || recordingSeconds > 0 || (isQuickBurstMode && greenScreenEnabled)) && (
                <div className="flex items-center justify-between bg-black/75 backdrop-blur-md px-3.5 py-2 rounded-2xl border border-white/15 text-white text-xs">
                  <div className="truncate pr-2">
                    <span className="font-extrabold text-[#FFB300]">
                      {mediaFileName ||
                        (isMainBlastMode ? 'Main Blast Video Ready' : 'Quick Burst Clip Ready')}
                    </span>
                    {isQuickBurstMode && (
                      <span className="text-white/75 ml-1.5">
                        · {activeFilterObj.label} · {playbackSpeed}x
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {isQuickBurstMode && (
                      <button
                        type="button"
                        onClick={() => {
                          setYouCutDrawerOpen(true);
                          setYouCutTab('trim');
                        }}
                        className="px-2.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 font-bold"
                      >
                        ✂️ Edit
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setYouCutDrawerOpen(false);
                        setStudioStep('details');
                      }}
                      className="px-3 py-1.5 rounded-lg fism-gradient-flame font-extrabold shadow flex items-center gap-1"
                    >
                      Next <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* RIGHT VERTICAL YOUCUT DOCK — ONLY SHOWN IN QUICK BURST MODE */}
            {isQuickBurstMode && (
              <div
                onWheel={(e) => {
                  if (e.deltaY > 15) setYouCutDrawerOpen(true);
                }}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 z-30 py-3 px-2 rounded-full bg-white/12 backdrop-blur-md border border-white/15 flex flex-col items-center gap-4 text-white max-h-[58vh] overflow-y-auto shadow-2xl"
              >
                <button
                  onClick={() => {
                    const nextFacing = cameraFacing === 'user' ? 'environment' : 'user';
                    setCameraFacing(nextFacing);
                    startCameraStream(nextFacing);
                    onTriggerToast(
                      `Camera flipped to ${nextFacing === 'user' ? 'Front Selfie' : 'Rear Lens'}`,
                    );
                  }}
                  title="Flip Camera"
                  className="w-10 h-10 rounded-full hover:bg-white/15 flex items-center justify-center transition-transform active:rotate-180"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>

                <button
                  onClick={() => {
                    const nextTimer = countdownSetting === 0 ? 3 : countdownSetting === 3 ? 10 : 0;
                    setCountdownSetting(nextTimer);
                    onTriggerToast(
                      nextTimer === 0 ? 'Timer Off' : `Countdown Timer set to ${nextTimer}s`,
                    );
                  }}
                  title="Countdown Timer"
                  className="w-10 h-10 rounded-full hover:bg-white/15 flex flex-col items-center justify-center relative"
                >
                  <Timer className="w-5 h-5" />
                  {countdownSetting > 0 && (
                    <span className="text-[9px] font-extrabold text-[#FFB300]">
                      {countdownSetting}s
                    </span>
                  )}
                </button>

                <button
                  onClick={() => {
                    const nextDur = maxDurationSetting === 15 ? 60 : 15;
                    setMaxDurationSetting(nextDur);
                    onTriggerToast(`Quick Burst duration set to ${nextDur} s`);
                  }}
                  title="Quick Burst Recording Duration"
                  className="w-10 h-10 rounded-full hover:bg-white/15 flex items-center justify-center font-extrabold text-xs tracking-tight"
                >
                  {maxDurationSetting} s
                </button>

                <button
                  onClick={() => {
                    setSparkleVfxOn((v) => !v);
                    onTriggerToast(sparkleVfxOn ? 'Sparkle VFX Off' : '✨ Sparkle VFX Enabled');
                  }}
                  title="Effects"
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    sparkleVfxOn ? 'bg-[#7C3AED] text-white' : 'hover:bg-white/15'
                  }`}
                >
                  <Sparkles className="w-5 h-5" />
                </button>

                <button
                  onClick={() => {
                    const nextSpd =
                      playbackSpeed === 1
                        ? 1.5
                        : playbackSpeed === 1.5
                          ? 2
                          : playbackSpeed === 2
                            ? 0.5
                            : 1;
                    setPlaybackSpeed(nextSpd);
                    onTriggerToast(`Speed: ${nextSpd}x`);
                  }}
                  title="Recording Speed"
                  className="w-10 h-10 rounded-full hover:bg-white/15 flex items-center justify-center font-extrabold text-sm"
                >
                  {playbackSpeed}x
                </button>

                <button
                  onClick={() => {
                    setGreenScreenEnabled((g) => !g);
                    setYouCutDrawerOpen(true);
                    setYouCutTab('greenscreen');
                  }}
                  title="Green Screen Background Cutout"
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    greenScreenEnabled ? 'bg-[#16A34A] text-white' : 'hover:bg-white/15'
                  }`}
                >
                  <UserCheck className="w-5 h-5" />
                </button>

                <button
                  onClick={() => setYouCutDrawerOpen((o) => !o)}
                  title="Open Quick Burst Video Editor"
                  className="w-10 h-10 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center"
                >
                  {youCutDrawerOpen ? (
                    <ChevronUp className="w-5 h-5" />
                  ) : (
                    <ChevronDown className="w-5 h-5" />
                  )}
                </button>
              </div>
            )}

            {/* BOTTOM CAPTURE CONTROLS + MODE BAR */}
            <div className="relative z-30 pb-4 pt-2 px-4 space-y-5 bg-gradient-to-t from-black via-black/80 to-transparent">
              <div className="flex items-center justify-between gap-3">
                {/* LEFT: Add Video from Device */}
                <div className="w-20 flex flex-col items-center justify-center shrink-0">
                  <label
                    title="Add Video from Device"
                    className="group cursor-pointer flex flex-col items-center gap-1.5"
                  >
                    <div className="w-13 h-13 rounded-2xl overflow-hidden border-2 border-white/85 bg-white/10 shadow-lg relative flex items-center justify-center group-hover:scale-105 transition-transform">
                      <img
                        src={
                          mediaFileUrl && !mediaIsVideo
                            ? mediaFileUrl
                            : customThumbUrl || GENERATED_ASSETS.mountainPost
                        }
                        alt="Add Media"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/25 flex items-center justify-center">
                        <Plus className="w-5 h-5 text-white drop-shadow" />
                      </div>
                    </div>
                    <span className="text-white text-xs font-bold tracking-tight">Add</span>
                    <input
                      type="file"
                      accept="video/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleAddFileFromDevice(file);
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>

                {/* CENTER: Record Circle */}
                <div className="flex flex-col items-center justify-center shrink-0">
                  <button
                    onClick={handlePressWhiteRecordCircle}
                    aria-label="Start or Stop Camera Recording"
                    className="w-20 h-20 rounded-full border-4 border-white p-1.5 flex items-center justify-center shadow-[0_0_25px_rgba(255,255,255,0.4)] active:scale-95 transition-transform"
                  >
                    <div
                      className={`transition-all duration-200 ${
                        isRecording
                          ? 'w-8 h-8 rounded-lg bg-[#E53935]'
                          : 'w-full h-full rounded-full bg-white'
                      }`}
                    />
                  </button>
                  {isRecording && (
                    <span className="text-[11px] font-extrabold text-[#E53935] mt-1 animate-pulse">
                      ● REC {recordingSeconds}s / {maxDurationSetting}s
                    </span>
                  )}
                </div>

                {/* RIGHT: Filters ONLY in Quick Burst Mode; Flip Camera + Next -> in Main Blast */}
                {isQuickBurstMode ? (
                  <div
                    ref={filterScrollRef}
                    onWheel={(e) => {
                      if (filterScrollRef.current) {
                        filterScrollRef.current.scrollLeft += e.deltaY;
                      }
                    }}
                    className="flex-1 flex items-center gap-2.5 overflow-x-auto no-scrollbar py-1 pl-1"
                  >
                    {publishedArFilters
                      .filter((f) => f.publishedToUsers)
                      .map((arFlt) => {
                        const selected = activeArFilterId === arFlt.id;
                        return (
                          <button
                            key={arFlt.id}
                            type="button"
                            onClick={() => {
                              setActiveArFilterId((prev) => (prev === arFlt.id ? null : arFlt.id));
                              onTriggerToast(
                                selected
                                  ? `Removed AR Filter: ${arFlt.name}`
                                  : `🤖 AR Filter active: ${arFlt.name}`,
                              );
                            }}
                            className="shrink-0 flex flex-col items-center gap-1 group"
                          >
                            <div
                              style={{ borderColor: arFlt.primaryColor }}
                              className={`w-12 h-12 rounded-full overflow-hidden transition-all flex items-center justify-center bg-slate-900 border-2 relative ${
                                selected
                                  ? 'ring-3 ring-[#00F5D4] scale-110'
                                  : 'opacity-90 hover:opacity-100'
                              }`}
                            >
                              <Sparkles
                                className="w-5 h-5"
                                style={{ color: arFlt.primaryColor }}
                              />
                              <span className="absolute bottom-0 inset-x-0 bg-black/75 text-[8px] font-black text-white text-center leading-tight py-0.5">
                                AR
                              </span>
                            </div>
                            <span className="text-[10px] text-[#00F5D4] font-bold truncate max-w-[56px]">
                              {arFlt.name.split(' ')[0]}
                            </span>
                          </button>
                        );
                      })}

                    {STUDIO_FILTERS.map((flt) => {
                      const selected = activeFilter === flt.id && !activeArFilterId;
                      return (
                        <button
                          key={flt.id}
                          type="button"
                          onClick={() => {
                            setActiveFilter(flt.id);
                            if (flt.id === 'none') setActiveArFilterId(null);
                            onTriggerToast(`✨ Filter applied: ${flt.label}`);
                          }}
                          className="shrink-0 flex flex-col items-center gap-1 group"
                        >
                          <div
                            className={`w-12 h-12 rounded-full overflow-hidden transition-all ${
                              selected
                                ? 'ring-3 ring-[#FFB300] scale-110'
                                : 'ring-1 ring-white/40 opacity-80 hover:opacity-100'
                            }`}
                          >
                            <img
                              src={flt.thumb}
                              alt={flt.label}
                              className={`w-full h-full object-cover ${flt.css}`}
                            />
                          </div>
                          <span className="text-[10px] text-white/90 font-semibold truncate max-w-[54px]">
                            {flt.label.split(' ')[0]}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="w-20 flex flex-col items-center justify-center shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        const nextFacing = cameraFacing === 'user' ? 'environment' : 'user';
                        setCameraFacing(nextFacing);
                        startCameraStream(nextFacing);
                      }}
                      className="w-12 h-12 rounded-2xl bg-white/15 hover:bg-white/25 text-white flex items-center justify-center"
                      title="Flip Camera"
                    >
                      <RefreshCw className="w-5 h-5" />
                    </button>
                    <span className="text-white text-[11px] font-bold mt-1.5">Flip</span>
                  </div>
                )}
              </div>

              {renderModeBar()}
            </div>

            <FismUserFilterBrowserSheet
              open={smartFilterSheetOpen}
              onClose={() => setSmartFilterSheetOpen(false)}
              smartState={smartFilterState}
              publishedStudioFilters={publishedStudioFilters}
              publishedArFilters={publishedArFilters}
              activeArFilterId={activeArFilterId}
              onSelectArFilter={(flt) => {
                setActiveArFilterId(flt ? flt.id : null);
                onTriggerToast(flt ? `AR Filter active: ${flt.name}` : 'AR Filter removed.');
              }}
              onSelectStudioFilter={handleSelectUserStudioFilter}
              liveStatus={smartFilterStatus}
              onGameReset={() => setGameActionSignal((g) => ({ seq: g.seq + 1, type: 'reset' }))}
              onGameTogglePause={() =>
                setGameActionSignal((g) => ({ seq: g.seq + 1, type: 'togglePause' }))
              }
              isRecording={isRecording}
              onToggleRecord={handlePressWhiteRecordCircle}
            />

            {/* SLIDE-UP YOUCUT EDITING DRAWER — STRICTLY QUICK BURST ONLY (NO PUBLISH/TITLE TAB HERE) */}
            {isQuickBurstMode && youCutDrawerOpen && (
              <div className="absolute inset-x-0 bottom-0 z-40 bg-[#121624] border-t-2 border-[#FF5722] rounded-t-3xl p-4 text-white space-y-3.5 max-h-[72vh] overflow-y-auto shadow-[0_-16px_40px_rgba(0,0,0,0.85)]">
                <div className="w-12 h-1.5 bg-white/25 rounded-full mx-auto" />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Scissors className="w-4 h-4 text-[#FF5722]" />
                    <span className="font-extrabold text-sm">
                      Quick Burst Editor (YouCut)
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setYouCutDrawerOpen(false);
                        setStudioStep('details');
                      }}
                      className="px-3.5 py-1.5 rounded-xl fism-gradient-flame text-white text-xs font-extrabold flex items-center gap-1 shadow-md"
                    >
                      Next <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setYouCutDrawerOpen(false)}
                      className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* YouCut Editing Tabs ONLY (No Title/Description/Upload inside Editor) */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  {[
                    { id: 'trim', label: '✂️ Trim / Split' },
                    { id: 'greenscreen', label: '🟢 Green Screen' },
                    { id: 'filters', label: '🎨 Filters' },
                    { id: 'text', label: '🔤 Text & Stickers' },
                    { id: 'speed', label: '⏩ Speed' },
                    { id: 'audio', label: '🎵 Music & AI' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() =>
                        setYouCutTab(
                          t.id as 'trim' | 'greenscreen' | 'text' | 'filters' | 'speed' | 'audio',
                        )
                      }
                      className={`px-3 py-1.5 rounded-xl text-xs font-extrabold shrink-0 ${
                        youCutTab === t.id
                          ? 'bg-[#FF5722] text-white'
                          : 'bg-white/10 text-white/75 hover:text-white'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                {youCutTab === 'trim' && (
                  <div className="space-y-3 bg-black/40 p-3.5 rounded-2xl border border-white/10">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span>
                        Timeline Trim: {trimStartPct}% — {trimEndPct}% (Splits: {splitPoints.length})
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          const mid = Math.round((trimStartPct + trimEndPct) / 2);
                          setSplitPoints((prev) => [...prev, mid]);
                          onTriggerToast(`✂️ Split clip at ${mid}% mark!`);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-[#7C3AED] text-white text-[11px] font-extrabold"
                      >
                        + Split Clip Here
                      </button>
                    </div>
                    <div className="relative h-12 rounded-xl bg-[#1E2538] overflow-hidden border-2 border-[#FFB300] flex items-center px-2">
                      <div
                        className="h-8 rounded-lg fism-gradient-flame opacity-85 flex items-center justify-between px-3 text-[10px] font-extrabold"
                        style={{
                          marginLeft: `${trimStartPct}%`,
                          width: `${Math.max(10, trimEndPct - trimStartPct)}%`,
                        }}
                      >
                        <span>IN</span>
                        <span>QUICK BURST ({playbackSpeed}x)</span>
                        <span>OUT</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <label className="block text-white/70 mb-1">Trim Start ({trimStartPct}%)</label>
                        <input
                          type="range"
                          min={0}
                          max={Math.max(0, trimEndPct - 10)}
                          value={trimStartPct}
                          onChange={(e) => setTrimStartPct(Number(e.target.value))}
                          className="w-full accent-[#FF5722]"
                        />
                      </div>
                      <div>
                        <label className="block text-white/70 mb-1">Trim End ({trimEndPct}%)</label>
                        <input
                          type="range"
                          min={Math.min(100, trimStartPct + 10)}
                          max={100}
                          value={trimEndPct}
                          onChange={(e) => setTrimEndPct(Number(e.target.value))}
                          className="w-full accent-[#FF5722]"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {youCutTab === 'greenscreen' && (
                  <div className="space-y-3 bg-black/40 p-3.5 rounded-2xl border border-white/10">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <div className="text-xs font-extrabold text-[#16A34A]">
                          Green Screen Background &amp; Official Filters
                        </div>
                        <p className="text-[11px] text-white/70">
                          Remix another Quick Burst behind your clip or search all Admin-created Photo,
                          Chroma &amp; Game Filters!
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setYouCutDrawerOpen(false);
                          setSmartFilterSheetOpen(true);
                        }}
                        className="px-3.5 py-2 rounded-xl bg-[#00F5D4] text-slate-950 text-xs font-black"
                      >
                        Search &amp; Browse App Filters
                      </button>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <label className="px-3 py-2 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold cursor-pointer">
                        📂 Upload Custom Green Screen BG
                        <input
                          type="file"
                          accept="video/*,image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              setGreenScreenCustomBg(URL.createObjectURL(file));
                              setGreenScreenEnabled(true);
                              onTriggerToast('🟢 Custom Green Screen background loaded!');
                            }
                          }}
                        />
                      </label>
                      {[
                        { label: 'Booyah Arena BG', url: GENERATED_ASSETS.studioThumb },
                        { label: '8K Studio BG', url: GENERATED_ASSETS.heroCover },
                        { label: 'Alpine Peak BG', url: GENERATED_ASSETS.mountainPost },
                      ].map((preset) => (
                        <button
                          key={preset.label}
                          type="button"
                          onClick={() => {
                            setGreenScreenCustomBg(preset.url);
                            setGreenScreenEnabled(true);
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold"
                        >
                          {preset.label}
                        </button>
                      ))}
                      {greenScreenSourcePost && (
                        <button
                          type="button"
                          onClick={onClearGreenScreenSource}
                          className="px-2.5 py-1.5 rounded-xl bg-[#DC2626] text-white text-xs font-bold"
                        >
                          Clear Remix BG
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {youCutTab === 'filters' && (
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 bg-black/40 p-3 rounded-2xl border border-white/10">
                    {STUDIO_FILTERS.map((flt) => (
                      <button
                        key={flt.id}
                        type="button"
                        onClick={() => setActiveFilter(flt.id)}
                        className={`p-2 rounded-xl flex flex-col items-center gap-1 border ${
                          activeFilter === flt.id
                            ? 'border-[#FFB300] bg-white/15'
                            : 'border-white/10 bg-white/5'
                        }`}
                      >
                        <img
                          src={flt.thumb}
                          alt={flt.label}
                          className={`w-10 h-10 rounded-full object-cover ${flt.css}`}
                        />
                        <span className="text-[10px] font-bold">{flt.label}</span>
                      </button>
                    ))}
                  </div>
                )}

                {youCutTab === 'text' && (
                  <div className="space-y-2.5 bg-black/40 p-3.5 rounded-2xl border border-white/10">
                    <input
                      type="text"
                      value={textOverlay}
                      onChange={(e) => setTextOverlay(e.target.value)}
                      placeholder="Type text to overlay on clip..."
                      className="w-full px-3 py-2 rounded-xl bg-white/10 border border-white/20 text-xs text-white"
                    />
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        '🔥 BOOYAH!',
                        '😜 CLUTCH 1v4',
                        '⚡ QUICK BURST',
                        '👑 1M+ VIRAL',
                        '🎵 SOUND ON',
                        '',
                      ].map((stk) => (
                        <button
                          key={stk || 'none'}
                          type="button"
                          onClick={() => setStickerOverlay(stk)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-extrabold ${
                            stickerOverlay === stk ? 'bg-[#FF5722] text-white' : 'bg-white/10'
                          }`}
                        >
                          {stk || 'No Sticker'}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {youCutTab === 'speed' && (
                  <div className="flex items-center justify-between gap-2 bg-black/40 p-3.5 rounded-2xl border border-white/10">
                    <span className="text-xs font-bold">Speed Curve:</span>
                    <div className="flex gap-2">
                      {([0.5, 1, 1.5, 2] as const).map((spd) => (
                        <button
                          key={spd}
                          type="button"
                          onClick={() => setPlaybackSpeed(spd)}
                          className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold ${
                            playbackSpeed === spd ? 'fism-gradient-flame text-white' : 'bg-white/10'
                          }`}
                        >
                          {spd}x
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {youCutTab === 'audio' && (
                  <div className="space-y-3 bg-black/40 p-3.5 rounded-2xl border border-white/10">
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <label className="block text-white/75 mb-1">
                          Original Audio ({originalVolume}%)
                        </label>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={originalVolume}
                          onChange={(e) => setOriginalVolume(Number(e.target.value))}
                          className="w-full accent-[#FF5722]"
                        />
                      </div>
                      <div>
                        <label className="block text-white/75 mb-1">
                          Added Music ({musicVolume}%)
                        </label>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={musicVolume}
                          onChange={(e) => setMusicVolume(Number(e.target.value))}
                          className="w-full accent-[#7C3AED]"
                        />
                      </div>
                    </div>

                    <div className="pt-2 border-t border-white/10 space-y-2">
                      <div className="text-xs font-extrabold text-[#FFB300]">
                        🤖 Generate AI Music + Cover Photo
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={aiMusicPrompt}
                          onChange={(e) => setAiMusicPrompt(e.target.value)}
                          placeholder="Describe beat or song..."
                          className="flex-1 px-3 py-1.5 rounded-xl bg-white/10 border border-white/20 text-xs text-white"
                        />
                        <button
                          type="button"
                          onClick={onGenerateAiMusicAndCover}
                          disabled={aiMusicGenerating}
                          className="px-3 py-1.5 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold shrink-0"
                        >
                          {aiMusicGenerating ? 'Generating...' : '✨ Generate'}
                        </button>
                      </div>
                      {generatedMusicUrl && (
                        <div className="flex items-center justify-between gap-2 pt-1">
                          <audio src={generatedMusicUrl} controls className="h-8 flex-1" />
                          <button
                            type="button"
                            onClick={onUploadAiMusicToChannel}
                            className="px-3 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold"
                          >
                            Publish AI Song
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* ===================================================================
            6. IN-STUDIO MUSIC LIBRARY & UPLOADER DRAWER (Opened by "🎵 Add sound" or "Music")
            =================================================================== */}
        {musicDrawerOpen && (
          <div className="absolute inset-0 z-50 bg-[#0D111D]/98 p-4 flex flex-col justify-between text-white overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-white/15 pb-3">
                <div className="flex items-center gap-2">
                  <Music className="w-5 h-5 text-[#FF5722]" />
                  <div>
                    <h3 className="font-extrabold text-base">
                      FISM App Music Library &amp; Uploader
                    </h3>
                    <p className="text-[11px] text-white/65">
                      Pick any sound for your Short or upload your own music track for everyone to
                      use!
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setMusicDrawerOpen(false)}
                  className="p-2 rounded-full bg-white/10 hover:bg-white/20"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Upload New Music Track to App Music Section */}
              <div className="p-3.5 rounded-2xl bg-white/5 border border-[#7C3AED] space-y-2.5">
                <div className="text-xs font-extrabold text-[#FFB300] flex items-center gap-1.5">
                  <Upload className="w-4 h-4" /> + Upload Your Own Music to FISM Music Hub
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={newTrackTitle}
                    onChange={(e) => setNewTrackTitle(e.target.value)}
                    placeholder="Song / Sound Title..."
                    className="px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-xs text-white"
                  />
                  <input
                    type="text"
                    value={newTrackGenre}
                    onChange={(e) => setNewTrackGenre(e.target.value)}
                    placeholder="Genre (e.g. Phonk, Hip-Hop, Lo-Fi)"
                    className="px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-xs text-white"
                  />
                </div>
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <label className="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-xs font-bold cursor-pointer">
                    🎵 Select Audio File (.mp3/.wav)
                    <input
                      type="file"
                      accept="audio/*,video/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setNewTrackAudioUrl(URL.createObjectURL(file));
                          if (!newTrackTitle.trim()) {
                            setNewTrackTitle(file.name.replace(/\.[^/.]+$/, ''));
                          }
                        }
                      }}
                    />
                  </label>
                  <label className="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-xs font-bold cursor-pointer">
                    🖼️ Cover Photo
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) setNewTrackCoverUrl(URL.createObjectURL(file));
                      }}
                    />
                  </label>
                  <button
                    type="button"
                    onClick={handleUploadMusicInModal}
                    className="px-4 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold"
                  >
                    Upload &amp; Use Music
                  </button>
                </div>
              </div>

              {/* Existing App Music Tracks List */}
              <div className="space-y-2">
                <div className="text-xs font-extrabold uppercase tracking-wider text-white/60">
                  Available App Sounds ({musicTracks.length})
                </div>
                {musicTracks.map((trk) => {
                  const isAttached = selectedMusicTrack?.id === trk.id;
                  return (
                    <div
                      key={trk.id}
                      className={`p-3 rounded-2xl border flex items-center justify-between gap-3 ${
                        isAttached
                          ? 'bg-[#FF5722]/20 border-[#FF5722]'
                          : 'bg-white/5 border-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={trk.coverUrl}
                          alt={trk.title}
                          className="w-12 h-12 rounded-xl object-cover shrink-0 border border-white/20"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-xs sm:text-sm truncate">{trk.title}</div>
                          <div className="text-[11px] text-white/65 truncate">
                            @{trk.uploaderUsername} • {trk.genre} • {trk.usesCount.toLocaleString()}{' '}
                            Shorts
                          </div>
                          {trk.audioUrl && (
                            <audio src={trk.audioUrl} controls className="h-6 w-44 mt-1" />
                          )}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          onSelectMusicTrack(isAttached ? null : trk);
                          setMusicDrawerOpen(false);
                          onTriggerToast(
                            isAttached
                              ? 'Removed sound from Short'
                              : `🎵 Attached sound: "${trk.title}"`,
                          );
                        }}
                        className={`px-3.5 py-2 rounded-xl text-xs font-extrabold shrink-0 ${
                          isAttached ? 'bg-white text-black' : 'fism-gradient-flame text-white'
                        }`}
                      >
                        {isAttached ? '✓ Selected' : 'Use Sound'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/* ============================================================================
   DEDICATED IN-APP MUSIC SECTION (FISM MUSIC HUB)
   Everyone can upload music from Create and attach music to their Shorts/Videos!
   ============================================================================ */
interface FismMusicHubScreenProps {
  musicTracks: FismMusicTrack[];
  onUploadMusicTrack: (track: FismMusicTrack) => void;
  onUseMusicInShort: (track: FismMusicTrack) => void;
  currentUsername: string;
  onTriggerToast: (msg: string) => void;
}

export const FismMusicHubScreen: React.FC<FismMusicHubScreenProps> = ({
  musicTracks,
  onUploadMusicTrack,
  onUseMusicInShort,
  currentUsername,
  onTriggerToast,
}) => {
  const [songTitle, setSongTitle] = useState('');
  const [songArtist, setSongArtist] = useState(currentUsername);
  const [songGenre, setSongGenre] = useState('Gaming Phonk / Free Fire Beat');
  const [songAudioUrl, setSongAudioUrl] = useState('');
  const [songCoverUrl, setSongCoverUrl] = useState(GENERATED_ASSETS.studioThumb);

  const handleCreateMusic = (e: React.FormEvent) => {
    e.preventDefault();
    if (!songTitle.trim()) {
      onTriggerToast('Please enter a title for your music track!');
      return;
    }
    const newTrack: FismMusicTrack = {
      id: `music_${Date.now()}`,
      title: songTitle.trim(),
      artist: songArtist.trim() || currentUsername,
      uploaderUsername: currentUsername,
      audioUrl: songAudioUrl,
      coverUrl: songCoverUrl,
      duration: '00:35',
      genre: songGenre,
      usesCount: 1,
      createdAt: 'Just now',
    };
    onUploadMusicTrack(newTrack);
    setSongTitle('');
    setSongAudioUrl('');
    onTriggerToast(`🎵 "${newTrack.title}" published to FISM Music Section!`);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="fism-card p-5 bg-gradient-to-r from-[#101426] via-[#1E1B4B] to-[#31102F] text-white flex items-center justify-between flex-wrap gap-4">
        <div>
          <span className="px-2.5 py-0.5 rounded-full bg-[#FFB300] text-[#101426] text-[10px] font-extrabold uppercase">
            Community Audio Library
          </span>
          <h1 className="text-xl sm:text-2xl font-extrabold flex items-center gap-2 mt-1">
            <Headphones className="w-6 h-6 text-[#FF5722]" /> FISM Music Section — Upload &amp;
            Remix Sounds
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Anyone can upload original music, beats, or audio tracks here and use them in Quick
            Burst (Shorts) or Remix!
          </p>
        </div>
      </div>

      {/* Upload Music Box */}
      <form onSubmit={handleCreateMusic} className="fism-card p-5 space-y-4 border-2 border-[#7C3AED]">
        <h2 className="font-extrabold text-base flex items-center gap-2 text-[#7C3AED]">
          <Plus className="w-5 h-5" /> Upload Your Music Track to FISM
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <input
            type="text"
            value={songTitle}
            onChange={(e) => setSongTitle(e.target.value)}
            placeholder="Music / Song Title..."
            className="px-3.5 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm font-bold"
          />
          <input
            type="text"
            value={songArtist}
            onChange={(e) => setSongArtist(e.target.value)}
            placeholder="Artist / Creator Name..."
            className="px-3.5 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm"
          />
          <input
            type="text"
            value={songGenre}
            onChange={(e) => setSongGenre(e.target.value)}
            placeholder="Genre (Phonk, Rap, Trap, Instrumental)..."
            className="px-3.5 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm"
          />
        </div>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <label className="px-3.5 py-2 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold cursor-pointer flex items-center gap-1.5">
              <Music className="w-4 h-4" /> Select Audio File (.mp3 / .wav)
              <input
                type="file"
                accept="audio/*,video/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    setSongAudioUrl(URL.createObjectURL(file));
                    if (!songTitle.trim()) {
                      setSongTitle(file.name.replace(/\.[^/.]+$/, ''));
                    }
                  }
                }}
              />
            </label>
            <label className="px-3.5 py-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold cursor-pointer flex items-center gap-1.5 border border-[#D8E1F0] dark:border-slate-700">
              <ImageIcon className="w-4 h-4 text-[#FF5722]" /> Select Cover Art
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) setSongCoverUrl(URL.createObjectURL(file));
                }}
              />
            </label>
          </div>
          <button
            type="submit"
            className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold"
          >
            🚀 Publish Music Track
          </button>
        </div>
      </form>

      {/* All Music Tracks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {musicTracks.map((trk) => (
          <div
            key={trk.id}
            className="fism-card p-4 flex items-center justify-between gap-3 hover:border-[#FF5722] transition-all"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <img
                src={trk.coverUrl}
                alt={trk.title}
                className="w-16 h-16 rounded-2xl object-cover ring-2 ring-[#FF5722] shrink-0"
              />
              <div className="min-w-0">
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-[#FF5722]/15 text-[#FF5722]">
                  {trk.genre}
                </span>
                <h3 className="font-extrabold text-sm sm:text-base truncate mt-1">{trk.title}</h3>
                <p className="text-xs text-[#52607A] truncate">
                  By @{trk.uploaderUsername} • {trk.usesCount.toLocaleString()} Shorts using this
                  sound
                </p>
                {trk.audioUrl && (
                  <audio src={trk.audioUrl} controls className="h-7 w-full mt-1.5" />
                )}
              </div>
            </div>

            <button
              onClick={() => onUseMusicInShort(trk)}
              className="fism-btn-primary px-3.5 py-2 rounded-xl text-xs font-extrabold shrink-0 flex items-center gap-1.5"
            >
              <Music className="w-3.5 h-3.5" /> Use Sound
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
