import React, { useEffect, useRef, useState } from 'react';
import {
  Award,
  Check,
  Coins,
  Copy,
  Crown,
  Gift,
  Image as ImageIcon,
  KeyRound,
  Lock,
  Plus,
  ShieldCheck,
  Sparkles,
  Trophy,
  Unlock,
  Wallet,
  X,
} from 'lucide-react';
import {
  FismClaimedGiftReceipt,
  FismCoinWallet,
  FismGiftDropConfig,
  FREE_PREMIUM_COIN_COST,
  GENERATED_ASSETS,
  PREMIUM_COIN_PACK_BONUS,
} from '../types';

interface FismCoinWalletAndLeaderboardProps {
  currentUserId: string;
  currentUsername: string;
  currentDisplayName: string;
  myWallet: FismCoinWallet;
  leaderboard: FismCoinWallet[];
  claimedReceipts: FismClaimedGiftReceipt[];
  activeGiftDrops: FismGiftDropConfig[];
  userHasBoughtPremium: boolean;
  onTopUpCoins: (amount: number, packLabel: string) => Promise<void> | void;
  onRedeemFreePremiumWithCoins: () => Promise<void> | void;
  onOpenFuelUpPremium: () => void;
  onOpenCreateVideoWithGiftDrop: () => void;
  onClaimGiftDrop: (drop: FismGiftDropConfig) => Promise<FismClaimedGiftReceipt | null> | void;
  onTriggerToast: (msg: string) => void;
}

export const FismCoinWalletAndLeaderboard: React.FC<FismCoinWalletAndLeaderboardProps> = ({
  currentUserId,
  myWallet,
  leaderboard,
  claimedReceipts,
  activeGiftDrops,
  userHasBoughtPremium,
  onTopUpCoins,
  onRedeemFreePremiumWithCoins,
  onOpenFuelUpPremium,
  onOpenCreateVideoWithGiftDrop,
  onClaimGiftDrop,
  onTriggerToast,
}) => {
  const [subTab, setSubTab] = useState<'leaderboard' | 'wallet' | 'vault'>('leaderboard');
  const [busyAction, setBusyAction] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string>('');

  const progressPct = Math.min(
    100,
    Math.round((myWallet.coinBalance / FREE_PREMIUM_COIN_COST) * 100),
  );
  const coinsNeeded = Math.max(0, FREE_PREMIUM_COIN_COST - myWallet.coinBalance);
  const canRedeemFreePremium = myWallet.coinBalance >= FREE_PREMIUM_COIN_COST;

  const myRankIdx = leaderboard.findIndex((w) => w.uid === currentUserId);
  const myRankDisplay = myRankIdx >= 0 ? `#${myRankIdx + 1}` : 'Unranked';

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopiedId(id);
    onTriggerToast('Copied reward value to clipboard!');
    setTimeout(() => setCopiedId(''), 1800);
  };

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className="rounded-3xl bg-[#101626] text-white p-5 sm:p-6 border border-[#EAB308]/35 shadow-xl relative overflow-hidden">
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-[#FF5722]/20 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAB308]/20 text-[#FACC15] text-[11px] font-extrabold border border-[#EAB308]/40">
              <Coins className="w-3.5 h-3.5" /> FISM Creator Coin Economy &amp; Video Gift Drops
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              Coin Wallet, Gift Drop Vault &amp; Global Leaderboard
            </h2>
            <p className="text-xs sm:text-sm text-white/75 max-w-2xl">
              Buy 1-Month Premium to receive{' '}
              <strong className="text-[#FACC15]">
                +{PREMIUM_COIN_PACK_BONUS.toLocaleString()} Wallet Coins
              </strong>{' '}
              instantly, drop Coins, Secret Text, Photos &amp; Redeem Codes inside your videos, or
              reach <strong className="text-white">100,000 (1 Lakh) Coins</strong> to unlock 1 Month
              of Free Premium!
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white/10 border border-white/15 rounded-2xl p-3.5 shrink-0">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FACC15] to-[#EA580C] text-[#0B0E17] flex items-center justify-center shadow-lg">
              <Wallet className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[11px] text-white/70 font-bold uppercase tracking-wide">
                Your Coin Balance • Rank {myRankDisplay}
              </div>
              <div className="text-2xl font-black text-[#FACC15] tabular-nums">
                {myWallet.coinBalance.toLocaleString()} Coins
              </div>
              <div className="text-[11px] text-white/75 tabular-nums">
                Earned: {myWallet.totalEarnedCoins.toLocaleString()} • Dropped:{' '}
                {myWallet.totalDroppedCoins.toLocaleString()}
              </div>
            </div>
          </div>
        </div>

        {/* 100,000 Coins -> 1 Month Free Premium Progress */}
        <div className="relative z-10 mt-5 p-4 rounded-2xl bg-black/40 border border-white/15 space-y-2.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-[#FACC15] shrink-0" />
              <div>
                <div className="text-xs sm:text-sm font-extrabold text-white">
                  100,000 (1 Lakh) Coins Free Premium Milestone
                </div>
                <div className="text-[11px] text-white/70 tabular-nums">
                  {canRedeemFreePremium
                    ? 'Unlocked! Redeem 100,000 Coins for 1 Month of Full Premium Access.'
                    : `${myWallet.coinBalance.toLocaleString()} / ${FREE_PREMIUM_COIN_COST.toLocaleString()} Coins (${coinsNeeded.toLocaleString()} more needed)`}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={!canRedeemFreePremium || busyAction === 'redeem'}
                onClick={async () => {
                  setBusyAction('redeem');
                  try {
                    await onRedeemFreePremiumWithCoins();
                  } finally {
                    setBusyAction('');
                  }
                }}
                className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all shrink-0 flex items-center gap-1.5 ${
                  canRedeemFreePremium
                    ? 'bg-gradient-to-r from-[#FACC15] to-[#FF5722] text-[#0B0E17] shadow-lg hover:brightness-105'
                    : 'bg-white/10 text-white/50 cursor-not-allowed'
                }`}
              >
                {canRedeemFreePremium ? (
                  <Unlock className="w-3.5 h-3.5" />
                ) : (
                  <Lock className="w-3.5 h-3.5" />
                )}
                {busyAction === 'redeem' ? 'Redeeming...' : 'Redeem 1-Month Free Premium'}
              </button>
              <button
                type="button"
                onClick={onOpenCreateVideoWithGiftDrop}
                className="px-3.5 py-2 rounded-xl bg-[#FF5722] hover:bg-[#EA4312] text-white text-xs font-extrabold flex items-center gap-1.5 shrink-0"
              >
                <Gift className="w-3.5 h-3.5" /> Create Gift Drop Video
              </button>
            </div>
          </div>

          <div className="w-full h-2.5 rounded-full bg-white/15 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#FACC15] via-[#FF8F00] to-[#FF5722] transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          {
            id: 'leaderboard' as const,
            label: `Global Coin Leaderboard (${leaderboard.length})`,
            icon: <Trophy className="w-4 h-4" />,
          },
          {
            id: 'wallet' as const,
            label: '10,000-Coin Premium Pack & Top-Up',
            icon: <Plus className="w-4 h-4" />,
          },
          {
            id: 'vault' as const,
            label: `Claimed Gift Drops (${claimedReceipts.length})`,
            icon: <Gift className="w-4 h-4" />,
          },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setSubTab(tab.id)}
            className={`px-4 py-2.5 rounded-2xl text-xs font-extrabold flex items-center gap-2 shrink-0 transition-all border ${
              subTab === tab.id
                ? 'bg-[#FF5722] text-white border-[#FF5722] shadow-md'
                : 'bg-white text-[#1A1A1A] border-[#E4E7EF] hover:border-[#FF5722]/40'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: GLOBAL COIN LEADERBOARD */}
      {subTab === 'leaderboard' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 bg-white rounded-3xl border border-[#E4E7EF] shadow-sm overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-[#EEF1F6] flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <Trophy className="w-5 h-5 text-[#EAB308]" />
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-[#1A1A1A]">
                    Global Coin Leaderboard
                  </h3>
                  <p className="text-[11px] text-[#52607A]">
                    Live ranking by total FISM Wallet Coins — top creators unlock Free Monthly
                    Premium at 100,000 Coins.
                  </p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-[#FEF9C3] text-[#854D0E] text-[11px] font-extrabold border border-[#FDE047]">
                Live Sync
              </span>
            </div>

            <div className="divide-y divide-[#EEF1F6]">
              {leaderboard.map((entry, idx) => {
                const isMe = entry.uid === currentUserId;
                const rank = idx + 1;
                const reaches100k = entry.coinBalance >= FREE_PREMIUM_COIN_COST;
                return (
                  <div
                    key={entry.uid}
                    className={`px-4 sm:px-5 py-3.5 flex items-center justify-between gap-3 ${
                      isMe ? 'bg-[#FFF5EE]' : 'hover:bg-[#F8FAFD]'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-8 h-8 rounded-xl font-black text-xs flex items-center justify-center shrink-0 tabular-nums ${
                          rank === 1
                            ? 'bg-[#FACC15] text-[#0B0E17] shadow-sm'
                            : rank === 2
                              ? 'bg-[#E2E8F0] text-[#0F172A]'
                              : rank === 3
                                ? 'bg-[#FDBA74] text-[#431407]'
                                : 'bg-[#F1F5F9] text-[#475569]'
                        }`}
                      >
                        #{rank}
                      </div>
                      <img
                        src={entry.avatarUrl || GENERATED_ASSETS.avatar1}
                        alt={entry.displayName}
                        className="w-10 h-10 rounded-full object-cover border border-[#E2E8F0] shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-extrabold text-sm text-[#1A1A1A] truncate">
                            {entry.displayName}
                          </span>
                          {isMe && (
                            <span className="px-2 py-0.5 rounded-full bg-[#FF5722] text-white text-[10px] font-extrabold">
                              YOU
                            </span>
                          )}
                          {entry.premiumExpiresAt && (
                            <Crown className="w-3.5 h-3.5 text-[#EAB308] shrink-0" />
                          )}
                        </div>
                        <div className="text-xs text-[#52607A] truncate">
                          @{entry.username} • Dropped:{' '}
                          <span className="tabular-nums">
                            {entry.totalDroppedCoins.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="font-black text-sm sm:text-base text-[#D97706] tabular-nums flex items-center justify-end gap-1">
                        <Coins className="w-4 h-4 text-[#EAB308]" />
                        {entry.coinBalance.toLocaleString()}
                      </div>
                      <div className="text-[10px] font-bold text-[#64748B]">
                        {reaches100k ? '✓ 100k Free Premium Ready' : 'Coins in Wallet'}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Live Video Gift Drops Radar */}
          <div className="bg-white rounded-3xl border border-[#E4E7EF] shadow-sm p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-sm text-[#1A1A1A] flex items-center gap-2">
                <Gift className="w-4 h-4 text-[#FF5722]" /> Live Gift Drops on Videos
              </h3>
              <span className="text-[11px] font-bold text-[#64748B] tabular-nums">
                {activeGiftDrops.filter((d) => d.status === 'active').length} Active
              </span>
            </div>

            <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
              {activeGiftDrops.map((drop) => {
                const remaining = Math.max(0, drop.winnerLimit - drop.claimedCount);
                const alreadyClaimed = drop.claimedByUids.includes(currentUserId);
                const exhausted = drop.status === 'exhausted' || remaining <= 0;
                return (
                  <div
                    key={drop.id}
                    className={`p-3 rounded-2xl border space-y-2 ${
                      exhausted
                        ? 'bg-[#F8FAFC] border-[#E2E8F0] opacity-80'
                        : 'bg-gradient-to-br from-[#FFF7ED] to-white border-[#FDBA74]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="text-xs font-extrabold text-[#1A1A1A] truncate">
                          {drop.rewardTitle}
                        </div>
                        <div className="text-[11px] text-[#52607A]">
                          By @{drop.creatorUsername} • {drop.rewardType.replace('_', ' ').toUpperCase()}
                        </div>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold tabular-nums shrink-0 ${
                          exhausted
                            ? 'bg-[#E2E8F0] text-[#475569]'
                            : 'bg-[#FF5722] text-white'
                        }`}
                      >
                        {exhausted
                          ? 'Expired'
                          : `${remaining}/${drop.winnerLimit} Left`}
                      </span>
                    </div>

                    {drop.coinsPerWinner > 0 && (
                      <div className="text-xs font-black text-[#D97706] tabular-nums">
                        +{drop.coinsPerWinner.toLocaleString()} Coins per Winner
                      </div>
                    )}

                    <button
                      type="button"
                      disabled={exhausted || alreadyClaimed || busyAction === drop.id}
                      onClick={async () => {
                        setBusyAction(drop.id);
                        try {
                          await onClaimGiftDrop(drop);
                        } finally {
                          setBusyAction('');
                        }
                      }}
                      className={`w-full py-2 rounded-xl text-xs font-extrabold transition-all ${
                        alreadyClaimed
                          ? 'bg-[#16A34A]/15 text-[#15803D] cursor-default'
                          : exhausted
                            ? 'bg-[#E2E8F0] text-[#64748B] cursor-not-allowed'
                            : 'bg-[#FF5722] hover:bg-[#E64A19] text-white shadow'
                      }`}
                    >
                      {alreadyClaimed
                        ? '✓ Claimed — View in Vault'
                        : exhausted
                          ? 'Gift Claimed / Expired'
                          : busyAction === drop.id
                            ? 'Claiming...'
                            : '🎁 Claim First-Come-First-Serve'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: 10,000 COIN PREMIUM PACK & CREATOR WALLET TOP-UP */}
      {subTab === 'wallet' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* 1-Month Premium 10,000 Coin Pack */}
          <div className="rounded-3xl bg-gradient-to-br from-[#161E31] to-[#0B0F1A] text-white p-6 border border-[#EAB308]/40 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-full bg-[#EAB308] text-[#0B0E17] text-[11px] font-black">
                BEST CREATOR VALUE
              </span>
              {userHasBoughtPremium && (
                <span className="px-2.5 py-1 rounded-full bg-[#16A34A]/20 text-[#4ADE80] text-[11px] font-extrabold border border-[#16A34A]/40">
                  ✓ Premium Active
                </span>
              )}
            </div>
            <div>
              <h3 className="text-xl font-black flex items-center gap-2">
                <Crown className="w-6 h-6 text-[#FACC15]" /> 1-Month Premium + 10,000 Coin Pack
              </h3>
              <p className="text-xs text-white/75 mt-1">
                Whenever your 1-Month Premium subscription is purchased and approved via Fuel Up,
                your wallet automatically receives{' '}
                <strong className="text-[#FACC15]">10,000 Coins</strong> to host Gift Drops in your
                videos!
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-between">
              <div>
                <div className="text-xs text-white/70">Included Coin Bonus</div>
                <div className="text-2xl font-black text-[#FACC15] tabular-nums">
                  +{PREMIUM_COIN_PACK_BONUS.toLocaleString()} Coins
                </div>
              </div>
              <button
                type="button"
                onClick={onOpenFuelUpPremium}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FACC15] to-[#FF5722] text-[#0B0E17] text-xs font-black shadow-lg"
              >
                {userHasBoughtPremium ? 'Extend / Fuel Up' : 'Buy 1-Month Premium →'}
              </button>
            </div>
          </div>

          {/* Instant Creator Wallet Top-Up Packs */}
          <div className="rounded-3xl bg-white p-6 border border-[#E4E7EF] shadow-sm space-y-4">
            <div>
              <h3 className="text-lg font-extrabold text-[#1A1A1A] flex items-center gap-2">
                <Wallet className="w-5 h-5 text-[#FF5722]" /> Instant Creator Coin Wallet Top-Up
              </h3>
              <p className="text-xs text-[#52607A] mt-0.5">
                Need extra coins to reward more viewers in your Quick Burst or Main Blast videos?
                Top up instantly below.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { coins: 2_500, label: 'Starter Drop Pack', price: '₹49 / $0.59' },
                { coins: 10_000, label: 'Creator 10K Pack', price: '₹149 / $1.79' },
                { coins: 25_000, label: 'Viral Streamer 25K', price: '₹349 / $4.19' },
                { coins: 100_000, label: 'Legend 1 Lakh Pack', price: '₹1,199 / $14.49' },
              ].map((pack) => (
                <button
                  key={pack.coins}
                  type="button"
                  disabled={busyAction === `topup_${pack.coins}`}
                  onClick={async () => {
                    setBusyAction(`topup_${pack.coins}`);
                    try {
                      await onTopUpCoins(pack.coins, pack.label);
                    } finally {
                      setBusyAction('');
                    }
                  }}
                  className="p-3.5 rounded-2xl border border-[#E2E8F0] hover:border-[#FF5722] bg-[#F8FAFC] hover:bg-[#FFF5EE] text-left transition-all space-y-1"
                >
                  <div className="text-sm font-black text-[#D97706] tabular-nums">
                    +{pack.coins.toLocaleString()} Coins
                  </div>
                  <div className="text-xs font-bold text-[#1A1A1A]">{pack.label}</div>
                  <div className="text-[11px] font-extrabold text-[#FF5722]">
                    {busyAction === `topup_${pack.coins}` ? 'Adding...' : `Top Up (${pack.price})`}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CLAIMED GIFT DROPS VAULT */}
      {subTab === 'vault' && (
        <div className="bg-white rounded-3xl border border-[#E4E7EF] shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-base text-[#1A1A1A] flex items-center gap-2">
                <Award className="w-5 h-5 text-[#16A34A]" /> Your Claimed Gift Drops Vault
              </h3>
              <p className="text-xs text-[#52607A]">
                All Coins, Secret Texts, Exclusive Photos &amp; Redeem Codes you captured before
                winner slots filled up.
              </p>
            </div>
          </div>

          {claimedReceipts.length === 0 ? (
            <div className="py-10 text-center text-sm text-[#64748B]">
              No claimed gifts yet! Watch videos in Main Blast or Quick Burst and tap the floating{' '}
              <strong>🎁 Gift Drop</strong> box fast when it appears.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {claimedReceipts.map((rcpt) => (
                <div
                  key={rcpt.id}
                  className="p-4 rounded-2xl border border-[#E2E8F0] bg-[#F8FAFC] space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-sm font-extrabold text-[#1A1A1A]">{rcpt.rewardTitle}</div>
                      <div className="text-[11px] text-[#52607A]">
                        From @{rcpt.creatorUsername} • Claimed at {rcpt.claimedAt}
                      </div>
                    </div>
                    {rcpt.coinsAwarded > 0 && (
                      <span className="px-2.5 py-1 rounded-full bg-[#FEF9C3] text-[#854D0E] text-[11px] font-black tabular-nums">
                        +{rcpt.coinsAwarded.toLocaleString()} Coins
                      </span>
                    )}
                  </div>

                  {rcpt.rewardType === 'photo' && rcpt.rewardValue ? (
                    <img
                      src={rcpt.rewardValue}
                      alt={rcpt.rewardTitle}
                      className="w-full h-40 object-cover rounded-xl border border-[#E2E8F0]"
                    />
                  ) : (
                    <div className="p-3 rounded-xl bg-white border border-[#E2E8F0] flex items-center justify-between gap-2">
                      <span className="text-xs font-mono font-bold text-[#0F172A] break-all">
                        {rcpt.rewardValue}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopy(rcpt.id, rcpt.rewardValue)}
                        className="px-2.5 py-1 rounded-lg bg-[#FF5722]/10 text-[#FF5722] text-[11px] font-extrabold shrink-0 flex items-center gap-1"
                      >
                        {copiedId === rcpt.id ? (
                          <Check className="w-3.5 h-3.5" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        {copiedId === rcpt.id ? 'Copied' : 'Copy'}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

interface FismVideoGiftDropOverlayProps {
  drop: FismGiftDropConfig;
  currentUserId: string;
  compact?: boolean;
  watchCompleted?: boolean;
  watchProgressPct?: number;
  onClaimDrop: (drop: FismGiftDropConfig) => Promise<FismClaimedGiftReceipt | null>;
}

export const FismVideoGiftDropOverlay: React.FC<FismVideoGiftDropOverlayProps> = ({
  drop,
  currentUserId,
  compact = false,
  watchCompleted = true,
  watchProgressPct = 100,
  onClaimDrop,
}) => {
  const [claiming, setClaiming] = useState(false);
  const [revealedReceipt, setRevealedReceipt] = useState<FismClaimedGiftReceipt | null>(null);
  const [lockWarningOpen, setLockWarningOpen] = useState(false);
  const [unlockPopupOpen, setUnlockPopupOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const remaining = Math.max(0, drop.winnerLimit - drop.claimedCount);
  const alreadyClaimed = drop.claimedByUids.includes(currentUserId);
  const exhausted = drop.status === 'exhausted' || remaining <= 0;
  const isLocked = !watchCompleted && !alreadyClaimed && !exhausted;

  const prevWatchCompletedRef = useRef<boolean>(watchCompleted);
  useEffect(() => {
    if (!prevWatchCompletedRef.current && watchCompleted && !alreadyClaimed && !exhausted) {
      setLockWarningOpen(false);
      setUnlockPopupOpen(true);
    }
    prevWatchCompletedRef.current = watchCompleted;
  }, [watchCompleted, alreadyClaimed, exhausted]);

  const handleClaim = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isLocked) {
      setLockWarningOpen(true);
      return;
    }
    if (claiming || (exhausted && !alreadyClaimed)) return;
    setClaiming(true);
    try {
      const receipt = await onClaimDrop(drop);
      if (receipt) {
        setUnlockPopupOpen(false);
        setRevealedReceipt(receipt);
      }
    } finally {
      setClaiming(false);
    }
  };

  const safePct = Math.max(0, Math.min(100, Math.round(watchProgressPct || 0)));

  return (
    <>
      <button
        type="button"
        onClick={handleClaim}
        disabled={(exhausted && !alreadyClaimed) || claiming}
        className={`group flex items-center gap-2 rounded-2xl border backdrop-blur-md transition-all shadow-xl ${
          compact ? 'px-2.5 py-1.5 text-[11px]' : 'px-3.5 py-2 text-xs'
        } ${
          alreadyClaimed
            ? 'bg-[#16A34A]/90 border-[#4ADE80]/60 text-white'
            : exhausted
              ? 'bg-black/75 border-white/20 text-white/70 cursor-not-allowed'
              : isLocked
                ? 'bg-black/80 border-amber-400/60 text-amber-100 hover:bg-black/90'
                : 'bg-gradient-to-r from-[#FF5722]/95 via-[#F59E0B]/95 to-[#EAB308]/95 border-white/50 text-white hover:scale-105'
        }`}
      >
        <div
          className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 ${
            isLocked ? 'bg-amber-500/25 text-amber-300' : 'bg-white/20'
          }`}
        >
          {alreadyClaimed ? (
            <Check className="w-4 h-4" />
          ) : isLocked ? (
            <Lock className="w-4 h-4" />
          ) : drop.rewardType === 'photo' ? (
            <ImageIcon className="w-4 h-4" />
          ) : drop.rewardType === 'redeem_code' ? (
            <KeyRound className="w-4 h-4" />
          ) : (
            <Gift className="w-4 h-4" />
          )}
        </div>
        <div className="text-left leading-tight">
          <div className="font-black tracking-tight flex items-center gap-1">
            {alreadyClaimed
              ? '✓ Gift Claimed'
              : exhausted
                ? 'Gift Claimed / Expired'
                : isLocked
                  ? `🔒 Gift Locked (${safePct}%)`
                  : claiming
                    ? 'Claiming SP Coins...'
                    : '🎁 Gift Unlocked! Claim'}
          </div>
          <div className="text-[10px] font-bold opacity-95 tabular-nums">
            {isLocked
              ? 'Watch 100% video to unlock Gift'
              : exhausted
                ? `0/${drop.winnerLimit} Slots Left`
                : `${remaining}/${drop.winnerLimit} Left${
                    drop.coinsPerWinner > 0 ? ` • +${drop.coinsPerWinner} SP Coins` : ''
                  }`}
          </div>
        </div>
      </button>

      {/* Locked Pop-up when User Tries to Click Before 100% Video Completion */}
      {lockWarningOpen && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            setLockWarningOpen(false);
          }}
          className="fixed inset-0 z-[105] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm rounded-3xl bg-[#0F172A] text-white border-2 border-[#F59E0B] p-6 shadow-2xl space-y-4 text-center"
          >
            <div className="w-14 h-14 mx-auto rounded-2xl bg-[#F59E0B]/20 border border-[#F59E0B]/50 flex items-center justify-center text-[#FBBF24]">
              <Lock className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-black leading-snug text-[#FDE68A]">
              🔒 कृपया पहले पूरा वीडियो देखें, तभी गिफ्ट अनलॉक होगा!
            </h3>
            <p className="text-xs text-slate-300">
              Watch this video all the way to <strong>100%</strong> to unlock{' '}
              <strong>{drop.rewardTitle}</strong>
              {drop.coinsPerWinner > 0 ? ` (+${drop.coinsPerWinner} SP Coins)` : ''}.
            </p>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-extrabold text-amber-300 tabular-nums">
                <span>Video Watched</span>
                <span>{safePct}% / 100%</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-white/15 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#FF5722] to-[#FACC15] transition-all duration-300"
                  style={{ width: `${safePct}%` }}
                />
              </div>
            </div>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setLockWarningOpen(false);
              }}
              className="min-h-[44px] w-full py-2.5 rounded-xl bg-gradient-to-r from-[#FF5722] to-[#F59E0B] text-white text-xs font-black shadow-lg"
            >
              Keep Watching Video →
            </button>
          </div>
        </div>
      )}

      {/* Celebratory Animated Pop-up on 100% Video Completion */}
      {unlockPopupOpen && !alreadyClaimed && !exhausted && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            setUnlockPopupOpen(false);
          }}
          className="fixed inset-0 z-[105] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-3xl bg-gradient-to-br from-[#111827] via-[#1E1B4B] to-[#3B0764] text-white border-2 border-[#4ADE80] p-6 shadow-[0_0_50px_rgba(74,222,128,0.45)] space-y-4 text-center animate-[bounce_0.45s_ease-out_1]"
          >
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-[#16A34A] to-[#4ADE80] text-[#052E16] flex items-center justify-center shadow-xl">
              <Unlock className="w-8 h-8" />
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#4ADE80]/20 text-[#4ADE80] border border-[#4ADE80]/40 text-xs font-black">
              <Sparkles className="w-3.5 h-3.5" /> 100% VIDEO COMPLETED
            </div>
            <h3 className="text-2xl font-black tracking-tight text-white">
              🎁 Gift Unlocked!
            </h3>
            <p className="text-xs sm:text-sm text-slate-200">
              You watched the complete video! Claim{' '}
              <strong>{drop.rewardTitle}</strong>
              {drop.coinsPerWinner > 0
                ? ` and receive +${drop.coinsPerWinner.toLocaleString()} SP Coins right now.`
                : ' right now.'}
            </p>
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                disabled={claiming}
                onClick={handleClaim}
                className="min-h-[44px] flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-[#FF5722] via-[#F59E0B] to-[#16A34A] text-white text-xs sm:text-sm font-black shadow-xl hover:scale-[1.02] transition-transform flex items-center justify-center gap-2"
              >
                <Coins className="w-4 h-4" />
                {claiming
                  ? 'Claiming...'
                  : drop.coinsPerWinner > 0
                    ? `Claim +${drop.coinsPerWinner} SP Coins Now!`
                    : 'Claim Reward Now!'}
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setUnlockPopupOpen(false);
                }}
                className="min-h-[44px] px-3.5 rounded-xl bg-white/15 hover:bg-white/25 text-xs font-bold"
              >
                Later
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reward Reveal Modal */}
      {revealedReceipt && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            setRevealedReceipt(null);
          }}
          className="fixed inset-0 z-[106] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-3xl bg-[#111827] text-white border border-[#FACC15]/50 p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#FACC15] font-black text-base">
                <Sparkles className="w-5 h-5" /> Reward Claimed Successfully!
              </div>
              <button
                type="button"
                onClick={() => setRevealedReceipt(null)}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2">
              <div className="text-sm font-extrabold">{revealedReceipt.rewardTitle}</div>
              <div className="text-xs text-white/75">
                Dropped by @{revealedReceipt.creatorUsername} • {revealedReceipt.claimedAt}
              </div>

              {revealedReceipt.coinsAwarded > 0 && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FACC15] text-[#0B0E17] text-xs font-black tabular-nums">
                  <Coins className="w-3.5 h-3.5" /> +
                  {revealedReceipt.coinsAwarded.toLocaleString()} SP &amp; Wallet Coins Credited!
                </div>
              )}

              {revealedReceipt.rewardType === 'photo' && revealedReceipt.rewardValue ? (
                <img
                  src={revealedReceipt.rewardValue}
                  alt={revealedReceipt.rewardTitle}
                  className="w-full max-h-56 object-cover rounded-xl border border-white/20 mt-2"
                />
              ) : (
                <div className="mt-2 p-3 rounded-xl bg-black/60 border border-[#FACC15]/40 flex items-center justify-between gap-2">
                  <span className="font-mono text-xs sm:text-sm font-bold text-[#FACC15] break-all">
                    {revealedReceipt.rewardValue}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(revealedReceipt.rewardValue).catch(() => {});
                      setCopied(true);
                      setTimeout(() => setCopied(false), 1800);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-[#FF5722] text-white text-xs font-extrabold shrink-0 flex items-center gap-1"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied!' : 'Copy'}
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs text-[#4ADE80] font-bold">
              <ShieldCheck className="w-4 h-4 shrink-0" /> Saved automatically to your Claimed Gift
              Drops Vault.
            </div>
          </div>
        </div>
      )}
    </>
  );
};
