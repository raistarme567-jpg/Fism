import React, { useState } from 'react';
import {
  ShoppingBag,
  Sparkles,
  Megaphone,
  Link2,
  CheckCircle2,
  Lock,
  Plus,
  Trash2,
  Pause,
  Play,
  TrendingUp,
  Store,
  Bot,
  Film,
  Zap,
  ExternalLink,
} from 'lucide-react';
import {
  FismAffiliateStoreConfig,
  FismSmartAdItem,
  FismSmartAdPlacement,
  FismUserBehaviorProfile,
  GENERATED_ASSETS,
} from '../types';
import { getTopUserInterestCategories } from '../utils/flameAlgorithm';

interface FismAdAndAffiliateStudioProps {
  currentUserId: string;
  currentUsername: string;
  currentDisplayName: string;
  currentAvatar: string;
  subscriberCount: number; // Mapped from profile Sparks / Subscribers
  storeConfig: FismAffiliateStoreConfig;
  onSaveStoreConfig: (cfg: FismAffiliateStoreConfig) => Promise<void> | void;
  smartAds: FismSmartAdItem[];
  onCreateCreatorAd: (ad: FismSmartAdItem) => Promise<void> | void;
  onToggleAdActive: (adId: string) => void;
  onDeleteAd: (adId: string) => void;
  behaviorProfile: FismUserBehaviorProfile;
  onTriggerToast: (msg: string) => void;
}

const MONETIZATION_THRESHOLD = 5000;

export const FismAdAndAffiliateStudio: React.FC<FismAdAndAffiliateStudioProps> = ({
  currentUserId,
  currentUsername,
  currentDisplayName,
  currentAvatar,
  subscriberCount,
  storeConfig,
  onSaveStoreConfig,
  smartAds,
  onCreateCreatorAd,
  onToggleAdActive,
  onDeleteAd,
  behaviorProfile,
  onTriggerToast,
}) => {
  const isMonetizationUnlocked = subscriberCount >= MONETIZATION_THRESHOLD;
  const progressPct = Math.min(100, Math.round((subscriberCount / MONETIZATION_THRESHOLD) * 100));

  const [amazonUrl, setAmazonUrl] = useState(storeConfig.amazonAffiliateUrl || '');
  const [amazonTag, setAmazonTag] = useState(storeConfig.amazonTag || '');
  const [flipkartUrl, setFlipkartUrl] = useState(storeConfig.flipkartAffiliateUrl || '');
  const [flipkartId, setFlipkartId] = useState(storeConfig.flipkartId || '');
  const [meeshoUrl, setMeeshoUrl] = useState(storeConfig.meeshoAffiliateUrl || '');
  const [meeshoCode, setMeeshoCode] = useState(storeConfig.meeshoCode || '');
  const [savingStore, setSavingStore] = useState(false);

  const [adTitle, setAdTitle] = useState('');
  const [adDesc, setAdDesc] = useState('');
  const [adPlacement, setAdPlacement] = useState<FismSmartAdPlacement>('quickBurst');
  const [adStorePlatform, setAdStorePlatform] =
    useState<FismSmartAdItem['storePlatform']>('Amazon');
  const [adProductUrl, setAdProductUrl] = useState('');
  const [adCtaLabel, setAdCtaLabel] = useState('Shop Now →');
  const [adCategoryTags, setAdCategoryTags] = useState('gaming, tech, esports');
  const [adMediaUrl, setAdMediaUrl] = useState<string>(GENERATED_ASSETS.shopHeadset);
  const [adIsVideo, setAdIsVideo] = useState<boolean>(false);
  const [launchingAd, setLaunchingAd] = useState<boolean>(false);

  const topInterests = getTopUserInterestCategories(behaviorProfile, 4);
  const myCreatorAds = smartAds.filter(
    (ad) => ad.source === 'creator' && (ad.creatorId === currentUserId || ad.creatorUsername === currentUsername),
  );

  const handleSaveStores = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingStore(true);
    try {
      await onSaveStoreConfig({
        userId: currentUserId,
        amazonAffiliateUrl: amazonUrl.trim(),
        amazonTag: amazonTag.trim(),
        flipkartAffiliateUrl: flipkartUrl.trim(),
        flipkartId: flipkartId.trim(),
        meeshoAffiliateUrl: meeshoUrl.trim(),
        meeshoCode: meeshoCode.trim(),
        updatedAt: new Date().toLocaleTimeString(),
      });
    } finally {
      setSavingStore(false);
    }
  };

  const handleLaunchCreatorAd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isMonetizationUnlocked) {
      onTriggerToast('Reach 5,000 Subscribers / Sparks to unlock Creator Ad monetization.');
      return;
    }
    if (!adTitle.trim()) {
      onTriggerToast('Enter an Ad Title before launching your Creator Ad.');
      return;
    }

    setLaunchingAd(true);
    try {
      const resolvedLink =
        adProductUrl.trim() ||
        (adStorePlatform === 'Amazon'
          ? amazonUrl.trim() || 'https://www.amazon.in'
          : adStorePlatform === 'Flipkart'
            ? flipkartUrl.trim() || 'https://www.flipkart.com'
            : adStorePlatform === 'Meesho'
              ? meeshoUrl.trim() || 'https://www.meesho.com'
              : 'https://fism.shop');

      const newAd: FismSmartAdItem = {
        id: `ad_creator_${Date.now()}`,
        source: 'creator',
        placement: adPlacement,
        title: adTitle.trim(),
        description:
          adDesc.trim() || 'Sponsored Creator Product • Powered by FISM Flame Algorithm.',
        mediaUrl: adMediaUrl || GENERATED_ASSETS.shopHeadset,
        isVideo: adIsVideo,
        productLinkUrl: resolvedLink,
        ctaLabel: adCtaLabel.trim() || 'Shop Now →',
        storePlatform: adStorePlatform,
        categoryTags: adCategoryTags
          .split(',')
          .map((t) => t.trim().toLowerCase())
          .filter(Boolean)
          .slice(0, 10),
        creatorId: currentUserId,
        creatorUsername: currentUsername,
        creatorDisplayName: currentDisplayName,
        creatorAvatar: currentAvatar,
        isActive: true,
        impressions: 1,
        clicks: 0,
        likes: 0,
        createdAt: 'Just now',
      };

      await onCreateCreatorAd(newAd);
      setAdTitle('');
      setAdDesc('');
      setAdProductUrl('');
    } finally {
      setLaunchingAd(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* 1. FLAME ALGORITHM LIVE PERSONALIZATION TELEMETRY */}
      <div className="fism-card p-5 border-2 border-[#7C3AED]/50 bg-gradient-to-br from-[#0F172A] via-[#172033] to-[#1E1B4B] text-white space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl fism-gradient-flame flex items-center justify-center shadow-lg">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base flex items-center gap-2">
                AI Flame Algorithm — Real-Time Interest Graph
              </h3>
              <p className="text-[11px] text-slate-300">
                Tracks watch time, Sparks, game activity &amp; search tags to deliver hyper-personalized
                Main Blast videos, Quick Burst shorts, and matching ads.
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full bg-[#16A34A]/20 border border-[#16A34A] text-[#4ADE80] text-[10px] font-extrabold uppercase">
            ● Live ML Ranking Active
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {topInterests.map((item) => (
            <div
              key={item.category}
              className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1.5"
            >
              <div className="flex items-center justify-between text-xs font-extrabold capitalize">
                <span>#{item.category}</span>
                <span className="text-[#FFB300]">{item.percentage}%</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full rounded-full fism-gradient-flame transition-all duration-500"
                  style={{ width: `${item.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. 5,000+ SUBSCRIBERS CREATOR MONETIZATION & AFFILIATE STUDIO */}
      <div className="fism-card p-5 border-2 border-[#FF5722]/60 space-y-5">
        <div className="flex items-start justify-between flex-wrap gap-3 border-b border-[#D8E1F0] dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl fism-gradient-flame text-white flex items-center justify-center shadow-lg">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-extrabold text-base sm:text-lg">
                  Ad &amp; Affiliate Studio (5,000+ Subscribers)
                </h2>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                    isMonetizationUnlocked
                      ? 'bg-[#16A34A] text-white'
                      : 'bg-amber-500/20 text-amber-600 dark:text-amber-300 border border-amber-500/40'
                  }`}
                >
                  {isMonetizationUnlocked
                    ? `✓ Unlocked (${subscriberCount.toLocaleString()} Subscribers)`
                    : `🔒 ${subscriberCount.toLocaleString()} / 5,000 Subscribers`}
                </span>
              </div>
              <p className="text-xs text-[#52607A] mt-0.5">
                Connect Amazon, Flipkart &amp; Meesho affiliate stores, launch Creator Ads in Main
                Blast &amp; Quick Burst, and activate the Keyword-to-Product Auto-Comment Bot.
              </p>
            </div>
          </div>
        </div>

        {/* Eligibility Progress Gate */}
        {!isMonetizationUnlocked ? (
          <div className="p-4 rounded-2xl bg-[#101426] text-white space-y-3 border border-[#FF5722]/40">
            <div className="flex items-center justify-between text-xs font-extrabold">
              <span className="flex items-center gap-1.5 text-[#FFB300]">
                <Lock className="w-4 h-4" /> Creator Monetization Eligibility Gate
              </span>
              <span>{progressPct}% Complete</span>
            </div>
            <div className="h-2.5 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full fism-gradient-flame rounded-full transition-all duration-500"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <p className="text-xs text-slate-300">
              Cross <strong>5,000 Subscribers (Sparks)</strong> to automatically unlock the{' '}
              <strong>Ad &amp; Affiliate Studio</strong>, Connect Store (Amazon / Flipkart / Meesho),
              and Creator Ad placements.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* A. CONNECT STORE HUB (AMAZON, FLIPKART, MEESHO) */}
            <form
              onSubmit={handleSaveStores}
              className="p-4 rounded-2xl bg-[#F5F7FF] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-4"
            >
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h3 className="font-extrabold text-sm flex items-center gap-2 text-[#151B2B] dark:text-white">
                    <Store className="w-4 h-4 text-[#FF5722]" /> Connect Store Hub — Amazon,
                    Flipkart &amp; Meesho
                  </h3>
                  <p className="text-[11px] text-[#52607A]">
                    Link your external affiliate store IDs so your videos &amp; Auto-Comment Bot
                    push verified checkout links automatically.
                  </p>
                </div>
                <button
                  type="submit"
                  disabled={savingStore}
                  className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {savingStore ? 'Saving...' : 'Save Store Connections'}
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Amazon */}
                <div className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 space-y-2">
                  <div className="text-xs font-extrabold flex items-center justify-between">
                    <span className="text-[#FF9900]">📦 Amazon Associates</span>
                    {amazonUrl && (
                      <span className="text-[10px] text-[#16A34A] font-bold">● Linked</span>
                    )}
                  </div>
                  <input
                    type="text"
                    value={amazonTag}
                    onChange={(e) => setAmazonTag(e.target.value)}
                    placeholder="Affiliate Tag (e.g. fismcreator-21)"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                  />
                  <input
                    type="url"
                    value={amazonUrl}
                    onChange={(e) => setAmazonUrl(e.target.value)}
                    placeholder="https://www.amazon.in/shop/..."
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                  />
                </div>

                {/* Flipkart */}
                <div className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 space-y-2">
                  <div className="text-xs font-extrabold flex items-center justify-between">
                    <span className="text-[#2874F0]">🛒 Flipkart Affiliate</span>
                    {flipkartUrl && (
                      <span className="text-[10px] text-[#16A34A] font-bold">● Linked</span>
                    )}
                  </div>
                  <input
                    type="text"
                    value={flipkartId}
                    onChange={(e) => setFlipkartId(e.target.value)}
                    placeholder="Affiliate ID (e.g. flp_fism99)"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                  />
                  <input
                    type="url"
                    value={flipkartUrl}
                    onChange={(e) => setFlipkartUrl(e.target.value)}
                    placeholder="https://www.flipkart.com/..."
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                  />
                </div>

                {/* Meesho */}
                <div className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 space-y-2">
                  <div className="text-xs font-extrabold flex items-center justify-between">
                    <span className="text-[#F43397]">🛍️ Meesho Creator Store</span>
                    {meeshoUrl && (
                      <span className="text-[10px] text-[#16A34A] font-bold">● Linked</span>
                    )}
                  </div>
                  <input
                    type="text"
                    value={meeshoCode}
                    onChange={(e) => setMeeshoCode(e.target.value)}
                    placeholder="Reseller / Creator Code"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                  />
                  <input
                    type="url"
                    value={meeshoUrl}
                    onChange={(e) => setMeeshoUrl(e.target.value)}
                    placeholder="https://www.meesho.com/..."
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                  />
                </div>
              </div>
            </form>

            {/* B. LAUNCH CREATOR AD (MAIN BLAST MID-ROLL OR QUICK BURST SHORT AD) */}
            <form
              onSubmit={handleLaunchCreatorAd}
              className="p-4 rounded-2xl bg-[#F5F7FF] dark:bg-slate-900 border border-[#7C3AED]/40 space-y-3.5"
            >
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h3 className="font-extrabold text-sm flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#7C3AED]" /> Create &amp; Launch Creator Ad
                </h3>
                <span className="text-[11px] font-bold text-[#7C3AED] flex items-center gap-1">
                  <Bot className="w-3.5 h-3.5" /> Auto-targeted by Flame Algorithm
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  value={adTitle}
                  onChange={(e) => setAdTitle(e.target.value)}
                  placeholder="Creator Ad Title (e.g. Pro Gaming Mouse 40% Off)..."
                  className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                />
                <div className="flex gap-2">
                  <select
                    value={adPlacement}
                    onChange={(e) => setAdPlacement(e.target.value as FismSmartAdPlacement)}
                    aria-label="Ad placement"
                    className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                  >
                    <option value="quickBurst">⚡ Quick Burst Short Ad</option>
                    <option value="longVideo">🎬 Long Video Mid-Roll (15s)</option>
                  </select>
                  <select
                    value={adStorePlatform}
                    onChange={(e) =>
                      setAdStorePlatform(e.target.value as FismSmartAdItem['storePlatform'])
                    }
                    aria-label="Store platform"
                    className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                  >
                    <option value="Amazon">Amazon</option>
                    <option value="Flipkart">Flipkart</option>
                    <option value="Meesho">Meesho</option>
                    <option value="FISM Store">FISM Store</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="url"
                  value={adProductUrl}
                  onChange={(e) => setAdProductUrl(e.target.value)}
                  placeholder="Product Affiliate Link URL..."
                  className="sm:col-span-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                />
                <input
                  type="text"
                  value={adCtaLabel}
                  onChange={(e) => setAdCtaLabel(e.target.value)}
                  placeholder="Button Label (Shop Now)"
                  className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  value={adDesc}
                  onChange={(e) => setAdDesc(e.target.value)}
                  placeholder="Short promotional copy..."
                  className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                />
                <input
                  type="text"
                  value={adCategoryTags}
                  onChange={(e) => setAdCategoryTags(e.target.value)}
                  placeholder="Interest tags: gaming, tech, music..."
                  className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                />
              </div>

              <div className="flex items-center justify-between flex-wrap gap-3">
                <label className="px-3.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold cursor-pointer flex items-center gap-1.5">
                  <Film className="w-4 h-4 text-[#FF5722]" />
                  <span>{adIsVideo ? '✓ Ad Video Selected' : 'Upload Ad Video / Product Photo'}</span>
                  <input
                    type="file"
                    accept="video/*,image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      const url = URL.createObjectURL(file);
                      setAdMediaUrl(url);
                      setAdIsVideo(file.type.startsWith('video/'));
                    }}
                  />
                </label>

                <button
                  type="submit"
                  disabled={launchingAd}
                  className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-4 h-4" />
                  {launchingAd ? 'Publishing Ad...' : 'Launch Creator Ad Live'}
                </button>
              </div>
            </form>

            {/* C. ACTIVE CREATOR ADS PERFORMANCE */}
            <div className="space-y-2.5">
              <div className="text-xs font-extrabold uppercase tracking-wider text-[#52607A]">
                Your Active Creator Ads ({myCreatorAds.length})
              </div>
              {myCreatorAds.length === 0 ? (
                <div className="p-4 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs text-[#52607A]">
                  No personal creator ads launched yet. Create one above to run across Main Blast
                  &amp; Quick Burst!
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {myCreatorAds.map((ad) => (
                    <div
                      key={ad.id}
                      className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="px-2 py-0.5 rounded bg-[#7C3AED] text-white text-[9px] font-black uppercase flex items-center gap-1">
                            {ad.placement === 'quickBurst' ? (
                              <Zap className="w-2.5 h-2.5" />
                            ) : (
                              <Film className="w-2.5 h-2.5" />
                            )}
                            {ad.placement === 'quickBurst' ? 'Quick Burst' : 'Main Blast 15s'}
                          </span>
                          <span className="px-2 py-0.5 rounded bg-amber-500/15 text-amber-600 dark:text-amber-300 text-[9px] font-extrabold">
                            {ad.storePlatform}
                          </span>
                        </div>
                        <div className="font-extrabold text-xs truncate">{ad.title}</div>
                        <div className="text-[11px] text-[#52607A] flex items-center gap-2">
                          <span>👁️ {ad.impressions}</span>
                          <span>🖱️ {ad.clicks} clicks</span>
                          <span>❤️ {ad.likes}</span>
                          {ad.productLinkUrl && (
                            <a
                              href={ad.productLinkUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[#2563EB] inline-flex items-center gap-0.5 hover:underline"
                            >
                              <Link2 className="w-3 h-3" /> Link
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => onToggleAdActive(ad.id)}
                          title={ad.isActive ? 'Pause Ad' : 'Resume Ad'}
                          className={`p-2 rounded-lg text-xs font-bold ${
                            ad.isActive
                              ? 'bg-[#16A34A]/15 text-[#16A34A]'
                              : 'bg-slate-200 dark:bg-slate-800 text-[#52607A]'
                          }`}
                        >
                          {ad.isActive ? (
                            <Pause className="w-3.5 h-3.5" />
                          ) : (
                            <Play className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteAd(ad.id)}
                          title="Delete Ad"
                          className="p-2 rounded-lg bg-red-500/15 text-[#DC2626]"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
