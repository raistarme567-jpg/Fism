import React, { useState, useEffect, useRef } from 'react';
import {
  ShoppingBag,
  Plus,
  MapPin,
  Phone,
  Video,
  Copy,
  Check,
  X,
  Lock,
  Unlock,
  ShieldAlert,
  Crown,
  Ban,
  CheckCircle2,
  Eye,
  Film,
  Image as ImageIcon,
  Mail,
  MessageCircle,
  Sparkles,
  Heart,
  Flame,
  RefreshCw,
  Mic,
  MicOff,
  PhoneOff,
  Navigation,
  Clock,
  Key,
  UserCheck,
  AlertTriangle,
  Gamepad2,
  FolderOpen,
  Upload,
  Play,
  Pause,
  Trophy,
  Bell,
  QrCode,
  Wand2,
  Sliders,
  Camera,
  ShieldCheck,
  Search,
  Users,
  Radio,
  UserPlus,
  HardDriveDownload,
  Download,
  Share2,
  Trash2,
} from 'lucide-react';
import {
  FismScreen,
  FismShoppingProduct,
  FismAdminUserDossier,
  FismGameItem,
  FismSurveyQuestion,
  FismSurveyCampaign,
  FismSurveySubmission,
  FismUpiConfig,
  FismUpiPaymentRequest,
  FismWithdrawalRequest,
  FismArFilterAsset,
  FismCopyrightAssetRecord,
  FismCopyrightViolationRecord,
  FismLiveCreatorPermissionRecord,
  FismAdsterraConfig,
  FismApkReleaseInfo,
  FismBannerOriginalSize,
  FismSavedStudioFilter,
  INITIAL_GAMES,
  INITIAL_PUBLISHED_AR_FILTERS,
  GENERATED_ASSETS,
} from '../types';
import {
  Face3DModelPreset,
  INITIAL_4_3D_FACE_MODELS,
} from './FismOnFireGamingLive';
import { drawArFilterOverlay } from '../utils/arFilterRenderer';
import {
  FismAdminExportBackupModal,
  FismAdminTrackingFoldersBoard,
} from './FismAdminTrackingAndBackupPanel';
import { FismSecurityDefensePanel } from './FismSecurityDefensePanel';
import {
  extractAdsterraBannerFromSnippet,
  extractAdsterraNativeFromSnippet,
} from './FismFlameFeedAds';
import { FismAdminSmartFilterBuilder } from './FismSmartFilterStudio';
import { buildFismShareUrl, shareFismLink } from '../utils/fismDeepLinks';

// ============================================================================
// 1. EMOJI BLAST MINI-GAME MODAL (लाल गेंद और इमोजी ब्लास्ट गेम - 3 Chances)
// ============================================================================
interface EmojiBlastGameProps {
  emoji: string;
  onClose: () => void;
}

interface FlyingEmojiEntity {
  id: number;
  emoji: string;
  x: number; // percentage 0..100
  y: number; // percentage 0..100
  vx: number;
  vy: number;
}

export const FismEmojiBlastGameModal: React.FC<EmojiBlastGameProps> = ({
  emoji,
  onClose,
}) => {
  const [chances, setChances] = useState<number>(3);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(120);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [entities, setEntities] = useState<FlyingEmojiEntity[]>([]);
  const [burstEffects, setBurstEffects] = useState<
    { id: number; x: number; y: number; text: string }[]
  >([]);

  const nextIdRef = useRef(1);
  const chancesRef = useRef(3);
  chancesRef.current = chances;

  const restartGame = () => {
    setChances(3);
    chancesRef.current = 3;
    setScore(0);
    setIsPaused(false);
    setIsGameOver(false);
    setEntities([]);
  };

  useEffect(() => {
    if (isGameOver || isPaused) return;

    // Spawn flying emojis from all 4 sides toward center (50, 50)
    const spawnInterval = setInterval(() => {
      const side = Math.floor(Math.random() * 4);
      let startX = 50;
      let startY = 50;
      if (side === 0) {
        // Left edge
        startX = 2;
        startY = 10 + Math.random() * 80;
      } else if (side === 1) {
        // Right edge
        startX = 96;
        startY = 10 + Math.random() * 80;
      } else if (side === 2) {
        // Top edge
        startX = 10 + Math.random() * 80;
        startY = 4;
      } else {
        // Bottom edge
        startX = 10 + Math.random() * 80;
        startY = 94;
      }

      const dx = 50 - startX;
      const dy = 50 - startY;
      const dist = Math.hypot(dx, dy) || 1;
      const speed = 0.65 + Math.random() * 0.45;

      const newEntity: FlyingEmojiEntity = {
        id: nextIdRef.current++,
        emoji: emoji || '🔥',
        x: startX,
        y: startY,
        vx: (dx / dist) * speed,
        vy: (dy / dist) * speed,
      };

      setEntities((prev) => [...prev, newEntity]);
    }, 850);

    // Physics step
    const moveInterval = setInterval(() => {
      setEntities((prev) => {
        const remaining: FlyingEmojiEntity[] = [];
        let hitsThisTick = 0;

        for (const item of prev) {
          const nx = item.x + item.vx;
          const ny = item.y + item.vy;
          const distToRedBall = Math.hypot(nx - 50, ny - 50);

          // Red ball collision radius ~7%
          if (distToRedBall < 7.5) {
            hitsThisTick += 1;
          } else {
            remaining.push({ ...item, x: nx, y: ny });
          }
        }

        if (hitsThisTick > 0) {
          setChances((c) => {
            const updated = Math.max(0, c - hitsThisTick);
            if (updated <= 0) {
              setIsGameOver(true);
            }
            return updated;
          });
        }

        return remaining;
      });
    }, 35);

    return () => {
      clearInterval(spawnInterval);
      clearInterval(moveInterval);
    };
  }, [emoji, isGameOver, isPaused]);

  const handleBlastEmoji = (entity: FlyingEmojiEntity) => {
    if (isGameOver || isPaused) return;
    setEntities((prev) => prev.filter((e) => e.id !== entity.id));
    setScore((s) => {
      const next = s + 10;
      if (next > highScore) setHighScore(next);
      return next;
    });
    const burstId = Date.now() + Math.random();
    setBurstEffects((prev) => [
      ...prev,
      { id: burstId, x: entity.x, y: entity.y, text: '💥 +10' },
    ]);
    setTimeout(() => {
      setBurstEffects((prev) => prev.filter((b) => b.id !== burstId));
    }, 450);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl h-[520px] rounded-3xl overflow-hidden bg-gradient-to-br from-[#0F172A] via-[#1E1B4B] to-[#31102F] border-2 border-[#FF5722] shadow-2xl flex flex-col justify-between select-none">
        {/* Top Game HUD */}
        <div className="relative z-20 p-4 bg-black/50 backdrop-blur-md flex items-center justify-between flex-wrap gap-2 border-b border-white/15 text-white">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{emoji}</span>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base flex items-center gap-2">
                Emoji Blast Defense Game
                <span className="px-2 py-0.5 rounded bg-[#FF5722] text-[10px] uppercase">
                  Live Chat Arcade
                </span>
              </h3>
              <p className="text-[11px] text-slate-300">
                Tap incoming {emoji} emojis before they touch the center Red Ball (लाल गेंद)!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* 3 Chances / Lives */}
            <div className="flex items-center gap-1 bg-white/10 px-2.5 py-1.5 rounded-xl">
              <span className="text-xs font-bold mr-1">Lives:</span>
              {[1, 2, 3].map((idx) => (
                <Heart
                  key={idx}
                  className={`w-4 h-4 ${
                    idx <= chances
                      ? 'text-[#E53935] fill-[#E53935]'
                      : 'text-slate-600'
                  }`}
                />
              ))}
            </div>

            <div className="px-2.5 py-1.5 rounded-xl bg-[#F59E0B] text-white font-extrabold text-xs">
              Score: {score} • High: {highScore}
            </div>

            <button
              onClick={() => setIsPaused((p) => !p)}
              className="px-2.5 py-1.5 rounded-xl bg-[#2563EB] text-white font-extrabold text-xs"
            >
              {isPaused ? '▶ Resume' : '⏸ Pause'}
            </button>

            <button
              onClick={restartGame}
              className="px-2.5 py-1.5 rounded-xl bg-[#7C3AED] text-white font-extrabold text-xs"
            >
              ↻ Restart
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Center Playfield with Red Ball & Flying Emojis */}
        <div className="relative flex-1 w-full overflow-hidden">
          {/* Center Red Ball (लाल गेंद) */}
          <div
            style={{ left: '50%', top: '50%' }}
            className="absolute -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-gradient-to-br from-[#FF5252] via-[#E53935] to-[#991B1B] shadow-[0_0_40px_#EF4444] border-4 border-white/80 flex flex-col items-center justify-center text-white z-10"
          >
            <span className="text-[10px] font-extrabold uppercase tracking-tighter">
              लाल गेंद
            </span>
            <span className="text-xs font-black">{chances}/3</span>
          </div>

          {/* Protective Radar Rings */}
          <div
            style={{ left: '50%', top: '50%' }}
            className="absolute -translate-x-1/2 -translate-y-1/2 w-36 h-36 rounded-full border border-red-500/30 pointer-events-none"
          />
          <div
            style={{ left: '50%', top: '50%' }}
            className="absolute -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full border border-orange-500/20 pointer-events-none"
          />

          {/* Flying Emojis */}
          {entities.map((ent) => (
            <button
              key={ent.id}
              onClick={() => handleBlastEmoji(ent)}
              style={{ left: `${ent.x}%`, top: `${ent.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/15 hover:bg-[#FF5722] border border-white/40 flex items-center justify-center text-2xl shadow-lg transition-transform active:scale-125 cursor-pointer z-20"
            >
              {ent.emoji}
            </button>
          ))}

          {/* Blast Particle Popups */}
          {burstEffects.map((b) => (
            <div
              key={b.id}
              style={{ left: `${b.x}%`, top: `${b.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 text-xs font-black text-[#F59E0B] pointer-events-none animate-bounce z-30"
            >
              {b.text}
            </div>
          ))}

          {/* Game Over / OUT Overlay */}
          {isGameOver && (
            <div className="absolute inset-0 z-40 bg-black/85 flex flex-col items-center justify-center text-center p-6 text-white space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-[#E53935] flex items-center justify-center text-3xl shadow-xl">
                💥
              </div>
              <h2 className="text-3xl font-black tracking-tight text-[#FF5722]">
                OUT! (तीनों चांस खत्म)
              </h2>
              <p className="text-sm text-slate-300 max-w-md">
                3 emojis touched the center Red Ball (लाल गेंद). Your final blast score is{' '}
                <span className="font-extrabold text-[#F59E0B]">{score} points</span>!
              </p>
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={restartGame}
                  className="fism-btn-primary px-6 py-3 rounded-xl font-extrabold text-sm flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" /> Play Again (3 Chances)
                </button>
                <button
                  onClick={onClose}
                  className="px-5 py-3 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-sm"
                >
                  Back to Personal Chat
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Instruction Bar */}
        <div className="p-3 bg-black/60 text-center text-xs text-slate-300 border-t border-white/10">
          Tip: Click or tap every incoming <span className="font-bold text-white">{emoji}</span>{' '}
          to blast it before it hits the Red Ball!
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 2. AUDIO & VIDEO CALLING MODAL (Personal Chat & Shopping Seller Call)
// ============================================================================
interface CallModalProps {
  targetName: string;
  targetAvatar: string;
  targetPhone?: string;
  mode: 'audio' | 'video';
  publishedArFilters?: FismArFilterAsset[];
  onClose: () => void;
}

export const FismCallModal: React.FC<CallModalProps> = ({
  targetName,
  targetAvatar,
  targetPhone,
  mode,
  publishedArFilters = INITIAL_PUBLISHED_AR_FILTERS,
  onClose,
}) => {
  const [callSeconds, setCallSeconds] = useState(0);
  const [micMuted, setMicMuted] = useState(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [switchingCam, setSwitchingCam] = useState(false);
  const [activeArFilterId, setActiveArFilterId] = useState<string | null>(null);
  const [arTrayOpen, setArTrayOpen] = useState<boolean>(mode === 'video');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const arOverlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const micMutedRef = useRef(micMuted);
  micMutedRef.current = micMuted;

  const activeArFilter =
    publishedArFilters.find((f) => f.id === activeArFilterId) || null;

  // Call duration timer (never drops when switching camera or changing AR filters)
  useEffect(() => {
    const timer = setInterval(() => setCallSeconds((s) => s + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  // Initialize & Cleanup MediaStream
  useEffect(() => {
    if (mode !== 'video') return;
    let active = true;
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode }, audio: true })
      .then((stream) => {
        if (!active) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        stream.getAudioTracks().forEach((t) => {
          t.enabled = !micMutedRef.current;
        });
        streamRef.current = stream;
        setCameraError(null);
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
          localVideoRef.current.play().catch(() => {});
        }
      })
      .catch(() => {
        if (active) {
          setCameraError('Camera preview unavailable in current browser permission state.');
        }
      });

    return () => {
      active = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };
  }, [mode]);

  // Seamless Front / Rear Camera Switching without dropping call or audio track
  const handleSwitchCamera = async () => {
    if (mode !== 'video' || switchingCam) return;
    const nextFacing: 'user' | 'environment' = facingMode === 'user' ? 'environment' : 'user';
    setSwitchingCam(true);
    try {
      const oldVideoTracks = streamRef.current ? streamRef.current.getVideoTracks() : [];
      const newVideoStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: nextFacing },
        audio: false,
      });
      const newVideoTrack = newVideoStream.getVideoTracks()[0];
      if (streamRef.current && newVideoTrack) {
        oldVideoTracks.forEach((t) => {
          streamRef.current?.removeTrack(t);
          t.stop();
        });
        streamRef.current.addTrack(newVideoTrack);
      } else {
        streamRef.current = newVideoStream;
      }
      if (localVideoRef.current && streamRef.current) {
        localVideoRef.current.srcObject = streamRef.current;
        localVideoRef.current.play().catch(() => {});
      }
      setFacingMode(nextFacing);
      setCameraError(null);
    } catch {
      // Even on desktop single-cam environments, reflect mode switch gracefully
      setFacingMode(nextFacing);
    } finally {
      setSwitchingCam(false);
    }
  };

  // Toggle mic track cleanly
  const handleToggleMic = () => {
    setMicMuted((prev) => {
      const next = !prev;
      if (streamRef.current) {
        streamRef.current.getAudioTracks().forEach((t) => {
          t.enabled = !next;
        });
      }
      return next;
    });
  };

  // Real-time AR Filter Canvas Overlay Loop
  useEffect(() => {
    if (mode !== 'video' || !activeArFilter) return;
    let rafId = 0;
    const renderArFrame = (now: number) => {
      const canvas = arOverlayCanvasRef.current;
      if (canvas) {
        const rect = canvas.getBoundingClientRect();
        const w = Math.max(240, Math.round(rect.width || 320));
        const h = Math.max(180, Math.round(rect.height || 240));
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
        }
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, w, h);
          drawArFilterOverlay(ctx, w, h, activeArFilter, now);
        }
      }
      rafId = requestAnimationFrame(renderArFrame);
    };
    rafId = requestAnimationFrame(renderArFrame);
    return () => cancelAnimationFrame(rafId);
  }, [mode, activeArFilter]);

  const formattedTime = `${String(Math.floor(callSeconds / 60)).padStart(2, '0')}:${String(
    callSeconds % 60,
  ).padStart(2, '0')}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
      <div className="relative w-full max-w-xl rounded-3xl overflow-hidden bg-[#111827] border border-slate-700 text-white p-5 flex flex-col items-center justify-between min-h-[500px] shadow-2xl space-y-3">
        <div className="w-full flex items-center justify-between text-xs text-slate-400 flex-wrap gap-2">
          <span className="px-2.5 py-1 rounded-lg bg-[#16A34A] text-white font-bold flex items-center gap-1.5">
            ● Live {mode === 'video' ? 'Video Call' : 'Voice Call'} Connected
            {mode === 'video' && (
              <span className="px-1.5 py-0.5 rounded bg-black/30 text-[10px]">
                {facingMode === 'user' ? 'Front Cam' : 'Rear Cam'}
              </span>
            )}
          </span>
          <span className="font-mono font-bold text-sm text-white">{formattedTime}</span>
        </div>

        {mode === 'video' ? (
          <div className="w-full space-y-3">
            <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-slate-900 border border-slate-700 flex items-center justify-center">
              <img
                src={targetAvatar}
                alt={targetName}
                className="w-full h-full object-cover opacity-50"
              />
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/30 pointer-events-none">
                <img
                  src={targetAvatar}
                  alt={targetName}
                  className="w-16 h-16 rounded-full object-cover ring-4 ring-[#FF5722]"
                />
                <h3 className="font-extrabold text-base mt-2">{targetName}</h3>
                {targetPhone && <p className="text-[11px] text-slate-300">{targetPhone}</p>}
              </div>

              {/* Self Camera PIP with Real-Time AR Filter Overlay & Front/Rear Camera */}
              <div className="absolute bottom-3 right-3 w-36 h-28 sm:w-44 sm:h-32 rounded-2xl overflow-hidden bg-black border-2 border-[#00F5D4] shadow-2xl">
                {!cameraError ? (
                  <video
                    ref={localVideoRef}
                    muted
                    playsInline
                    style={
                      activeArFilter?.cssFilter ? { filter: activeArFilter.cssFilter } : undefined
                    }
                    className={`w-full h-full object-cover ${
                      facingMode === 'user' ? '-scale-x-100' : ''
                    }`}
                  />
                ) : (
                  <img
                    src={GENERATED_ASSETS.avatar1}
                    alt="You"
                    style={
                      activeArFilter?.cssFilter ? { filter: activeArFilter.cssFilter } : undefined
                    }
                    className="w-full h-full object-cover opacity-85"
                  />
                )}
                {activeArFilter && (
                  <canvas
                    ref={arOverlayCanvasRef}
                    className="absolute inset-0 w-full h-full pointer-events-none"
                  />
                )}
                <div className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-[9px] font-extrabold text-[#00F5D4]">
                  {facingMode === 'user' ? 'Front' : 'Rear'}
                  {activeArFilter ? ` • ${activeArFilter.name}` : ''}
                </div>
              </div>
            </div>

            {/* Dynamic Live AR Filter Picker Bar */}
            {arTrayOpen && (
              <div className="p-2.5 rounded-2xl bg-slate-900/90 border border-slate-700 space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-extrabold text-[#00F5D4]">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" /> Live Call AR Filters (Synced with Admin AI Studio)
                  </span>
                  {activeArFilter && (
                    <button
                      type="button"
                      onClick={() => setActiveArFilterId(null)}
                      className="text-[10px] text-slate-300 hover:text-white underline"
                    >
                      Clear Filter
                    </button>
                  )}
                </div>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  <button
                    type="button"
                    onClick={() => setActiveArFilterId(null)}
                    className={`px-3 py-1.5 rounded-xl text-[11px] font-extrabold shrink-0 border ${
                      !activeArFilterId
                        ? 'bg-white text-slate-900 border-white'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    Normal
                  </button>
                  {publishedArFilters
                    .filter((f) => f.publishedToUsers)
                    .map((flt) => {
                      const active = activeArFilterId === flt.id;
                      return (
                        <button
                          key={flt.id}
                          type="button"
                          onClick={() => setActiveArFilterId(active ? null : flt.id)}
                          style={{
                            borderColor: active ? flt.primaryColor : undefined,
                          }}
                          className={`px-3 py-1.5 rounded-xl text-[11px] font-extrabold shrink-0 border flex items-center gap-1.5 transition-all ${
                            active
                              ? 'bg-slate-800 text-white shadow-lg scale-105'
                              : 'bg-slate-800/70 text-slate-200 border-slate-700 hover:border-slate-500'
                          }`}
                        >
                          <span
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: flt.primaryColor }}
                          />
                          {flt.name}
                        </button>
                      );
                    })}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="my-8 flex flex-col items-center text-center">
            <div className="relative">
              <img
                src={targetAvatar}
                alt={targetName}
                className="w-28 h-28 rounded-full object-cover ring-4 ring-[#FF5722] shadow-2xl"
              />
              <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#16A34A] ring-4 ring-[#111827]" />
            </div>
            <h3 className="text-xl font-extrabold mt-4">{targetName}</h3>
            {targetPhone && (
              <p className="text-sm text-[#F59E0B] font-mono mt-1">{targetPhone}</p>
            )}
            <p className="text-xs text-slate-400 mt-1">HD Encrypted FISM Voice Line</p>
          </div>
        )}

        <div className="flex items-center justify-center flex-wrap gap-3">
          <button
            type="button"
            onClick={handleToggleMic}
            title={micMuted ? 'Unmute Mic' : 'Mute Mic'}
            className={`p-3.5 rounded-full ${
              micMuted ? 'bg-[#F59E0B] text-white' : 'bg-slate-800 text-white hover:bg-slate-700'
            }`}
          >
            {micMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {mode === 'video' && (
            <>
              <button
                type="button"
                onClick={handleSwitchCamera}
                disabled={switchingCam}
                className="px-3.5 py-3 rounded-2xl bg-[#2563EB] hover:bg-blue-700 text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
              >
                <RefreshCw className={`w-4 h-4 ${switchingCam ? 'animate-spin' : ''}`} />
                {facingMode === 'user' ? 'Switch to Rear' : 'Switch to Front'}
              </button>
              <button
                type="button"
                onClick={() => setArTrayOpen((v) => !v)}
                className={`px-3.5 py-3 rounded-2xl text-xs font-extrabold flex items-center gap-1.5 shadow ${
                  arTrayOpen
                    ? 'bg-[#7C3AED] text-white'
                    : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                }`}
              >
                <Sparkles className="w-4 h-4" /> AR Filters
              </button>
            </>
          )}

          {targetPhone && (
            <a
              href={`tel:${targetPhone.replace(/\s+/g, '')}`}
              className="px-4 py-3 rounded-2xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1.5"
            >
              <Phone className="w-4 h-4" /> Dial
            </a>
          )}

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-3 rounded-2xl bg-[#DC2626] hover:bg-red-700 text-white font-extrabold text-xs flex items-center gap-2 shadow-lg"
          >
            <PhoneOff className="w-4 h-4" /> End Call
          </button>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 3. SHOPPING SECTION (शॉपिंग सेक्शन - Min 2 to Max 15 Photos + 1 Mandatory Video)
// ============================================================================
interface ShoppingSectionProps {
  products: FismShoppingProduct[];
  onAddProduct: (product: FismShoppingProduct) => void;
  onStartCall: (info: {
    name: string;
    avatar: string;
    phone: string;
    mode: 'audio' | 'video';
  }) => void;
  onOpenSellerChat: (sellerName: string, sellerAvatar: string) => void;
  onOpenLocationMap?: (target: {
    lat: number;
    lng: number;
    title: string;
    label: string;
  }) => void;
  onTriggerToast: (msg: string) => void;
  isPremiumSection: boolean;
}

export const FismShoppingHub: React.FC<ShoppingSectionProps> = ({
  products,
  onAddProduct,
  onStartCall,
  onOpenSellerChat,
  onOpenLocationMap,
  onTriggerToast,
  isPremiumSection,
}) => {
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [unlockedBuyProductIds, setUnlockedBuyProductIds] = useState<string[]>([]);
  const [activePhotoIndexMap, setActivePhotoIndexMap] = useState<Record<string, number>>({});
  const [playingVideoProductId, setPlayingVideoProductId] = useState<string | null>(null);

  // New Product Form State (Min 2 photos, Max 15 photos, Min 1 & Max 1 video)
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('₹14,999');
  const [phoneNumber, setPhoneNumber] = useState('+91 98765 43210');
  const [email, setEmail] = useState('creator.shop@fism.social');
  const [locationLabel, setLocationLabel] = useState('Connaught Place, New Delhi');
  const [lat, setLat] = useState<number>(28.6315);
  const [lng, setLng] = useState<number>(77.2167);
  const [photos, setPhotos] = useState<string[]>([
    GENERATED_ASSETS.heroCover,
    GENERATED_ASSETS.mountainPost,
  ]);
  const [videoUrl, setVideoUrl] = useState<string>(GENERATED_ASSETS.studioThumb);
  const [videoTitle, setVideoTitle] = useState<string>('Product Live Inspection Video (MP4)');
  const [formError, setFormError] = useState<string | null>(null);

  const handleTagRealtimeLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const cLat = +pos.coords.latitude.toFixed(5);
          const cLng = +pos.coords.longitude.toFixed(5);
          setLat(cLat);
          setLng(cLng);
          setLocationLabel(`Real-Time GPS Tagged (${cLat}, ${cLng})`);
          onTriggerToast(`Real-time GPS location tagged: ${cLat}, ${cLng}`);
        },
        () => {
          setLat(28.6139);
          setLng(77.209);
          setLocationLabel('Real-Time GPS Tagged • New Delhi Hub (28.6139, 77.2090)');
          onTriggerToast('Real-time location tagged!');
        },
      );
    } else {
      setLocationLabel('Real-Time GPS Tagged • Cyber Hub (28.4950, 77.0890)');
      onTriggerToast('Real-time location tagged!');
    }
  };

  const handleAddSamplePhoto = (url: string) => {
    if (photos.length >= 15) {
      setFormError('Maximum 15 photos allowed per shopping listing!');
      return;
    }
    setFormError(null);
    setPhotos((prev) => [...prev, url]);
  };

  const handlePublishListing = () => {
    if (!title.trim()) {
      setFormError('Please enter a product title.');
      return;
    }
    if (photos.length < 2 || photos.length > 15) {
      setFormError('Shopping rule: You must attach minimum 2 photos and maximum 15 photos.');
      return;
    }
    if (!videoUrl.trim()) {
      setFormError('Shopping rule: Minimum 1 and maximum 1 product video is mandatory.');
      return;
    }
    if (!phoneNumber.trim() || !email.trim()) {
      setFormError('Please provide both your contact Phone Number and Email ID.');
      return;
    }

    const newProd: FismShoppingProduct = {
      id: `prod_${Date.now()}`,
      title: title.trim(),
      description:
        description.trim() ||
        'Verified FISM Creator Marketplace product with real-time location & video inspection.',
      price: price.trim() || '₹9,999',
      photos,
      videoUrl,
      videoTitle: videoTitle.trim() || 'Official Product Video',
      sellerId: 'local_hearth_user',
      sellerName: 'Alex Ignis (My Hearth)',
      sellerAvatar: GENERATED_ASSETS.avatar1,
      phoneNumber: phoneNumber.trim(),
      email: email.trim(),
      locationLabel: locationLabel.trim(),
      lat,
      lng,
      createdAt: 'Just now',
    };

    onAddProduct(newProd);
    setCreateModalOpen(false);
    setTitle('');
    setDescription('');
    setFormError(null);
    onTriggerToast('Product published to FISM Shopping Section!');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="fism-card p-5 flex items-center justify-between flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold flex items-center gap-2">
              <ShoppingBag className="w-6 h-6 text-[#FF5722]" /> FISM Shopping Section (शॉपिंग
              स्टोर)
            </h1>
            {isPremiumSection && (
              <span className="px-2.5 py-0.5 rounded-full bg-[#F59E0B] text-white text-xs font-extrabold flex items-center gap-1">
                <Crown className="w-3.5 h-3.5" /> PREMIUM SECTION
              </span>
            )}
          </div>
          <p className="text-xs text-[#52607A] mt-1">
            List products with 2–15 photos + 1 mandatory video, real-time GPS location navigation,
            and instant Buy &amp; Call seller access.
          </p>
        </div>

        <button
          onClick={() => setCreateModalOpen(true)}
          className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 shadow-lg"
        >
          <Plus className="w-5 h-5" /> + Add Product (2–15 Photos &amp; 1 Video)
        </button>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {products.map((prod) => {
          const currentPhotoIdx = activePhotoIndexMap[prod.id] || 0;
          const isBuyUnlocked = unlockedBuyProductIds.includes(prod.id);
          const isPlayingVideo = playingVideoProductId === prod.id;

          return (
            <div key={prod.id} className="fism-card overflow-hidden flex flex-col justify-between">
              <div>
                {/* Top Seller & Price Header */}
                <div className="p-4 flex items-center justify-between gap-2 border-b border-[#D8E1F0] dark:border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={prod.sellerAvatar}
                      alt={prod.sellerName}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-[#FF5722]"
                    />
                    <div>
                      <div className="font-bold text-sm flex items-center gap-1">
                        {prod.sellerName}
                        <CheckCircle2 className="w-4 h-4 text-[#2563EB]" />
                      </div>
                      <div className="text-[11px] text-[#52607A]">{prod.createdAt}</div>
                    </div>
                  </div>
                  <div className="px-3.5 py-1.5 rounded-xl fism-gradient-flame text-white font-extrabold text-sm shadow">
                    {prod.price}
                  </div>
                </div>

                {/* Multi-Photo Carousel (2 to 15 Photos) + 1 Mandatory Video Toggle */}
                <div className="relative aspect-video bg-[#0F172A] overflow-hidden">
                  <img
                    src={prod.photos[currentPhotoIdx] || prod.photos[0]}
                    alt={prod.title}
                    className="w-full h-full object-cover"
                  />

                  {isPlayingVideo && (
                    <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center p-3 text-white text-center z-10">
                      {prod.videoUrl.startsWith('blob:') ||
                      prod.videoUrl.startsWith('data:video') ||
                      prod.videoUrl.endsWith('.mp4') ? (
                        <video
                          src={prod.videoUrl}
                          controls
                          autoPlay
                          loop
                          playsInline
                          className="w-full h-full object-contain rounded-lg"
                        />
                      ) : (
                        <>
                          <Film className="w-10 h-10 text-[#FF5722] animate-pulse mb-2" />
                          <div className="font-extrabold text-sm">{prod.videoTitle}</div>
                          <p className="text-xs text-slate-300 mt-1">
                            Playing verified 1/1 mandatory seller product showcase video
                          </p>
                        </>
                      )}
                      <button
                        onClick={() => setPlayingVideoProductId(null)}
                        className="mt-2 px-4 py-1.5 rounded-lg bg-[#FF5722] text-white text-xs font-bold shadow"
                      >
                        Back to Photos ({prod.photos.length} Photos)
                      </button>
                    </div>
                  )}

                  {/* Photo Count & Video Badge */}
                  <div className="absolute top-3 left-3 flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-black/75 text-white text-xs font-bold">
                      📷 Photo {currentPhotoIdx + 1} / {prod.photos.length}
                    </span>
                    <button
                      onClick={() =>
                        setPlayingVideoProductId((prev) => (prev === prod.id ? null : prod.id))
                      }
                      className="px-2.5 py-1 rounded-lg bg-[#7C3AED] text-white text-xs font-bold flex items-center gap-1 shadow"
                    >
                      <Film className="w-3.5 h-3.5" /> {isPlayingVideo ? 'Hide Video' : 'Watch 1/1 Video'}
                    </button>
                  </div>

                  {/* Next / Prev Photo Controls */}
                  <div className="absolute bottom-3 right-3 flex items-center gap-1.5">
                    <button
                      onClick={() =>
                        setActivePhotoIndexMap((prev) => ({
                          ...prev,
                          [prod.id]:
                            currentPhotoIdx > 0 ? currentPhotoIdx - 1 : prod.photos.length - 1,
                        }))
                      }
                      className="px-2.5 py-1 rounded bg-black/75 text-white text-xs font-bold"
                    >
                      ◀ Prev
                    </button>
                    <button
                      onClick={() =>
                        setActivePhotoIndexMap((prev) => ({
                          ...prev,
                          [prod.id]:
                            currentPhotoIdx < prod.photos.length - 1 ? currentPhotoIdx + 1 : 0,
                        }))
                      }
                      className="px-2.5 py-1 rounded bg-black/75 text-white text-xs font-bold"
                    >
                      Next ▶
                    </button>
                  </div>
                </div>

                {/* Product Details & Real-Time Location Link */}
                <div className="p-4 space-y-3">
                  <h3 className="font-extrabold text-base sm:text-lg">{prod.title}</h3>
                  <p className="text-xs sm:text-sm text-[#52607A] dark:text-slate-300">
                    {prod.description}
                  </p>

                  {/* Real-Time Location Tag & In-App Google Maps + App Link Share */}
                  <div className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800/90 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2 text-xs">
                      <MapPin className="w-4 h-4 text-[#FF5722] shrink-0" />
                      <div>
                        <span className="font-bold">{prod.locationLabel}</span>
                        <div className="text-[11px] text-[#52607A]">
                          GPS: {prod.lat}, {prod.lng}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => {
                          if (onOpenLocationMap) {
                            onOpenLocationMap({
                              lat: prod.lat,
                              lng: prod.lng,
                              title: prod.title,
                              label: prod.locationLabel,
                            });
                          } else {
                            onTriggerToast(`Seller GPS: ${prod.lat}, ${prod.lng}`);
                          }
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Navigation className="w-3.5 h-3.5" /> Visit Seller Location
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          void shareFismLink({
                            title: `${prod.title} on FISM Shopping`,
                            text: `${prod.title} (${prod.price}) on FISM Shop:`,
                            url: buildFismShareUrl('item', prod.id),
                            triggerToast: onTriggerToast,
                          })
                        }
                        className="px-2.5 py-1.5 rounded-lg bg-[#0F172A] text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Share2 className="w-3.5 h-3.5" /> Share Link
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Buy Button & Unlocked Phone / Call / Video Call / Copy Panel */}
              <div className="p-4 pt-0">
                {!isBuyUnlocked ? (
                  <button
                    onClick={() => {
                      setUnlockedBuyProductIds((prev) => [...prev, prod.id]);
                      onTriggerToast(
                        `Seller phone number & calling unlocked for "${prod.title}"!`,
                      );
                    }}
                    className="w-full fism-btn-primary py-3 rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 shadow-md"
                  >
                    <ShoppingBag className="w-4 h-4" /> Buy Now (Reveal Number, Call &amp; Video Call)
                  </button>
                ) : (
                  <div className="p-4 rounded-2xl bg-[#EEF3FB] dark:bg-slate-800 border-2 border-[#16A34A] space-y-3">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-[#16A34A] text-white">
                          Seller Contact Unlocked
                        </span>
                        <div className="font-mono font-extrabold text-base mt-1 flex items-center gap-2">
                          <Phone className="w-4 h-4 text-[#16A34A]" /> {prod.phoneNumber}
                        </div>
                        <div className="text-xs text-[#52607A] flex items-center gap-1 mt-0.5">
                          <Mail className="w-3.5 h-3.5" /> {prod.email}
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          navigator.clipboard?.writeText(prod.phoneNumber);
                          onTriggerToast(`Copied seller number: ${prod.phoneNumber}`);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold flex items-center gap-1.5"
                      >
                        <Copy className="w-3.5 h-3.5 text-[#7C3AED]" /> Copy Number
                      </button>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() =>
                          onStartCall({
                            name: prod.sellerName,
                            avatar: prod.sellerAvatar,
                            phone: prod.phoneNumber,
                            mode: 'audio',
                          })
                        }
                        className="py-2.5 px-3 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center justify-center gap-1.5 shadow"
                      >
                        <Phone className="w-4 h-4" /> Voice Call
                      </button>

                      <button
                        onClick={() =>
                          onStartCall({
                            name: prod.sellerName,
                            avatar: prod.sellerAvatar,
                            phone: prod.phoneNumber,
                            mode: 'video',
                          })
                        }
                        className="py-2.5 px-3 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold flex items-center justify-center gap-1.5 shadow"
                      >
                        <Video className="w-4 h-4" /> Video Call
                      </button>

                      <button
                        onClick={() => onOpenSellerChat(prod.sellerName, prod.sellerAvatar)}
                        className="py-2.5 px-3 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold flex items-center justify-center gap-1.5 shadow"
                      >
                        <MessageCircle className="w-4 h-4" /> Chat
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Create Shopping Product Modal (Min 2 to Max 15 Photos + 1 Video) */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4 overflow-y-auto">
          <div className="fism-card max-w-2xl w-full p-5 sm:p-6 space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-[#D8E1F0] dark:border-slate-800 pb-3">
              <h2 className="text-lg font-extrabold flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-[#FF5722]" /> List New Shopping Product
              </h2>
              <button
                onClick={() => setCreateModalOpen(false)}
                className="p-1.5 rounded-lg bg-[#F3F6FC] dark:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-[#DC2626] text-white text-xs font-bold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold mb-1">Product Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Sony FX3 Cinema Rig / Custom Sneakers"
                  className="w-full px-3.5 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-bold mb-1">Price Tag</label>
                <input
                  type="text"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="₹14,999"
                  className="w-full px-3.5 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold mb-1">Seller Phone Number (For Calls)</label>
                <input
                  type="text"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-bold mb-1">Seller Email ID</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm"
                />
              </div>
            </div>

            {/* Real-Time Location Tagging */}
            <div>
              <label className="block text-xs font-bold mb-1">
                Product Pickup / Store Location (Real-Time GPS Tag)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={locationLabel}
                  onChange={(e) => setLocationLabel(e.target.value)}
                  className="flex-1 px-3.5 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-semibold"
                />
                <button
                  type="button"
                  onClick={handleTagRealtimeLocation}
                  className="px-3.5 py-2 rounded-xl bg-[#2563EB] text-white text-xs font-bold flex items-center gap-1.5 shrink-0"
                >
                  <MapPin className="w-4 h-4" /> Tag Real-Time GPS
                </button>
              </div>
            </div>

            {/* Photos Uploader (Minimum 2, Maximum 15) */}
            <div className="p-3.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold">
                  Product Photos ({photos.length} / 15) — Minimum 2 &amp; Maximum 15 Required
                </span>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleAddSamplePhoto(GENERATED_ASSETS.heroCover)}
                    className="px-2.5 py-1 rounded bg-[#FF5722] text-white text-[11px] font-bold"
                  >
                    + Add Photo
                  </button>
                  <label className="px-2.5 py-1 rounded bg-[#2563EB] text-white text-[11px] font-bold cursor-pointer">
                    Upload File
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      className="hidden"
                      onChange={(e) => {
                        const files = Array.from(e.target.files || []);
                        for (const f of files) {
                          handleAddSamplePhoto(URL.createObjectURL(f));
                        }
                      }}
                    />
                  </label>
                </div>
              </div>

              <div className="flex gap-2 overflow-x-auto pb-1">
                {photos.map((imgUrl, index) => (
                  <div key={index} className="relative shrink-0 w-16 h-16 rounded-lg overflow-hidden border border-slate-400">
                    <img src={imgUrl} alt="" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setPhotos((prev) => prev.filter((_, i) => i !== index))}
                      className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-[#DC2626] text-white text-[10px] flex items-center justify-center"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Mandatory 1 Video Section (Min 1, Max 1) */}
            <div className="p-3.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between flex-wrap gap-2">
              <div>
                <div className="text-xs font-extrabold flex items-center gap-1.5">
                  <Film className="w-4 h-4 text-[#7C3AED]" /> Product Video (1 / 1 Mandatory)
                </div>
                <div className="text-[11px] text-[#52607A]">{videoTitle}</div>
              </div>
              <label className="px-3 py-1.5 rounded-lg bg-[#7C3AED] text-white text-xs font-bold cursor-pointer">
                Replace 1/1 Video
                <input
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setVideoUrl(URL.createObjectURL(file));
                      setVideoTitle(file.name);
                    }
                  }}
                />
              </label>
            </div>

            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe product condition, warranty, and pickup details..."
              className="w-full p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCreateModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handlePublishListing}
                className="fism-btn-primary px-6 py-2.5 rounded-xl text-xs font-extrabold"
              >
                Publish Product to Shopping
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// 4. ADMIN FILE VAULT (3-Step Lock -> Live ID Ban/Unban + Long-Press Full Data + Per-Section Premium ON/OFF)
// ============================================================================
interface AdminFileVaultProps {
  unlocked: boolean;
  onUnlockSuccess: () => void;
  userDossiers: FismAdminUserDossier[];
  onToggleBanUser: (uid: string) => void;
  globalPremiumOn: boolean;
  onToggleGlobalPremium: (next: boolean) => void;
  sectionPremiumMap: Record<FismScreen, boolean>;
  onToggleSectionPremium: (screen: FismScreen) => void;
  onTriggerToast: (msg: string) => void;
  gamesList?: FismGameItem[];
  onAdminUploadGame?: (game: FismGameItem) => void;
  activeSurvey?: FismSurveyCampaign | null;
  onLaunchSurvey?: (survey: FismSurveyCampaign) => void;
  onStopSurvey?: () => void;
  surveySubmissions?: FismSurveySubmission[];
  upiConfig?: FismUpiConfig;
  onUpdateUpiConfig?: (config: FismUpiConfig) => void;
  upiRequests?: FismUpiPaymentRequest[];
  onAcceptUpiRequest?: (requestId: string) => void;
  onDeclineUpiRequest?: (requestId: string) => void;
  custom3DModels?: Face3DModelPreset[];
  onAdminUpload3DModel?: (model: Face3DModelPreset) => void;
  appLogoBgUrl?: string;
  onUpdateAppLogoBg?: (photoUrl: string) => void;
  withdrawalRequests?: FismWithdrawalRequest[];
  onAcceptWithdrawalRequest?: (requestId: string) => void;
  onDeclineWithdrawalRequest?: (requestId: string) => void;
  userHasBoughtPremium?: boolean;
  onToggleUserBoughtPremium?: (bought: boolean) => void;
  publishedArFilters?: FismArFilterAsset[];
  onPublishArFilter?: (filter: FismArFilterAsset) => void;
  publishedStudioFilters?: FismSavedStudioFilter[];
  onPublishStudioFilter?: (filter: FismSavedStudioFilter) => void;
  onDeleteStudioFilter?: (id: string) => void;
  copyrightAssets?: FismCopyrightAssetRecord[];
  copyrightViolations?: FismCopyrightViolationRecord[];
  onAddCopyrightAsset?: (asset: FismCopyrightAssetRecord) => void;
  onApproveCopyrightAppeal?: (violationId: string) => void;
  onRejectCopyrightAppeal?: (violationId: string) => void;
  liveCreatorUsers?: FismLiveCreatorPermissionRecord[];
  onGrantLiveCreatorAccess?: (user: FismLiveCreatorPermissionRecord, grant: boolean) => void;
  smartAds?: import('../types').FismSmartAdItem[];
  onCreateSmartAd?: (ad: import('../types').FismSmartAdItem) => Promise<void> | void;
  onToggleSmartAd?: (adId: string) => void;
  onDeleteSmartAd?: (adId: string) => void;
  founderGiftClaims?: import('../types').FismFounderGiftClaim[];
  onRespondFounderGift?: (
    claimId: string,
    status: 'approved' | 'shipped',
    adminNote?: string,
  ) => Promise<void> | void;
  adsterraConfig?: FismAdsterraConfig | null;
  onSaveAdsterraConfig?: (cfg: FismAdsterraConfig) => Promise<void> | void;
  apkRelease?: FismApkReleaseInfo | null;
  onUploadApkRelease?: (payload: {
    appName: string;
    version: string;
    details: string;
    fileName: string;
    sizeBytes: number;
    base64Data: string;
  }) => Promise<void> | void;
  onDeleteApkRelease?: () => Promise<void> | void;
}

const ADMIN_HARDCODED_PASSWORD = 'H7#x9!Kp2@Fism';

export const FismAdminFileVault: React.FC<AdminFileVaultProps> = ({
  unlocked,
  onUnlockSuccess,
  userDossiers,
  onToggleBanUser,
  globalPremiumOn,
  onToggleGlobalPremium,
  sectionPremiumMap,
  onToggleSectionPremium,
  onTriggerToast,
  gamesList = INITIAL_GAMES,
  onAdminUploadGame,
  activeSurvey,
  onLaunchSurvey,
  onStopSurvey,
  surveySubmissions = [],
  upiConfig,
  onUpdateUpiConfig,
  upiRequests = [],
  onAcceptUpiRequest,
  onDeclineUpiRequest,
  custom3DModels = [],
  onAdminUpload3DModel,
  appLogoBgUrl = '',
  onUpdateAppLogoBg,
  withdrawalRequests = [],
  onAcceptWithdrawalRequest,
  onDeclineWithdrawalRequest,
  userHasBoughtPremium = false,
  onToggleUserBoughtPremium,
  publishedArFilters = INITIAL_PUBLISHED_AR_FILTERS,
  onPublishArFilter,
  publishedStudioFilters = [],
  onPublishStudioFilter,
  onDeleteStudioFilter,
  copyrightAssets = [],
  copyrightViolations = [],
  onAddCopyrightAsset,
  onApproveCopyrightAppeal,
  onRejectCopyrightAppeal,
  liveCreatorUsers = [],
  onGrantLiveCreatorAccess,
  smartAds = [],
  onCreateSmartAd,
  onToggleSmartAd,
  onDeleteSmartAd,
  founderGiftClaims = [],
  onRespondFounderGift,
  adsterraConfig = null,
  onSaveAdsterraConfig,
  apkRelease = null,
  onUploadApkRelease,
  onDeleteApkRelease,
}) => {
  // 3-Step Lock State (Strict — No Auto-Fill)
  const [lockStep, setLockStep] = useState<1 | 2 | 3>(1);
  const [step1Pin, setStep1Pin] = useState('');
  const [step2Pattern, setStep2Pattern] = useState('');
  const [step3MasterKey, setStep3MasterKey] = useState('');
  const [lockError, setLockError] = useState<string | null>(null);

  // Admin OTP Mobile Number (Default: 8235286811, changeable from Admin File)
  const [adminOtpPhone, setAdminOtpPhone] = useState<string>(() => {
    try {
      return localStorage.getItem('fism_admin_otp_phone') || '8235286811';
    } catch {
      return '8235286811';
    }
  });
  const [newOtpPhoneDraft, setNewOtpPhoneDraft] = useState<string>(adminOtpPhone);
  const [generatedStage2Otp, setGeneratedStage2Otp] = useState<string>('');
  const [otpSentBanner, setOtpSentBanner] = useState<string | null>(null);

  // Admin Copyright Asset Form State
  const [crAssetTitle, setCrAssetTitle] = useState('');
  const [crRightsHolder, setCrRightsHolder] = useState('');
  const [crKeywords, setCrKeywords] = useState('');
  const [crAction, setCrAction] = useState<'RESTRICTED_COPYRIGHT' | 'BLOCKED'>('RESTRICTED_COPYRIGHT');

  // Admin Live Creator Chat Access Search State
  const [liveCreatorSearchQuery, setLiveCreatorSearchQuery] = useState('');
  const [liveCreatorServerResults, setLiveCreatorServerResults] = useState<
    FismLiveCreatorPermissionRecord[]
  >([]);

  // Admin Official Ads Uploader State
  const [offAdTitle, setOffAdTitle] = useState('');
  const [offAdDesc, setOffAdDesc] = useState('');
  const [offAdPlacement, setOffAdPlacement] =
    useState<import('../types').FismSmartAdPlacement>('longVideo');
  const [offAdUrl, setOffAdUrl] = useState('https://www.amazon.in');
  const [offAdCta, setOffAdCta] = useState('Explore Official Offer');
  const [offAdTags, setOffAdTags] = useState('gaming, esports, tech');
  const [offAdMediaUrl, setOffAdMediaUrl] = useState(GENERATED_ASSETS.studioThumb);
  const [offAdIsVideo, setOffAdIsVideo] = useState(false);

  // Admin AdsTerra Live Tag Studio State
  const [adEnabledDraft, setAdEnabledDraft] = useState<boolean>(adsterraConfig?.enabled ?? true);
  const [bannerEnabledDraft, setBannerEnabledDraft] = useState<boolean>(
    adsterraConfig?.bannerEnabled ?? true,
  );
  const [bannerKeyDraft, setBannerKeyDraft] = useState<string>(adsterraConfig?.bannerKey || '');
  const [bannerHostDraft, setBannerHostDraft] = useState<string>(
    adsterraConfig?.bannerHost || 'bicea.org',
  );
  const [bannerScriptUrlDraft, setBannerScriptUrlDraft] = useState<string>(
    adsterraConfig?.bannerScriptUrl || '',
  );
  const [bannerSizeDraft, setBannerSizeDraft] = useState<FismBannerOriginalSize>(
    adsterraConfig?.bannerSize || '320x50',
  );
  const [bannerRawHtmlDraft, setBannerRawHtmlDraft] = useState<string>(
    adsterraConfig?.bannerRawHtml || '',
  );
  const [rectBannerEnabledDraft, setRectBannerEnabledDraft] = useState<boolean>(
    adsterraConfig?.rectBannerEnabled ?? true,
  );
  const [rectBannerKeyDraft, setRectBannerKeyDraft] = useState<string>(
    adsterraConfig?.rectBannerKey || '',
  );
  const [rectBannerScriptUrlDraft, setRectBannerScriptUrlDraft] = useState<string>(
    adsterraConfig?.rectBannerScriptUrl || '',
  );
  const [rectBannerRawHtmlDraft, setRectBannerRawHtmlDraft] = useState<string>(
    adsterraConfig?.rectBannerRawHtml || '',
  );
  const [nativeEnabledDraft, setNativeEnabledDraft] = useState<boolean>(
    adsterraConfig?.nativeEnabled ?? true,
  );
  const [nativeScriptUrlDraft, setNativeScriptUrlDraft] = useState<string>(
    adsterraConfig?.nativeScriptUrl || '',
  );
  const [nativeContainerIdDraft, setNativeContainerIdDraft] = useState<string>(
    adsterraConfig?.nativeContainerId || '',
  );
  const [nativeRawHtmlDraft, setNativeRawHtmlDraft] = useState<string>(
    adsterraConfig?.nativeRawHtml || '',
  );
  const [savingAdsterra, setSavingAdsterra] = useState(false);

  useEffect(() => {
    if (!adsterraConfig) return;
    setAdEnabledDraft(adsterraConfig.enabled);
    setBannerEnabledDraft(adsterraConfig.bannerEnabled);
    setBannerKeyDraft(adsterraConfig.bannerKey);
    setBannerHostDraft(adsterraConfig.bannerHost || 'bicea.org');
    setBannerScriptUrlDraft(adsterraConfig.bannerScriptUrl || '');
    setBannerSizeDraft(adsterraConfig.bannerSize || '320x50');
    setBannerRawHtmlDraft(adsterraConfig.bannerRawHtml || '');
    setRectBannerEnabledDraft(adsterraConfig.rectBannerEnabled ?? true);
    setRectBannerKeyDraft(adsterraConfig.rectBannerKey || '');
    setRectBannerScriptUrlDraft(adsterraConfig.rectBannerScriptUrl || '');
    setRectBannerRawHtmlDraft(adsterraConfig.rectBannerRawHtml || '');
    setNativeEnabledDraft(adsterraConfig.nativeEnabled);
    setNativeScriptUrlDraft(adsterraConfig.nativeScriptUrl || '');
    setNativeContainerIdDraft(adsterraConfig.nativeContainerId || '');
    setNativeRawHtmlDraft(adsterraConfig.nativeRawHtml || '');
  }, [adsterraConfig]);

  // Admin Single-Slot APK Release Form State
  const [apkAppName, setApkAppName] = useState<string>(
    apkRelease?.appName || 'FISM — Flame Social',
  );
  const [apkVersion, setApkVersion] = useState<string>(apkRelease?.version || '2.4.0');
  const [apkDetails, setApkDetails] = useState<string>(
    apkRelease?.details ||
      'Official FISM Android APK with verified Deep Linking (App Links), 4K Reels, & Hardware Security.',
  );
  const [apkFileName, setApkFileName] = useState<string>('');
  const [apkSizeBytes, setApkSizeBytes] = useState<number>(0);
  const [apkBase64Data, setApkBase64Data] = useState<string>('');
  const [apkUploading, setApkUploading] = useState<boolean>(false);

  // Admin File Internal Tab
  const [adminTab, setAdminTab] = useState<
    | 'profiles'
    | 'trackingFolders'
    | 'upiSetup'
    | 'upiNotifications'
    | 'officialAds'
    | 'apkRelease'
    | 'copyrightProtection'
    | 'liveCreatorAccess'
    | 'otpSettings'
    | 'premium'
    | 'aiSecurityGuard'
    | 'aiFilterStudio'
    | 'gameUploader'
    | 'model3DUploader'
    | 'appLogoChanger'
    | 'surveyBoard'
    | 'founderGifts'
  >('upiNotifications');
  const [exportBackupOpen, setExportBackupOpen] = useState(false);

  useEffect(() => {
    if (adminTab !== 'liveCreatorAccess') return;
    let active = true;
    const q = encodeURIComponent(liveCreatorSearchQuery.trim());
    fetch(`/api/admin/live-creator-users?q=${q}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (active && data?.users && Array.isArray(data.users)) {
          setLiveCreatorServerResults(data.users);
        }
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [adminTab, liveCreatorSearchQuery, liveCreatorUsers]);

  // AI Filter Creator Studio & Live Sandbox State
  const [aiFilterPromptInput, setAiFilterPromptInput] = useState<string>(
    'Add glowing cyberpunk sunglasses on the face',
  );
  const [aiFilterGenerating, setAiFilterGenerating] = useState<boolean>(false);
  const [draftAiFilter, setDraftAiFilter] = useState<FismArFilterAsset>(
    INITIAL_PUBLISHED_AR_FILTERS[0],
  );
  const [sandboxCamActive, setSandboxCamActive] = useState<boolean>(false);
  const [sandboxCamError, setSandboxCamError] = useState<string | null>(null);
  const sandboxVideoRef = useRef<HTMLVideoElement | null>(null);
  const sandboxCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const sandboxStreamRef = useRef<MediaStream | null>(null);

  const stopSandboxCamera = () => {
    if (sandboxStreamRef.current) {
      sandboxStreamRef.current.getTracks().forEach((t) => t.stop());
      sandboxStreamRef.current = null;
    }
    setSandboxCamActive(false);
  };

  const startSandboxCamera = async () => {
    try {
      stopSandboxCamera();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      sandboxStreamRef.current = stream;
      setSandboxCamActive(true);
      setSandboxCamError(null);
      setTimeout(() => {
        if (sandboxVideoRef.current) {
          sandboxVideoRef.current.srcObject = stream;
          sandboxVideoRef.current.play().catch(() => {});
        }
      }, 60);
    } catch {
      setSandboxCamActive(false);
      setSandboxCamError('Webcam permission unavailable — Live Sandbox preview active on studio avatar.');
    }
  };

  useEffect(() => {
    if (adminTab !== 'aiFilterStudio') {
      stopSandboxCamera();
      return;
    }
    let rafId = 0;
    const drawLoop = (now: number) => {
      const canvas = sandboxCanvasRef.current;
      if (canvas) {
        const rect = canvas.getBoundingClientRect();
        const w = Math.max(320, Math.round(rect.width || 480));
        const h = Math.max(240, Math.round(rect.height || 320));
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
        }
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, w, h);
          drawArFilterOverlay(ctx, w, h, draftAiFilter, now);
        }
      }
      rafId = requestAnimationFrame(drawLoop);
    };
    rafId = requestAnimationFrame(drawLoop);
    return () => {
      cancelAnimationFrame(rafId);
    };
  }, [adminTab, draftAiFilter]);

  useEffect(() => {
    return () => stopSandboxCamera();
  }, []);

  const handleGenerateAiFilter = async () => {
    if (!aiFilterPromptInput.trim()) {
      onTriggerToast('Please describe the AR filter you want AI to create.');
      return;
    }
    setAiFilterGenerating(true);
    try {
      const res = await fetch('/api/gemini/create-filter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: aiFilterPromptInput.trim() }),
      });
      const data = await res.json();
      if (data?.filter) {
        setDraftAiFilter(data.filter as FismArFilterAsset);
        onTriggerToast(`🎨 AI Filter "${data.filter.name}" synthesized! Test it in Live Sandbox below.`);
      }
    } catch {
      onTriggerToast('Failed to reach AI Filter Synthesizer. Try again.');
    } finally {
      setAiFilterGenerating(false);
    }
  };

  const [logoBgDraftUrl, setLogoBgDraftUrl] = useState<string>(appLogoBgUrl || '');
  const [logoBgFileName, setLogoBgFileName] = useState<string>(
    appLogoBgUrl ? 'Custom Uploaded Logo Background' : 'Default Flame Gradient',
  );

  useEffect(() => {
    setLogoBgDraftUrl(appLogoBgUrl || '');
  }, [appLogoBgUrl]);

  // Admin 3D Model Uploader State (Starts with 4 Default Models; Admin uploads more via Open File)
  const [new3DModelName, setNew3DModelName] = useState('');
  const [new3DModelFileName, setNew3DModelFileName] = useState('star_3d_bunny_bundle.glb');
  const [new3DHeadgear, setNew3DHeadgear] =
    useState<Face3DModelPreset['headgear']>('bunny-ears');
  const [new3DEyeStyle, setNew3DEyeStyle] =
    useState<Face3DModelPreset['eyeStyle']>('glow-red');
  const [new3DMaskStyle, setNew3DMaskStyle] =
    useState<Face3DModelPreset['maskStyle']>('warrior-mask');
  const [new3DPrimaryColor, setNew3DPrimaryColor] = useState('#F8FAFC');
  const [new3DAccentColor, setNew3DAccentColor] = useState('#FF5722');

  // Admin UPI ID & QR Code Upload State
  const [adminUpiIdInput, setAdminUpiIdInput] = useState<string>(
    upiConfig?.upiId || 'fism.official@okaxis',
  );
  const [adminMerchantNameInput, setAdminMerchantNameInput] = useState<string>(
    upiConfig?.merchantName || 'FISM Official Flame Pay',
  );
  const [adminQrCodePreview, setAdminQrCodePreview] = useState<string>(
    upiConfig?.qrCodeUrl || '',
  );
  const [adminQrFileName, setAdminQrFileName] = useState<string>('Default FISM UPI QR Code');

  useEffect(() => {
    if (upiConfig) {
      setAdminUpiIdInput(upiConfig.upiId);
      setAdminMerchantNameInput(upiConfig.merchantName);
      setAdminQrCodePreview(upiConfig.qrCodeUrl);
    }
  }, [upiConfig]);

  // Admin Multi-Question Survey Builder State
  const [surveyTitle, setSurveyTitle] = useState('FISM Creator & Audience Experience Survey');
  const [surveyQuestions, setSurveyQuestions] = useState<FismSurveyQuestion[]>([
    {
      id: 'q_1',
      questionText: 'आपको FISM ऐप का कौन सा फीचर सबसे ज्यादा पसंद है?',
      options: ['Quick Burst (Shorts)', '3D VR Cinema Theater', 'On Fire Gaming Live'],
    },
  ]);

  // Admin Game Uploader State (OPEN FILE / SELECT FOLDER -> Game Name, Title, Description -> Upload Game)
  const [newGameName, setNewGameName] = useState('');
  const [newGameTitle, setNewGameTitle] = useState('');
  const [newGameDesc, setNewGameDesc] = useState('');
  const [newGameFolder, setNewGameFolder] = useState('/admin-uploads/cyber-blaster-2d');
  const [newGameFilesCount, setNewGameFilesCount] = useState<number>(6);
  const [newGameEngine, setNewGameEngine] = useState<FismGameItem['engineType']>('customAdmin2D');
  const [newGameIsGreenScreen, setNewGameIsGreenScreen] = useState<boolean>(true);
  const [newGameChromaSensitivity, setNewGameChromaSensitivity] = useState<number>(56);
  const [newGameOverlayUrl, setNewGameOverlayUrl] = useState<string>('');
  const [newGameOverlayType, setNewGameOverlayType] = useState<'image' | 'video' | 'engine'>(
    'engine',
  );

  // AI Security & Anti-Hacking Guard State
  const [virtualWallsActive, setVirtualWallsActive] = useState({
    perimeterWall: true,
    codePatrolWall: true,
    databaseVaultWall: true,
  });
  const [securityScanning, setSecurityScanning] = useState(false);
  const [intrusionLogs, setIntrusionLogs] = useState<
    {
      id: string;
      timestamp: string;
      threatType: string;
      sourceIp: string;
      targetVector: string;
      actionTaken: string;
      quarantined: boolean;
    }[]
  >([
    {
      id: 'sec_1',
      timestamp: '15:18:42 IST',
      threatType: 'Brute-Force 3-Step Admin Lock Probe',
      sourceIp: '185.220.101.44 (External Tor Node)',
      targetVector: '/controlCore/adminFileVault',
      actionTaken: 'Blocked by Virtual Wall Alpha • Reported to Admin Panel',
      quarantined: true,
    },
    {
      id: 'sec_2',
      timestamp: '15:24:09 IST',
      threatType: 'Unauthorized Payload Injection Attempt',
      sourceIp: '103.145.12.88',
      targetVector: '/api/subscriptions/verify',
      actionTaken: 'Intercepted by AI Code Patrol • Signature Logged',
      quarantined: false,
    },
    {
      id: 'sec_3',
      timestamp: '15:26:55 IST',
      threatType: 'Suspicious Multi-Account Rate Spike (>3 Accounts)',
      sourceIp: '45.133.1.92',
      targetVector: 'Auth / OTP Verification Gate',
      actionTaken: 'Blocked at Perimeter Wall • OTP Challenge Enforced',
      quarantined: true,
    },
  ]);

  const handleRunAiSecurityPatrol = () => {
    setSecurityScanning(true);
    setTimeout(() => {
      setSecurityScanning(false);
      const nowStr = new Date().toLocaleTimeString();
      setIntrusionLogs((prev) => [
        {
          id: `sec_${Date.now()}`,
          timestamp: nowStr,
          threatType: 'AI Patrol Deep Code & Packet Audit Completed',
          sourceIp: 'Internal + External Perimeter Scan',
          targetVector: 'All 15 FISM App Modules & Firestore Rules',
          actionTaken: '0 Breaches • 3 Virtual Security Walls 100% Intact',
          quarantined: true,
        },
        ...prev,
      ]);
      onTriggerToast('AI Security Patrol completed: Virtual barriers active & 0 breaches!');
    }, 900);
  };

  // Long-Press User Full Data Modal
  const [inspectedUser, setInspectedUser] = useState<FismAdminUserDossier | null>(null);
  const longPressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const startLongPress = (dossier: FismAdminUserDossier) => {
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = setTimeout(() => {
      setInspectedUser(dossier);
      onTriggerToast(`Long-press unlocked full telemetry dossier for @${dossier.username}`);
    }, 450);
  };

  const cancelLongPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const allAppSectionsList: { id: FismScreen; label: string; desc: string }[] = [
    { id: 'flameFeed', label: 'Flame Feed (Home)', desc: 'Main timeline, stories & post composer' },
    { id: 'mainBlast', label: 'Main Blast (Videos)', desc: '8K cinema long-form video feed' },
    { id: 'quickBurst', label: 'Quick Burst (Shorts)', desc: '9:16 vertical short video feed' },
    { id: 'shoppingSection', label: 'Shopping Section (Store)', desc: '2–15 photos & 1 video marketplace' },
    { id: 'emberChat', label: 'Ember Chat (Personal Chat)', desc: 'Direct messaging, calling & Emoji Blast game' },
    { id: 'warmSparks', label: 'Warm Sparks (Notifications)', desc: 'Real-time activity & alert center' },
    { id: 'myHearth', label: 'My Hearth (Profile)', desc: 'Creator profile & multi-account switcher' },
    { id: 'onFire', label: 'On Fire (Live Broadcast)', desc: 'Real-time WebRTC live camera studio' },
    { id: 'circleFeed', label: 'Circle Feed (Subscribers)', desc: 'Exclusive subscriber-only feed' },
    { id: 'fuelUp', label: 'Fuel Up (Memberships)', desc: 'Creator subscription tiers' },
    { id: 'ashStash', label: 'Ash Stash (Saved)', desc: 'Bookmarked collections' },
    { id: 'findFlame', label: 'Find Flame (Search)', desc: 'Global discovery & hashtag search' },
    { id: 'flame3DArena', label: '3D & XR Spatial Arena', desc: 'Three.js Ember Cruiser & XR Blocks' },
    { id: 'aiWorkspaceHub', label: 'AI, Maps & Workspace Hub', desc: 'Gemini AI + Google Maps + Workspace' },
    { id: 'flameMaps', label: 'Flame Maps (Live GPS)', desc: 'Interactive Maps, Places & Daily Locate Pins' },
    { id: 'installApp', label: 'Install App (APK Hub)', desc: 'Official FISM Android APK Download' },
    { id: 'aiCloneStudio', label: 'AI Clone Studio', desc: 'Digital Avatar training, lip-sync & video export' },
    { id: 'communityChat', label: 'Community Chat', desc: 'Mutual-follower rooms & group video calls' },
    { id: 'controlCore', label: 'Control Core (Settings)', desc: 'Normal, Smart & Advanced settings' },
  ];

  // Render 3-Step Security Lock if not yet unlocked
  if (!unlocked) {
    return (
      <div className="max-w-lg mx-auto fism-card p-6 sm:p-8 space-y-5 border-2 border-[#FF5722]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl fism-gradient-flame text-white flex items-center justify-center shadow-lg">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold">Admin File — 3-Step Security Lock</h1>
              <p className="text-xs text-[#52607A]">
                Complete all 3 verification steps to unlock the confidential Admin File.
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full bg-[#FF5722] text-white text-xs font-extrabold">
            Step {lockStep} of 3
          </span>
        </div>

        {/* Step Progress Bar */}
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-2 rounded-full ${
                s <= lockStep ? 'fism-gradient-flame' : 'bg-[#D8E1F0] dark:bg-slate-800'
              }`}
            />
          ))}
        </div>

        {lockError && (
          <div className="p-3 rounded-xl bg-[#DC2626] text-white text-xs font-bold">
            {lockError}
          </div>
        )}

        {lockStep === 1 && (
          <div className="space-y-3">
            <label className="block text-xs font-extrabold uppercase text-[#52607A]">
              Stage 1: Confidential Admin Password Verification
            </label>
            <input
              type="password"
              value={step1Pin}
              onChange={(e) => setStep1Pin(e.target.value)}
              placeholder="Enter Confidential Admin Password..."
              className="w-full px-4 py-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-center text-lg font-mono font-extrabold tracking-widest"
            />
            <button
              onClick={() => {
                if (step1Pin.trim() === ADMIN_HARDCODED_PASSWORD) {
                  setLockError(null);
                  fetch('/api/admin/auth-step', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ step: 1, credential: step1Pin.trim() }),
                  }).catch(() => {});
                  setLockStep(2);
                  onTriggerToast('Stage 1 Password Verified! Proceed to Stage 2 OTP Verification.');
                } else {
                  setLockError(
                    '❌ गलत पासवर्ड! जब तक सही Admin Password नहीं डाला जाएगा, लॉक नहीं खुलेगा।',
                  );
                }
              }}
              className="w-full fism-btn-primary py-3 rounded-xl text-xs font-extrabold shadow-lg"
            >
              Verify Stage 1 Password →
            </button>
          </div>
        )}

        {lockStep === 2 && (
          <div className="space-y-3">
            <label className="block text-xs font-extrabold uppercase text-[#52607A]">
              Stage 2: Admin Mobile OTP Verification (+91-{adminOtpPhone})
            </label>
            <div className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between gap-2 flex-wrap">
              <div className="text-xs">
                <span className="text-[#52607A] font-semibold">Registered Admin Number: </span>
                <span className="font-mono font-extrabold text-[#FF5722]">
                  +91 {adminOtpPhone}
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  const newOtp = String(Math.floor(100000 + Math.random() * 900000));
                  setGeneratedStage2Otp(newOtp);
                  setLockError(null);
                  const smsMsg = `📩 SMS Delivered to +91-${adminOtpPhone}: Your FISM Admin File OTP is ${newOtp}`;
                  setOtpSentBanner(smsMsg);
                  fetch('/api/admin/send-otp', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ phone: adminOtpPhone, otp: newOtp }),
                  }).catch(() => {});
                  onTriggerToast(smsMsg);
                }}
                className="px-3.5 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-extrabold shadow"
              >
                📲 Send OTP to {adminOtpPhone}
              </button>
            </div>

            {otpSentBanner && (
              <div className="p-3 rounded-xl bg-emerald-950/90 border border-emerald-500 text-emerald-200 text-xs font-mono font-bold">
                {otpSentBanner}
              </div>
            )}

            <input
              type="text"
              value={step2Pattern}
              onChange={(e) => setStep2Pattern(e.target.value)}
              placeholder={`Enter 6-Digit OTP sent to ${adminOtpPhone}...`}
              className="w-full px-4 py-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-center text-base font-mono font-extrabold tracking-widest"
            />
            <button
              onClick={() => {
                if (generatedStage2Otp && step2Pattern.trim() === generatedStage2Otp) {
                  setLockError(null);
                  fetch('/api/admin/auth-step', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ step: 2, credential: step2Pattern.trim() }),
                  }).catch(() => {});
                  setLockStep(3);
                  onTriggerToast(`Stage 2 OTP Verified on +91-${adminOtpPhone}!`);
                } else if (!generatedStage2Otp) {
                  setLockError(
                    `⚠️ पहले "Send OTP to ${adminOtpPhone}" बटन पर क्लिक करके OTP मंगवाएं।`,
                  );
                } else {
                  setLockError(
                    `❌ गलत OTP! कृपया +91-${adminOtpPhone} पर आया हुआ सही 6-अंकों का OTP डालें।`,
                  );
                }
              }}
              className="w-full fism-btn-primary py-3 rounded-xl text-xs font-extrabold shadow-lg"
            >
              Verify Stage 2 OTP →
            </button>
          </div>
        )}

        {lockStep === 3 && (
          <div className="space-y-3">
            <label className="block text-xs font-extrabold uppercase text-[#52607A]">
              Stage 3: Final Admin Password Confirmation
            </label>
            <input
              type="password"
              value={step3MasterKey}
              onChange={(e) => setStep3MasterKey(e.target.value)}
              placeholder="Re-enter Confidential Admin Password to Unlock..."
              className="w-full px-4 py-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-center text-base font-mono font-extrabold tracking-widest"
            />
            <button
              onClick={() => {
                if (step3MasterKey.trim() === ADMIN_HARDCODED_PASSWORD) {
                  setLockError(null);
                  fetch('/api/admin/auth-step', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ step: 3, credential: step3MasterKey.trim() }),
                  }).catch(() => {});
                  onUnlockSuccess();
                  onTriggerToast('3-Step Admin Authentication Verified! Admin File is now OPEN.');
                } else {
                  setLockError(
                    '❌ गलत पासवर्ड! जब तक सही Admin Password नहीं डाला जाएगा, लॉक नहीं खुलेगा।',
                  );
                }
              }}
              className="w-full fism-btn-primary py-3 rounded-xl text-xs font-extrabold shadow-lg"
            >
              Unlock Admin File 🔓
            </button>
          </div>
        )}
      </div>
    );
  }

  // Unlocked Admin File Interface
  const bannedCount = userDossiers.filter((u) => u.isBanned).length;
  const activeCount = userDossiers.length - bannedCount;

  return (
    <div className="space-y-6">
      {/* Top Admin File Header */}
      <div className="fism-card p-5 border-2 border-[#7C3AED] flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl fism-gradient-royal text-white flex items-center justify-center shadow-lg">
            <Unlock className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-extrabold">Admin File Vault (एडमिन फाइल)</h1>
              <span className="px-2.5 py-0.5 rounded-full bg-[#16A34A] text-white text-[10px] font-extrabold uppercase">
                3-Step Lock Open • Live Data
              </span>
            </div>
            <p className="text-xs text-[#52607A]">
              Live ID Ban/Unban, Per-User Tracking Folders &amp; Encrypted ID Vault, USB OTG/PC
              Backup, Per-Section Premium &amp; 108-Layer AI Defense.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setExportBackupOpen(true)}
            className="ml-2 px-4 py-2.5 min-h-[44px] rounded-xl bg-gradient-to-r from-[#2563EB] to-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-2 shadow-lg hover:brightness-110 transition-all"
          >
            <HardDriveDownload className="w-4 h-4" /> Export / Transfer Data (USB OTG / PC)
          </button>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap bg-[#F3F6FC] dark:bg-slate-800 p-1.5 rounded-xl">
          <button
            onClick={() => setAdminTab('upiNotifications')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'upiNotifications'
                ? 'bg-gradient-to-r from-[#FF5722] to-[#E53935] text-white shadow-lg'
                : 'text-[#FF5722] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            <Bell className="w-4 h-4" /> 🔔 Notifications (UPI &amp; $500 Withdrawals)
            {upiRequests.filter((r) => r.status === 'pending').length +
              withdrawalRequests.filter((w) => w.status === 'pending').length >
              0 && (
              <span className="px-2 py-0.5 rounded-full bg-white text-[#E53935] text-[10px] font-black">
                {upiRequests.filter((r) => r.status === 'pending').length +
                  withdrawalRequests.filter((w) => w.status === 'pending').length}
              </span>
            )}
          </button>
          <button
            onClick={() => setAdminTab('trackingFolders')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'trackingFolders'
                ? 'bg-gradient-to-r from-[#2563EB] to-[#7C3AED] text-white shadow-lg'
                : 'text-[#2563EB] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            <FolderOpen className="w-4 h-4" /> 📁 User Folders &amp; Encrypted IDs
          </button>
          <button
            onClick={() => setAdminTab('upiSetup')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'upiSetup'
                ? 'bg-[#FF5722] text-white shadow'
                : 'text-[#52607A] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            <QrCode className="w-4 h-4" /> 💳 UPI &amp; QR Code Setup
          </button>
          <button
            onClick={() => setAdminTab('profiles')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all ${
              adminTab === 'profiles'
                ? 'fism-btn-primary shadow'
                : 'text-[#52607A] hover:text-[#172033]'
            }`}
          >
            User Profiles (Ban/Unban)
          </button>
          <button
            onClick={() => setAdminTab('premium')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'premium'
                ? 'bg-[#F59E0B] text-white shadow'
                : 'text-[#52607A] hover:text-[#172033]'
            }`}
          >
            <Crown className="w-4 h-4" /> Premium Controller
          </button>
          <button
            onClick={() => setAdminTab('aiSecurityGuard')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'aiSecurityGuard'
                ? 'bg-[#16A34A] text-white shadow'
                : 'text-[#52607A] hover:text-[#172033]'
            }`}
          >
            <ShieldAlert className="w-4 h-4" /> 🛡️ 108-Layer AI Security
          </button>
          <button
            onClick={() => setAdminTab('gameUploader')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'gameUploader'
                ? 'bg-[#7C3AED] text-white shadow'
                : 'text-[#52607A] hover:text-[#172033]'
            }`}
          >
            <Gamepad2 className="w-4 h-4" /> Game Uploader (गेम अपलोड)
          </button>
          <button
            onClick={() => setAdminTab('model3DUploader')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'model3DUploader'
                ? 'bg-gradient-to-r from-[#FF5722] to-[#7C3AED] text-white shadow'
                : 'text-[#52607A] hover:text-[#172033]'
            }`}
          >
            <Sparkles className="w-4 h-4" /> 🎭 3D Models Upload ({4 + custom3DModels.length})
          </button>
          <button
            onClick={() => setAdminTab('appLogoChanger')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'appLogoChanger'
                ? 'bg-gradient-to-r from-[#E53935] to-[#FFB300] text-white shadow-lg'
                : 'text-[#52607A] hover:text-[#172033]'
            }`}
          >
            <ImageIcon className="w-4 h-4" /> 🖼️ App Logo Change (FISM फोटो बदलें)
          </button>
          <button
            onClick={() => setAdminTab('otpSettings')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'otpSettings'
                ? 'bg-[#16A34A] text-white shadow-lg'
                : 'text-[#52607A] hover:text-[#172033]'
            }`}
          >
            📲 Change OTP Verification ({adminOtpPhone})
          </button>
          <button
            onClick={() => setAdminTab('aiFilterStudio')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'aiFilterStudio'
                ? 'bg-gradient-to-r from-[#00F5D4] to-[#7C3AED] text-slate-950 shadow-lg'
                : 'text-[#52607A] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            <Wand2 className="w-4 h-4" /> 🎨 AI Filter Studio ({publishedArFilters.length})
          </button>
          <button
            onClick={() => setAdminTab('copyrightProtection')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'copyrightProtection'
                ? 'bg-[#DC2626] text-white shadow-lg'
                : 'text-[#DC2626] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" /> 🛡️ Copyright &amp; Appeals (
            {copyrightViolations.filter((v) => v.status === 'APPEAL_PENDING').length})
          </button>
          <button
            onClick={() => setAdminTab('liveCreatorAccess')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'liveCreatorAccess'
                ? 'bg-gradient-to-r from-[#FF5722] to-[#7C3AED] text-white shadow-lg'
                : 'text-[#7C3AED] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            <Radio className="w-4 h-4" /> 🎙️ Live Creator Access (
            {liveCreatorUsers.filter((u) => u.canAccessLiveCreatorChat).length})
          </button>
          <button
            onClick={() => setAdminTab('officialAds')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'officialAds'
                ? 'bg-gradient-to-r from-[#FF5722] to-[#F59E0B] text-white shadow-lg'
                : 'text-[#FF5722] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            📢 Official Ads &amp; AdsTerra ({smartAds.filter((a) => a.source === 'official').length})
          </button>
          <button
            onClick={() => setAdminTab('apkRelease')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'apkRelease'
                ? 'bg-gradient-to-r from-[#16A34A] to-[#0D9488] text-white shadow-lg'
                : 'text-[#16A34A] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            <Download className="w-4 h-4" /> 📲 APK Upload (Single Slot)
          </button>
          <button
            onClick={() => setAdminTab('surveyBoard')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'surveyBoard'
                ? 'bg-[#2563EB] text-white shadow'
                : 'text-[#52607A] hover:text-[#172033]'
            }`}
          >
            <Trophy className="w-4 h-4" /> 📊 Survey &amp; Data Board
          </button>
          <button
            onClick={() => setAdminTab('founderGifts')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              adminTab === 'founderGifts'
                ? 'bg-gradient-to-r from-[#DC2626] to-[#991B1B] text-white shadow-lg'
                : 'text-[#DC2626] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            🎁 Red Card Founder Gifts ({founderGiftClaims.length})
          </button>
        </div>
      </div>

      {/* USB OTG Pen Drive / Computer Backup Export Modal */}
      <FismAdminExportBackupModal
        open={exportBackupOpen}
        onClose={() => setExportBackupOpen(false)}
        onTriggerToast={onTriggerToast}
      />

      {/* ADMIN PER-USER TRACKING FOLDERS & ENCRYPTED 18+ ID VAULT */}
      {adminTab === 'trackingFolders' && (
        <FismAdminTrackingFoldersBoard
          onTriggerToast={onTriggerToast}
          onOpenExportModal={() => setExportBackupOpen(true)}
        />
      )}

      {/* ADMIN OFFICIAL ADS BROADCAST TAB (Long Video Ads, Quick Burst Short Ads, Banner Ads) */}
      {adminTab === 'officialAds' && (
        <div className="space-y-6">
          <div className="fism-card p-5 bg-gradient-to-r from-[#101426] via-[#1E1B4B] to-[#31102F] text-white border-2 border-[#FF5722] flex items-center justify-between flex-wrap gap-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full bg-[#FF5722] text-white text-[10px] font-black uppercase">
                Platform Owner Ads Broadcast
              </span>
              <h2 className="text-lg sm:text-xl font-black mt-1">
                📢 Official Ads Studio — Long Video, Quick Burst &amp; Banner Ads
              </h2>
              <p className="text-xs text-slate-300 mt-0.5">
                Publish Official Platform Ads across Main Blast (15s Mid-Roll), Quick Burst Vertical
                Shorts, and Flame Feed Banners.
              </p>
            </div>
            <span className="px-3 py-1 rounded-xl bg-[#16A34A]/20 border border-[#16A34A] text-[#4ADE80] text-xs font-extrabold">
              {smartAds.filter((a) => a.isActive).length} Live Campaigns Active
            </span>
          </div>

          {/* LIVE ADSTERRA ORIGINAL-SIZE BANNER & NATIVE BANNER CONFIGURATION */}
          <div className="fism-card p-5 space-y-4 border-2 border-[#16A34A]/60">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3 className="font-extrabold text-sm sm:text-base flex items-center gap-2">
                  🌐 AdsTerra Live Banner &amp; Native Banner Tag Setup (Original IAB Sizes)
                </h3>
                <p className="text-xs text-[#52607A]">
                  Paste your real AdsTerra Banner (320×50 / 468×60 / 728×90 / 300×250) and Native
                  Banner scripts here. Real AdsTerra ads render unclipped without FISM promo covers.
                </p>
              </div>
              <label className="inline-flex items-center gap-2 text-xs font-extrabold cursor-pointer">
                <input
                  type="checkbox"
                  checked={adEnabledDraft}
                  onChange={(e) => setAdEnabledDraft(e.target.checked)}
                />
                AdsTerra Master ON
              </label>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Banner Ad Config (320x50) */}
              <div className="p-4 rounded-2xl bg-[#F3F6FC] dark:bg-slate-800/80 border border-[#D8E1F0] dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-[#FF5722]">
                    1. Banner Ad (320×50 / IAB)
                  </span>
                  <label className="inline-flex items-center gap-1.5 text-[11px] font-bold">
                    <input
                      type="checkbox"
                      checked={bannerEnabledDraft}
                      onChange={(e) => setBannerEnabledDraft(e.target.checked)}
                    />
                    Enabled
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <select
                    value={bannerSizeDraft}
                    onChange={(e) => setBannerSizeDraft(e.target.value as FismBannerOriginalSize)}
                    aria-label="AdsTerra Banner Original Size"
                    className="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                  >
                    <option value="320x50">320×50 Mobile Banner</option>
                    <option value="468x60">468×60 Full Banner</option>
                    <option value="728x90">728×90 Leaderboard</option>
                    <option value="300x250">300×250 Medium Rect</option>
                  </select>
                  <input
                    type="text"
                    value={bannerKeyDraft}
                    onChange={(e) => setBannerKeyDraft(e.target.value)}
                    placeholder="Banner atOptions.key"
                    className="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono"
                  />
                </div>
                <input
                  type="url"
                  value={bannerScriptUrlDraft}
                  onChange={(e) => setBannerScriptUrlDraft(e.target.value)}
                  placeholder="https://bicea.org/22/..."
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono"
                />

                <textarea
                  rows={3}
                  value={bannerRawHtmlDraft}
                  onChange={(e) => setBannerRawHtmlDraft(e.target.value)}
                  placeholder="Paste full 320x50 Banner <script> snippet..."
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-mono"
                />
                <button
                  type="button"
                  onClick={() => {
                    const parsed = extractAdsterraBannerFromSnippet(bannerRawHtmlDraft);
                    if (parsed.key) setBannerKeyDraft(parsed.key);
                    if (parsed.host) setBannerHostDraft(parsed.host);
                    if (parsed.scriptUrl) setBannerScriptUrlDraft(parsed.scriptUrl);
                    if (parsed.size) setBannerSizeDraft(parsed.size);
                    onTriggerToast(
                      parsed.key || parsed.scriptUrl
                        ? `Extracted Key & Size ${parsed.size || bannerSizeDraft}`
                        : 'Paste full AdsTerra Banner <script> snippet above to auto-extract.',
                    );
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#0F172A] text-white text-[11px] font-bold"
                >
                  Auto-Extract Banner Tag
                </button>
              </div>

              {/* Medium Rectangle Banner Ad Config (300x250) */}
              <div className="p-4 rounded-2xl bg-[#F3F6FC] dark:bg-slate-800/80 border border-[#D8E1F0] dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-[#2563EB]">
                    2. Banner Ad (300×250 Rect)
                  </span>
                  <label className="inline-flex items-center gap-1.5 text-[11px] font-bold">
                    <input
                      type="checkbox"
                      checked={rectBannerEnabledDraft}
                      onChange={(e) => setRectBannerEnabledDraft(e.target.checked)}
                    />
                    Enabled
                  </label>
                </div>

                <input
                  type="text"
                  value={rectBannerKeyDraft}
                  onChange={(e) => setRectBannerKeyDraft(e.target.value)}
                  placeholder="300x250 atOptions.key"
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono"
                />
                <input
                  type="url"
                  value={rectBannerScriptUrlDraft}
                  onChange={(e) => setRectBannerScriptUrlDraft(e.target.value)}
                  placeholder="https://bicea.org/22/..."
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono"
                />
                <textarea
                  rows={3}
                  value={rectBannerRawHtmlDraft}
                  onChange={(e) => setRectBannerRawHtmlDraft(e.target.value)}
                  placeholder="Paste full 300x250 Banner <script> snippet..."
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-mono"
                />
                <button
                  type="button"
                  onClick={() => {
                    const parsed = extractAdsterraBannerFromSnippet(rectBannerRawHtmlDraft);
                    if (parsed.key) setRectBannerKeyDraft(parsed.key);
                    if (parsed.scriptUrl) setRectBannerScriptUrlDraft(parsed.scriptUrl);
                    onTriggerToast(
                      parsed.key || parsed.scriptUrl
                        ? 'Extracted 300×250 Banner Key & Script!'
                        : 'Paste full 300×250 <script> snippet above to auto-extract.',
                    );
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#0F172A] text-white text-[11px] font-bold"
                >
                  Auto-Extract 300×250 Tag
                </button>
              </div>

              {/* Native Banner Ad Config */}
              <div className="p-4 rounded-2xl bg-[#F3F6FC] dark:bg-slate-800/80 border border-[#D8E1F0] dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-[#7C3AED]">
                    3. Native Banner (Auto-Height)
                  </span>
                  <label className="inline-flex items-center gap-1.5 text-[11px] font-bold">
                    <input
                      type="checkbox"
                      checked={nativeEnabledDraft}
                      onChange={(e) => setNativeEnabledDraft(e.target.checked)}
                    />
                    Enabled
                  </label>
                </div>

                <input
                  type="text"
                  value={nativeContainerIdDraft}
                  onChange={(e) => setNativeContainerIdDraft(e.target.value)}
                  placeholder="container-xxxxxxxxxxxxxxxx"
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono"
                />
                <input
                  type="url"
                  value={nativeScriptUrlDraft}
                  onChange={(e) => setNativeScriptUrlDraft(e.target.value)}
                  placeholder="https://bicea.org/21/..."
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono"
                />

                <textarea
                  rows={3}
                  value={nativeRawHtmlDraft}
                  onChange={(e) => setNativeRawHtmlDraft(e.target.value)}
                  placeholder='Paste full Native <script ...></script><div id="container-..."></div> snippet...'
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-mono"
                />
                <button
                  type="button"
                  onClick={() => {
                    const parsed = extractAdsterraNativeFromSnippet(nativeRawHtmlDraft);
                    if (parsed.scriptUrl) setNativeScriptUrlDraft(parsed.scriptUrl);
                    if (parsed.containerId) setNativeContainerIdDraft(parsed.containerId);
                    onTriggerToast(
                      parsed.scriptUrl || parsed.containerId
                        ? `Extracted Native Script & Container ${parsed.containerId || ''}`
                        : 'Paste full AdsTerra Native snippet above to auto-extract.',
                    );
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#0F172A] text-white text-[11px] font-bold"
                >
                  Auto-Extract Native Tag
                </button>
              </div>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <button
                type="button"
                disabled={savingAdsterra}
                onClick={async () => {
                  if (!onSaveAdsterraConfig) return;
                  setSavingAdsterra(true);
                  try {
                    await onSaveAdsterraConfig({
                      enabled: adEnabledDraft,
                      bannerEnabled: bannerEnabledDraft,
                      bannerKey: bannerKeyDraft.trim(),
                      bannerHost: bannerHostDraft.trim() || 'bicea.org',
                      bannerScriptUrl: bannerScriptUrlDraft.trim(),
                      bannerSize: bannerSizeDraft,
                      bannerRawHtml: bannerRawHtmlDraft.trim(),
                      rectBannerEnabled: rectBannerEnabledDraft,
                      rectBannerKey: rectBannerKeyDraft.trim(),
                      rectBannerScriptUrl: rectBannerScriptUrlDraft.trim(),
                      rectBannerRawHtml: rectBannerRawHtmlDraft.trim(),
                      nativeEnabled: nativeEnabledDraft,
                      nativeContainerId: nativeContainerIdDraft.trim(),
                      nativeScriptUrl: nativeScriptUrlDraft.trim(),
                      nativeRawHtml: nativeRawHtmlDraft.trim(),
                      updatedAt: new Date().toISOString(),
                    });
                  } finally {
                    setSavingAdsterra(false);
                  }
                }}
                className="px-5 py-2.5 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white text-xs font-extrabold shadow"
              >
                {savingAdsterra ? 'Saving AdsTerra...' : '💾 Save Live AdsTerra Config'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setBannerKeyDraft('');
                  setBannerScriptUrlDraft('');
                  setBannerRawHtmlDraft('');
                  setRectBannerKeyDraft('');
                  setRectBannerScriptUrlDraft('');
                  setRectBannerRawHtmlDraft('');
                  setNativeScriptUrlDraft('');
                  setNativeContainerIdDraft('');
                  setNativeRawHtmlDraft('');
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-bold"
              >
                Clear Draft Fields
              </button>
            </div>
          </div>

          <div className="fism-card p-5 space-y-4 border-2 border-[#7C3AED]/40">
            <h3 className="font-extrabold text-sm sm:text-base">
              ➕ Create &amp; Broadcast New Official Ad
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={offAdTitle}
                onChange={(e) => setOffAdTitle(e.target.value)}
                placeholder="Official Ad Headline (e.g. Official Gaming Championship Gear)..."
                className="px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              />
              <select
                value={offAdPlacement}
                onChange={(e) =>
                  setOffAdPlacement(e.target.value as import('../types').FismSmartAdPlacement)
                }
                aria-label="Official ad placement format"
                className="px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              >
                <option value="longVideo">🎬 Long Video Ad (Main Blast 15s Mid-Roll)</option>
                <option value="quickBurst">⚡ Quick Burst Short Ad (Vertical Interactive)</option>
                <option value="banner">🖼️ Banner Ad (Flame Feed 320x50 &amp; Native Slot)</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                type="url"
                value={offAdUrl}
                onChange={(e) => setOffAdUrl(e.target.value)}
                placeholder="Destination / Product URL..."
                className="sm:col-span-2 px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
              />
              <input
                type="text"
                value={offAdCta}
                onChange={(e) => setOffAdCta(e.target.value)}
                placeholder="CTA Button Label"
                className="px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={offAdDesc}
                onChange={(e) => setOffAdDesc(e.target.value)}
                placeholder="Official Ad Description..."
                className="px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
              />
              <input
                type="text"
                value={offAdTags}
                onChange={(e) => setOffAdTags(e.target.value)}
                placeholder="Interest tags: gaming, esports, tech, music..."
                className="px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
              />
            </div>

            <div className="flex items-center justify-between flex-wrap gap-3">
              <label className="px-3.5 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold cursor-pointer">
                {offAdIsVideo ? '✓ Official Ad Video Ready' : '📁 Upload Ad Video / Image Media'}
                <input
                  type="file"
                  accept="video/*,image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    setOffAdMediaUrl(URL.createObjectURL(f));
                    setOffAdIsVideo(f.type.startsWith('video/'));
                  }}
                />
              </label>
              <button
                type="button"
                onClick={async () => {
                  if (!offAdTitle.trim()) {
                    onTriggerToast('Enter an Official Ad Headline first.');
                    return;
                  }
                  const newOfficialAd: import('../types').FismSmartAdItem = {
                    id: `ad_official_${Date.now()}`,
                    source: 'official',
                    placement: offAdPlacement,
                    title: offAdTitle.trim(),
                    description:
                      offAdDesc.trim() || 'Official FISM Platform Sponsored Campaign.',
                    mediaUrl: offAdMediaUrl || GENERATED_ASSETS.studioThumb,
                    isVideo: offAdIsVideo,
                    productLinkUrl: offAdUrl.trim() || 'https://fism.shop',
                    ctaLabel: offAdCta.trim() || 'Explore Official Offer',
                    storePlatform: 'Official',
                    categoryTags: offAdTags
                      .split(',')
                      .map((t) => t.trim().toLowerCase())
                      .filter(Boolean),
                    creatorId: 'fism_official',
                    creatorUsername: 'fism_official',
                    creatorDisplayName: 'FISM Official Ads',
                    creatorAvatar: GENERATED_ASSETS.avatar1,
                    isActive: true,
                    impressions: 1,
                    clicks: 0,
                    likes: 0,
                    createdAt: 'Official Broadcast',
                  };
                  await onCreateSmartAd?.(newOfficialAd);
                  setOffAdTitle('');
                  setOffAdDesc('');
                }}
                className="fism-btn-primary px-5 py-2.5 rounded-xl text-xs font-extrabold shadow"
              >
                🚀 Broadcast Official Ad Live
              </button>
            </div>
          </div>

          <div className="fism-card p-5 space-y-3">
            <h3 className="font-extrabold text-sm">
              All Official &amp; Creator Ads Inventory ({smartAds.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {smartAds.map((ad) => (
                <div
                  key={ad.id}
                  className="p-3.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span
                        className={`px-2 py-0.5 rounded text-[9px] font-black uppercase text-white ${
                          ad.source === 'official' ? 'bg-[#FF5722]' : 'bg-[#7C3AED]'
                        }`}
                      >
                        {ad.source}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-slate-900 text-amber-300 text-[9px] font-extrabold uppercase">
                        {ad.placement}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[9px] font-extrabold ${
                          ad.isActive
                            ? 'bg-[#16A34A]/15 text-[#16A34A]'
                            : 'bg-red-500/15 text-[#DC2626]'
                        }`}
                      >
                        {ad.isActive ? 'ACTIVE' : 'PAUSED'}
                      </span>
                    </div>
                    <div className="font-extrabold text-xs truncate">{ad.title}</div>
                    <div className="text-[11px] text-[#52607A]">
                      @{ad.creatorUsername} • 👁️ {ad.impressions} • 🖱️ {ad.clicks} • ❤️{' '}
                      {ad.likes}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => onToggleSmartAd?.(ad.id)}
                      className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-[11px] font-extrabold"
                    >
                      {ad.isActive ? 'Pause' : 'Resume'}
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteSmartAd?.(ad.id)}
                      className="px-2.5 py-1.5 rounded-lg bg-red-500/15 text-[#DC2626] text-[11px] font-extrabold"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* COPYRIGHT PROTECTION, CONTENT ID FINGERPRINTING & CREATOR APPEALS TAB */}
      {adminTab === 'copyrightProtection' && (
        <div className="space-y-6">
          <div className="fism-card p-5 bg-gradient-to-r from-[#0F172A] via-[#3B0764] to-[#7F1D1D] text-white border-2 border-[#DC2626] flex items-center justify-between flex-wrap gap-4">
            <div>
              <span className="px-2.5 py-0.5 rounded bg-[#DC2626] text-white text-[10px] font-black uppercase">
                Content ID &amp; View-Blocking Enforcement
              </span>
              <h2 className="text-xl font-extrabold mt-1 flex items-center gap-2">
                <ShieldCheck className="w-6 h-6 text-[#FFB300]" /> Copyright Protection, Fingerprints
                &amp; Appeals Dashboard
              </h2>
              <p className="text-xs text-slate-200 mt-1 max-w-2xl">
                Every uploaded video is scanned via dual perceptual video &amp; audio-stride
                fingerprinting. Flagged videos are set to <strong>RESTRICTED_COPYRIGHT / BLOCKED</strong>{' '}
                with <strong>views locked to 0</strong> and suppressed from all feeds, search, and
                recommendations.
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs font-extrabold">
              <div className="px-3.5 py-2 rounded-xl bg-black/40 border border-white/15">
                Flagged Videos: {copyrightViolations.length}
              </div>
              <div className="px-3.5 py-2 rounded-xl bg-amber-500/20 border border-amber-400 text-amber-200">
                Pending Appeals:{' '}
                {copyrightViolations.filter((v) => v.status === 'APPEAL_PENDING').length}
              </div>
            </div>
          </div>

          {/* Violations & Appeals Queue */}
          <div className="fism-card p-5 space-y-4">
            <h3 className="font-extrabold text-base flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-[#DC2626]" /> Flagged Videos &amp; Creator
              Dispute Appeals
            </h3>
            {copyrightViolations.length === 0 ? (
              <div className="p-6 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 text-center text-xs font-bold text-[#52607A]">
                No copyright or unknown content violations detected yet. Upload a video with a
                protected keyword (e.g. &quot;t-series&quot;, &quot;pirated&quot;, &quot;reupload&quot;)
                or duplicate stream to test automatic Content ID enforcement.
              </div>
            ) : (
              <div className="space-y-3">
                {copyrightViolations.map((v) => (
                  <div
                    key={v.id}
                    className={`p-4 rounded-xl border-2 space-y-2.5 ${
                      v.status === 'RESTORED'
                        ? 'border-[#16A34A] bg-emerald-50/40 dark:bg-emerald-950/20'
                        : v.status === 'APPEAL_PENDING'
                          ? 'border-[#F59E0B] bg-amber-50/50 dark:bg-amber-950/20'
                          : 'border-[#DC2626] bg-red-50/40 dark:bg-red-950/20'
                    }`}
                  >
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-extrabold text-sm">{v.videoTitle}</span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase text-white ${
                              v.status === 'RESTORED'
                                ? 'bg-[#16A34A]'
                                : v.status === 'APPEAL_PENDING'
                                  ? 'bg-[#F59E0B]'
                                  : 'bg-[#DC2626]'
                            }`}
                          >
                            {v.status}
                          </span>
                          <span className="px-2 py-0.5 rounded bg-slate-900 text-white text-[10px] font-mono">
                            Views Locked: {v.viewsBlockedAt}
                          </span>
                        </div>
                        <div className="text-xs text-[#52607A] mt-0.5">
                          Uploader: <strong>@{v.uploaderUsername}</strong> • Confidence:{' '}
                          {Math.round(v.confidence * 100)}% • {v.createdAt}
                        </div>
                      </div>

                      {v.status !== 'RESTORED' && (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => onApproveCopyrightAppeal?.(v.id)}
                            className="px-3.5 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold shadow"
                          >
                            ✓ Approve &amp; Restore Video
                          </button>
                          <button
                            type="button"
                            onClick={() => onRejectCopyrightAppeal?.(v.id)}
                            className="px-3.5 py-2 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold shadow"
                          >
                            ✕ Keep Blocked
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="text-xs font-semibold text-[#172033] dark:text-slate-200">
                      Reason: {v.reason}
                    </div>
                    <div className="flex flex-wrap gap-2 text-[11px] font-mono text-[#52607A]">
                      <span>Video Hash: {v.videoFingerprint || 'N/A'}</span>
                      <span>•</span>
                      <span>Audio Hash: {v.audioFingerprint || 'N/A'}</span>
                    </div>

                    {v.appealProofText && (
                      <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-[#F59E0B] text-xs space-y-1">
                        <div className="font-extrabold text-[#F59E0B]">
                          📩 Creator Dispute / Ownership Proof ({v.appealSubmittedAt || 'Just now'}):
                        </div>
                        <p>{v.appealProofText}</p>
                        {v.appealProofFileName && (
                          <div className="text-[11px] font-mono text-[#2563EB]">
                            Attached Proof File: {v.appealProofFileName}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Register New Protected Asset */}
          <div className="fism-card p-5 space-y-4 border-2 border-[#7C3AED]">
            <h3 className="font-extrabold text-base">
              Register Protected Copyright Asset (Content ID Database)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input
                type="text"
                value={crAssetTitle}
                onChange={(e) => setCrAssetTitle(e.target.value)}
                placeholder="Protected Asset Title (e.g. Studio Master Track)"
                className="px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              />
              <input
                type="text"
                value={crRightsHolder}
                onChange={(e) => setCrRightsHolder(e.target.value)}
                placeholder="Rights Holder / Studio Name"
                className="px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              />
              <input
                type="text"
                value={crKeywords}
                onChange={(e) => setCrKeywords(e.target.value)}
                placeholder="Trigger Keywords (comma separated, e.g. my exclusive song, leaked)"
                className="px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              />
              <div className="flex items-center gap-2">
                <select
                  value={crAction}
                  onChange={(e) =>
                    setCrAction(e.target.value as 'RESTRICTED_COPYRIGHT' | 'BLOCKED')
                  }
                  className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                >
                  <option value="RESTRICTED_COPYRIGHT">RESTRICTED_COPYRIGHT</option>
                  <option value="BLOCKED">BLOCKED (Hard Block)</option>
                </select>
                <button
                  type="button"
                  onClick={() => {
                    if (!crAssetTitle.trim()) {
                      onTriggerToast('Enter protected asset title.');
                      return;
                    }
                    const newAsset: FismCopyrightAssetRecord = {
                      id: `cr_asset_${Date.now()}`,
                      title: crAssetTitle.trim(),
                      rightsHolder: crRightsHolder.trim() || 'FISM Verified Rights Holder',
                      videoHashPrefix: '',
                      audioHashPrefix: '',
                      keywords: crKeywords
                        .split(',')
                        .map((k) => k.trim().toLowerCase())
                        .filter(Boolean),
                      action: crAction,
                      createdAt: new Date().toLocaleDateString(),
                    };
                    onAddCopyrightAsset?.(newAsset);
                    setCrAssetTitle('');
                    setCrRightsHolder('');
                    setCrKeywords('');
                  }}
                  className="fism-btn-primary px-4 py-2.5 rounded-xl text-xs font-extrabold shrink-0"
                >
                  + Add Protected Asset
                </button>
              </div>
            </div>

            {copyrightAssets.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                {copyrightAssets.map((asset) => (
                  <div
                    key={asset.id}
                    className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-extrabold truncate">{asset.title}</span>
                      <span className="px-2 py-0.5 rounded bg-[#DC2626] text-white text-[10px] font-black shrink-0">
                        {asset.action}
                      </span>
                    </div>
                    <div className="text-[11px] text-[#52607A]">
                      Rights Holder: {asset.rightsHolder}
                    </div>
                    <div className="text-[10px] font-mono text-[#7C3AED] truncate">
                      Keywords: {asset.keywords.join(', ') || 'Hash-only'}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ADMIN-GATED LIVE CREATOR CHAT ACCESS MANAGEMENT TAB */}
      {adminTab === 'liveCreatorAccess' && (() => {
        const mergedUsersMap = new Map<string, FismLiveCreatorPermissionRecord>();
        liveCreatorUsers.forEach((u) => {
          mergedUsersMap.set(u.uid, u);
        });
        liveCreatorServerResults.forEach((su) => {
          const existing = mergedUsersMap.get(su.uid);
          if (!existing) {
            mergedUsersMap.set(su.uid, su);
          } else {
            mergedUsersMap.set(su.uid, {
              ...existing,
              canAccessLiveCreatorChat:
                existing.canAccessLiveCreatorChat || su.canAccessLiveCreatorChat,
              grantedAt: existing.grantedAt || su.grantedAt,
            });
          }
        });
        const qLower = liveCreatorSearchQuery.trim().toLowerCase();
        const filteredUsers = Array.from(mergedUsersMap.values()).filter((u) => {
          if (!qLower) return true;
          return (
            u.username.toLowerCase().includes(qLower) ||
            u.uid.toLowerCase().includes(qLower) ||
            u.displayName.toLowerCase().includes(qLower)
          );
        });

        return (
          <div className="space-y-5">
            <div className="fism-card p-5 bg-gradient-to-r from-[#1E1B4B] via-[#4C1D95] to-[#7C2D12] text-white border-2 border-[#7C3AED] flex items-center justify-between flex-wrap gap-4">
              <div>
                <span className="px-2.5 py-0.5 rounded bg-[#FFB300] text-slate-950 text-[10px] font-black uppercase">
                  Admin-Gated VIP Permission Control
                </span>
                <h2 className="text-xl font-extrabold mt-1 flex items-center gap-2">
                  <Radio className="w-6 h-6 text-[#FFB300]" /> Live Creator Chat — User Search &amp;
                  Access Unlock
                </h2>
                <p className="text-xs text-slate-200 mt-1 max-w-2xl">
                  The <strong>Live Creator Chat</strong> section is completely hidden and locked for
                  all regular users by default. Search any user by <strong>username</strong> or{' '}
                  <strong>User ID (UID)</strong> below and click <strong>Add</strong> to unlock the
                  exclusive Live Creator Chat room &amp; group video calling on their interface in
                  real time.
                </p>
              </div>
              <div className="px-4 py-2.5 rounded-xl bg-black/40 border border-white/15 text-xs font-extrabold">
                Unlocked Creators:{' '}
                <span className="text-[#00F5D4]">
                  {
                    Array.from(mergedUsersMap.values()).filter((u) => u.canAccessLiveCreatorChat)
                      .length
                  }
                </span>
              </div>
            </div>

            <div className="fism-card p-5 space-y-4">
              <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-[#52607A] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={liveCreatorSearchQuery}
                    onChange={(e) => setLiveCreatorSearchQuery(e.target.value)}
                    placeholder="Search registered user by @username, display name, or User ID (UID)..."
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#7C3AED]"
                  />
                </div>
                {liveCreatorSearchQuery && (
                  <button
                    onClick={() => setLiveCreatorSearchQuery('')}
                    className="px-4 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 text-xs font-extrabold"
                  >
                    Clear Search
                  </button>
                )}
              </div>

              {filteredUsers.length === 0 ? (
                <div className="p-8 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 text-center text-xs font-bold text-[#52607A]">
                  No registered user matched &quot;{liveCreatorSearchQuery}&quot;. Try searching
                  another username or UID.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredUsers.map((userRec) => {
                    const isGranted = Boolean(userRec.canAccessLiveCreatorChat);
                    return (
                      <div
                        key={userRec.uid}
                        className={`p-4 rounded-xl border-2 flex items-center justify-between gap-3 transition-all ${
                          isGranted
                            ? 'border-[#16A34A] bg-emerald-50/50 dark:bg-emerald-950/20'
                            : 'border-[#D8E1F0] dark:border-slate-700 bg-white dark:bg-slate-900'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={userRec.avatarUrl || GENERATED_ASSETS.avatar1}
                            alt={userRec.displayName}
                            className="w-11 h-11 rounded-full object-cover ring-2 ring-[#7C3AED]/40 shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-extrabold text-sm truncate">
                                {userRec.displayName}
                              </span>
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                                  isGranted
                                    ? 'bg-[#16A34A] text-white'
                                    : 'bg-slate-200 dark:bg-slate-700 text-[#52607A] dark:text-slate-300'
                                }`}
                              >
                                {isGranted ? 'Unlocked' : 'Hidden'}
                              </span>
                            </div>
                            <div className="text-xs text-[#52607A] truncate">
                              @{userRec.username} • ID: <span className="font-mono">{userRec.uid}</span>
                            </div>
                            {userRec.grantedAt && isGranted && (
                              <div className="text-[10px] text-[#16A34A] font-bold mt-0.5">
                                Added: {userRec.grantedAt}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="shrink-0 flex items-center gap-2">
                          {isGranted ? (
                            <button
                              onClick={() => onGrantLiveCreatorAccess?.(userRec, false)}
                              className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold transition-all"
                            >
                              Revoke
                            </button>
                          ) : (
                            <button
                              onClick={() => onGrantLiveCreatorAccess?.(userRec, true)}
                              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF5722] to-[#7C3AED] hover:opacity-95 text-white text-xs font-extrabold shadow flex items-center gap-1.5 transition-all"
                            >
                              <UserPlus className="w-3.5 h-3.5" /> Add
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* YEAR 5+ RED CARD FOUNDER SURPRISE GIFTS & MERCH FULFILLMENT */}
      {adminTab === 'founderGifts' && (
        <div className="space-y-4">
          <div className="fism-card p-5 bg-gradient-to-r from-[#160508] via-[#450A0A] to-[#7F1D1D] text-white border-2 border-[#EF4444]">
            <h2 className="text-lg sm:text-xl font-black flex items-center gap-2">
              🎁 Year 5+ Ultimate Red Card — Founder Surprise Gifts &amp; Merch Fulfillment
            </h2>
            <p className="text-xs text-red-100 mt-1">
              Approve and mark exclusive Red Card veteran merchandise claims as Shipped directly from
              Founder &amp; Admin HQ.
            </p>
          </div>

          {founderGiftClaims.length === 0 ? (
            <div className="fism-card p-6 text-center text-xs font-bold text-[#52607A]">
              No Year 5+ Red Card Founder Gift claims submitted yet.
            </div>
          ) : (
            <div className="space-y-3">
              {founderGiftClaims.map((claim) => (
                <div
                  key={claim.id}
                  className="fism-card p-4 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between gap-3 flex-wrap"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-black text-sm">{claim.displayName}</span>
                      <span className="text-xs text-[#52607A]">@{claim.username}</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          claim.status === 'shipped'
                            ? 'bg-[#16A34A]/15 text-[#16A34A]'
                            : claim.status === 'approved'
                              ? 'bg-[#2563EB]/15 text-[#2563EB]'
                              : 'bg-[#F59E0B]/15 text-[#D97706]'
                        }`}
                      >
                        {claim.status}
                      </span>
                    </div>
                    <div className="text-xs font-bold text-[#EF4444]">{claim.giftItem}</div>
                    {claim.shippingNote && (
                      <div className="text-[11px] text-[#52607A]">Note: {claim.shippingNote}</div>
                    )}
                    <div className="text-[10px] text-[#52607A]">Claimed: {claim.claimedAt}</div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {claim.status === 'pending' && (
                      <button
                        type="button"
                        onClick={() =>
                          void onRespondFounderGift?.(claim.id, 'approved', 'Approved by Founder')
                        }
                        className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-[#2563EB] text-white text-xs font-black"
                      >
                        Approve
                      </button>
                    )}
                    {claim.status !== 'shipped' && (
                      <button
                        type="button"
                        onClick={() =>
                          void onRespondFounderGift?.(claim.id, 'shipped', 'Dispatched via FISM VIP Courier')
                        }
                        className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-black"
                      >
                        Mark Shipped 📦
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ADMIN SINGLE-SLOT APK UPLOADER & INSTALL SECTION CONTROL */}
      {adminTab === 'apkRelease' && (
        <div className="fism-card p-6 border-2 border-[#16A34A] space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <span className="px-2.5 py-0.5 rounded bg-[#16A34A] text-white text-[10px] font-black uppercase">
                Single-Slot Android APK Release
              </span>
              <h2 className="text-xl font-extrabold mt-1 flex items-center gap-2">
                <Download className="w-5 h-5 text-[#16A34A]" /> Official FISM APK Upload (Only 1
                Active APK Allowed)
              </h2>
              <p className="text-xs text-[#52607A]">
                Admin यहाँ App Name, Version और Details डालकर 1 Official <code>.apk</code> फ़ाइल
                अपलोड कर सकता है। वही APK पूरे ऐप के Install Button / Install Section में दिखेगा;
                नया APK डालने पर पुराना ऑटोमैटिक Replace हो जाएगा।
              </p>
            </div>
          </div>

          {apkRelease && (
            <div className="p-4 rounded-2xl bg-[#F0FDF4] dark:bg-emerald-950/30 border-2 border-[#16A34A] flex items-center justify-between flex-wrap gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2 py-0.5 rounded bg-[#16A34A] text-white text-[10px] font-black uppercase">
                    ACTIVE LIVE APK
                  </span>
                  <span className="font-extrabold text-sm">{apkRelease.appName}</span>
                  <span className="text-xs font-mono font-bold text-[#16A34A]">
                    v{apkRelease.version}
                  </span>
                </div>
                <p className="text-xs text-[#52607A] dark:text-slate-300">{apkRelease.details}</p>
                <div className="text-[11px] font-mono text-[#52607A]">
                  File: {apkRelease.fileName} •{' '}
                  {(apkRelease.sizeBytes / (1024 * 1024)).toFixed(2)} MB • Package:{' '}
                  {apkRelease.packageName} • Uploaded: {apkRelease.uploadedAt}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={apkRelease.downloadUrl}
                  download={apkRelease.fileName}
                  className="px-3.5 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold inline-flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" /> Test Download
                </a>
                <button
                  type="button"
                  onClick={() => void onDeleteApkRelease?.()}
                  className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold inline-flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Remove APK
                </button>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-extrabold mb-1">App Name</label>
              <input
                type="text"
                value={apkAppName}
                onChange={(e) => setApkAppName(e.target.value)}
                placeholder="FISM — Flame Social"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-extrabold mb-1">Version</label>
              <input
                type="text"
                value={apkVersion}
                onChange={(e) => setApkVersion(e.target.value)}
                placeholder="2.4.0"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-extrabold mb-1">
              Release Details &amp; Highlights
            </label>
            <textarea
              rows={3}
              value={apkDetails}
              onChange={(e) => setApkDetails(e.target.value)}
              placeholder="What's new in this APK build..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
            />
          </div>

          <div className="flex items-center justify-between flex-wrap gap-3">
            <label className="px-4 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border-2 border-dashed border-[#16A34A] text-xs font-extrabold cursor-pointer flex items-center gap-2">
              <Upload className="w-4 h-4 text-[#16A34A]" />
              {apkFileName
                ? `Selected: ${apkFileName} (${(apkSizeBytes / (1024 * 1024)).toFixed(2)} MB)`
                : 'Choose Single .APK File'}
              <input
                type="file"
                accept=".apk,application/vnd.android.package-archive"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  if (!f.name.toLowerCase().endsWith('.apk')) {
                    onTriggerToast('केवल .apk फ़ाइल ही अपलोड की जा सकती है!');
                    return;
                  }
                  setApkFileName(f.name);
                  setApkSizeBytes(f.size);
                  const reader = new FileReader();
                  reader.onload = () => {
                    const res = typeof reader.result === 'string' ? reader.result : '';
                    const b64 = res.includes(',') ? res.split(',')[1] : res;
                    setApkBase64Data(b64);
                    onTriggerToast(`APK Ready: ${f.name}`);
                  };
                  reader.readAsDataURL(f);
                }}
              />
            </label>

            <button
              type="button"
              disabled={apkUploading || !apkBase64Data}
              onClick={async () => {
                if (!onUploadApkRelease || !apkBase64Data) {
                  onTriggerToast('कृपया पहले एक .apk फ़ाइल चुनें।');
                  return;
                }
                setApkUploading(true);
                try {
                  await onUploadApkRelease({
                    appName: apkAppName.trim() || 'FISM — Flame Social',
                    version: apkVersion.trim() || '1.0.0',
                    details: apkDetails.trim() || 'Official FISM Android Release',
                    fileName: apkFileName || 'FISM_Flame_Official.apk',
                    sizeBytes: apkSizeBytes,
                    base64Data: apkBase64Data,
                  });
                  setApkFileName('');
                  setApkSizeBytes(0);
                  setApkBase64Data('');
                } finally {
                  setApkUploading(false);
                }
              }}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#16A34A] to-[#0D9488] text-white text-xs font-extrabold shadow-lg disabled:opacity-50"
            >
              {apkUploading
                ? 'Uploading & Replacing APK...'
                : apkRelease
                  ? '🔄 Replace Active APK (Single Slot)'
                  : '🚀 Publish Official APK to Install Section'}
            </button>
          </div>
        </div>
      )}

      {/* ADMIN OTP VERIFICATION NUMBER CHANGER TAB */}
      {adminTab === 'otpSettings' && (
        <div className="fism-card p-6 border-2 border-[#16A34A] space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <span className="px-2.5 py-0.5 rounded bg-[#16A34A] text-white text-[10px] font-extrabold uppercase">
                Stage 2 OTP Security Control
              </span>
              <h2 className="text-xl font-extrabold mt-1">
                📲 Change Admin OTP Verification Mobile Number
              </h2>
              <p className="text-xs text-[#52607A]">
                Default Admin OTP number is <strong>8235286811</strong>. You can update the mobile
                number here so future Stage 2 Admin File OTPs are sent to your new number.
              </p>
            </div>
            <div className="px-4 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono font-extrabold">
              Active OTP Number: <span className="text-[#16A34A]">+91-{adminOtpPhone}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
            <div className="sm:col-span-2">
              <label className="block text-xs font-extrabold mb-1">
                New Admin OTP Mobile Number (10 Digits)
              </label>
              <input
                type="tel"
                value={newOtpPhoneDraft}
                onChange={(e) => setNewOtpPhoneDraft(e.target.value)}
                placeholder="Enter 10-digit mobile number (e.g. 8235286811)..."
                className="w-full px-4 py-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm font-mono font-extrabold"
              />
            </div>
            <button
              type="button"
              onClick={() => {
                const clean = newOtpPhoneDraft.replace(/[^0-9]/g, '').trim();
                if (clean.length < 10) {
                  onTriggerToast('⚠️ कृपया कम से कम 10 अंकों का सही मोबाइल नंबर दर्ज करें।');
                  return;
                }
                setAdminOtpPhone(clean);
                setNewOtpPhoneDraft(clean);
                try {
                  localStorage.setItem('fism_admin_otp_phone', clean);
                } catch {
                  // ignore
                }
                fetch('/api/admin/update-otp-phone', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ newPhone: clean }),
                }).catch(() => {});
                onTriggerToast(
                  `✅ Admin OTP Verification Number updated to +91-${clean}!`,
                );
              }}
              className="fism-btn-primary py-3 px-5 rounded-xl text-xs font-extrabold shadow-lg"
            >
              Save New OTP Number
            </button>
          </div>
        </div>
      )}

      {/* ADMIN DASHBOARD LIVE STATISTICS GRID */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2.5">
        {[
          { label: 'Total Users', value: userDossiers.length, color: 'text-[#2563EB]' },
          { label: 'Active Users', value: activeCount, color: 'text-[#16A34A]' },
          { label: 'Banned Users', value: bannedCount, color: 'text-[#DC2626]' },
          { label: 'Premium Users', value: globalPremiumOn ? userDossiers.length : 2, color: 'text-[#F59E0B]' },
          { label: 'Total Videos', value: 142, color: 'text-[#FF5722]' },
          { label: 'Total Shorts', value: 318, color: 'text-[#7C3AED]' },
          { label: 'Total Posts', value: 520, color: 'text-[#2563EB]' },
          { label: 'Total Uploads', value: 980, color: 'text-[#16A34A]' },
          { label: 'Total Products', value: 64, color: 'text-[#FF5722]' },
          { label: 'Total Messages', value: '14.8K', color: 'text-[#7C3AED]' },
          { label: 'Reported Accounts', value: bannedCount, color: 'text-[#DC2626]' },
          { label: 'Security Alerts', value: intrusionLogs.length, color: 'text-[#F59E0B]' },
        ].map((stat) => (
          <div key={stat.label} className="fism-card p-3 text-center">
            <div className={`text-lg font-black font-mono ${stat.color}`}>{stat.value}</div>
            <div className="text-[10px] font-extrabold uppercase text-[#52607A] mt-0.5">
              {stat.label}
            </div>
          </div>
        ))}
      </div>

      {/* TAB: AI FILTER CREATOR STUDIO + LIVE SANDBOX + ONE-CLICK PUBLISH */}
      {adminTab === 'aiFilterStudio' && (
        <div className="space-y-5">
          <FismAdminSmartFilterBuilder
            gamesList={gamesList}
            publishedStudioFilters={publishedStudioFilters}
            onPublishStudioFilter={(flt) => onPublishStudioFilter?.(flt)}
            onDeleteStudioFilter={(id) => onDeleteStudioFilter?.(id)}
            onTriggerToast={onTriggerToast}
          />

          <div className="fism-card p-6 border-2 border-[#00F5D4] space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-[#00F5D4] text-slate-950 text-[10px] font-black uppercase">
                  Gemini AI Filter Synthesizer + Live AR Sandbox
                </span>
                <h2 className="text-xl font-extrabold mt-1 flex items-center gap-2">
                  <Wand2 className="w-5 h-5 text-[#7C3AED]" /> AI Filter Creator Studio (AR &amp; Shaders)
                </h2>
                <p className="text-xs text-[#52607A]">
                  Type any AR filter idea, generate it with Gemini AI, test alignment live on your
                  camera in the Sandbox, and click <strong>Upload &amp; Publish Filter</strong> to sync
                  instantly to all users&apos; Shorts Camera &amp; Video Calls.
                </p>
              </div>
              <span className="px-3 py-1 rounded-xl bg-[#7C3AED]/15 text-[#7C3AED] text-xs font-extrabold">
                {publishedArFilters.length} Filters Synced Live
              </span>
            </div>

            {/* Prompt Input & Generate Button */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <input
                type="text"
                value={aiFilterPromptInput}
                onChange={(e) => setAiFilterPromptInput(e.target.value)}
                placeholder='Describe AR filter (e.g., "Add glowing cyberpunk sunglasses on the face")...'
                className="sm:col-span-9 px-4 py-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs sm:text-sm font-bold"
              />
              <button
                type="button"
                disabled={aiFilterGenerating}
                onClick={handleGenerateAiFilter}
                className="sm:col-span-3 fism-btn-primary py-3 px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 shadow-lg disabled:opacity-60"
              >
                <Sparkles className={`w-4 h-4 ${aiFilterGenerating ? 'animate-spin' : ''}`} />
                {aiFilterGenerating ? 'Synthesizing...' : 'Generate Filter with AI'}
              </button>
            </div>

            {/* Quick Prompt Presets */}
            <div className="flex items-center gap-2 flex-wrap text-[11px]">
              <span className="font-bold text-[#52607A]">Quick AI Ideas:</span>
              {[
                'Add glowing cyberpunk sunglasses on the face',
                'Neon golden angel halo over head with soft glow',
                'Fiery inferno flame crown with amber sparks',
                'Futuristic red laser robot visor',
                'Cute holographic pink cat ears',
              ].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setAiFilterPromptInput(preset)}
                  className="px-2.5 py-1 rounded-lg bg-[#F1F5F9] dark:bg-slate-800 hover:bg-[#7C3AED] hover:text-white font-semibold transition-colors"
                >
                  {preset}
                </button>
              ))}
            </div>

            {/* Live Filter Testing Sandbox + Fine-Tuning Controls */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 pt-2">
              {/* Left: Live Camera / Avatar AR Sandbox */}
              <div className="lg:col-span-7 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-extrabold flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-[#00F5D4]" /> Live Filter Testing Sandbox
                  </h3>
                  <div className="flex items-center gap-2">
                    {!sandboxCamActive ? (
                      <button
                        type="button"
                        onClick={startSandboxCamera}
                        className="px-3 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
                      >
                        <Camera className="w-3.5 h-3.5" /> Start Live Test Camera
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={stopSandboxCamera}
                        className="px-3 py-1.5 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold"
                      >
                        Stop Camera
                      </button>
                    )}
                  </div>
                </div>

                <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-slate-950 border-2 border-[#7C3AED] flex items-center justify-center shadow-xl">
                  {sandboxCamActive ? (
                    <video
                      ref={sandboxVideoRef}
                      muted
                      playsInline
                      autoPlay
                      style={
                        draftAiFilter.cssFilter ? { filter: draftAiFilter.cssFilter } : undefined
                      }
                      className="w-full h-full object-cover -scale-x-100"
                    />
                  ) : (
                    <img
                      src={GENERATED_ASSETS.avatar1}
                      alt="Sandbox Model"
                      style={
                        draftAiFilter.cssFilter ? { filter: draftAiFilter.cssFilter } : undefined
                      }
                      className="w-full h-full object-cover opacity-90"
                    />
                  )}
                  <canvas
                    ref={sandboxCanvasRef}
                    className="absolute inset-0 w-full h-full pointer-events-none"
                  />
                  <div className="absolute bottom-3 left-3 px-3 py-1 rounded-xl bg-black/75 text-white text-[11px] font-bold">
                    Testing: <span className="text-[#00F5D4]">{draftAiFilter.name}</span> ({draftAiFilter.overlayType})
                  </div>
                </div>
                {sandboxCamError && (
                  <p className="text-[11px] font-bold text-[#F59E0B]">{sandboxCamError}</p>
                )}
              </div>

              {/* Right: Fine-Tuning Sliders & One-Click Upload/Publish */}
              <div className="lg:col-span-5 p-4 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
                <h3 className="text-sm font-extrabold flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-[#FF5722]" /> Alignment &amp; Shader Controls
                </h3>

                <div>
                  <label className="block text-[11px] font-extrabold mb-1">Filter Display Name</label>
                  <input
                    type="text"
                    value={draftAiFilter.name}
                    onChange={(e) =>
                      setDraftAiFilter((prev) => ({ ...prev, name: e.target.value }))
                    }
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-extrabold mb-1">Primary Color</label>
                    <input
                      type="color"
                      value={draftAiFilter.primaryColor}
                      onChange={(e) =>
                        setDraftAiFilter((prev) => ({
                          ...prev,
                          primaryColor: e.target.value.toUpperCase(),
                          thumbnailColor: e.target.value.toUpperCase(),
                        }))
                      }
                      className="w-full h-9 rounded-lg cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-extrabold mb-1">Secondary Color</label>
                    <input
                      type="color"
                      value={draftAiFilter.secondaryColor}
                      onChange={(e) =>
                        setDraftAiFilter((prev) => ({
                          ...prev,
                          secondaryColor: e.target.value.toUpperCase(),
                        }))
                      }
                      className="w-full h-9 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>

                <div>
                  <label className="flex justify-between text-[11px] font-bold mb-1">
                    <span>Eye Anchor Y-Offset</span>
                    <span>{draftAiFilter.eyeOffsetY}px</span>
                  </label>
                  <input
                    type="range"
                    min={-60}
                    max={60}
                    value={draftAiFilter.eyeOffsetY}
                    onChange={(e) =>
                      setDraftAiFilter((prev) => ({ ...prev, eyeOffsetY: Number(e.target.value) }))
                    }
                    className="w-full accent-[#FF5722]"
                  />
                </div>

                <div>
                  <label className="flex justify-between text-[11px] font-bold mb-1">
                    <span>AR Scale</span>
                    <span>{draftAiFilter.scale.toFixed(2)}x</span>
                  </label>
                  <input
                    type="range"
                    min={0.6}
                    max={1.8}
                    step={0.05}
                    value={draftAiFilter.scale}
                    onChange={(e) =>
                      setDraftAiFilter((prev) => ({ ...prev, scale: Number(e.target.value) }))
                    }
                    className="w-full accent-[#7C3AED]"
                  />
                </div>

                <div>
                  <label className="flex justify-between text-[11px] font-bold mb-1">
                    <span>Neon Glow Intensity</span>
                    <span>{draftAiFilter.glowIntensity}</span>
                  </label>
                  <input
                    type="range"
                    min={0}
                    max={35}
                    value={draftAiFilter.glowIntensity}
                    onChange={(e) =>
                      setDraftAiFilter((prev) => ({
                        ...prev,
                        glowIntensity: Number(e.target.value),
                      }))
                    }
                    className="w-full accent-[#00F5D4]"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const readyFilter: FismArFilterAsset = {
                      ...draftAiFilter,
                      id: draftAiFilter.id || `ar_pub_${Date.now()}`,
                      publishedToUsers: true,
                      createdAt: new Date().toLocaleTimeString(),
                    };
                    onPublishArFilter?.(readyFilter);
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#16A34A] to-[#0EA5E9] text-white text-xs font-black flex items-center justify-center gap-2 shadow-xl hover:opacity-95"
                >
                  <Upload className="w-4 h-4" /> Upload &amp; Publish Filter to All Users
                </button>
              </div>
            </div>

            {/* Published Filters Library */}
            <div className="pt-3 border-t border-[#D8E1F0] dark:border-slate-800 space-y-2">
              <div className="text-xs font-extrabold uppercase text-[#52607A]">
                Published AR Filters (Live on Camera Studio &amp; Video Calls)
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {publishedArFilters.map((flt) => (
                  <div
                    key={flt.id}
                    className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className="w-8 h-8 rounded-full shrink-0 border-2 border-white shadow"
                        style={{
                          background: `linear-gradient(135deg, ${flt.primaryColor}, ${flt.secondaryColor})`,
                        }}
                      />
                      <div className="min-w-0">
                        <div className="text-xs font-extrabold truncate">{flt.name}</div>
                        <div className="text-[10px] text-[#52607A] truncate">{flt.overlayType}</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setDraftAiFilter(flt)}
                      className="px-2.5 py-1 rounded-lg bg-[#7C3AED]/15 text-[#7C3AED] text-[10px] font-extrabold shrink-0"
                    >
                      Test
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: USER PROFILES, LIVE BAN/UNBAN & LONG-PRESS SECRET DOSSIER */}
      {adminTab === 'profiles' && (
        <div className="space-y-4">
          <div className="p-3.5 rounded-xl bg-[#EEF3FB] dark:bg-slate-800 border border-[#2563EB] text-xs font-bold flex items-center justify-between flex-wrap gap-2">
            <span>
              💡 Tip: Click <strong>Ban / Unban</strong> to change live status immediately.{' '}
              <strong>Long-Press (Hold for 0.5s)</strong> on any user row to inspect their complete
              user profile dossier, watch history, verified phone status, security audit &amp; cryptographic hash!
            </span>
          </div>

          <div className="space-y-3">
            {userDossiers.map((u) => (
              <div
                key={u.uid}
                onMouseDown={() => startLongPress(u)}
                onMouseUp={cancelLongPress}
                onMouseLeave={cancelLongPress}
                onTouchStart={() => startLongPress(u)}
                onTouchEnd={cancelLongPress}
                className={`fism-card p-4 transition-all cursor-pointer select-none border-2 ${
                  u.isBanned
                    ? 'border-[#DC2626] bg-red-50/40 dark:bg-red-950/20'
                    : 'border-[#D8E1F0] dark:border-slate-800 hover:border-[#FF5722]'
                }`}
              >
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={u.avatarUrl}
                      alt={u.displayName}
                      className="w-14 h-14 rounded-2xl object-cover ring-2 ring-[#FF5722]"
                    />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-base">{u.displayName}</span>
                        <span className="text-xs font-mono text-[#52607A]">
                          (@{u.username} • ID: {u.uid})
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase ${
                            u.isBanned
                              ? 'bg-[#DC2626] text-white'
                              : 'bg-[#16A34A] text-white'
                          }`}
                        >
                          {u.isBanned ? '● LIVE: BANNED' : '● LIVE: UNBANNED'}
                        </span>
                      </div>
                      <p className="text-xs text-[#52607A] mt-1">{u.liveStatusText}</p>
                      <div className="flex items-center gap-3 mt-1 text-[11px] font-bold text-[#2563EB] flex-wrap">
                        <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-[#16A34A] font-mono">
                          🌐 Live IP: {u.ipAddress || '103.84.219.14 (Live Tracked)'}
                        </span>
                        <span>•</span>
                        <span>Videos: {u.videosUploadedCount}</span>
                        <span>•</span>
                        <span>Sparks: {u.sparksFollowersCount.toLocaleString()}</span>
                        <span>•</span>
                        <span>Flames: {u.flamesFollowingCount}</span>
                      </div>
                      {u.categories && u.categories.length > 0 && (
                        <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                          {u.categories.map((cat) => (
                            <span
                              key={cat}
                              className="px-2 py-0.5 rounded bg-[#7C3AED]/15 text-[#7C3AED] text-[10px] font-extrabold"
                            >
                              #{cat}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right Actions: Ban / Unban Buttons + Inspect Full Data */}
                  <div
                    className="flex items-center gap-2 flex-wrap"
                    onMouseDown={(e) => e.stopPropagation()}
                    onTouchStart={(e) => e.stopPropagation()}
                  >
                    <button
                      onClick={() => setInspectedUser(u)}
                      className="px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold flex items-center gap-1.5 hover:border-[#7C3AED]"
                    >
                      <Eye className="w-4 h-4 text-[#7C3AED]" /> Long-Press / Full Data
                    </button>

                    <button
                      onClick={() => {
                        if (!u.isBanned) onToggleBanUser(u.uid);
                      }}
                      disabled={u.isBanned}
                      className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1 ${
                        u.isBanned
                          ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                          : 'bg-[#DC2626] text-white shadow'
                      }`}
                    >
                      <Ban className="w-3.5 h-3.5" /> Ban ID
                    </button>

                    <button
                      onClick={() => {
                        if (u.isBanned) onToggleBanUser(u.uid);
                      }}
                      disabled={!u.isBanned}
                      className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1 ${
                        !u.isBanned
                          ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                          : 'bg-[#16A34A] text-white shadow'
                      }`}
                    >
                      <UserCheck className="w-3.5 h-3.5" /> Unban ID
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: PREMIUM MASTER SWITCH & ALL SECTIONS ON/OFF CONTROLLER */}
      {adminTab === 'premium' && (
        <div className="space-y-5">
          {/* Master Global Premium Switch & Demo Buy Card */}
          <div className="fism-card p-5 bg-gradient-to-r from-[#172033] via-[#1E1B4B] to-[#31102F] text-white flex items-center justify-between flex-wrap gap-4">
            <div>
              <span className="px-2.5 py-0.5 rounded bg-[#F59E0B] text-white text-[10px] font-extrabold uppercase">
                Master Premium Control (प्रीमियम ऑन / ऑफ सेक्शन)
              </span>
              <h2 className="text-xl font-extrabold mt-1 flex items-center gap-2">
                <Crown className="w-6 h-6 text-[#F59E0B]" /> Global App Premium Status:{' '}
                <span className={globalPremiumOn ? 'text-[#16A34A]' : 'text-[#EF4444]'}>
                  {globalPremiumOn ? 'PREMIUM ON' : 'PREMIUM OFF'}
                </span>
              </h2>
              <p className="text-xs text-slate-300 mt-1">
                Turn Master Premium ON or OFF for the entire app, or toggle individual sections
                below. (Demo Buy Mode Active)
              </p>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              {onToggleUserBoughtPremium && (
                <button
                  onClick={() => {
                    const nextVal = !userHasBoughtPremium;
                    onToggleUserBoughtPremium(nextVal);
                    onTriggerToast(
                      nextVal
                        ? '👑 User Premium Membership Marked as PURCHASED (Unlocked)!'
                        : '🔒 User Premium Membership Marked as NOT PURCHASED (Strict Buy Premium Gate Active)!',
                    );
                  }}
                  className={`px-4 py-2.5 rounded-xl text-xs font-extrabold shadow-lg ${
                    userHasBoughtPremium
                      ? 'bg-[#16A34A] text-white'
                      : 'bg-[#F59E0B] text-[#101426]'
                  }`}
                >
                  {userHasBoughtPremium
                    ? '✅ User Has Bought Premium (Click to Reset Gate)'
                    : '🔒 User Has NOT Bought Premium (Gate Active)'}
                </button>
              )}

              <button
                onClick={() => onToggleGlobalPremium(!globalPremiumOn)}
                className={`px-5 py-2.5 rounded-xl text-xs font-extrabold shadow-lg ${
                  globalPremiumOn ? 'bg-[#16A34A] text-white' : 'bg-[#DC2626] text-white'
                }`}
              >
                {globalPremiumOn ? 'Master Premium: ON' : 'Master Premium: OFF'}
              </button>
            </div>
          </div>

          {/* All App Sections List with Individual ON / OFF Buttons */}
          <div className="fism-card p-5 space-y-3">
            <h3 className="font-extrabold text-base">
              All App Sections — Individual Premium ON / OFF Switches
            </h3>
            <p className="text-xs text-[#52607A]">
              Toggle any section ON to move it into Premium Mode, or OFF to return it to Standard
              Mode.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              {allAppSectionsList.map((sec) => {
                const isSecOn = Boolean(sectionPremiumMap[sec.id] && globalPremiumOn);
                return (
                  <div
                    key={sec.id}
                    className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 ${
                      isSecOn
                        ? 'border-[#F59E0B] bg-amber-50/40 dark:bg-amber-950/20'
                        : 'border-[#D8E1F0] dark:border-slate-800 bg-[#F8FAFE] dark:bg-slate-900'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-sm flex items-center gap-1.5 flex-wrap">
                        <span>{sec.label}</span>
                        {isSecOn && (
                          <span className="px-2 py-0.5 rounded bg-[#F59E0B] text-white text-[10px] font-extrabold">
                            👑 PREMIUM
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-[#52607A]">{sec.desc}</div>
                    </div>

                    <button
                      onClick={() => onToggleSectionPremium(sec.id)}
                      className={`px-4 py-2 rounded-xl text-xs font-extrabold shrink-0 transition-all ${
                        isSecOn
                          ? 'bg-[#16A34A] text-white shadow'
                          : 'bg-slate-300 dark:bg-slate-800 text-[#172033] dark:text-white'
                      }`}
                    >
                      {isSecOn ? 'ON (Premium)' : 'OFF (Normal)'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: 108-LAYER ULTIMATE AI SECURITY & ANTI-HACKING DEFENSE GRID */}
      {adminTab === 'aiSecurityGuard' && (
        <FismSecurityDefensePanel onTriggerToast={onTriggerToast} />
      )}

      {/* TAB 4: ADMIN FILE 2D GAME UPLOADER (OPEN FILE / SELECT FOLDER -> NAME, TITLE, DESCRIPTION -> UPLOAD GAME) */}
      {adminTab === 'gameUploader' && (
        <div className="space-y-5">
          <div className="fism-card p-5 bg-gradient-to-r from-[#1E1B4B] via-[#31102F] to-[#0F172A] text-white border-2 border-[#7C3AED] flex items-center justify-between flex-wrap gap-4">
            <div>
              <span className="px-2.5 py-0.5 rounded bg-[#FF5722] text-white text-[10px] font-extrabold uppercase">
                Admin-Only 2D Game Publisher
              </span>
              <h2 className="text-xl font-extrabold mt-1 flex items-center gap-2">
                <Gamepad2 className="w-6 h-6 text-[#F59E0B]" /> Admin File — 2D Game Folder &amp; File Uploader
              </h2>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                Only Admins inside the unlocked Admin File Vault can upload new games. Regular users
                in the Game Section have <strong>NO upload access</strong>—they only see published
                games and click <strong>&quot;Play Game&quot;</strong>!
              </p>
            </div>
          </div>

          <div className="fism-card p-5 space-y-4 border-2 border-[#D8E1F0] dark:border-slate-800">
            <h3 className="font-extrabold text-base flex items-center gap-2">
              <FolderOpen className="w-5 h-5 text-[#FF5722]" /> Step 1: Open Game File or Select Game Folder
            </h3>

            <div className="flex items-center gap-3 flex-wrap">
              <label className="px-4 py-2.5 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold flex items-center gap-2 cursor-pointer shadow">
                <Upload className="w-4 h-4" /> OPEN FILE (Select Game Build File)
                <input
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    const files = Array.from(e.target.files || []);
                    if (files.length === 0) return;
                    const first = files[0];
                    const cleanName = first.name.replace(/\.[^/.]+$/, '');
                    setNewGameFolder(`/admin-games/${first.name}`);
                    setNewGameFilesCount(files.length);
                    if (!newGameName) setNewGameName(cleanName);
                    if (!newGameTitle) setNewGameTitle(`${cleanName} — 2D Arcade Edition`);
                    const mediaAsset =
                      files.find((f) => f.type.startsWith('video/')) ||
                      files.find((f) => f.type.startsWith('image/'));
                    if (mediaAsset) {
                      const isVid = mediaAsset.type.startsWith('video/');
                      if (mediaAsset.size <= 3_500_000) {
                        const reader = new FileReader();
                        reader.onload = () => {
                          if (typeof reader.result === 'string') {
                            setNewGameOverlayUrl(reader.result);
                            setNewGameOverlayType(isVid ? 'video' : 'image');
                          }
                        };
                        reader.readAsDataURL(mediaAsset);
                      } else {
                        setNewGameOverlayUrl(URL.createObjectURL(mediaAsset));
                        setNewGameOverlayType(isVid ? 'video' : 'image');
                      }
                    } else {
                      setNewGameOverlayUrl('');
                      setNewGameOverlayType('engine');
                    }
                    onTriggerToast(`Loaded ${files.length} game file(s): ${first.name}`);
                  }}
                />
              </label>

              <label className="px-4 py-2.5 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-2 cursor-pointer shadow">
                <FolderOpen className="w-4 h-4" /> SELECT GAME FOLDER (पूरा गेम फोल्डर चुनें)
                <input
                  type="file"
                  multiple
                  {...({ webkitdirectory: '', directory: '' } as React.InputHTMLAttributes<HTMLInputElement>)}
                  className="hidden"
                  onChange={(e) => {
                    const files = Array.from(e.target.files || []);
                    if (files.length === 0) return;
                    const relPath =
                      (files[0] as File & { webkitRelativePath?: string }).webkitRelativePath ||
                      files[0].name;
                    const folderRoot = relPath.split('/')[0] || 'custom-2d-game';
                    setNewGameFolder(`/admin-folders/${folderRoot}`);
                    setNewGameFilesCount(files.length);
                    if (!newGameName) setNewGameName(folderRoot);
                    if (!newGameTitle) setNewGameTitle(`${folderRoot} — Official 2D Game`);
                    const mediaAsset =
                      files.find((f) => f.type.startsWith('video/')) ||
                      files.find((f) => f.type.startsWith('image/'));
                    if (mediaAsset) {
                      const isVid = mediaAsset.type.startsWith('video/');
                      if (mediaAsset.size <= 3_500_000) {
                        const reader = new FileReader();
                        reader.onload = () => {
                          if (typeof reader.result === 'string') {
                            setNewGameOverlayUrl(reader.result);
                            setNewGameOverlayType(isVid ? 'video' : 'image');
                          }
                        };
                        reader.readAsDataURL(mediaAsset);
                      } else {
                        setNewGameOverlayUrl(URL.createObjectURL(mediaAsset));
                        setNewGameOverlayType(isVid ? 'video' : 'image');
                      }
                    } else {
                      setNewGameOverlayUrl('');
                      setNewGameOverlayType('engine');
                    }
                    onTriggerToast(
                      `Selected folder "${folderRoot}" (${files.length} files ready)!`,
                    );
                  }}
                />
              </label>

              <div className="px-3.5 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono">
                Selected Path: <strong>{newGameFolder}</strong> ({newGameFilesCount} files)
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div>
                <label className="block text-xs font-extrabold mb-1">Game Name (गेम का नाम)</label>
                <input
                  type="text"
                  value={newGameName}
                  onChange={(e) => setNewGameName(e.target.value)}
                  placeholder="e.g. Cyber Blaster 2D"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold mb-1">Game Title (गेम का टाइटल)</label>
                <input
                  type="text"
                  value={newGameTitle}
                  onChange={(e) => setNewGameTitle(e.target.value)}
                  placeholder="e.g. Cyber Blaster 2D: Inferno Boss Rush"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold mb-1">2D Gameplay Template Engine</label>
                <select
                  value={newGameEngine}
                  onChange={(e) =>
                    setNewGameEngine(e.target.value as FismGameItem['engineType'])
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                >
                  <option value="customAdmin2D">2D Starfighter &amp; Coin Blaster Engine</option>
                  <option value="flameRunner2D">2D Side-Scrolling Runner &amp; Jump Engine</option>
                  <option value="brickBreaker2D">2D Physics Paddle &amp; Brick Breaker Engine</option>
                  <option value="cyberSnake2D">2D Neon Grid Snake Engine</option>
                  <option value="redBallDefense2D">2D Red Ball Emoji Defense Engine</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-extrabold mb-1">
                Game Description (गेम का डिस्क्रिप्शन और कंट्रोल्स)
              </label>
              <textarea
                rows={2}
                value={newGameDesc}
                onChange={(e) => setNewGameDesc(e.target.value)}
                placeholder="Describe rules, controls, and rewards for players in the 2D Game Section..."
                className="w-full p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
              />
            </div>

            <div className="p-3.5 rounded-xl bg-[#16A34A]/10 border border-[#16A34A]/35 flex items-center justify-between flex-wrap gap-3">
              <label className="flex items-center gap-2.5 cursor-pointer text-xs font-extrabold">
                <input
                  type="checkbox"
                  checked={newGameIsGreenScreen}
                  onChange={(e) => setNewGameIsGreenScreen(e.target.checked)}
                  className="w-4 h-4 accent-[#16A34A]"
                />
                <span>
                  Publish as Green-Screen Camera Game Filter (Users play &amp; record over live camera)
                </span>
              </label>
              {newGameIsGreenScreen && (
                <div className="flex items-center gap-2 text-xs font-bold">
                  <span>Chroma Sensitivity: {newGameChromaSensitivity}%</span>
                  <input
                    type="range"
                    min={15}
                    max={95}
                    value={newGameChromaSensitivity}
                    onChange={(e) => setNewGameChromaSensitivity(Number(e.target.value))}
                    className="w-28 accent-[#16A34A]"
                  />
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => {
                  const finalName = newGameName.trim() || 'Admin Custom 2D Arcade';
                  const finalTitle =
                    newGameTitle.trim() || `${finalName} — Official Admin 2D Release`;
                  const finalDesc =
                    newGameDesc.trim() ||
                    'Uploaded directly from the Admin File Vault. Click Play Game to launch in the 2D Game Hub!';
                  const newGame: FismGameItem = {
                    id: `game_admin_${Date.now()}`,
                    name: finalName,
                    title: finalTitle,
                    description: finalDesc,
                    category: newGameIsGreenScreen
                      ? 'Green-Screen Camera Game'
                      : 'Admin Uploaded 2D Game',
                    folderName: newGameFolder,
                    filesCount: newGameFilesCount,
                    uploadedByAdmin: true,
                    createdAt: 'Just uploaded by Admin',
                    engineType: newGameEngine,
                    isGreenScreenGame: newGameIsGreenScreen,
                    chromaColor: '#00FF00',
                    chromaSensitivity: newGameChromaSensitivity,
                    overlayMediaUrl: newGameOverlayUrl || undefined,
                    overlayMediaType: newGameOverlayUrl ? newGameOverlayType : 'engine',
                  };
                  onAdminUploadGame?.(newGame);
                  setNewGameName('');
                  setNewGameTitle('');
                  setNewGameDesc('');
                  setNewGameOverlayUrl('');
                  setNewGameOverlayType('engine');
                  onTriggerToast(
                    `Game "${finalName}" uploaded! Available in 2D Game Section & Create Camera Game Filters.`,
                  );
                }}
                className="fism-btn-primary px-6 py-3 rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-lg"
              >
                <Upload className="w-4 h-4" /> Upload Game to 2D Game Section
              </button>
            </div>
          </div>

          {/* Currently Published Games in 2D Game Section */}
          <div className="fism-card p-5 space-y-3">
            <h3 className="font-extrabold text-sm">
              Published Games Live in 2D Game Hub ({gamesList.length} Games)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {gamesList.map((g) => (
                <div
                  key={g.id}
                  className="p-3.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 flex items-center justify-between gap-3"
                >
                  <div>
                    <div className="font-extrabold text-sm flex items-center gap-2">
                      <span>🎮 {g.name}</span>
                      <span className="px-2 py-0.5 rounded bg-[#16A34A] text-white text-[10px]">
                        LIVE 2D
                      </span>
                    </div>
                    <div className="text-xs font-semibold text-[#52607A] mt-0.5">{g.title}</div>
                    <div className="text-[11px] font-mono text-[#7C3AED] mt-0.5">
                      Folder: {g.folderName} ({g.filesCount} files)
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4B: ADMIN 3D MODEL UPLOADER (Starts with 4 Default Models; Admin uploads more via Open File!) */}
      {adminTab === 'model3DUploader' && (
        <div className="max-w-[950px] mx-auto space-y-6">
          <div className="rounded-2xl p-6 bg-[#101426] text-white border-2 border-[#FF5722] shadow-xl space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-3 border-b border-white/15 pb-4">
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-[#FF5722] text-white text-[10px] font-black uppercase">
                  Admin File • Open File Select 3D Model &amp; Upload
                </span>
                <h2 className="text-xl font-black mt-1 flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-[#FFB300]" /> Admin 3D Character Model Uploader
                  (3D मॉडल अपलोडर)
                </h2>
                <p className="text-xs text-slate-300 mt-1">
                  शुरुआत में केवल <strong>4 डिफ़ॉल्ट 3D मॉडल</strong> (Raistar 3D, Star Bunny Bundle, Ajju
                  Bhai, Mr. Bean) रखे गए हैं। यहाँ से एडमिन <strong>Open File — Select 3D Model</strong> के
                  ज़रिए जितने चाहे नए 3D मॉडल्स अपलोड कर सकता है — वे सभी यूजर के चेहरे, बैठने/खड़े होने और होंठों
                  (Lip-Sync) के साथ रियल-टाइम एनिमेट होंगे!
                </p>
              </div>
              <span className="px-3.5 py-1.5 rounded-xl bg-[#181F36] border border-[#FFB300] text-[#FFB300] text-xs font-extrabold">
                Active 3D Models: {INITIAL_4_3D_FACE_MODELS.length + custom3DModels.length}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                  1. Open File — Select 3D Model File (.glb, .gltf, .obj, .fbx or Rig)
                </label>
                <div className="flex items-center gap-2 flex-wrap">
                  <label className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FF5722] to-[#E53935] text-white text-xs font-black flex items-center gap-2 cursor-pointer shadow-lg">
                    <Upload className="w-4 h-4" /> Open File — Select 3D Model
                    <input
                      type="file"
                      accept=".glb,.gltf,.obj,.fbx,image/*,*/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        setNew3DModelFileName(file.name);
                        const baseName = file.name
                          .replace(/\.[^/.]+$/, '')
                          .replace(/[-_]/g, ' ');
                        if (!new3DModelName.trim()) {
                          setNew3DModelName(baseName);
                        }
                        onTriggerToast(`✅ Selected 3D Model File: ${file.name}`);
                      }}
                    />
                  </label>
                  <span className="text-xs font-mono text-amber-300 truncate">
                    {new3DModelFileName}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                  2. 3D Character Model Name (e.g. Star 3D Bunny Bundle, White444 3D) *
                </label>
                <input
                  type="text"
                  value={new3DModelName}
                  onChange={(e) => setNew3DModelName(e.target.value)}
                  placeholder="e.g. Star 3D Bunny Bundle V2 / White444 Demon 3D"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#181F36] border border-[#FF5722] text-white text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                  3. 3D Headgear / Bundle Rig Style
                </label>
                <select
                  value={new3DHeadgear}
                  onChange={(e) =>
                    setNew3DHeadgear(e.target.value as Face3DModelPreset['headgear'])
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#181F36] border border-slate-700 text-white text-xs font-bold"
                >
                  <option value="bunny-ears">🐰 3D Bunny Ears (Raistar / Bunny Bundle)</option>
                  <option value="hoodie-headset">🎧 Pro Gamer Hoodie &amp; RGB Headset</option>
                  <option value="crown">👑 Royal Golden Crown</option>
                  <option value="horns">😈 Samurai / Cyber Horns</option>
                  <option value="spiky-hair">⚡ Anime Spiky 3D Hair</option>
                  <option value="helmet">🪖 Tactical Esports Helmet</option>
                  <option value="none">🙂 Classic Expressive Toon</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                    4. Eye Tracking Style
                  </label>
                  <select
                    value={new3DEyeStyle}
                    onChange={(e) =>
                      setNew3DEyeStyle(e.target.value as Face3DModelPreset['eyeStyle'])
                    }
                    className="w-full px-3 py-2.5 rounded-xl bg-[#181F36] border border-slate-700 text-white text-xs font-bold"
                  >
                    <option value="glow-red">🔴 Blazing Red Glow</option>
                    <option value="glow-gold">🟡 Golden Star Glow</option>
                    <option value="glow-cyan">🔵 Cyber Cyan Glow</option>
                    <option value="visor">🥽 Pro Cyber Visor</option>
                    <option value="bean-expressive">👀 Expressive Cartoon Eyes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-[#FFB300] mb-1">
                    5. Jaw / Lip-Sync Style
                  </label>
                  <select
                    value={new3DMaskStyle}
                    onChange={(e) =>
                      setNew3DMaskStyle(e.target.value as Face3DModelPreset['maskStyle'])
                    }
                    className="w-full px-3 py-2.5 rounded-xl bg-[#181F36] border border-slate-700 text-white text-xs font-bold"
                  >
                    <option value="warrior-mask">⚔️ 3D Warrior Mask + Moving Lips</option>
                    <option value="full-toon">🗣️ Full Expressive Moving Lips</option>
                    <option value="cyber-visor">🤖 Cyber Jaw + Lip-Sync</option>
                    <option value="skull-flame">🔥 Flame Skull + Lip-Sync</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-extrabold text-slate-300 mb-1">
                    Primary 3D Shader Color
                  </label>
                  <input
                    type="color"
                    value={new3DPrimaryColor}
                    onChange={(e) => setNew3DPrimaryColor(e.target.value)}
                    className="w-full h-10 rounded-xl bg-[#181F36] border border-slate-700 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block text-xs font-extrabold text-slate-300 mb-1">
                    Glow / Lip Accent Color
                  </label>
                  <input
                    type="color"
                    value={new3DAccentColor}
                    onChange={(e) => setNew3DAccentColor(e.target.value)}
                    className="w-full h-10 rounded-xl bg-[#181F36] border border-slate-700 cursor-pointer"
                  />
                </div>
              </div>

              <div className="flex items-end">
                <button
                  onClick={() => {
                    if (!new3DModelName.trim()) {
                      onTriggerToast('कृपया 3D Model का नाम लिखें!');
                      return;
                    }
                    const createdModel: Face3DModelPreset = {
                      id: `admin_3d_${Date.now()}`,
                      name: new3DModelName.trim(),
                      category: 'Admin Custom 3D',
                      primaryColor: new3DPrimaryColor,
                      secondaryColor: '#0F172A',
                      accentColor: new3DAccentColor,
                      eyeStyle: new3DEyeStyle,
                      headgear: new3DHeadgear,
                      maskStyle: new3DMaskStyle,
                      badgeText: new3DModelName
                        .trim()
                        .split(' ')
                        .slice(0, 2)
                        .join(' ')
                        .toUpperCase(),
                      tagline: `Admin Uploaded (${new3DModelFileName}) • Head + Posture + Lip-Sync`,
                      modelFileName: new3DModelFileName,
                      uploadedByAdmin: true,
                    };
                    onAdminUpload3DModel?.(createdModel);
                    setNew3DModelName('');
                    onTriggerToast(
                      `✅ 3D Model "${createdModel.name}" अपलोड हो गया! अब On Fire के 3D Face Selector में उपलब्ध है।`,
                    );
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#E53935] via-[#FF5722] to-[#FFB300] text-white text-xs sm:text-sm font-black uppercase shadow-xl flex items-center justify-center gap-2"
                >
                  <Upload className="w-4 h-4" /> Upload &amp; Add 3D Model to App
                </button>
              </div>
            </div>

            {/* Active 3D Models List (4 Built-in + Admin Uploaded) */}
            <div className="pt-4 border-t border-white/15 space-y-2.5">
              <div className="text-xs font-extrabold text-[#FFB300] uppercase">
                Active 3D Models in App ({INITIAL_4_3D_FACE_MODELS.length} Default +{' '}
                {custom3DModels.length} Admin Uploaded)
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[...INITIAL_4_3D_FACE_MODELS, ...custom3DModels].map((m, idx) => (
                  <div
                    key={m.id}
                    className="p-3.5 rounded-xl bg-[#181F36] border border-slate-700 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        style={{
                          background: `radial-gradient(circle at 30% 30%, ${m.primaryColor}, ${m.secondaryColor})`,
                          borderColor: m.accentColor,
                        }}
                        className="w-11 h-11 rounded-xl border-2 flex items-center justify-center font-black text-[10px] text-white shrink-0"
                      >
                        #{idx + 1}
                      </div>
                      <div className="min-w-0">
                        <div className="font-extrabold text-xs text-white truncate flex items-center gap-1.5">
                          <span>{m.name}</span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-black ${
                              m.uploadedByAdmin
                                ? 'bg-[#7C3AED] text-white'
                                : 'bg-[#FF5722] text-white'
                            }`}
                          >
                            {m.uploadedByAdmin ? 'ADMIN UPLOADED' : 'DEFAULT 4'}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">{m.tagline}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4C: ADMIN APP LOGO CHANGE (OPEN FILE SELECT PHOTO -> CHANGE BACKGROUND PHOTO BEHIND "FISM" NAME) */}
      {adminTab === 'appLogoChanger' && (
        <div className="max-w-[950px] mx-auto space-y-6">
          <div className="rounded-2xl p-6 bg-[#101426] text-white border-2 border-[#FFB300] shadow-xl space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-3 border-b border-white/15 pb-4">
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-[#FFB300] text-[#101426] text-[10px] font-black uppercase">
                  Admin File • App Logo Background Photo Changer
                </span>
                <h2 className="text-xl font-black mt-1 flex items-center gap-2">
                  <ImageIcon className="w-6 h-6 text-[#FF5722]" /> App Logo Change — Open File &amp;
                  Select Photo (FISM लोगो बैकग्राउंड फोटो बदलें)
                </h2>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                  ऐप में ऊपर जहाँ <strong>FISM</strong> नाम लिखा हुआ है, उसका नाम <strong>FISM</strong> ही
                  रहेगा लेकिन आप यहाँ <strong>Open File — Select Photo</strong> करके उसके पीछे का{' '}
                  <strong>Background Photo</strong> कभी भी बदल सकते हैं!
                </p>
              </div>
              <span className="px-3.5 py-1.5 rounded-xl bg-[#181F36] border border-[#FF5722] text-[#FFB300] text-xs font-extrabold">
                Brand Name Locked: &quot;FISM&quot;
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              {/* Left: Open File Select Photo & Save */}
              <div className="md:col-span-7 space-y-4">
                <div className="p-4 rounded-2xl bg-[#181F36] border border-white/15 space-y-3">
                  <label className="block text-xs font-extrabold text-[#FFB300]">
                    1. Open File — Select Photo for FISM Logo Background (फोटो चुनें)
                  </label>
                  <div className="flex items-center gap-3 flex-wrap">
                    <label className="px-5 py-3 rounded-xl bg-gradient-to-r from-[#FF5722] via-[#E53935] to-[#FFB300] text-white text-xs sm:text-sm font-black uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-xl hover:scale-[1.01] transition-transform">
                      <Upload className="w-4 h-4" /> Open File — Select Photo
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          setLogoBgFileName(file.name);
                          const reader = new FileReader();
                          reader.onload = () => {
                            if (typeof reader.result === 'string') {
                              const dataUrl = reader.result;
                              setLogoBgDraftUrl(dataUrl);
                              onUpdateAppLogoBg?.(dataUrl);
                              onTriggerToast(
                                `✅ FISM App Logo का Background Photo ("${file.name}") बदल गया है! नाम "FISM" वही रहेगा।`,
                              );
                            }
                          };
                          reader.readAsDataURL(file);
                          e.target.value = '';
                        }}
                      />
                    </label>
                    <span className="text-xs font-mono text-amber-300 truncate max-w-[240px]">
                      {logoBgFileName}
                    </span>
                  </div>
                </div>

                {/* Quick Preset Background Photos + Save / Reset */}
                <div className="p-4 rounded-2xl bg-[#181F36] border border-white/15 space-y-3">
                  <div className="text-xs font-extrabold text-slate-300">
                    2. Quick Studio Background Photo Presets or Reset:
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {[
                      { label: '🔥 Studio Hero Photo', url: GENERATED_ASSETS.heroCover },
                      { label: '🏔️ Golden Alpine Photo', url: GENERATED_ASSETS.mountainPost },
                      { label: '🎬 Cyber Rig Photo', url: GENERATED_ASSETS.studioThumb },
                    ].map((preset) => (
                      <button
                        key={preset.label}
                        type="button"
                        onClick={() => {
                          setLogoBgDraftUrl(preset.url);
                          setLogoBgFileName(preset.label);
                          onUpdateAppLogoBg?.(preset.url);
                          onTriggerToast(`✅ FISM Logo Background set to ${preset.label}!`);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-[#FF5722] text-white text-xs font-extrabold transition-colors"
                      >
                        {preset.label}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => {
                        setLogoBgDraftUrl('');
                        setLogoBgFileName('Default Flame Gradient');
                        onUpdateAppLogoBg?.('');
                        onTriggerToast('↺ Reset FISM Logo to Default Flame Gradient.');
                      }}
                      className="px-3 py-1.5 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold"
                    >
                      Reset Default
                    </button>
                  </div>
                </div>
              </div>

              {/* Right: Live Preview of Top Header "FISM" Logo */}
              <div className="md:col-span-5 p-5 rounded-2xl bg-[#181F36] border-2 border-[#FF5722] flex flex-col items-center justify-center text-center space-y-3">
                <span className="px-3 py-0.5 rounded-full bg-[#FF5722] text-white text-[10px] font-black uppercase">
                  Live Header Preview (नाम वही रहेगा, बैकग्राउंड फोटो बदलेगा)
                </span>

                <div
                  style={
                    logoBgDraftUrl
                      ? {
                          backgroundImage: `linear-gradient(rgba(16,20,38,0.45), rgba(16,20,38,0.45)), url(${logoBgDraftUrl})`,
                          backgroundSize: 'cover',
                          backgroundPosition: 'center',
                        }
                      : undefined
                  }
                  className={`px-5 py-3 rounded-2xl border-2 border-[#FFB300] shadow-2xl flex items-center gap-3 ${
                    !logoBgDraftUrl ? 'fism-gradient-flame' : ''
                  }`}
                >
                  <div
                    style={
                      logoBgDraftUrl
                        ? {
                            backgroundImage: `url(${logoBgDraftUrl})`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center',
                          }
                        : undefined
                    }
                    className="w-11 h-11 rounded-xl fism-gradient-flame flex items-center justify-center text-white shadow-md border border-white/50 relative overflow-hidden"
                  >
                    <Flame className="w-6 h-6 fill-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-1.5">
                      <span className="font-black text-2xl tracking-tight text-white drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]">
                        FISM
                      </span>
                      <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-[#FFB300] text-[#101426]">
                        PRO
                      </span>
                    </div>
                    <div className="text-[10px] font-bold text-white/95 drop-shadow">
                      Flame Interactive Social Media
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-300">
                  ऊपर ऐप के हेडर में नाम <strong>FISM</strong> हमेशा यही रहेगा और पीछे आपका चुना हुआ फोटो दिखेगा।
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: ADMIN SURVEY BUILDER & SURVEY DATA BOARD (LEADERBOARD) */}
      {adminTab === 'surveyBoard' && (
        <div className="space-y-6">
          <div className="fism-card p-5 bg-gradient-to-r from-[#0F172A] via-[#1E3A8A] to-[#31102F] text-white border-2 border-[#2563EB] flex items-center justify-between flex-wrap gap-4">
            <div>
              <span className="px-2.5 py-0.5 rounded bg-[#F59E0B] text-white text-[10px] font-extrabold uppercase">
                Live Screen-Blocking User Survey &amp; Data Board
              </span>
              <h2 className="text-xl font-extrabold mt-1 flex items-center gap-2">
                <Trophy className="w-6 h-6 text-[#F59E0B]" /> Admin File — Multi-Question Survey
                Builder &amp; Data Board
              </h2>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                Create a survey with 1 or more questions. Each question starts with 3 options +{' '}
                <strong>+ Add Option</strong> (up to 20+ options) + a permanently locked{' '}
                <strong>4th/Last Option: &quot;More / Other (अपना जवाब लिखें)&quot;</strong>. Click{' '}
                <strong>Continue &amp; Launch Survey</strong> to display it across the user&apos;s
                screen!
              </p>
            </div>

            {activeSurvey?.isActive && (
              <button
                onClick={() => {
                  onStopSurvey?.();
                  onTriggerToast('Active survey stopped.');
                }}
                className="px-4 py-2.5 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold shadow-lg"
              >
                Stop Active Survey
              </button>
            )}
          </div>

          {/* Survey Builder Card */}
          <div className="fism-card p-5 space-y-5 border-2 border-[#D8E1F0] dark:border-slate-800">
            <div>
              <label className="block text-xs font-extrabold uppercase text-[#52607A] mb-1">
                Survey Campaign Title (सर्वे का टाइटल)
              </label>
              <input
                type="text"
                value={surveyTitle}
                onChange={(e) => setSurveyTitle(e.target.value)}
                placeholder="Enter Survey Title..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-sm font-extrabold"
              />
            </div>

            <div className="space-y-4">
              {surveyQuestions.map((q, qIdx) => (
                <div
                  key={q.id}
                  className="p-4 rounded-2xl bg-[#F8FAFE] dark:bg-slate-900 border-2 border-[#D8E1F0] dark:border-slate-800 space-y-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-[#2563EB] text-white text-xs font-extrabold">
                      Question #{qIdx + 1}
                    </span>
                    {surveyQuestions.length > 1 && (
                      <button
                        onClick={() =>
                          setSurveyQuestions((prev) => prev.filter((item) => item.id !== q.id))
                        }
                        className="text-xs font-bold text-[#DC2626] hover:underline"
                      >
                        Remove Question
                      </button>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold mb-1">
                      Write Question #{qIdx + 1} (अपना सवाल लिखें)
                    </label>
                    <input
                      type="text"
                      value={q.questionText}
                      onChange={(e) => {
                        const val = e.target.value;
                        setSurveyQuestions((prev) =>
                          prev.map((item) =>
                            item.id === q.id ? { ...item, questionText: val } : item,
                          ),
                        );
                      }}
                      placeholder="e.g. आपको हमारे ऐप में अगला कौन सा फीचर चाहिए?"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                    />
                  </div>

                  {/* Options List (Starts with 3 options + Add Option button up to 20+) */}
                  <div className="space-y-2">
                    <div className="text-xs font-extrabold text-[#52607A]">
                      Options ({q.options.length} Custom Options + 1 Locked &quot;More / Other&quot;
                      Option):
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {q.options.map((opt, optIdx) => (
                        <div key={optIdx} className="flex items-center gap-1.5">
                          <span className="px-2.5 py-2 rounded-lg bg-[#EEF3FB] dark:bg-slate-800 text-xs font-extrabold text-[#2563EB] shrink-0">
                            #{optIdx + 1}
                          </span>
                          <input
                            type="text"
                            value={opt}
                            onChange={(e) => {
                              const val = e.target.value;
                              setSurveyQuestions((prev) =>
                                prev.map((item) => {
                                  if (item.id !== q.id) return item;
                                  const nextOpts = [...item.options];
                                  nextOpts[optIdx] = val;
                                  return { ...item, options: nextOpts };
                                }),
                              );
                            }}
                            placeholder={`Option ${optIdx + 1}...`}
                            className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-semibold"
                          />
                          {q.options.length > 3 && (
                            <button
                              onClick={() => {
                                setSurveyQuestions((prev) =>
                                  prev.map((item) => {
                                    if (item.id !== q.id) return item;
                                    return {
                                      ...item,
                                      options: item.options.filter((_, i) => i !== optIdx),
                                    };
                                  }),
                                );
                              }}
                              className="p-1.5 rounded-lg bg-red-500/10 text-[#DC2626] text-xs font-bold"
                              title="Remove option"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      ))}

                      {/* Permanently Locked Final Option: More / Other */}
                      <div className="flex items-center gap-1.5 opacity-95">
                        <span className="px-2.5 py-2 rounded-lg bg-[#FF5722] text-white text-xs font-extrabold shrink-0">
                          Locked #{q.options.length + 1}
                        </span>
                        <div className="flex-1 px-3 py-2 rounded-xl bg-orange-500/10 border border-[#FF5722] text-xs font-extrabold text-[#FF5722]">
                          More / Other (अपना जवाब लिखें — Opens Textbox)
                        </div>
                      </div>
                    </div>

                    <div className="pt-1">
                      <button
                        onClick={() => {
                          setSurveyQuestions((prev) =>
                            prev.map((item) =>
                              item.id === q.id
                                ? {
                                    ...item,
                                    options: [
                                      ...item.options,
                                      `Option ${item.options.length + 1}`,
                                    ],
                                  }
                                : item,
                            ),
                          );
                        }}
                        className="px-3.5 py-2 rounded-xl bg-[#EEF3FB] dark:bg-slate-800 border border-[#2563EB] text-[#2563EB] text-xs font-extrabold flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" /> + Add Option (15–20+ Options Supported)
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between flex-wrap gap-3 pt-2 border-t border-[#D8E1F0] dark:border-slate-800">
              <button
                onClick={() => {
                  setSurveyQuestions((prev) => [
                    ...prev,
                    {
                      id: `q_${Date.now()}_${prev.length + 1}`,
                      questionText: `Question #${prev.length + 1}: आप किस कैटेगरी के वीडियो सबसे ज्यादा देखते हैं?`,
                      options: ['Gaming & Esports', 'Web Development & Tech', 'Sarkari Naukri & Education'],
                    },
                  ]);
                }}
                className="px-4 py-2.5 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
              >
                <Plus className="w-4 h-4" /> + Add Another Question (एक और सवाल जोड़ें)
              </button>

              <button
                onClick={() => {
                  const cleanedQuestions = surveyQuestions
                    .map((q) => ({
                      ...q,
                      questionText: q.questionText.trim() || 'Your Feedback Question',
                      options: q.options.map((o, idx) => o.trim() || `Option ${idx + 1}`),
                    }))
                    .filter((q) => q.options.length >= 3);

                  if (cleanedQuestions.length === 0) {
                    onTriggerToast('Please add at least 1 question with 3 options.');
                    return;
                  }

                  const newCampaign: FismSurveyCampaign = {
                    id: `survey_${Date.now()}`,
                    title: surveyTitle.trim() || 'Official FISM Admin Survey',
                    createdAt: new Date().toLocaleString(),
                    isActive: true,
                    questions: cleanedQuestions,
                  };
                  onLaunchSurvey?.(newCampaign);
                  onTriggerToast(
                    'Survey Launched! It will now appear on the user screen for instant feedback.',
                  );
                }}
                className="fism-btn-primary px-6 py-3 rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-xl"
              >
                <CheckCircle2 className="w-4 h-4" /> Continue &amp; Launch Survey on User Screen →
              </button>
            </div>
          </div>

          {/* SURVEY DATA BOARD (LEADERBOARD OF ALL USER SUBMISSIONS) */}
          <div className="fism-card p-5 space-y-4 border-2 border-[#16A34A]">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3 className="font-extrabold text-base flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-[#16A34A]" /> Survey Data Board &amp; User Review
                  Leaderboard ({surveySubmissions.length} Submissions)
                </h3>
                <p className="text-xs text-[#52607A]">
                  Every time a user selects an option or writes a custom answer in &quot;More /
                  Other&quot; and clicks <strong>Send</strong>, their response is recorded live here!
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-[#16A34A] text-white text-xs font-extrabold">
                Live Data Board
              </span>
            </div>

            {surveySubmissions.length === 0 ? (
              <div className="p-6 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 text-center text-xs font-bold text-[#52607A]">
                No survey responses submitted yet. Launch a survey above and submit a response to see
                it live on the Data Board!
              </div>
            ) : (
              <div className="space-y-3">
                {surveySubmissions.map((sub, idx) => (
                  <div
                    key={sub.id}
                    className="p-4 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 space-y-2"
                  >
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-[#2563EB] text-white text-xs font-extrabold flex items-center justify-center">
                          #{idx + 1}
                        </span>
                        <span className="font-extrabold text-sm">{sub.displayName}</span>
                        <span className="text-xs font-mono text-[#52607A]">
                          (@{sub.username} • ID: {sub.userId})
                        </span>
                      </div>
                      <span className="px-2.5 py-0.5 rounded bg-[#16A34A] text-white text-[10px] font-extrabold">
                        Submitted: {sub.submittedAt}
                      </span>
                    </div>

                    <div className="space-y-1.5 pt-1">
                      {sub.answers.map((ans, aIdx) => (
                        <div
                          key={ans.questionId}
                          className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                        >
                          <div className="font-bold text-[#52607A]">
                            Q{aIdx + 1}: {ans.questionText}
                          </div>
                          <div className="font-extrabold text-[#172033] dark:text-white mt-0.5 flex items-center gap-2 flex-wrap">
                            <span className="px-2 py-0.5 rounded bg-[#FF5722]/15 text-[#FF5722]">
                              Selected: {ans.selectedOption}
                            </span>
                            {ans.customMoreText && (
                              <span className="px-2.5 py-0.5 rounded bg-[#2563EB]/15 text-[#2563EB]">
                                ✍️ Custom &quot;More&quot; Answer: &quot;{ans.customMoreText}&quot;
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB: ADMIN UPI & QR CODE SETUP + ADMIN NOTIFICATIONS / PENDING PAYMENT REQUESTS */}
      {(adminTab === 'upiSetup' || adminTab === 'upiNotifications') && (
        <div className="max-w-[950px] mx-auto space-y-6">
          {/* 1. ADMIN UPI ID & QR CODE UPLOADER CARD */}
          <div className="rounded-2xl p-5 sm:p-6 bg-[#101426] text-white border-2 border-[#FF5722] shadow-[0_12px_35px_rgba(255,87,34,0.28)] space-y-5">
            <div className="flex items-start justify-between flex-wrap gap-3 border-b border-white/15 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FF5722] to-[#E53935] text-white flex items-center justify-center shadow-lg">
                  <QrCode className="w-6 h-6" />
                </div>
                <div>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#FF5722] text-white text-[10px] font-black uppercase tracking-wider">
                    Admin File • UPI &amp; QR Code Master Setup
                  </span>
                  <h2 className="text-lg sm:text-xl font-black mt-1 text-white">
                    1. Admin UPI ID &amp; Payment QR Code Setup (एडमिन UPI और QR कोड सेटअप)
                  </h2>
                  <p className="text-xs text-amber-200/90 mt-0.5">
                    यहाँ अपना <strong>UPI ID</strong> लिखें और <strong>Open File — Select QR Code &amp; Upload</strong> से अपना QR कोड अपलोड करके सेट करें। यही UPI ID और QR कोड यूजर को <strong>Fuel Up</strong> सेक्शन में दिखेगा!
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-xl bg-emerald-500/20 border border-[#16A34A] text-[#4ADE80] text-xs font-extrabold">
                ● Live Active in Fuel Up
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
              {/* Left: UPI ID & Merchant Name Inputs + Open File Select QR Code */}
              <div className="md:col-span-7 space-y-4">
                <div>
                  <label className="block text-xs font-extrabold uppercase tracking-wider text-[#FFB300] mb-1.5">
                    Admin UPI ID (अपना UPI ID जोड़ें) *
                  </label>
                  <input
                    type="text"
                    value={adminUpiIdInput}
                    onChange={(e) => setAdminUpiIdInput(e.target.value)}
                    placeholder="e.g. yourname@okaxis, 9876543210@ybl, merchant@paytm"
                    className="w-full px-4 py-3 rounded-xl bg-[#1A2038] border-2 border-[#FF5722] text-white font-mono text-sm font-extrabold placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#FFB300]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-300 mb-1.5">
                    Receiver / Merchant Name (रिसीवर का नाम)
                  </label>
                  <input
                    type="text"
                    value={adminMerchantNameInput}
                    onChange={(e) => setAdminMerchantNameInput(e.target.value)}
                    placeholder="e.g. FISM Official Flame Pay"
                    className="w-full px-4 py-2.5 rounded-xl bg-[#1A2038] border border-slate-700 text-white text-xs sm:text-sm font-bold focus:outline-none focus:border-[#FF5722]"
                  />
                </div>

                <div className="space-y-2 pt-1">
                  <label className="block text-xs font-extrabold uppercase tracking-wider text-[#FF5722]">
                    Payment QR Code Image (Open File → Select QR Code &amp; Upload)
                  </label>
                  <div className="flex items-center gap-3 flex-wrap">
                    <label className="px-4 py-3 rounded-xl bg-gradient-to-r from-[#FF5722] to-[#E53935] hover:opacity-95 text-white text-xs font-black flex items-center gap-2 cursor-pointer shadow-lg">
                      <Upload className="w-4 h-4" /> Open File — Select QR Code &amp; Upload
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          setAdminQrFileName(file.name);
                          const reader = new FileReader();
                          reader.onload = () => {
                            if (typeof reader.result === 'string') {
                              const dataUrl = reader.result;
                              setAdminQrCodePreview(dataUrl);
                              const updatedConfig: FismUpiConfig = {
                                upiId: adminUpiIdInput.trim() || 'fism.official@okaxis',
                                merchantName:
                                  adminMerchantNameInput.trim() || 'FISM Official Flame Pay',
                                qrCodeUrl: dataUrl,
                                updatedAt: new Date().toLocaleString(),
                              };
                              onUpdateUpiConfig?.(updatedConfig);
                              onTriggerToast(
                                `✅ QR Code "${file.name}" अपलोड और सेट हो गया है! अब यूजर को Fuel Up में दिखेगा।`,
                              );
                            }
                          };
                          reader.readAsDataURL(file);
                          e.target.value = '';
                        }}
                      />
                    </label>
                    <span className="text-xs font-mono text-slate-300 truncate max-w-[220px]">
                      File: {adminQrFileName}
                    </span>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (!adminUpiIdInput.trim()) {
                        onTriggerToast('कृपया अपना UPI ID दर्ज करें!');
                        return;
                      }
                      const updatedConfig: FismUpiConfig = {
                        upiId: adminUpiIdInput.trim(),
                        merchantName:
                          adminMerchantNameInput.trim() || 'FISM Official Flame Pay',
                        qrCodeUrl: adminQrCodePreview,
                        updatedAt: new Date().toLocaleString(),
                      };
                      onUpdateUpiConfig?.(updatedConfig);
                      onTriggerToast(
                        `✅ UPI ID (${updatedConfig.upiId}) और QR Code सफलतापूर्वक सेट हो गया है!`,
                      );
                    }}
                    className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#FF5722] via-[#E53935] to-[#FFB300] text-white text-xs sm:text-sm font-black uppercase tracking-wider shadow-xl flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform"
                  >
                    <CheckCircle2 className="w-5 h-5" /> Upload &amp; Set UPI ID + QR Code (सेट करें)
                  </button>
                </div>
              </div>

              {/* Right: Live QR Code Preview Box */}
              <div className="md:col-span-5 flex flex-col items-center justify-center p-4 rounded-2xl bg-[#1A2038] border-2 border-[#FFB300] text-center space-y-2.5">
                <span className="px-3 py-0.5 rounded-full bg-[#FFB300] text-[#101426] text-[10px] font-black uppercase">
                  Live QR Preview (Fuel Up Checkout)
                </span>
                <div className="w-48 h-48 rounded-2xl bg-white p-2.5 flex items-center justify-center shadow-xl overflow-hidden">
                  {adminQrCodePreview ? (
                    <img
                      src={adminQrCodePreview}
                      alt="Admin UPI QR Code"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="text-[#101426] text-xs font-extrabold p-4">
                      No QR Uploaded Yet
                    </div>
                  )}
                </div>
                <div className="text-xs font-extrabold text-white">
                  {adminMerchantNameInput || 'FISM Official Flame Pay'}
                </div>
                <div className="px-3 py-1 rounded-lg bg-black/50 border border-[#FF5722] font-mono text-xs font-black text-[#FFB300]">
                  UPI ID: {adminUpiIdInput || 'Not Set'}
                </div>
              </div>
            </div>
          </div>

          {/* 2. ADMIN NOTIFICATIONS / PENDING UPI PAYMENT REQUESTS SECTION */}
          <div className="rounded-2xl p-5 sm:p-6 bg-[#101426] text-white border-2 border-[#E53935] shadow-[0_12px_35px_rgba(229,57,53,0.25)] space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-3 border-b border-white/15 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#E53935] to-[#FF5722] text-white flex items-center justify-center shadow-lg">
                  <Bell className="w-6 h-6" />
                </div>
                <div>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#E53935] text-white text-[10px] font-black uppercase">
                    Admin File • Notifications &amp; Payment Verification
                  </span>
                  <h2 className="text-lg sm:text-xl font-black mt-1 text-white">
                    2. Admin Notifications — Pending Fuel Up UPI Requests (नोटिफिकेशन सेक्शन)
                  </h2>
                  <p className="text-xs text-slate-300 mt-0.5">
                    जब भी कोई यूजर पेमेंट करके अपना UPI ID और डिटेल्स भेजेगा, उसका मैसेज यहाँ आएगा।{' '}
                    <strong>[Accept]</strong> करने पर यूजर का तुरंत <strong>Fuel Up</strong> हो जाएगा, और{' '}
                    <strong>[Decline]</strong> करने पर यूजर के नोटिफिकेशन में रीट्राई मैसेज चला जाएगा!
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1.5 rounded-xl bg-[#FF5722] text-white text-xs font-black">
                  Pending: {upiRequests.filter((r) => r.status === 'pending').length}
                </span>
                <span className="px-3 py-1.5 rounded-xl bg-[#1A2038] border border-slate-700 text-slate-200 text-xs font-bold">
                  Total: {upiRequests.length}
                </span>
              </div>
            </div>

            {upiRequests.length === 0 ? (
              <div className="p-8 rounded-2xl bg-[#1A2038] border border-slate-700 text-center space-y-2">
                <Bell className="w-10 h-10 text-[#FF5722] mx-auto opacity-80" />
                <div className="text-sm font-extrabold text-white">
                  अभी कोई UPI Payment Request पेंडिंग नहीं है
                </div>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  जैसे ही कोई यूजर <strong>Fuel Up</strong> सेक्शन में जाकर अपना UPI ID और ट्रांजैक्शन डिटेल भरकर <strong>Send</strong> करेगा, वह तुरंत यहाँ **Accept / Decline** बटन के साथ दिखाई देगा।
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {upiRequests.map((req) => (
                  <div
                    key={req.id}
                    className={`p-4 sm:p-5 rounded-2xl border-2 transition-all ${
                      req.status === 'pending'
                        ? 'bg-[#1A2038] border-[#FF5722] shadow-lg'
                        : req.status === 'accepted'
                          ? 'bg-emerald-950/35 border-[#16A34A]'
                          : 'bg-red-950/35 border-[#DC2626]'
                    }`}
                  >
                    <div className="flex items-start justify-between flex-wrap gap-4">
                      <div className="flex items-start gap-3.5">
                        <img
                          src={req.userAvatar}
                          alt={req.displayName}
                          className="w-12 h-12 rounded-2xl object-cover ring-2 ring-[#FF5722] shrink-0"
                        />
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-base text-white">
                              {req.displayName}
                            </span>
                            <span className="text-xs font-mono text-amber-300">
                              (@{req.username} • ID: {req.userId})
                            </span>
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                                req.requestType === 'sp_coin_pack'
                                  ? 'bg-[#0284C7] text-white'
                                  : 'bg-[#7C3AED] text-white'
                              }`}
                            >
                              {req.requestType === 'sp_coin_pack'
                                ? `🪙 ONLY SP COINS (+${(req.spCoinsAmount || 500).toLocaleString()} SP) — NO PREMIUM`
                                : '👑 FUEL UP PREMIUM (+500 SP + 10k Coins)'}
                            </span>
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                                req.status === 'pending'
                                  ? 'bg-[#FFB300] text-[#101426]'
                                  : req.status === 'accepted'
                                    ? 'bg-[#16A34A] text-white'
                                    : 'bg-[#DC2626] text-white'
                              }`}
                            >
                              {req.status === 'pending'
                                ? '⏳ PENDING APPROVAL'
                                : req.status === 'accepted'
                                  ? req.requestType === 'sp_coin_pack'
                                    ? '✅ CREDITED SP COINS'
                                    : '✅ ACCEPTED (FUEL UP ACTIVE)'
                                  : '❌ DECLINED (RETRY SENT)'}
                            </span>
                          </div>

                          <div className="text-xs text-slate-300">
                            Plan: <strong className="text-[#FFB300]">{req.planName}</strong> · Amount:{' '}
                            <strong className="text-[#4ADE80]">{req.amountLabel}</strong>
                            {req.requestType === 'sp_coin_pack' && req.spCoinsAmount
                              ? ` · Credits ${(req.spCoinsAmount || 0).toLocaleString()} SP Coins Only`
                              : ''}
                            {req.creatorName ? ` · Creator: ${req.creatorName}` : ''}
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
                            <div className="px-3 py-2 rounded-xl bg-black/40 border border-white/10">
                              <div className="text-[10px] uppercase font-bold text-slate-400">
                                User&apos;s UPI ID (यूजर का UPI ID)
                              </div>
                              <div className="font-mono text-xs font-black text-[#FFB300] mt-0.5 break-all">
                                {req.senderUpiId}
                              </div>
                            </div>
                            <div className="px-3 py-2 rounded-xl bg-black/40 border border-white/10">
                              <div className="text-[10px] uppercase font-bold text-slate-400">
                                UTR / Transaction ID
                              </div>
                              <div className="font-mono text-xs font-black text-white mt-0.5 break-all">
                                {req.utrTransactionId}
                              </div>
                            </div>
                            <div className="px-3 py-2 rounded-xl bg-black/40 border border-white/10">
                              <div className="text-[10px] uppercase font-bold text-slate-400">
                                Payer Name &amp; Time
                              </div>
                              <div className="text-xs font-bold text-slate-200 mt-0.5">
                                {req.payerName} · {req.submittedAt}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* ADMIN ACTION BUTTONS: [Accept] & [Decline] */}
                      <div className="flex items-center gap-2.5 flex-wrap self-center">
                        <button
                          type="button"
                          onClick={() => onAcceptUpiRequest?.(req.id)}
                          className="px-5 py-2.5 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg transition-transform hover:scale-105"
                        >
                          <Check className="w-4 h-4" />
                          {req.requestType === 'sp_coin_pack'
                            ? `Accept (+${(req.spCoinsAmount || 500).toLocaleString()} SP Only)`
                            : 'Accept (फ्यूल अप करें)'}
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeclineUpiRequest?.(req.id)}
                          className="px-5 py-2.5 rounded-xl bg-[#DC2626] hover:bg-[#B91C1C] text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg transition-transform hover:scale-105"
                        >
                          <X className="w-4 h-4" /> Decline (अस्वीकार करें)
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 3. ADMIN NOTIFICATIONS — CREATOR $500+ WITHDRAWAL REQUESTS (COPY DETAILS + ACCEPT = SUCCESSFUL / DECLINE = REFUND TO WALLET) */}
          <div className="rounded-2xl p-5 sm:p-6 bg-[#101426] text-white border-2 border-[#FFB300] shadow-[0_12px_35px_rgba(255,179,0,0.22)] space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-3 border-b border-white/15 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FFB300] to-[#FF5722] text-[#101426] flex items-center justify-center shadow-lg">
                  <Crown className="w-6 h-6" />
                </div>
                <div>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#FFB300] text-[#101426] text-[10px] font-black uppercase">
                    Admin File • Creator Earning Withdrawal Requests ($500+ Limit)
                  </span>
                  <h2 className="text-lg sm:text-xl font-black mt-1 text-white">
                    3. Creator Earning Withdrawals — Copy Details, Accept (Successful) or Decline (Refund)
                  </h2>
                  <p className="text-xs text-slate-300 mt-0.5">
                    जब यूजर $500+ लिमिट पूरी करके विड्रॉल अपलोड करता है, तो उसकी पूरी डिटेल (Name, Profile ID, Username, Card / UPI / Amazon Pay) यहाँ आती है। आप <strong>Copy</strong> कर सकते हैं।{' '}
                    <strong>[Accept]</strong> पर क्लिक करने से यूजर को <strong>Successful</strong> दिखेगा, और{' '}
                    <strong>[Decline]</strong> पर क्लिक करने से पैसे यूजर की ID/वॉलेट में वापस चले जाएंगे और उसे <strong>&quot;Your payment is declined&quot;</strong> नोटिफिकेशन मिलेगा!
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1.5 rounded-xl bg-[#FFB300] text-[#101426] text-xs font-black">
                  Pending Withdrawals: {withdrawalRequests.filter((w) => w.status === 'pending').length}
                </span>
                <span className="px-3 py-1.5 rounded-xl bg-[#1A2038] border border-slate-700 text-slate-200 text-xs font-bold">
                  Total: {withdrawalRequests.length}
                </span>
              </div>
            </div>

            {withdrawalRequests.length === 0 ? (
              <div className="p-8 rounded-2xl bg-[#1A2038] border border-slate-700 text-center space-y-2">
                <Crown className="w-10 h-10 text-[#FFB300] mx-auto opacity-80" />
                <div className="text-sm font-extrabold text-white">
                  अभी कोई Creator Withdrawal Request पेंडिंग नहीं है
                </div>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  जैसे ही कोई क्रिएटर <strong>Creator Earning</strong> सेक्शन में $500+ विड्रॉल फॉर्म भरकर <strong>Upload</strong> करेगा, उसकी रिक्वेस्ट यहाँ दिखाई देगी।
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {withdrawalRequests.map((wd) => (
                  <div
                    key={wd.id}
                    className={`p-4 sm:p-5 rounded-2xl border-2 transition-all space-y-4 ${
                      wd.status === 'pending'
                        ? 'bg-[#1A2038] border-[#FFB300] shadow-lg'
                        : wd.status === 'accepted'
                        ? 'bg-emerald-950/35 border-[#16A34A]'
                        : 'bg-red-950/35 border-[#DC2626]'
                    }`}
                  >
                    <div className="flex items-start justify-between flex-wrap gap-4">
                      <div className="flex items-start gap-3.5">
                        <img
                          src={wd.userAvatar}
                          alt={wd.profileName}
                          className="w-12 h-12 rounded-2xl object-cover ring-2 ring-[#FFB300] shrink-0"
                        />
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-base text-white">
                              {wd.userFullName}
                            </span>
                            <span className="text-xs font-mono text-amber-300">
                              (Profile: {wd.profileName} • @{wd.username} • ID: {wd.profileId})
                            </span>
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                                wd.status === 'pending'
                                  ? 'bg-[#FFB300] text-[#101426]'
                                  : wd.status === 'accepted'
                                  ? 'bg-[#16A34A] text-white'
                                  : 'bg-[#DC2626] text-white'
                              }`}
                            >
                              {wd.status === 'pending'
                                ? '⏳ YOUR WITHDRAWAL IS PENDING'
                                : wd.status === 'accepted'
                                ? '✓ SUCCESSFUL (PAID)'
                                : '✕ YOUR PAYMENT IS DECLINED (REFUNDED)'}
                            </span>
                          </div>

                          <div className="text-xs text-slate-200">
                            Withdrawal Amount:{' '}
                            <strong className="text-[#4ADE80] text-sm">
                              {wd.convertedAmountLabel}
                            </strong>{' '}
                            • Country: <strong>{wd.countryName}</strong> • Method:{' '}
                            <strong className="text-[#FFB300]">{wd.paymentMethodLabel}</strong>
                          </div>
                        </div>
                      </div>

                      {/* Copy All Details Button */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          type="button"
                          onClick={() => {
                            const copySummary = `Name: ${wd.userFullName} | Profile Name: ${wd.profileName} | Username: @${wd.username} | Profile ID: ${wd.profileId} | Amount: ${wd.convertedAmountLabel} | Method: ${wd.paymentMethodLabel} | Details: ${wd.paymentAccountDetails}`;
                            navigator.clipboard?.writeText(copySummary);
                            onTriggerToast(`✅ Copied full withdrawal details for ${wd.userFullName}!`);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-amber-300 text-xs font-extrabold flex items-center gap-1.5 border border-amber-400/30"
                        >
                          <Copy className="w-3.5 h-3.5" /> Copy All Info
                        </button>
                      </div>
                    </div>

                    {/* Copyable Info Boxes (Profile ID, Username/Name, Payment Account Details) */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-[10px] uppercase font-bold text-slate-400">
                            User Name &amp; Profile Name
                          </div>
                          <div className="font-bold text-xs text-white truncate">
                            {wd.userFullName} ({wd.profileName})
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard?.writeText(`${wd.userFullName} (${wd.profileName})`);
                            onTriggerToast(`Copied Name: ${wd.userFullName}`);
                          }}
                          className="p-1.5 rounded-lg bg-white/10 hover:bg-[#FF5722] text-white shrink-0"
                          title="Copy Name"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-[10px] uppercase font-bold text-slate-400">
                            Profile ID &amp; @Username
                          </div>
                          <div className="font-mono font-black text-xs text-amber-300 truncate">
                            {wd.profileId} (@{wd.username})
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard?.writeText(`${wd.profileId} (@${wd.username})`);
                            onTriggerToast(`Copied Profile ID: ${wd.profileId}`);
                          }}
                          className="p-1.5 rounded-lg bg-white/10 hover:bg-[#FF5722] text-white shrink-0"
                          title="Copy Profile ID"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-[10px] uppercase font-bold text-slate-400">
                            {wd.paymentMethodLabel} Details
                          </div>
                          <div className="font-mono font-black text-xs text-[#4ADE80] truncate">
                            {wd.paymentAccountDetails}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard?.writeText(wd.paymentAccountDetails);
                            onTriggerToast(`Copied Payment Details: ${wd.paymentAccountDetails}`);
                          }}
                          className="p-1.5 rounded-lg bg-white/10 hover:bg-[#16A34A] text-white shrink-0"
                          title="Copy Payment Account Details"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* ADMIN ACCEPT (SUCCESSFUL) & DECLINE (REFUND TO WALLET) BUTTONS */}
                    <div className="flex items-center justify-between flex-wrap gap-3 pt-2 border-t border-white/10">
                      <span className="text-[11px] text-slate-400 font-mono">
                        Submitted: {wd.submittedAt}
                        {wd.reviewedAt ? ` • Reviewed: ${wd.reviewedAt}` : ''}
                      </span>

                      <div className="flex items-center gap-2.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => onAcceptWithdrawalRequest?.(wd.id)}
                          className="px-5 py-2.5 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg transition-transform hover:scale-105"
                        >
                          <Check className="w-4 h-4" /> Accept (Mark Successful)
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeclineWithdrawalRequest?.(wd.id)}
                          className="px-5 py-2.5 rounded-xl bg-[#DC2626] hover:bg-[#B91C1C] text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg transition-transform hover:scale-105"
                        >
                          <X className="w-4 h-4" /> Decline (Refund to User ID)
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* LONG-PRESS FULL USER DATA TELEMETRY MODAL */}
      {inspectedUser && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto">
          <div className="fism-card max-w-2xl w-full p-6 space-y-4 border-2 border-[#7C3AED] my-8">
            <div className="flex items-center justify-between border-b border-[#D8E1F0] dark:border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <img
                  src={inspectedUser.avatarUrl}
                  alt={inspectedUser.displayName}
                  className="w-12 h-12 rounded-2xl object-cover ring-2 ring-[#7C3AED]"
                />
                <div>
                  <h3 className="font-extrabold text-lg flex items-center gap-2">
                    {inspectedUser.displayName} — Complete Admin Dossier
                  </h3>
                  <p className="text-xs text-[#52607A]">
                    User ID: {inspectedUser.uid} • Status:{' '}
                    {inspectedUser.isBanned ? 'BANNED' : 'UNBANNED (LIVE)'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setInspectedUser(null)}
                className="p-1.5 rounded-lg bg-[#F3F6FC] dark:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Credentials, Email, Live IP Address, One-Way Hash Status, Verified Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800">
                <div className="text-[10px] font-bold uppercase text-[#52607A]">Email ID</div>
                <div className="font-mono font-bold text-xs mt-1 break-all">
                  {inspectedUser.email}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-[#16A34A]">
                <div className="text-[10px] font-bold uppercase text-[#16A34A]">
                  Real-Time IP Address
                </div>
                <div className="font-mono font-extrabold text-xs mt-1 text-[#16A34A] break-all">
                  {inspectedUser.ipAddress || '103.84.219.14 (Live)'}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800">
                <div className="text-[10px] font-bold uppercase text-[#52607A] flex items-center gap-1">
                  <Key className="w-3 h-3 text-[#16A34A]" /> Cryptographic Hash
                </div>
                <div className="font-mono font-bold text-xs mt-1 text-[#16A34A] break-all">
                  Argon2id Verified
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800">
                <div className="text-[10px] font-bold uppercase text-[#52607A]">
                  Verified Phone Status
                </div>
                <div className="font-mono font-bold text-xs mt-1">
                  {inspectedUser.phoneNumber}
                </div>
              </div>
            </div>

            {/* Profile Bio & Upload / Sparks / Flames Counts */}
            <div className="p-3.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 space-y-2">
              <div className="text-xs font-extrabold">Profile Description &amp; Social Stats</div>
              <p className="text-xs text-[#52607A] dark:text-slate-300">{inspectedUser.bio}</p>
              {inspectedUser.categories && inspectedUser.categories.length > 0 && (
                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  {inspectedUser.categories.map((cat) => (
                    <span
                      key={cat}
                      className="px-2 py-0.5 rounded bg-[#7C3AED]/15 text-[#7C3AED] text-[10px] font-extrabold"
                    >
                      #{cat}
                    </span>
                  ))}
                </div>
              )}
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#D8E1F0] dark:border-slate-700 text-center">
                <div>
                  <div className="font-extrabold text-sm">{inspectedUser.videosUploadedCount}</div>
                  <div className="text-[10px] text-[#52607A]">Videos Uploaded</div>
                </div>
                <div>
                  <div className="font-extrabold text-sm">
                    {inspectedUser.sparksFollowersCount.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-[#52607A]">Sparks</div>
                </div>
                <div>
                  <div className="font-extrabold text-sm">
                    {inspectedUser.flamesFollowingCount}
                  </div>
                  <div className="text-[10px] text-[#52607A]">Flames</div>
                </div>
              </div>
            </div>

            {/* What they used & Why they used it */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-xl bg-[#EEF3FB] dark:bg-slate-800 border border-[#2563EB]">
                <div className="text-xs font-extrabold text-[#2563EB]">
                  What Features Used (क्या यूज किया)
                </div>
                <p className="text-xs mt-1">{inspectedUser.whatUsedSummary}</p>
              </div>
              <div className="p-3.5 rounded-xl bg-[#EEF3FB] dark:bg-slate-800 border border-[#7C3AED]">
                <div className="text-xs font-extrabold text-[#7C3AED]">
                  Why Used / Activity Intent (क्यों यूज किया)
                </div>
                <p className="text-xs mt-1">{inspectedUser.whyUsedSummary}</p>
              </div>
            </div>

            {/* Real-Time Live Activity Stream (अभी क्या कर रहा है और क्यों) */}
            {inspectedUser.liveActivities && inspectedUser.liveActivities.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-[#16A34A] flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#16A34A]" /> Live Real-Time User Activity Log
                  (यूजर ने कब क्या किया और क्यों)
                </h4>
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {inspectedUser.liveActivities.map((act, i) => (
                    <div
                      key={i}
                      className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between gap-2 text-xs"
                    >
                      <div>
                        <span className="font-extrabold">{act.action}</span>
                        <span className="text-[#52607A] dark:text-slate-300 ml-2">
                          — {act.reason}
                        </span>
                      </div>
                      <span className="font-mono text-[10px] font-bold text-[#16A34A] shrink-0">
                        {act.timestamp}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Complete Video Watch History with Exact Timestamps */}
            <div className="space-y-2">
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-[#52607A] flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-[#FF5722]" /> Video Watch History (कौन सा वीडियो कब और
                किस टाइम देखा)
              </h4>
              <div className="space-y-2 max-h-44 overflow-y-auto">
                {inspectedUser.watchHistory.map((w, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 flex items-center justify-between gap-2 text-xs"
                  >
                    <div>
                      <div className="font-bold">{w.videoTitle}</div>
                      <div className="text-[11px] text-[#52607A]">
                        Date: {w.watchedAtDate} • Exact Time: <strong>{w.watchedAtTime}</strong>
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded bg-[#FF5722] text-white font-mono text-[11px] font-bold shrink-0">
                      {w.durationWatched}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => onToggleBanUser(inspectedUser.uid)}
                className={`px-4 py-2 rounded-xl text-xs font-extrabold text-white ${
                  inspectedUser.isBanned ? 'bg-[#16A34A]' : 'bg-[#DC2626]'
                }`}
              >
                {inspectedUser.isBanned ? 'Unban This User ID' : 'Ban This User ID'}
              </button>
              <button
                onClick={() => setInspectedUser(null)}
                className="px-5 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 text-xs font-bold"
              >
                Close Dossier
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// 5. FLOATING AI CHATBOT LAUNCHER WIDGET (Click to Open, Long-Press to Dismiss)
// ============================================================================
interface FloatingChatbotProps {
  visible: boolean;
  onDismiss: () => void;
  onOpenFullStudio: () => void;
}

export const FismFloatingChatbotWidget: React.FC<FloatingChatbotProps> = ({
  visible,
  onDismiss,
  onOpenFullStudio,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([
    {
      role: 'model',
      text: '🔥 Hi! I am your FISM Flame AI Assistant. Ask me anything about content ideas, Shorts editing, or platform features! (Tip: Long-press my floating icon anytime to hide me.)',
    },
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const pressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const didLongPressRef = useRef(false);

  if (!visible) return null;

  const startHold = () => {
    didLongPressRef.current = false;
    if (pressTimerRef.current) clearTimeout(pressTimerRef.current);
    pressTimerRef.current = setTimeout(() => {
      didLongPressRef.current = true;
      setIsOpen(false);
      onDismiss();
    }, 550);
  };

  const endHold = () => {
    if (pressTimerRef.current) {
      clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || busy) return;
    const userMsg = input.trim();
    setInput('');
    const updated = [...messages, { role: 'user' as const, text: userMsg }];
    setMessages(updated);
    setBusy(true);
    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'fast',
          history: updated.slice(0, -1),
          message: userMsg,
        }),
      });
      const data = await res.json();
      const rawReply = String(data?.text || '');
      const cleanReply =
        rawReply &&
        !rawReply.includes('"code":429') &&
        !rawReply.includes('RESOURCE_EXHAUSTED') &&
        !rawReply.includes('exceeded your current quota')
          ? rawReply
          : '🔥 **FISM Smart AI Assistant:**\nMain aapki madad ke liye taiyaar hoon! Aap Spark New (+) se Shorts/Videos upload kar sakte hain, Quick Burst mein 3-dot (•••) menu se Speed (1x–3x) & Voice Translation chala sakte hain, ya AI Studio mein Photo/Video generate kar sakte hain.';
      setMessages((prev) => [
        ...prev,
        {
          role: 'model',
          text: cleanReply,
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: 'model',
          text: '🔥 FISM AI Assistant ready hai! Spark New (+) se photo/video upload karein ya AI Studio mein Photo & Video banayein.',
        },
      ]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed bottom-20 right-4 z-40 flex flex-col items-end">
      {isOpen && (
        <div className="mb-3 w-80 sm:w-96 max-w-[calc(100vw-2rem)] fism-card shadow-2xl border-2 border-[#FF5722] overflow-hidden flex flex-col">
          <div className="p-3.5 fism-gradient-flame text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <div>
                <div className="font-extrabold text-xs">FISM Flame AI Assistant</div>
                <div className="text-[10px] text-white/85">Long-press launcher icon to hide</div>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  setIsOpen(false);
                  onOpenFullStudio();
                }}
                className="px-2 py-1 rounded bg-black/25 text-[10px] font-bold"
              >
                Full Studio
              </button>
              <button
                onClick={onDismiss}
                title="Hide floating AI icon"
                className="px-2 py-1 rounded bg-black/25 text-[10px] font-bold"
              >
                Hide Icon
              </button>
              <button onClick={() => setIsOpen(false)} className="p-1">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="p-3 space-y-2.5 max-h-64 overflow-y-auto bg-white dark:bg-[#111827] text-xs">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`p-2.5 rounded-xl max-w-[88%] whitespace-pre-wrap ${
                  m.role === 'user'
                    ? 'ml-auto fism-gradient-flame text-white font-semibold'
                    : 'bg-[#F3F6FC] dark:bg-slate-800 text-[#172033] dark:text-white'
                }`}
              >
                {m.text}
              </div>
            ))}
            {busy && (
              <div className="text-[11px] text-[#FF5722] font-bold animate-pulse">
                FISM AI is thinking...
              </div>
            )}
          </div>

          <div className="p-2.5 border-t border-[#D8E1F0] dark:border-slate-800 bg-white dark:bg-[#111827] flex gap-1.5">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask FISM AI in Hindi or English..."
              className="flex-1 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-[#0F172A] dark:text-white placeholder:text-[#64748B] border border-[#CBD5E1] dark:border-slate-700 text-xs font-medium"
            />
            <button
              onClick={handleSendMessage}
              className="fism-btn-primary px-3 py-1.5 rounded-xl text-xs font-extrabold"
            >
              Send
            </button>
          </div>
        </div>
      )}

      {/* Sleek Floating Launcher Button (Click to Open, Long-Press to Dismiss) */}
      <button
        onMouseDown={startHold}
        onMouseUp={endHold}
        onMouseLeave={endHold}
        onTouchStart={startHold}
        onTouchEnd={endHold}
        onClick={() => {
          if (didLongPressRef.current) return;
          setIsOpen((o) => !o);
        }}
        title="Click to open FISM AI Chatbot • Long-Press (Hold) to dismiss from screen"
        className="w-13 h-13 rounded-full fism-gradient-flame text-white shadow-[0_6px_25px_rgba(255,87,34,0.55)] border-2 border-white dark:border-slate-900 flex items-center justify-center hover:scale-105 active:scale-95 transition-transform select-none"
      >
        <Sparkles className="w-6 h-6" />
      </button>
    </div>
  );
};

// ============================================================================
// 6. DEDICATED 2D MULTI-GAME HUB (Play-Only for Normal Users; Admin Uploads via Admin File)
// ============================================================================
interface Fism2DGameCenterProps {
  games: FismGameItem[];
  onTriggerToast: (msg: string) => void;
}

export const Fism2DGameCenter: React.FC<Fism2DGameCenterProps> = ({
  games,
  onTriggerToast,
}) => {
  const [selectedGame, setSelectedGame] = useState<FismGameItem>(
    games[0] || INITIAL_GAMES[0],
  );
  const [gameState, setGameState] = useState<'MENU' | 'PLAYING' | 'PAUSED' | 'GAME_OVER'>('MENU');
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(280);
  const [lives, setLives] = useState<number>(3);
  const [soundOn, setSoundOn] = useState<boolean>(true);
  const [emojiDefenseOpen, setEmojiDefenseOpen] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const gameStateRef = useRef(gameState);
  gameStateRef.current = gameState;
  const soundOnRef = useRef(soundOn);
  soundOnRef.current = soundOn;

  // Web Audio Synth Beep Helper
  const playArcadeBeep = (freq = 520, duration = 0.08) => {
    if (!soundOnRef.current) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Ignore audio context autoplay restriction
    }
  };

  // Input Ref shared with the 2D Canvas Game Loop
  const inputRef = useRef({
    left: false,
    right: false,
    up: false,
    down: false,
    jumpPressed: false,
    firePressed: false,
  });

  const handleStartSelectedGame = (game: FismGameItem) => {
    setSelectedGame(game);
    if (game.engineType === 'redBallDefense2D') {
      setEmojiDefenseOpen(true);
      return;
    }
    setScore(0);
    setLives(3);
    setGameState('PLAYING');
    playArcadeBeep(660, 0.12);
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') inputRef.current.left = true;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') inputRef.current.right = true;
      if (e.code === 'ArrowUp' || e.code === 'KeyW') {
        inputRef.current.up = true;
        inputRef.current.jumpPressed = true;
      }
      if (e.code === 'ArrowDown' || e.code === 'KeyS') inputRef.current.down = true;
      if (e.code === 'Space') {
        inputRef.current.jumpPressed = true;
        inputRef.current.firePressed = true;
      }
      if (e.code === 'KeyF' || e.code === 'Enter') {
        inputRef.current.firePressed = true;
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') inputRef.current.left = false;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') inputRef.current.right = false;
      if (e.code === 'ArrowUp' || e.code === 'KeyW') inputRef.current.up = false;
      if (e.code === 'ArrowDown' || e.code === 'KeyS') inputRef.current.down = false;
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, []);

  // Main 2D HTML5 Canvas Game Loop (Supports Flame Runner 2D, Brick Breaker 2D, Cyber Snake 2D & Custom Admin 2D Games)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    let animId = 0;

    // Shared mutable state for active 2D engine
    let localScore = 0;
    let localLives = 3;

    // Engine A: Flame Runner 2D / Custom Admin 2D Starfighter state
    const runner = {
      x: 90,
      y: H - 90,
      vy: 0,
      onGround: true,
    };
    const fireballs: { x: number; y: number }[] = [];
    const obstacles: { x: number; y: number; w: number; h: number; isOrb: boolean }[] = [];
    let spawnTick = 0;

    // Engine B: Ember Brick Breaker 2D state
    let paddleX = W / 2 - 60;
    const ball = { x: W / 2, y: H - 70, vx: 4.4, vy: -4.6 };
    const bricks: { x: number; y: number; w: number; h: number; alive: boolean; color: string }[] = [];
    const colors = ['#FF5722', '#F59E0B', '#7C3AED', '#2563EB', '#16A34A'];
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 9; c++) {
        bricks.push({
          x: 34 + c * 82,
          y: 48 + r * 30,
          w: 74,
          h: 22,
          alive: true,
          color: colors[r % colors.length],
        });
      }
    }

    // Engine C: Neon Flame Snake 2D state
    const gridSize = 20;
    let snake = [
      { x: 10, y: 10 },
      { x: 9, y: 10 },
      { x: 8, y: 10 },
    ];
    let snakeDir = { x: 1, y: 0 };
    let food = { x: 16, y: 10 };
    let snakeTick = 0;

    const loop = () => {
      animId = requestAnimationFrame(loop);

      // Background
      const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
      bgGrad.addColorStop(0, '#090D16');
      bgGrad.addColorStop(1, '#1E1B4B');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, W, H);

      // Subtle 2D cyber grid
      ctx.strokeStyle = 'rgba(255, 87, 34, 0.12)';
      ctx.lineWidth = 1;
      for (let gx = 0; gx < W; gx += 40) {
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.lineTo(gx, H);
        ctx.stroke();
      }
      for (let gy = 0; gy < H; gy += 40) {
        ctx.beginPath();
        ctx.moveTo(0, gy);
        ctx.lineTo(W, gy);
        ctx.stroke();
      }

      if (gameStateRef.current !== 'PLAYING') {
        return;
      }

      const engine = selectedGame.engineType;

      // ----------------------------------------------------------------------
      // ENGINE 1: BRICK BREAKER 2D
      // ----------------------------------------------------------------------
      if (engine === 'brickBreaker2D') {
        if (inputRef.current.left) paddleX = Math.max(12, paddleX - 7.5);
        if (inputRef.current.right) paddleX = Math.min(W - 132, paddleX + 7.5);

        ball.x += ball.vx;
        ball.y += ball.vy;

        if (ball.x < 12 || ball.x > W - 12) ball.vx *= -1;
        if (ball.y < 12) ball.vy *= -1;

        // Paddle bounce
        if (
          ball.y >= H - 46 &&
          ball.y <= H - 28 &&
          ball.x >= paddleX - 8 &&
          ball.x <= paddleX + 128
        ) {
          ball.vy = -Math.abs(ball.vy);
          const hitOffset = (ball.x - (paddleX + 60)) / 60;
          ball.vx = hitOffset * 6.2;
          playArcadeBeep(540, 0.06);
        }

        // Brick collisions
        for (const b of bricks) {
          if (!b.alive) continue;
          if (
            ball.x >= b.x &&
            ball.x <= b.x + b.w &&
            ball.y >= b.y &&
            ball.y <= b.y + b.h
          ) {
            b.alive = false;
            ball.vy *= -1;
            localScore += 20;
            setScore(localScore);
            setHighScore((hs) => Math.max(hs, localScore));
            playArcadeBeep(780, 0.07);
            break;
          }
        }

        // Respawn bricks if all cleared
        if (bricks.every((b) => !b.alive)) {
          bricks.forEach((b) => {
            b.alive = true;
          });
          localScore += 100;
          setScore(localScore);
        }

        // Missed ball
        if (ball.y > H) {
          localLives -= 1;
          setLives(localLives);
          playArcadeBeep(220, 0.18);
          if (localLives <= 0) {
            setGameState('GAME_OVER');
            return;
          }
          ball.x = W / 2;
          ball.y = H - 70;
          ball.vx = 4.2;
          ball.vy = -4.6;
        }

        // Draw Bricks
        for (const b of bricks) {
          if (!b.alive) continue;
          ctx.fillStyle = b.color;
          ctx.fillRect(b.x, b.y, b.w, b.h);
          ctx.strokeStyle = '#FFFFFF';
          ctx.strokeRect(b.x, b.y, b.w, b.h);
        }

        // Draw Paddle
        ctx.fillStyle = '#FF5722';
        ctx.fillRect(paddleX, H - 38, 120, 14);

        // Draw Ball
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, 9, 0, Math.PI * 2);
        ctx.fillStyle = '#FEF08A';
        ctx.fill();
        return;
      }

      // ----------------------------------------------------------------------
      // ENGINE 2: NEON FLAME SNAKE 2D
      // ----------------------------------------------------------------------
      if (engine === 'cyberSnake2D') {
        if (inputRef.current.left && snakeDir.x === 0) snakeDir = { x: -1, y: 0 };
        if (inputRef.current.right && snakeDir.x === 0) snakeDir = { x: 1, y: 0 };
        if (inputRef.current.up && snakeDir.y === 0) snakeDir = { x: 0, y: -1 };
        if (inputRef.current.down && snakeDir.y === 0) snakeDir = { x: 0, y: 1 };

        snakeTick++;
        if (snakeTick % 6 === 0) {
          const cols = Math.floor(W / gridSize);
          const rows = Math.floor(H / gridSize);
          const head = {
            x: (snake[0].x + snakeDir.x + cols) % cols,
            y: (snake[0].y + snakeDir.y + rows) % rows,
          };

          // Self collision check
          if (snake.some((seg) => seg.x === head.x && seg.y === head.y)) {
            localLives -= 1;
            setLives(localLives);
            playArcadeBeep(200, 0.2);
            if (localLives <= 0) {
              setGameState('GAME_OVER');
              return;
            }
            snake = [
              { x: 10, y: 10 },
              { x: 9, y: 10 },
              { x: 8, y: 10 },
            ];
            snakeDir = { x: 1, y: 0 };
          } else {
            snake.unshift(head);
            if (head.x === food.x && head.y === food.y) {
              localScore += 25;
              setScore(localScore);
              setHighScore((hs) => Math.max(hs, localScore));
              playArcadeBeep(840, 0.08);
              food = {
                x: Math.floor(Math.random() * (cols - 2)) + 1,
                y: Math.floor(Math.random() * (rows - 2)) + 1,
              };
            } else {
              snake.pop();
            }
          }
        }

        // Draw Food Orb
        ctx.fillStyle = '#F59E0B';
        ctx.beginPath();
        ctx.arc(
          food.x * gridSize + gridSize / 2,
          food.y * gridSize + gridSize / 2,
          gridSize * 0.45,
          0,
          Math.PI * 2,
        );
        ctx.fill();

        // Draw Snake
        snake.forEach((seg, idx) => {
          ctx.fillStyle = idx === 0 ? '#FF5722' : '#16A34A';
          ctx.fillRect(
            seg.x * gridSize + 1,
            seg.y * gridSize + 1,
            gridSize - 2,
            gridSize - 2,
          );
        });
        return;
      }

      // ----------------------------------------------------------------------
      // ENGINE 3: FLAME RUNNER 2D & ADMIN UPLOADED 2D GAMES
      // ----------------------------------------------------------------------
      const groundY = H - 56;
      // Draw Neon Ground Floor
      ctx.fillStyle = '#1E293B';
      ctx.fillRect(0, groundY, W, 56);
      ctx.fillStyle = '#FF5722';
      ctx.fillRect(0, groundY, W, 4);

      // Horizontal movement
      if (inputRef.current.left) runner.x = Math.max(30, runner.x - 5.5);
      if (inputRef.current.right) runner.x = Math.min(W - 90, runner.x + 5.5);

      // Jump physics
      if (inputRef.current.jumpPressed && runner.onGround) {
        runner.vy = -12.5;
        runner.onGround = false;
        inputRef.current.jumpPressed = false;
        playArcadeBeep(520, 0.08);
      } else {
        inputRef.current.jumpPressed = false;
      }

      runner.y += runner.vy;
      runner.vy += 0.62;
      if (runner.y >= groundY - 44) {
        runner.y = groundY - 44;
        runner.vy = 0;
        runner.onGround = true;
      }

      // Shoot Fireballs
      if (inputRef.current.firePressed) {
        fireballs.push({ x: runner.x + 42, y: runner.y + 18 });
        inputRef.current.firePressed = false;
        playArcadeBeep(720, 0.05);
      }

      // Spawn Obstacles & Collectible Flame Orbs
      spawnTick++;
      if (spawnTick % 55 === 0) {
        const isOrb = Math.random() > 0.45;
        obstacles.push({
          x: W + 20,
          y: isOrb ? groundY - 95 - Math.random() * 55 : groundY - 42,
          w: isOrb ? 26 : 34,
          h: isOrb ? 26 : 42,
          isOrb,
        });
      }

      // Update Fireballs
      for (let i = fireballs.length - 1; i >= 0; i--) {
        fireballs[i].x += 9.5;
        ctx.fillStyle = '#FEF08A';
        ctx.beginPath();
        ctx.arc(fireballs[i].x, fireballs[i].y, 7, 0, Math.PI * 2);
        ctx.fill();
        if (fireballs[i].x > W) fireballs.splice(i, 1);
      }

      // Update Obstacles & Orbs
      for (let i = obstacles.length - 1; i >= 0; i--) {
        const ob = obstacles[i];
        ob.x -= 5.2;

        if (ob.isOrb) {
          ctx.fillStyle = '#F59E0B';
          ctx.beginPath();
          ctx.arc(ob.x + 13, ob.y + 13, 13, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = '#DC2626';
          ctx.fillRect(ob.x, ob.y, ob.w, ob.h);
          ctx.strokeStyle = '#FCA5A5';
          ctx.strokeRect(ob.x, ob.y, ob.w, ob.h);
        }

        // Check fireball hit on obstacle
        if (!ob.isOrb) {
          for (let f = fireballs.length - 1; f >= 0; f--) {
            const fb = fireballs[f];
            if (
              fb.x >= ob.x &&
              fb.x <= ob.x + ob.w &&
              fb.y >= ob.y &&
              fb.y <= ob.y + ob.h
            ) {
              fireballs.splice(f, 1);
              obstacles.splice(i, 1);
              localScore += 15;
              setScore(localScore);
              setHighScore((hs) => Math.max(hs, localScore));
              playArcadeBeep(880, 0.07);
              break;
            }
          }
        }

        // Check player collision
        if (
          obstacles[i] &&
          runner.x < ob.x + ob.w &&
          runner.x + 38 > ob.x &&
          runner.y < ob.y + ob.h &&
          runner.y + 44 > ob.y
        ) {
          if (ob.isOrb) {
            localScore += 20;
            setScore(localScore);
            setHighScore((hs) => Math.max(hs, localScore));
            playArcadeBeep(920, 0.08);
          } else {
            localLives -= 1;
            setLives(localLives);
            playArcadeBeep(190, 0.2);
            if (localLives <= 0) {
              setGameState('GAME_OVER');
              return;
            }
          }
          obstacles.splice(i, 1);
          continue;
        }

        if (ob.x < -50) obstacles.splice(i, 1);
      }

      // Draw Player 2D Hero Avatar
      ctx.fillStyle = '#FF5722';
      ctx.fillRect(runner.x, runner.y, 38, 44);
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(runner.x + 22, runner.y + 8, 10, 8);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [selectedGame]);

  return (
    <div className="space-y-6">
      {/* Top 2D Game Hub Banner (Play-Only for Normal Users) */}
      <div className="fism-card p-5 border-2 border-[#FF5722] flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl fism-gradient-flame text-white flex items-center justify-center shadow-lg">
            <Gamepad2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-extrabold">
                FISM 2D Arcade Game Hub (2D गेम्स सेक्शन)
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-[#16A34A] text-white text-[10px] font-extrabold uppercase">
                60FPS 2D Smooth Arcade • Play Only
              </span>
            </div>
            <p className="text-xs text-[#52607A] dark:text-slate-300 mt-0.5">
              Select any 2D game below and click <strong>&quot;Play Game&quot;</strong> to play
              instantly! (New game uploads are restricted to the Admin File Vault.)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3.5 py-2 rounded-xl bg-[#F59E0B] text-white text-xs font-extrabold flex items-center gap-1.5 shadow">
            <Trophy className="w-4 h-4" /> High Score: {highScore}
          </span>
        </div>
      </div>

      {/* 2D Game Catalog Grid — Click "Play Game" on Any Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {games.map((game) => {
          const isSelected = selectedGame.id === game.id;
          return (
            <div
              key={game.id}
              className={`fism-card p-4 border-2 transition-all flex flex-col justify-between gap-3 ${
                isSelected
                  ? 'border-[#FF5722] bg-orange-50/30 dark:bg-slate-800/90'
                  : 'border-[#D8E1F0] dark:border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="px-2.5 py-0.5 rounded-lg bg-[#7C3AED] text-white text-[10px] font-extrabold uppercase">
                    {game.category}
                  </span>
                  <span className="text-[11px] font-mono text-[#52607A]">
                    {game.createdAt}
                  </span>
                </div>
                <h3 className="font-extrabold text-base sm:text-lg mt-2">{game.title}</h3>
                <p className="text-xs text-[#52607A] dark:text-slate-300 mt-1">
                  {game.description}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-[#D8E1F0] dark:border-slate-700">
                <span className="text-[11px] font-bold text-[#2563EB]">
                  🎮 {game.name}
                </span>
                <button
                  onClick={() => handleStartSelectedGame(game)}
                  className="fism-btn-primary px-5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-md"
                >
                  <Play className="w-4 h-4" /> Play Game
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active 2D Canvas Game Viewport & Controls */}
      <div className="fism-card overflow-hidden border-2 border-[#7C3AED]">
        {/* Top Game HUD Bar */}
        <div className="p-3.5 bg-[#0F172A] text-white flex items-center justify-between flex-wrap gap-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Gamepad2 className="w-5 h-5 text-[#FF5722]" />
            <div>
              <div className="font-extrabold text-sm">{selectedGame.title}</div>
              <div className="text-[11px] text-slate-400">
                Controls: Arrow Keys / WASD + Spacebar (or use Touch Controls below)
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* 3 Lives */}
            <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800">
              <span className="text-xs font-bold mr-1">Lives:</span>
              {[1, 2, 3].map((i) => (
                <Heart
                  key={i}
                  className={`w-4 h-4 ${
                    i <= lives ? 'text-[#E53935] fill-[#E53935]' : 'text-slate-600'
                  }`}
                />
              ))}
            </div>

            <div className="px-3 py-1.5 rounded-xl bg-[#F59E0B] text-white font-extrabold text-xs">
              Score: {score}
            </div>

            <button
              onClick={() => setSoundOn((s) => !s)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 text-white text-xs font-bold"
            >
              {soundOn ? '🔊 SFX ON' : '🔇 SFX Mute'}
            </button>

            {gameState === 'PLAYING' ? (
              <button
                onClick={() => setGameState('PAUSED')}
                className="px-3.5 py-1.5 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold flex items-center gap-1"
              >
                <Pause className="w-3.5 h-3.5" /> Pause
              </button>
            ) : (
              <button
                onClick={() => handleStartSelectedGame(selectedGame)}
                className="px-4 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1"
              >
                <Play className="w-3.5 h-3.5" /> Play Game
              </button>
            )}
          </div>
        </div>

        {/* 2D Canvas Stage */}
        <div className="relative bg-[#090D16] flex items-center justify-center">
          <canvas
            ref={canvasRef}
            width={800}
            height={420}
            className="w-full max-h-[420px] object-contain block"
          />

          {/* Title / Pause / Game Over Overlay */}
          {gameState !== 'PLAYING' && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6 text-white space-y-4">
              <div className="w-16 h-16 rounded-2xl fism-gradient-flame flex items-center justify-center shadow-2xl">
                <Gamepad2 className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
                {gameState === 'GAME_OVER'
                  ? `GAME OVER! Final Score: ${score}`
                  : gameState === 'PAUSED'
                    ? 'GAME PAUSED'
                    : selectedGame.title}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 max-w-md">
                {selectedGame.description}
              </p>
              <div className="flex items-center gap-3 flex-wrap justify-center">
                <button
                  onClick={() => {
                    if (gameState === 'PAUSED') {
                      setGameState('PLAYING');
                    } else {
                      handleStartSelectedGame(selectedGame);
                    }
                  }}
                  className="fism-btn-primary px-7 py-3 rounded-xl font-extrabold text-sm flex items-center gap-2 shadow-xl"
                >
                  <Play className="w-4 h-4" />
                  {gameState === 'PAUSED' ? 'Resume 2D Game' : '▶ Play Game Now'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* On-Screen Touch / Click Arcade Controls for Mobile & Desktop */}
        <div className="p-3.5 bg-[#0F172A] border-t border-slate-800 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <button
              onMouseDown={() => {
                inputRef.current.left = true;
              }}
              onMouseUp={() => {
                inputRef.current.left = false;
              }}
              onTouchStart={() => {
                inputRef.current.left = true;
              }}
              onTouchEnd={() => {
                inputRef.current.left = false;
              }}
              className="px-4 py-2.5 rounded-xl bg-slate-800 active:bg-[#FF5722] text-white text-xs font-extrabold select-none"
            >
              ◀ LEFT
            </button>
            <button
              onMouseDown={() => {
                inputRef.current.right = true;
              }}
              onMouseUp={() => {
                inputRef.current.right = false;
              }}
              onTouchStart={() => {
                inputRef.current.right = true;
              }}
              onTouchEnd={() => {
                inputRef.current.right = false;
              }}
              className="px-4 py-2.5 rounded-xl bg-slate-800 active:bg-[#FF5722] text-white text-xs font-extrabold select-none"
            >
              RIGHT ▶
            </button>
            <button
              onClick={() => {
                inputRef.current.up = true;
                inputRef.current.jumpPressed = true;
                setTimeout(() => {
                  inputRef.current.up = false;
                }, 150);
              }}
              className="px-4 py-2.5 rounded-xl bg-[#2563EB] active:bg-blue-700 text-white text-xs font-extrabold select-none"
            >
              ▲ UP / JUMP
            </button>
            <button
              onClick={() => {
                inputRef.current.down = true;
                setTimeout(() => {
                  inputRef.current.down = false;
                }, 150);
              }}
              className="px-4 py-2.5 rounded-xl bg-slate-800 active:bg-[#FF5722] text-white text-xs font-extrabold select-none"
            >
              ▼ DOWN
            </button>
          </div>

          <button
            onClick={() => {
              inputRef.current.firePressed = true;
              inputRef.current.jumpPressed = true;
            }}
            className="fism-btn-primary px-6 py-2.5 rounded-xl text-xs font-extrabold shadow-lg select-none"
          >
            🔥 FIRE / ACTION
          </button>
        </div>
      </div>

      {/* Red Ball Defense 2D Modal when selected */}
      {emojiDefenseOpen && (
        <FismEmojiBlastGameModal
          emoji="🔥"
          onClose={() => {
            setEmojiDefenseOpen(false);
            onTriggerToast('Closed Red Ball 2D Defense Arcade.');
          }}
        />
      )}
    </div>
  );
};


