import React, { useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  Crown,
  Globe,
  Lock,
  MessageSquare,
  Mic,
  MicOff,
  PhoneCall,
  PhoneOff,
  Plus,
  Radio,
  Send,
  ShieldAlert,
  Sparkles,
  UserPlus,
  Users,
  Video,
  VideoOff,
} from 'lucide-react';
import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import {
  FismActiveGroupCall,
  FismCommunityMessage,
  FismCommunityRoom,
  FismCreator,
} from '../types';
import { FismRedMilestoneTick, FismVipGoldChatBadge } from './FismMilestoneCardsModal';

export interface CommunityAndCreatorChatProps {
  mode: 'community' | 'liveCreator';
  currentUser: {
    uid: string;
    username: string;
    displayName: string;
    avatarUrl: string;
  };
  creators: FismCreator[];
  onToggleConnectCreator: (uid: string) => void;
  communityRooms: FismCommunityRoom[];
  liveCreatorRoom: FismCommunityRoom | null;
  hasLiveCreatorAccess: boolean;
  messagesByRoom: Record<string, FismCommunityMessage[]>;
  activeCalls: Record<string, FismActiveGroupCall>;
  onCreateRoom: (payload: {
    name: string;
    description: string;
    privacy: 'public' | 'private';
  }) => Promise<void>;
  onJoinRoom: (room: FismCommunityRoom) => Promise<boolean>;
  onSendMessage: (roomId: string, text: string) => Promise<void>;
  onStartGroupCall: (room: FismCommunityRoom, callMode: 'audio' | 'video') => void;
  onAnswerGroupCall: (roomId: string, hasVideo: boolean, hasAudio: boolean) => void;
  onToggleCallMedia: (roomId: string, hasVideo: boolean, hasAudio: boolean) => void;
  onLeaveGroupCall: (roomId: string) => void;
  localCallStream: MediaStream | null;
  remotePeerStreams: Record<string, MediaStream>;
  onSwitchToMode?: (mode: 'community' | 'liveCreator') => void;
  onTriggerToast: (msg: string) => void;
  milestoneMembersMap?: Record<string, { hasRedTick?: boolean; vipGoldBadge?: boolean }>;
  onOpenMilestoneJourney?: (uid: string) => void;
}

export const FismCommunityAndCreatorChat: React.FC<CommunityAndCreatorChatProps> = ({
  mode,
  currentUser,
  creators,
  onToggleConnectCreator,
  communityRooms,
  liveCreatorRoom,
  hasLiveCreatorAccess,
  messagesByRoom,
  activeCalls,
  onCreateRoom,
  onJoinRoom,
  onSendMessage,
  onStartGroupCall,
  onAnswerGroupCall,
  onToggleCallMedia,
  onLeaveGroupCall,
  localCallStream,
  remotePeerStreams,
  onSwitchToMode,
  onTriggerToast,
  milestoneMembersMap = {},
  onOpenMilestoneJourney,
}) => {
  const [selectedRoomId, setSelectedRoomId] = useState<string>(
    communityRooms[0]?.id || '',
  );
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomDesc, setNewRoomDesc] = useState('');
  const [newRoomPrivacy, setNewRoomPrivacy] = useState<'public' | 'private'>('public');
  const [creatingRoom, setCreatingRoom] = useState(false);

  const [messageInput, setMessageInput] = useState('');
  const [sendingMsg, setSendingMsg] = useState(false);
  const [localCamOn, setLocalCamOn] = useState(true);
  const [localMicOn, setLocalMicOn] = useState(true);

  const localVideoElRef = useRef<HTMLVideoElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Sync selected room cleanly when switching tabs or rooms arrive
  useEffect(() => {
    if (mode === 'liveCreator' && liveCreatorRoom) {
      setSelectedRoomId(liveCreatorRoom.id);
    } else if (
      mode === 'community' &&
      (!selectedRoomId ||
        selectedRoomId === liveCreatorRoom?.id ||
        !communityRooms.some((r) => r.id === selectedRoomId))
    ) {
      if (communityRooms[0]) {
        setSelectedRoomId(communityRooms[0].id);
      }
    }
  }, [mode, communityRooms, liveCreatorRoom, selectedRoomId]);

  const activeRoom: FismCommunityRoom | null =
    mode === 'liveCreator'
      ? hasLiveCreatorAccess
        ? liveCreatorRoom
        : null
      : communityRooms.find((r) => r.id === selectedRoomId) || communityRooms[0] || null;

  const activeCall: FismActiveGroupCall | undefined = activeRoom
    ? activeCalls[activeRoom.id]
    : undefined;

  const isInActiveCall = Boolean(
    activeCall?.participants.some((p) => p.uid === currentUser.uid),
  );

  // Attach live MediaStream to local <video> tile
  useEffect(() => {
    if (localVideoElRef.current && localCallStream) {
      localVideoElRef.current.srcObject = localCallStream;
      localVideoElRef.current.play().catch(() => {});
    }
  }, [localCallStream, isInActiveCall, localCamOn]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeRoom?.id, messagesByRoom]);

  // Strict Mutual Follow Check for Community Rooms:
  // User is allowed only if:
  // 1) User is the creator of the room, OR
  // 2) User mutually follows the creator (Creator follows back via mutualFollowerIds/isMutual OR user isConnected AND creator is mutual)
  const checkMutualFollow = (room: FismCommunityRoom): boolean => {
    if (room.roomType === 'live_creator') {
      return hasLiveCreatorAccess;
    }
    if (room.creatorId === currentUser.uid) return true;
    if (room.memberIds.includes(currentUser.uid)) return true;

    const creatorObj = creators.find((c) => c.uid === room.creatorId);
    const userFollowsCreator = Boolean(creatorObj?.isConnected);
    // In FISM demo & synced state: creators with `creator_arian` follow back automatically when user follows them,
    // or if `room.mutualFollowerIds` includes `currentUser.uid`. Creators like `@elena_rostova` require explicit mutual connection.
    const creatorFollowsUserBack =
      room.mutualFollowerIds.includes(currentUser.uid) ||
      room.creatorId === 'creator_arian';

    return userFollowsCreator && creatorFollowsUserBack;
  };

  const canEnterActiveRoom = activeRoom ? checkMutualFollow(activeRoom) : false;
  const roomMessages = activeRoom ? messagesByRoom[activeRoom.id] || [] : [];

  // Guard: If mode is liveCreator and user does NOT have admin permission, show nothing / return to community
  if (mode === 'liveCreator' && !hasLiveCreatorAccess) {
    return (
      <div className="max-w-3xl mx-auto fism-card p-6 text-center space-y-3">
        <p className="text-sm font-bold text-[#52607A]">
          Redirecting to Community Chat...
        </p>
        {onSwitchToMode && (
          <button
            type="button"
            onClick={() => onSwitchToMode('community')}
            className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold"
          >
            Go to Community Chat
          </button>
        )}
      </div>
    );
  }

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomName.trim()) {
      onTriggerToast('Please enter a Community Chat name.');
      return;
    }
    setCreatingRoom(true);
    try {
      await onCreateRoom({
        name: newRoomName.trim(),
        description: newRoomDesc.trim(),
        privacy: newRoomPrivacy,
      });

      if (auth.currentUser?.emailVerified) {
        const fsId = `comm_${Date.now()}`;
        const safeUsername = (currentUser.username || 'fism_user')
          .replace(/[^a-zA-Z0-9_-]/g, '_')
          .slice(0, 40);
        try {
          await setDoc(doc(db, 'communityRooms', fsId), {
            name: newRoomName.trim().slice(0, 100),
            description: (newRoomDesc.trim() || 'Mutual Flame Community Room').slice(0, 400),
            privacy: newRoomPrivacy,
            roomType: 'community',
            creatorId: auth.currentUser.uid,
            creatorUsername: safeUsername.length >= 2 ? safeUsername : 'fism_user',
            createdAt: serverTimestamp(),
          });
        } catch (err) {
          console.warn('Firestore communityRooms sync skipped:', err);
        }
      }

      setNewRoomName('');
      setNewRoomDesc('');
      setShowCreateForm(false);
    } catch (err) {
      onTriggerToast(err instanceof Error ? err.message : 'Unable to create community room.');
    } finally {
      setCreatingRoom(false);
    }
  };

  const handleSendSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRoom || !messageInput.trim() || sendingMsg) return;
    if (!canEnterActiveRoom) {
      onTriggerToast(
        'Mutual follow required! Only mutual followers can chat in this community.',
      );
      return;
    }
    setSendingMsg(true);
    try {
      await onSendMessage(activeRoom.id, messageInput.trim());
      setMessageInput('');
    } finally {
      setSendingMsg(false);
    }
  };

  const participantCount = activeCall?.participants.length || 0;
  const gridColsClass =
    participantCount <= 1
      ? 'grid-cols-1 max-w-md mx-auto'
      : participantCount === 2
        ? 'grid-cols-1 sm:grid-cols-2'
        : participantCount <= 4
          ? 'grid-cols-2'
          : 'grid-cols-2 lg:grid-cols-3';

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      {/* Header */}
      <div
        className={`fism-card p-5 text-white border-2 flex items-center justify-between flex-wrap gap-4 ${
          mode === 'liveCreator'
            ? 'bg-gradient-to-r from-[#1E1B4B] via-[#4C1D95] to-[#7C2D12] border-[#FFB300]'
            : 'bg-gradient-to-r from-[#0F172A] via-[#1E293B] to-[#31102F] border-[#FF5722]'
        }`}
      >
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span
              className={`px-2.5 py-0.5 rounded text-[10px] font-black uppercase ${
                mode === 'liveCreator'
                  ? 'bg-[#FFB300] text-[#101426]'
                  : 'bg-[#FF5722] text-white'
              }`}
            >
              {mode === 'liveCreator'
                ? 'Admin-Approved Creator Access'
                : 'Mutual-Follow Gated Community'}
            </span>
            <span className="px-2.5 py-0.5 rounded bg-[#16A34A] text-white text-[10px] font-black uppercase">
              WebRTC + WebSocket Grid Calls
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold mt-1 flex items-center gap-2">
            {mode === 'liveCreator' ? (
              <>
                <Crown className="w-6 h-6 text-[#FFB300]" /> Live Creator Chat — Exclusive Room
              </>
            ) : (
              <>
                <Users className="w-6 h-6 text-[#FF5722]" /> Community Chat Rooms
              </>
            )}
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            {mode === 'liveCreator'
              ? 'Real-time creator lounge unlocked by Admin. Launch instant group voice or video calls where creators snap into a live grid.'
              : 'Create unlimited Public or Private community rooms. Only mutual followers can enter & chat; launch real-time group voice/video calls anytime.'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {mode === 'community' && (
            <button
              type="button"
              onClick={() => setShowCreateForm((v) => !v)}
              className="fism-btn-primary px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-lg"
            >
              <Plus className="w-4 h-4" /> Create Community Room
            </button>
          )}

          {/* Live Creator Chat Tab appears ONLY when Admin has explicitly granted permission */}
          {hasLiveCreatorAccess && onSwitchToMode && (
            <div className="flex items-center gap-1 bg-white/10 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => onSwitchToMode('community')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold ${
                  mode === 'community' ? 'bg-[#FF5722] text-white' : 'text-slate-200'
                }`}
              >
                Community Chat
              </button>
              <button
                type="button"
                onClick={() => onSwitchToMode('liveCreator')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1 ${
                  mode === 'liveCreator' ? 'bg-[#FFB300] text-[#101426]' : 'text-amber-300'
                }`}
              >
                <Crown className="w-3.5 h-3.5" /> Live Creator Chat
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Create Community Room Form */}
      {mode === 'community' && showCreateForm && (
        <form
          onSubmit={handleCreateSubmit}
          className="fism-card p-5 border-2 border-[#FF5722] space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-extrabold flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#FF5722]" /> Create New Community Chat Room
              (Unlimited Rooms Allowed)
            </h2>
            <button
              type="button"
              onClick={() => setShowCreateForm(false)}
              className="text-xs font-bold text-[#52607A]"
            >
              Close
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <input
              type="text"
              value={newRoomName}
              onChange={(e) => setNewRoomName(e.target.value)}
              placeholder="Community Room Name (e.g. Editors Circle)..."
              className="px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
            />
            <input
              type="text"
              value={newRoomDesc}
              onChange={(e) => setNewRoomDesc(e.target.value)}
              placeholder="Short description & mutual-follow rules..."
              className="px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
            />
            <div className="flex items-center gap-2">
              <select
                value={newRoomPrivacy}
                onChange={(e) =>
                  setNewRoomPrivacy(e.target.value as 'public' | 'private')
                }
                className="flex-1 px-3 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              >
                <option value="public">🌐 Public (Mutual Followers)</option>
                <option value="private">🔒 Private (Mutual Followers Only)</option>
              </select>
              <button
                type="submit"
                disabled={creatingRoom}
                className="fism-btn-primary px-4 py-2.5 rounded-xl text-xs font-extrabold shrink-0"
              >
                {creatingRoom ? 'Creating...' : '+ Create Room'}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Main Split Workspace: Rooms Sidebar + Active Room / Dynamic Group Call Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Rooms Column (Hidden in single-room Live Creator mode unless switching) */}
        {mode === 'community' && (
          <div className="lg:col-span-4 space-y-3">
            <div className="fism-card p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-extrabold uppercase text-[#52607A]">
                  Your &amp; Creator Communities ({communityRooms.length})
                </h2>
                <span className="text-[10px] font-bold text-[#FF5722]">
                  Mutual Follow Required
                </span>
              </div>

              <div className="space-y-2.5">
                {communityRooms.map((room) => {
                  const isAllowed = checkMutualFollow(room);
                  const roomCall = activeCalls[room.id];
                  const isSelected = activeRoom?.id === room.id;
                  return (
                    <button
                      key={room.id}
                      type="button"
                      onClick={() => setSelectedRoomId(room.id)}
                      className={`w-full text-left p-3.5 rounded-xl border-2 transition-all space-y-1.5 ${
                        isSelected
                          ? 'border-[#FF5722] bg-[#FF5722]/10'
                          : 'border-[#D8E1F0] dark:border-slate-800 hover:border-[#7C3AED]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <img
                            src={room.creatorAvatar}
                            alt={room.creatorDisplayName}
                            className="w-8 h-8 rounded-full object-cover shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="text-xs font-extrabold truncate flex items-center gap-1">
                              {room.privacy === 'private' ? (
                                <Lock className="w-3 h-3 text-[#F59E0B] shrink-0" />
                              ) : (
                                <Globe className="w-3 h-3 text-[#2563EB] shrink-0" />
                              )}
                              <span className="truncate">{room.name}</span>
                            </div>
                            <div className="text-[10px] text-[#52607A] truncate">
                              by @{room.creatorUsername} • {room.memberIds.length} members
                            </div>
                          </div>
                        </div>

                        {roomCall && (
                          <span className="px-2 py-0.5 rounded-full bg-[#16A34A] text-white text-[9px] font-black animate-pulse shrink-0">
                            ● CALL ({roomCall.participants.length})
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-[10px] font-bold">
                        {isAllowed ? (
                          <span className="text-[#16A34A] flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> Mutual Connection Verified
                          </span>
                        ) : (
                          <span className="text-[#DC2626] flex items-center gap-1">
                            <ShieldAlert className="w-3 h-3" /> Non-Follower Blocked
                          </span>
                        )}
                        <span className="uppercase text-[#52607A]">{room.privacy}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Right Chat + Dynamic Group Video/Voice Call Grid */}
        <div className={mode === 'community' ? 'lg:col-span-8 space-y-4' : 'lg:col-span-12 space-y-4'}>
          {!activeRoom ? (
            <div className="fism-card p-8 text-center text-xs text-[#52607A]">
              Select or create a Community Chat room to start chatting &amp; group calling.
            </div>
          ) : (
            <div className="fism-card overflow-hidden flex flex-col min-h-[580px]">
              {/* Room Top Bar */}
              <div className="p-4 border-b border-[#D8E1F0] dark:border-slate-800 flex items-center justify-between flex-wrap gap-3 bg-[#F8FAFE] dark:bg-slate-900">
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={activeRoom.creatorAvatar}
                    alt={activeRoom.creatorDisplayName}
                    className="w-10 h-10 rounded-xl object-cover border-2 border-[#FF5722] shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="font-extrabold text-sm flex items-center gap-1.5 flex-wrap">
                      <span>{activeRoom.name}</span>
                      <span className="px-2 py-0.5 rounded bg-[#7C3AED]/15 text-[#7C3AED] text-[10px] font-black uppercase">
                        {activeRoom.roomType === 'live_creator'
                          ? 'Live Creator'
                          : activeRoom.privacy}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#52607A] truncate">
                      {activeRoom.description}
                    </p>
                  </div>
                </div>

                {canEnterActiveRoom && (
                  <div className="flex items-center gap-2 flex-wrap">
                    {!activeCall ? (
                      <>
                        <button
                          type="button"
                          onClick={() => onStartGroupCall(activeRoom, 'audio')}
                          className="px-3.5 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1.5 shadow hover:opacity-95"
                        >
                          <PhoneCall className="w-3.5 h-3.5" /> Group Voice Call
                        </button>
                        <button
                          type="button"
                          onClick={() => onStartGroupCall(activeRoom, 'video')}
                          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#FF5722] to-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-1.5 shadow hover:opacity-95"
                        >
                          <Video className="w-3.5 h-3.5" /> Group Video Call
                        </button>
                      </>
                    ) : !isInActiveCall ? (
                      <button
                        type="button"
                        onClick={() =>
                          onAnswerGroupCall(
                            activeRoom.id,
                            activeCall.mode === 'video',
                            true,
                          )
                        }
                        className="px-4 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1.5 shadow animate-pulse"
                      >
                        <PhoneCall className="w-4 h-4" /> Answer &amp; Snap to Grid (
                        {activeCall.participants.length} Live)
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onLeaveGroupCall(activeRoom.id)}
                        className="px-4 py-2 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
                      >
                        <PhoneOff className="w-4 h-4" /> Leave Group Call
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* STRICT MUTUAL FOLLOW BLOCK SCREEN FOR NON-FOLLOWERS */}
              {!canEnterActiveRoom ? (
                <div className="flex-1 p-8 flex flex-col items-center justify-center text-center space-y-4 bg-red-50/40 dark:bg-red-950/15">
                  <div className="w-16 h-16 rounded-2xl bg-[#DC2626] text-white flex items-center justify-center shadow-xl">
                    <Lock className="w-8 h-8" />
                  </div>
                  <div className="max-w-md space-y-2">
                    <h3 className="text-lg font-extrabold text-[#DC2626]">
                      Mutual Follow Required to Enter &amp; Chat
                    </h3>
                    <p className="text-xs text-[#52607A] leading-relaxed">
                      <strong>{activeRoom.name}</strong> is protected by FISM&apos;s Mutual-Follow
                      Community Gate. You and <strong>@{activeRoom.creatorUsername}</strong> must
                      mutually follow each other (both directions) before you can view messages or
                      join group calls.
                    </p>
                  </div>

                  <div className="flex items-center gap-2.5 flex-wrap justify-center">
                    <button
                      type="button"
                      onClick={() => onToggleConnectCreator(activeRoom.creatorId)}
                      className="px-4 py-2.5 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
                    >
                      <UserPlus className="w-4 h-4" />
                      {creators.find((c) => c.uid === activeRoom.creatorId)?.isConnected
                        ? `Connected to @${activeRoom.creatorUsername} (Awaiting Mutual Follow Back)`
                        : `Connect / Follow @${activeRoom.creatorUsername}`}
                    </button>

                    <button
                      type="button"
                      onClick={async () => {
                        const creatorConnected = Boolean(
                          creators.find((c) => c.uid === activeRoom.creatorId)?.isConnected,
                        );
                        if (!creatorConnected) {
                          onTriggerToast(
                            `First Connect with @${activeRoom.creatorUsername} — non-followers cannot bypass the gate!`,
                          );
                          return;
                        }
                        const ok = await onJoinRoom(activeRoom);
                        if (ok) {
                          onTriggerToast(`Joined "${activeRoom.name}"!`);
                        }
                      }}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 text-white text-xs font-extrabold"
                    >
                      Verify Mutual Follow &amp; Enter
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {/* DYNAMIC SNAP-TO-GRID GROUP VOICE / VIDEO CALL STAGE */}
                  {activeCall && (
                    <div className="p-4 bg-[#0B1020] text-white border-b-2 border-[#7C3AED] space-y-3">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-full bg-[#16A34A] text-[10px] font-black uppercase animate-pulse flex items-center gap-1">
                            <Radio className="w-3 h-3" /> LIVE {activeCall.mode.toUpperCase()} GRID
                          </span>
                          <span className="text-xs font-extrabold">
                            {activeCall.participants.length} Participant
                            {activeCall.participants.length === 1 ? '' : 's'} Auto-Snapped
                          </span>
                        </div>

                        {isInActiveCall && (
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                const nextMic = !localMicOn;
                                setLocalMicOn(nextMic);
                                localCallStream
                                  ?.getAudioTracks()
                                  .forEach((t) => (t.enabled = nextMic));
                                onToggleCallMedia(activeRoom.id, localCamOn, nextMic);
                              }}
                              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1 ${
                                localMicOn ? 'bg-slate-800 text-white' : 'bg-[#DC2626] text-white'
                              }`}
                            >
                              {localMicOn ? (
                                <Mic className="w-3.5 h-3.5" />
                              ) : (
                                <MicOff className="w-3.5 h-3.5" />
                              )}
                              {localMicOn ? 'Mic On' : 'Muted'}
                            </button>

                            {activeCall.mode === 'video' && (
                              <button
                                type="button"
                                onClick={() => {
                                  const nextCam = !localCamOn;
                                  setLocalCamOn(nextCam);
                                  localCallStream
                                    ?.getVideoTracks()
                                    .forEach((t) => (t.enabled = nextCam));
                                  onToggleCallMedia(activeRoom.id, nextCam, localMicOn);
                                }}
                                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1 ${
                                  localCamOn
                                    ? 'bg-slate-800 text-white'
                                    : 'bg-[#F59E0B] text-[#101426]'
                                }`}
                              >
                                {localCamOn ? (
                                  <Video className="w-3.5 h-3.5" />
                                ) : (
                                  <VideoOff className="w-3.5 h-3.5" />
                                )}
                                {localCamOn ? 'Cam On' : 'Cam Off'}
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Responsive Auto-Snap Video/Audio Grid */}
                      <div className={`grid gap-3 ${gridColsClass}`}>
                        {activeCall.participants.map((p) => {
                          const isMe = p.uid === currentUser.uid;
                          const peerStream = isMe ? localCallStream : remotePeerStreams[p.uid];
                          return (
                            <div
                              key={p.uid}
                              className="relative aspect-video rounded-2xl overflow-hidden bg-[#181F36] border-2 border-[#7C3AED]/70 flex flex-col items-center justify-center shadow-lg transition-all"
                            >
                              {isMe && p.hasVideo && localCallStream ? (
                                <video
                                  ref={localVideoElRef}
                                  muted
                                  playsInline
                                  autoPlay
                                  className="w-full h-full object-cover"
                                />
                              ) : !isMe && p.hasVideo && peerStream ? (
                                <RemoteParticipantVideo stream={peerStream} />
                              ) : (
                                <div className="flex flex-col items-center justify-center gap-2 p-4">
                                  <div className="relative">
                                    <img
                                      src={p.avatarUrl}
                                      alt={p.displayName}
                                      className="w-16 h-16 rounded-full object-cover ring-4 ring-[#FF5722]/70"
                                    />
                                    {p.hasAudio && (
                                      <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full bg-[#16A34A] text-[9px] font-black">
                                        LIVE
                                      </span>
                                    )}
                                  </div>
                                  <span className="text-xs font-extrabold">{p.displayName}</span>
                                </div>
                              )}

                              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between px-2.5 py-1 rounded-lg bg-black/70 text-[11px] font-bold">
                                <span className="truncate">
                                  {p.displayName} {isMe ? '(You)' : ''}
                                </span>
                                <span className="flex items-center gap-1 shrink-0">
                                  {p.hasAudio ? (
                                    <Mic className="w-3 h-3 text-[#16A34A]" />
                                  ) : (
                                    <MicOff className="w-3 h-3 text-[#EF4444]" />
                                  )}
                                  {p.hasVideo ? (
                                    <Video className="w-3 h-3 text-[#38BDF8]" />
                                  ) : (
                                    <VideoOff className="w-3 h-3 text-slate-400" />
                                  )}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Chat Messages Feed */}
                  <div className="flex-1 p-4 space-y-3 max-h-[380px] overflow-y-auto bg-[#F8FAFE] dark:bg-slate-950/60">
                    {roomMessages.map((msg) => {
                      const isMine = msg.senderId === currentUser.uid;
                      return (
                        <div
                          key={msg.id}
                          className={`flex gap-2.5 ${isMine ? 'justify-end' : 'justify-start'}`}
                        >
                          {!isMine && (
                            <img
                              src={msg.senderAvatar}
                              alt={msg.senderDisplayName}
                              className="w-8 h-8 rounded-full object-cover shrink-0 mt-0.5"
                            />
                          )}
                          <div
                            className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 text-xs shadow-sm ${
                              msg.messageType === 'call_event'
                                ? 'bg-[#7C3AED]/15 border border-[#7C3AED] text-[#7C3AED] font-bold'
                                : isMine
                                  ? 'bg-[#FF5722] text-white'
                                  : 'bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700'
                            }`}
                          >
                            <div className="text-[10px] opacity-90 font-extrabold mb-0.5 flex items-center gap-1 flex-wrap">
                              <span>
                                {msg.senderDisplayName} (@{msg.senderUsername})
                              </span>
                              {milestoneMembersMap[msg.senderId]?.hasRedTick && (
                                <FismRedMilestoneTick
                                  size="sm"
                                  onClick={() => onOpenMilestoneJourney?.(msg.senderId)}
                                />
                              )}
                              {milestoneMembersMap[msg.senderId]?.vipGoldBadge && (
                                <FismVipGoldChatBadge />
                              )}
                              <span>• {msg.createdAt}</span>
                            </div>
                            <p className="leading-relaxed whitespace-pre-line">{msg.text}</p>
                          </div>
                        </div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Message Input Bar */}
                  <form
                    onSubmit={handleSendSubmit}
                    className="p-3.5 border-t border-[#D8E1F0] dark:border-slate-800 flex items-center gap-2 bg-white dark:bg-[#101426]"
                  >
                    <MessageSquare className="w-4 h-4 text-[#52607A] shrink-0" />
                    <input
                      type="text"
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      placeholder={
                        mode === 'liveCreator'
                          ? 'Message Live Creator Chat...'
                          : `Message ${activeRoom.name}...`
                      }
                      className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-semibold focus:outline-none focus:border-[#FF5722]"
                    />
                    <button
                      type="submit"
                      disabled={sendingMsg || !messageInput.trim()}
                      className="fism-btn-primary px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" /> Send
                    </button>
                  </form>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const RemoteParticipantVideo: React.FC<{ stream: MediaStream }> = ({ stream }) => {
  const ref = useRef<HTMLVideoElement | null>(null);
  useEffect(() => {
    if (ref.current) {
      ref.current.srcObject = stream;
      ref.current.play().catch(() => {});
    }
  }, [stream]);
  return <video ref={ref} playsInline autoPlay className="w-full h-full object-cover" />;
};
