import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  APIProvider,
  APILoadingStatus,
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useAdvancedMarkerRef,
  useApiLoadingStatus,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import { MapPin, Navigation, Search, Compass, Route as RouteIcon, X } from 'lucide-react';

const MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
const GMP_ATTRIBUTION_IDS = ['gmp_mcp_codeassist_v1_aistudio'];

function isQuotaError(err: unknown): boolean {
  const msg =
    err instanceof Error
      ? err.message
      : typeof err === 'string'
        ? err
        : JSON.stringify(err || '');
  return (
    msg.includes('OVER_QUERY_LIMIT') ||
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('OverQuotaMapError') ||
    msg.includes('QuotaExceededError') ||
    msg.includes('429')
  );
}

function triggerQuotaBanner() {
  window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
}

export const FismMapsApiProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  if (!MAPS_API_KEY) {
    return <>{children}</>;
  }
  return (
    <APIProvider
      apiKey={MAPS_API_KEY}
      language="en"
      region="IN"
      libraries={['marker', 'places', 'routes']}
    >
      {children}
    </APIProvider>
  );
};

interface MapCameraSyncProps {
  lat: number;
  lng: number;
  zoom?: number;
}

const MapCameraSync: React.FC<MapCameraSyncProps> = ({ lat, lng, zoom }) => {
  const map = useMap();
  useEffect(() => {
    if (!map) return;
    map.panTo({ lat, lng });
    if (typeof zoom === 'number') {
      map.setZoom(zoom);
    }
  }, [map, lat, lng, zoom]);
  return null;
};

interface FismEmberLiveLocationMapProps {
  lat: number;
  lng: number;
  senderName: string;
  accuracyMeters: number;
  isSharing: boolean;
  updatedAt?: string;
}

const EmberLivePinWithInfo: React.FC<FismEmberLiveLocationMapProps> = ({
  lat,
  lng,
  senderName,
  accuracyMeters,
  isSharing,
  updatedAt,
}) => {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const [infoOpen, setInfoOpen] = useState(false);

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat, lng }}
        title={`${senderName}'s Live Location`}
        onClick={() => setInfoOpen((prev) => !prev)}
      >
        <Pin
          background={isSharing ? '#16A34A' : '#64748B'}
          borderColor="#FFFFFF"
          glyphColor="#FFFFFF"
          scale={1.15}
        />
      </AdvancedMarker>
      {infoOpen && marker && (
        <InfoWindow anchor={marker} onCloseClick={() => setInfoOpen(false)} maxWidth={220}>
          <div className="text-[#151B2B] p-1 space-y-1 text-xs">
            <div className="font-bold">{senderName}</div>
            <div className="text-[11px] text-slate-600">
              {isSharing ? 'Live GPS Sharing Active' : 'Last Shared Location'} • ±{accuracyMeters}m
            </div>
            <div className="font-mono text-[10px] text-slate-500">
              {lat.toFixed(5)}, {lng.toFixed(5)}
            </div>
            {updatedAt && <div className="text-[10px] text-slate-400">{updatedAt}</div>}
          </div>
        </InfoWindow>
      )}
    </>
  );
};

export const FismEmberLiveLocationMap: React.FC<FismEmberLiveLocationMapProps> = (props) => {
  const apiStatus = useApiLoadingStatus();
  const mapsUnavailable =
    !MAPS_API_KEY ||
    apiStatus === APILoadingStatus.FAILED ||
    apiStatus === APILoadingStatus.AUTH_FAILURE;

  useEffect(() => {
    if (apiStatus === APILoadingStatus.AUTH_FAILURE) {
      triggerQuotaBanner();
    }
  }, [apiStatus]);

  if (mapsUnavailable) {
    return (
      <div className="relative h-44 w-full bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0C4A6E] p-3 flex flex-col justify-between overflow-hidden">
        <div className="flex items-center justify-between text-[10px] font-extrabold text-white">
          <span
            className={`px-2 py-0.5 rounded-full flex items-center gap-1 ${
              props.isSharing ? 'bg-[#16A34A]' : 'bg-slate-700'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full bg-white ${props.isSharing ? 'animate-ping' : ''}`}
            />
            {props.isSharing ? 'LIVE LOCATION ACTIVE' : 'LOCATION ENDED'}
          </span>
          <span className="font-mono text-[#38BDF8]">±{props.accuracyMeters}m</span>
        </div>
        <div className="flex flex-col items-center justify-center text-white">
          <div className="w-9 h-9 rounded-full bg-[#0EA5E9]/30 border-2 border-[#38BDF8] flex items-center justify-center">
            <MapPin className="w-5 h-5 text-[#38BDF8]" />
          </div>
          <span className="mt-1 px-2 py-0.5 rounded bg-black/75 font-mono text-[10px] text-[#38BDF8] font-bold">
            {props.lat.toFixed(5)}, {props.lng.toFixed(5)}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div
      className="relative h-48 w-full overflow-hidden bg-[#0F172A]"
      onMouseDown={(e) => e.stopPropagation()}
      onTouchStart={(e) => e.stopPropagation()}
    >
      <GoogleMap
        style={{ width: '100%', height: '100%' }}
        defaultCenter={{ lat: props.lat, lng: props.lng }}
        defaultZoom={15}
        mapId="DEMO_MAP_ID"
        gestureHandling="greedy"
        disableDefaultUI
        zoomControl
        internalUsageAttributionIds={GMP_ATTRIBUTION_IDS}
      >
        <MapCameraSync lat={props.lat} lng={props.lng} />
        <EmberLivePinWithInfo {...props} />
      </GoogleMap>
      <div className="pointer-events-none absolute top-2 left-2 z-10 flex items-center gap-1.5">
        <span
          className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold text-white shadow flex items-center gap-1 ${
            props.isSharing ? 'bg-[#16A34A]' : 'bg-slate-700'
          }`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full bg-white ${props.isSharing ? 'animate-ping' : ''}`}
          />
          {props.isSharing ? 'LIVE GPS' : 'ENDED'}
        </span>
        <span className="px-2 py-0.5 rounded-full bg-black/70 text-[#38BDF8] font-mono text-[10px] font-bold">
          ±{props.accuracyMeters}m
        </span>
      </div>
    </div>
  );
};

interface SelectedPlaceDetails {
  name: string;
  address: string;
  location: { lat: number; lng: number };
  rating?: number | null;
  userRatingCount?: number | null;
}

type TravelModeOption = 'DRIVING' | 'WALKING' | 'TWO_WHEELER';

interface RouteSummaryState {
  distanceMeters: number;
  durationMillis: number;
  travelMode: TravelModeOption;
}

interface RouteOverlayProps {
  origin: { lat: number; lng: number };
  destination: { lat: number; lng: number } | null;
  travelMode: TravelModeOption;
  onRouteComputed: (summary: RouteSummaryState | null) => void;
  onRouteError: (msg: string | null) => void;
}

const ModernRoutesOverlay: React.FC<RouteOverlayProps> = ({
  origin,
  destination,
  travelMode,
  onRouteComputed,
  onRouteError,
}) => {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);
  const originLat = origin.lat;
  const originLng = origin.lng;
  const destLat = destination?.lat ?? null;
  const destLng = destination?.lng ?? null;

  useEffect(() => {
    polylinesRef.current.forEach((p) => p.setMap(null));
    polylinesRef.current = [];
    onRouteError(null);

    if (!routesLib || !map || destLat === null || destLng === null) {
      onRouteComputed(null);
      return;
    }

    let cancelled = false;

    const sdkTravelMode =
      routesLib.TravelMode?.[travelMode as keyof typeof routesLib.TravelMode] ?? travelMode;

    const request: google.maps.routes.ComputeRoutesRequest = {
      origin: { lat: originLat, lng: originLng },
      destination: { lat: destLat, lng: destLng },
      travelMode: sdkTravelMode as google.maps.TravelModeString,
      fields: ['path', 'distanceMeters', 'durationMillis', 'viewport'],
    };

    routesLib.Route.computeRoutes(request)
      .then((response) => {
        if (cancelled) return;
        const primaryRoute = response?.routes?.[0];
        if (!primaryRoute) {
          onRouteComputed(null);
          onRouteError('No route found between your GPS location and selected spot.');
          return;
        }

        const newPolylines = primaryRoute.createPolylines({
          polylineOptions: {
            strokeColor: '#FF5722',
            strokeOpacity: 0.92,
            strokeWeight: 5,
          },
        });
        newPolylines.forEach((polyline) => polyline.setMap(map));
        polylinesRef.current = newPolylines;

        if (primaryRoute.viewport) {
          map.fitBounds(primaryRoute.viewport);
        }

        onRouteComputed({
          distanceMeters: primaryRoute.distanceMeters ?? 0,
          durationMillis: primaryRoute.durationMillis ?? 0,
          travelMode,
        });
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        if (isQuotaError(err)) {
          triggerQuotaBanner();
        }
        onRouteComputed(null);
        onRouteError(
          err instanceof Error
            ? err.message
            : 'Unable to load route data. Please check your network or API quota.',
        );
      });

    return () => {
      cancelled = true;
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };
  }, [routesLib, map, originLat, originLng, destLat, destLng, travelMode, onRouteComputed, onRouteError]);

  return null;
};

export interface MapCheckInPinItem {
  dayNumber: number;
  dateIso: string;
  lat: number;
  lng: number;
  locationLabel: string;
  checkedInAtIso?: string;
}

const CheckInPinMarker: React.FC<{
  pin: MapCheckInPinItem;
  onRouteHere: (coords: { lat: number; lng: number }, title: string) => void;
}> = ({ pin, onRouteHere }) => {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const [open, setOpen] = useState(false);

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: pin.lat, lng: pin.lng }}
        title={`Day ${pin.dayNumber} Check-In (${pin.dateIso})`}
        onClick={() => setOpen((p) => !p)}
      >
        <Pin background="#16A34A" borderColor="#FFFFFF" glyphColor="#FFFFFF" scale={1.05} />
      </AdvancedMarker>
      {open && marker && (
        <InfoWindow anchor={marker} onCloseClick={() => setOpen(false)} maxWidth={230}>
          <div className="text-xs text-[#151B2B] p-1 space-y-1">
            <div className="font-extrabold text-[#16A34A]">
              📍 Day {pin.dayNumber} Locate Pin ({pin.dateIso})
            </div>
            <div className="text-[11px] font-semibold">{pin.locationLabel}</div>
            <div className="font-mono text-[10px] text-slate-500">
              {pin.lat.toFixed(5)}, {pin.lng.toFixed(5)}
            </div>
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                onRouteHere({ lat: pin.lat, lng: pin.lng }, `Day ${pin.dayNumber} Locate Pin`);
              }}
              className="w-full px-2 py-1 rounded bg-[#FF5722] text-white text-[10px] font-bold cursor-pointer"
            >
              Navigate to Check-In Pin
            </button>
          </div>
        </InfoWindow>
      )}
    </>
  );
};

const QUICK_MAP_CITIES: { label: string; lat: number; lng: number }[] = [
  { label: 'New Delhi', lat: 28.6139, lng: 77.209 },
  { label: 'Mumbai', lat: 19.076, lng: 72.8777 },
  { label: 'Bengaluru', lat: 12.9716, lng: 77.5946 },
  { label: 'San Francisco', lat: 37.7749, lng: -122.4194 },
];

const NEARBY_CATEGORIES: { label: string; type: string }[] = [
  { label: '🎬 Studios', type: 'movie_theater' },
  { label: '☕ Cafes', type: 'cafe' },
  { label: '🌳 Parks', type: 'park' },
  { label: '🏛️ Landmarks', type: 'tourist_attraction' },
];

interface FismInteractiveCreatorMapProps {
  userCoords: { lat: number; lng: number };
  onUpdateUserCoords: (coords: { lat: number; lng: number }) => void;
  onPlaceChosenForGrounding?: (placeLabel: string) => void;
  checkInPins?: MapCheckInPinItem[];
}

const CreatorMapInner: React.FC<FismInteractiveCreatorMapProps> = ({
  userCoords,
  onUpdateUserCoords,
  onPlaceChosenForGrounding,
  checkInPins = [],
}) => {
  const map = useMap();
  const placesLib = useMapsLibrary('places');

  const [searchText, setSearchText] = useState('');
  const [suggestions, setSuggestions] = useState<google.maps.places.AutocompleteSuggestion[]>([]);
  const [suggestionsLoading, setSuggestionsLoading] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState<SelectedPlaceDetails | null>(null);
  const [nearbyResults, setNearbyResults] = useState<SelectedPlaceDetails[]>([]);
  const [activeNearbyType, setActiveNearbyType] = useState<string | null>(null);
  const [showPlaceInfo, setShowPlaceInfo] = useState(false);
  const [showHubInfo, setShowHubInfo] = useState(false);
  const [gpsStatusMsg, setGpsStatusMsg] = useState<string | null>(null);

  const [routeDestination, setRouteDestination] = useState<{ lat: number; lng: number } | null>(
    null,
  );
  const [travelMode, setTravelMode] = useState<TravelModeOption>('DRIVING');
  const [routeSummary, setRouteSummary] = useState<RouteSummaryState | null>(null);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [placesError, setPlacesError] = useState<string | null>(null);

  const sessionTokenRef = useRef<google.maps.places.AutocompleteSessionToken | null>(null);
  const [hubMarkerRef, hubMarker] = useAdvancedMarkerRef();
  const [placeMarkerRef, placeMarker] = useAdvancedMarkerRef();

  const resetSession = useCallback(() => {
    sessionTokenRef.current = null;
    setSuggestions([]);
  }, []);

  useEffect(() => {
    if (!placesLib || !searchText.trim()) {
      setSuggestions([]);
      setSuggestionsLoading(false);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        setPlacesError(null);
        setSuggestionsLoading(true);
        if (!sessionTokenRef.current) {
          sessionTokenRef.current = new placesLib.AutocompleteSessionToken();
        }
        const res = await placesLib.AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: searchText.trim(),
          sessionToken: sessionTokenRef.current,
          locationBias: {
            center: userCoords,
            radius: 25000,
          },
        });
        setSuggestions(res?.suggestions ?? []);
      } catch (err: unknown) {
        if (isQuotaError(err)) {
          triggerQuotaBanner();
        }
        setSuggestions([]);
        setPlacesError(
          err instanceof Error ? err.message : 'Unable to fetch place suggestions right now.',
        );
      } finally {
        setSuggestionsLoading(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [placesLib, searchText, userCoords.lat, userCoords.lng]);

  const handleSelectSuggestion = useCallback(
    async (suggestion: google.maps.places.AutocompleteSuggestion) => {
      if (!placesLib || !suggestion.placePrediction) return;
      try {
        setPlacesError(null);
        const place = suggestion.placePrediction.toPlace();
        await place.fetchFields({
          fields: [
            'displayName',
            'formattedAddress',
            'location',
            'viewport',
            'rating',
            'userRatingCount',
          ],
        });

        const loc = place.location;
        if (!loc) {
          setPlacesError('Selected place has no coordinates.');
          resetSession();
          return;
        }

        const lat = loc.lat();
        const lng = loc.lng();
        const details: SelectedPlaceDetails = {
          name: place.displayName || suggestion.placePrediction.text.text,
          address: place.formattedAddress || '',
          location: { lat, lng },
          rating: place.rating,
          userRatingCount: place.userRatingCount,
        };

        setSelectedPlace(details);
        setShowPlaceInfo(true);
        setRouteDestination(null);
        setRouteSummary(null);
        setSearchText(details.name);
        onPlaceChosenForGrounding?.(`${details.name} (${details.address})`);

        if (map) {
          if (place.viewport) {
            map.fitBounds(place.viewport);
          } else {
            map.panTo({ lat, lng });
            map.setZoom(15);
          }
        }
        resetSession();
      } catch (err: unknown) {
        if (isQuotaError(err)) {
          triggerQuotaBanner();
        }
        setPlacesError(
          err instanceof Error ? err.message : 'Unable to fetch details for this place.',
        );
      }
    },
    [placesLib, map, onPlaceChosenForGrounding, resetSession],
  );

  const handleSearchNearbyCategory = useCallback(
    async (includedPrimaryType: string) => {
      if (!placesLib || !placesLib.Place?.searchNearby) return;
      try {
        setPlacesError(null);
        setActiveNearbyType(includedPrimaryType);
        const { places } = await placesLib.Place.searchNearby({
          fields: ['displayName', 'formattedAddress', 'location', 'rating', 'userRatingCount'],
          locationRestriction: {
            center: userCoords,
            radius: 5000,
          },
          includedPrimaryTypes: [includedPrimaryType],
          maxResultCount: 6,
        });
        const mapped: SelectedPlaceDetails[] = (places || [])
          .filter((p) => p.location)
          .map((p) => ({
            name: p.displayName || 'Nearby Spot',
            address: p.formattedAddress || '',
            location: { lat: p.location!.lat(), lng: p.location!.lng() },
            rating: p.rating,
            userRatingCount: p.userRatingCount,
          }));
        setNearbyResults(mapped);
        if (mapped[0]) {
          setSelectedPlace(mapped[0]);
          setShowPlaceInfo(true);
          onPlaceChosenForGrounding?.(`${mapped[0].name} (${mapped[0].address})`);
        }
      } catch (err: unknown) {
        if (isQuotaError(err)) {
          triggerQuotaBanner();
        }
        setPlacesError(
          err instanceof Error ? err.message : 'Unable to search nearby places right now.',
        );
      }
    },
    [placesLib, userCoords.lat, userCoords.lng, onPlaceChosenForGrounding],
  );

  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      setGpsStatusMsg('Browser geolocation unavailable. Use city quick presets below.');
      return;
    }
    setGpsStatusMsg('Requesting GPS fix...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const next = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        onUpdateUserCoords(next);
        setGpsStatusMsg(`GPS Locked: ${next.lat.toFixed(4)}, ${next.lng.toFixed(4)}`);
        if (map) {
          map.panTo(next);
          map.setZoom(14);
        }
      },
      (err) => {
        setGpsStatusMsg(
          `GPS permission ${err.code === 1 ? 'denied' : 'timed out'} — pick a city preset or tap the map.`,
        );
      },
      { enableHighAccuracy: true, timeout: 7000, maximumAge: 30000 },
    );
  };

  return (
    <div className="space-y-3">
      {/* Header + GPS Trigger */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-[#FF5722]" />
          <div>
            <h3 className="font-display font-bold text-base">
              FISM Interactive Google Map &amp; Routes
            </h3>
            <p className="text-[11px] text-[#64748B] dark:text-[#AAB4C8]">
              Tap anywhere on map, search Places API (New), inspect Check-In Locate Pins &amp; compute routes
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={handleLocateMe}
          className="px-3 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-[#101426] hover:bg-[#E2E8F0] dark:hover:bg-[#1F293D] text-xs font-semibold cursor-pointer flex items-center gap-1.5"
        >
          <Compass className="w-3.5 h-3.5 text-[#0EA5E9]" />
          Use My GPS Location
        </button>
      </div>

      {/* Quick City Presets & Nearby Category Chips */}
      <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
        {QUICK_MAP_CITIES.map((city) => (
          <button
            key={city.label}
            type="button"
            onClick={() => {
              onUpdateUserCoords({ lat: city.lat, lng: city.lng });
              setGpsStatusMsg(`Centered on ${city.label}`);
              if (map) {
                map.panTo({ lat: city.lat, lng: city.lng });
                map.setZoom(13);
              }
            }}
            className="px-2.5 py-1 rounded-lg bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] font-bold hover:border-[#FF5722] cursor-pointer"
          >
            📍 {city.label}
          </button>
        ))}
        <span className="text-[#CBD5E1] dark:text-slate-600">|</span>
        {NEARBY_CATEGORIES.map((cat) => (
          <button
            key={cat.type}
            type="button"
            onClick={() => handleSearchNearbyCategory(cat.type)}
            className={`px-2.5 py-1 rounded-lg font-bold cursor-pointer border ${
              activeNearbyType === cat.type
                ? 'bg-[#FF5722] text-white border-[#FF5722]'
                : 'bg-[#FFF7ED] dark:bg-orange-950/30 text-[#C2410C] dark:text-orange-300 border-orange-200 dark:border-orange-900'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {gpsStatusMsg && (
        <div className="text-[11px] font-semibold text-[#0EA5E9] px-1">{gpsStatusMsg}</div>
      )}

      {/* Places API (New) Autocomplete Search Box */}
      <div className="relative">
        <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056]">
          <Search className="w-4 h-4 text-[#64748B] shrink-0" />
          <input
            type="text"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            placeholder="Search real places, shoot venues, cafes, landmarks..."
            className="flex-1 bg-transparent text-xs focus:outline-none text-[#172033] dark:text-white"
          />
          {suggestionsLoading && (
            <span className="text-[10px] text-[#64748B]">Searching...</span>
          )}
          {searchText && (
            <button
              type="button"
              onClick={() => {
                setSearchText('');
                resetSession();
              }}
              className="text-[#64748B] hover:text-[#172033] dark:hover:text-white"
              aria-label="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {suggestions.length > 0 && (
          <ul className="absolute left-0 right-0 top-full mt-1.5 z-30 rounded-xl bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] shadow-xl max-h-56 overflow-y-auto divide-y divide-[#E2E8F0] dark:divide-[#344056]">
            {suggestions.map((suggestion, idx) => (
              <li key={idx}>
                <button
                  type="button"
                  onClick={() => handleSelectSuggestion(suggestion)}
                  className="w-full text-left px-3 py-2.5 text-xs hover:bg-[#F8FAFC] dark:hover:bg-[#101426] flex items-start gap-2 cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#FF5722] shrink-0 mt-0.5" />
                  <span className="text-[#172033] dark:text-white font-medium">
                    {suggestion.placePrediction?.text.text}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {placesError && (
        <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200">
          {placesError}
        </div>
      )}

      {/* Map Viewport (Explicit Height Required per CF2) */}
      <div className="relative w-full h-[380px] rounded-xl overflow-hidden border border-[#E2E8F0] dark:border-[#344056]">
        <GoogleMap
          style={{ width: '100%', height: '100%' }}
          defaultCenter={userCoords}
          defaultZoom={13}
          mapId="DEMO_MAP_ID"
          gestureHandling="greedy"
          internalUsageAttributionIds={GMP_ATTRIBUTION_IDS}
          onClick={(ev) => {
            const ll = ev.detail?.latLng;
            if (!ll) return;
            const clickedLoc = { lat: ll.lat, lng: ll.lng };
            setSelectedPlace({
              name: 'Dropped Inspect Pin',
              address: `Coords: ${ll.lat.toFixed(5)}, ${ll.lng.toFixed(5)}`,
              location: clickedLoc,
            });
            setShowPlaceInfo(true);
            setRouteSummary(null);
            onPlaceChosenForGrounding?.(
              `Explore places near ${ll.lat.toFixed(4)}, ${ll.lng.toFixed(4)}`,
            );
          }}
        >
          <MapCameraSync lat={userCoords.lat} lng={userCoords.lng} />

          {/* User / Creator Hub AdvancedMarker */}
          <AdvancedMarker
            ref={hubMarkerRef}
            position={userCoords}
            title="Your Current GPS Location"
            onClick={() => setShowHubInfo((prev) => !prev)}
          >
            <Pin background="#FF5722" borderColor="#FFFFFF" glyphColor="#FFFFFF" />
          </AdvancedMarker>
          {showHubInfo && hubMarker && (
            <InfoWindow anchor={hubMarker} onCloseClick={() => setShowHubInfo(false)}>
              <div className="text-xs text-[#151B2B] p-1">
                <div className="font-bold">Your Current Location</div>
                <div className="font-mono text-[10px] text-slate-500">
                  {userCoords.lat.toFixed(5)}, {userCoords.lng.toFixed(5)}
                </div>
              </div>
            </InfoWindow>
          )}

          {/* Daily Streak Locate Check-In Pins */}
          {checkInPins.slice(0, 25).map((cp) => (
            <CheckInPinMarker
              key={`checkin_pin_${cp.dayNumber}_${cp.dateIso}`}
              pin={cp}
              onRouteHere={(coords, title) => {
                setSelectedPlace({
                  name: title,
                  address: cp.locationLabel,
                  location: coords,
                });
                setRouteDestination(coords);
              }}
            />
          ))}

          {/* Nearby Search Markers */}
          {nearbyResults.map((nr, i) => (
            <AdvancedMarker
              key={`nearby_${i}_${nr.name}`}
              position={nr.location}
              title={nr.name}
              onClick={() => {
                setSelectedPlace(nr);
                setShowPlaceInfo(true);
              }}
            >
              <Pin background="#7C3AED" borderColor="#FFFFFF" glyphColor="#FFFFFF" scale={0.95} />
            </AdvancedMarker>
          ))}

          {/* Selected Place AdvancedMarker + InfoWindow */}
          {selectedPlace && (
            <>
              <AdvancedMarker
                ref={placeMarkerRef}
                position={selectedPlace.location}
                title={selectedPlace.name}
                onClick={() => setShowPlaceInfo((prev) => !prev)}
              >
                <Pin background="#2563EB" borderColor="#FFFFFF" glyphColor="#FFFFFF" scale={1.15} />
              </AdvancedMarker>
              {showPlaceInfo && placeMarker && (
                <InfoWindow
                  anchor={placeMarker}
                  onCloseClick={() => setShowPlaceInfo(false)}
                  maxWidth={240}
                >
                  <div className="text-xs text-[#151B2B] p-1 space-y-1.5">
                    <div className="font-bold text-sm">{selectedPlace.name}</div>
                    {selectedPlace.address && (
                      <div className="text-[11px] text-slate-600">{selectedPlace.address}</div>
                    )}
                    {typeof selectedPlace.rating === 'number' && (
                      <div className="text-[11px] font-semibold text-amber-600">
                        ⭐ {selectedPlace.rating.toFixed(1)} (
                        {selectedPlace.userRatingCount?.toLocaleString() || 0} reviews)
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={() => setRouteDestination(selectedPlace.location)}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-[#FF5722] text-white text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Navigation className="w-3 h-3" /> Route from My Location
                    </button>
                  </div>
                </InfoWindow>
              )}
            </>
          )}

          <ModernRoutesOverlay
            origin={userCoords}
            destination={routeDestination}
            travelMode={travelMode}
            onRouteComputed={setRouteSummary}
            onRouteError={setRouteError}
          />
        </GoogleMap>
      </div>

      {/* Selected Place & Modern Routes API Controls */}
      {selectedPlace && (
        <div className="p-3.5 rounded-xl bg-[#F8FAFC] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] space-y-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="font-bold text-xs text-[#172033] dark:text-white truncate">
                {selectedPlace.name}
              </div>
              <div className="text-[11px] text-[#64748B] dark:text-[#AAB4C8] truncate">
                {selectedPlace.address}
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              {(['DRIVING', 'TWO_WHEELER', 'WALKING'] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => {
                    setTravelMode(mode);
                    setRouteDestination(selectedPlace.location);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer ${
                    travelMode === mode && routeDestination
                      ? 'bg-[#2563EB] text-white'
                      : 'bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] text-[#64748B] dark:text-[#AAB4C8]'
                  }`}
                >
                  {mode === 'TWO_WHEELER' ? '2-WHEELER' : mode}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setRouteDestination(selectedPlace.location)}
                className="px-3 py-1 rounded-lg fism-grad-orange-red text-white text-[11px] font-bold cursor-pointer flex items-center gap-1"
              >
                <RouteIcon className="w-3 h-3" /> Directions
              </button>
            </div>
          </div>

          {routeSummary && (
            <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-[#E2E8F0] dark:border-[#344056] text-xs">
              <span className="font-bold text-[#16A34A]">
                🛣️ {(routeSummary.distanceMeters / 1000).toFixed(2)} km
              </span>
              <span className="font-bold text-[#2563EB]">
                ⏱️ {Math.max(1, Math.round(routeSummary.durationMillis / 60000))} mins (
                {routeSummary.travelMode})
              </span>
              <button
                type="button"
                onClick={() => {
                  setRouteDestination(null);
                  setRouteSummary(null);
                }}
                className="ml-auto text-[11px] text-[#64748B] hover:underline cursor-pointer"
              >
                Clear Route
              </button>
            </div>
          )}

          {routeError && (
            <div className="text-xs text-amber-700 dark:text-amber-300">{routeError}</div>
          )}
        </div>
      )}
    </div>
  );
};

export const FismInteractiveCreatorMap: React.FC<FismInteractiveCreatorMapProps> = (props) => {
  const apiStatus = useApiLoadingStatus();

  useEffect(() => {
    if (apiStatus === APILoadingStatus.AUTH_FAILURE) {
      triggerQuotaBanner();
    }
  }, [apiStatus]);

  if (
    !MAPS_API_KEY ||
    apiStatus === APILoadingStatus.FAILED ||
    apiStatus === APILoadingStatus.AUTH_FAILURE
  ) {
    return (
      <div className="w-full h-[380px] rounded-xl border border-[#E2E8F0] dark:border-[#344056] flex flex-col items-center justify-center bg-[#F8FAFC] dark:bg-[#101426] p-6 text-center">
        <MapPin className="w-8 h-8 text-[#FF5722] mb-2" />
        <p className="text-sm font-semibold">Interactive Google Map</p>
        <p className="text-xs text-[#64748B] dark:text-[#AAB4C8] max-w-md mt-1">
          Coordinates: {props.userCoords.lat.toFixed(4)}, {props.userCoords.lng.toFixed(4)}. Use the
          Gemini Maps Grounding search on the right to discover real-time verified places and links.
        </p>
      </div>
    );
  }

  return <CreatorMapInner {...props} />;
};

export interface FismInAppMapModalProps {
  open: boolean;
  title: string;
  subtitle?: string;
  lat: number;
  lng: number;
  label?: string;
  isLive?: boolean;
  accuracyMeters?: number;
  onClose: () => void;
}

export const FismInAppMapModal: React.FC<FismInAppMapModalProps> = ({
  open,
  title,
  subtitle,
  lat,
  lng,
  label,
  isLive,
  accuracyMeters,
  onClose,
}) => {
  const apiStatus = useApiLoadingStatus();
  const [originCoords, setOriginCoords] = useState<{ lat: number; lng: number }>({
    lat: 28.6139,
    lng: 77.209,
  });
  const [showRoute, setShowRoute] = useState(false);
  const [travelMode, setTravelMode] = useState<TravelModeOption>('DRIVING');
  const [routeSummary, setRouteSummary] = useState<RouteSummaryState | null>(null);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [markerRef, marker] = useAdvancedMarkerRef();
  const [infoOpen, setInfoOpen] = useState(true);

  if (!open) return null;

  const mapsUnavailable =
    !MAPS_API_KEY ||
    apiStatus === APILoadingStatus.FAILED ||
    apiStatus === APILoadingStatus.AUTH_FAILURE;

  const startInAppDirections = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setOriginCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          setShowRoute(true);
        },
        () => {
          setShowRoute(true);
        },
        { enableHighAccuracy: true, timeout: 6000 },
      );
    } else {
      setShowRoute(true);
    }
  };

  return (
    <div className="fixed inset-0 z-[95] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="fism-card max-w-2xl w-full p-5 space-y-4 border-2 border-[#0EA5E9]">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-[#FF5722] shrink-0" />
              <h3 className="font-extrabold text-base truncate">{title}</h3>
              {isLive && (
                <span className="px-2 py-0.5 rounded-full bg-[#16A34A] text-white text-[10px] font-black">
                  LIVE ±{accuracyMeters ?? 15}m
                </span>
              )}
            </div>
            {(subtitle || label) && (
              <p className="text-xs text-[#52607A] dark:text-slate-300 truncate mt-0.5">
                {subtitle || label} • {lat.toFixed(5)}, {lng.toFixed(5)}
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="w-full h-[360px] rounded-2xl overflow-hidden border border-[#D8E1F0] dark:border-slate-700 bg-[#0F172A]">
          {mapsUnavailable ? (
            <div className="w-full h-full flex flex-col items-center justify-center text-white p-6 text-center space-y-2">
              <MapPin className="w-8 h-8 text-[#38BDF8]" />
              <div className="font-bold text-sm">{label || title}</div>
              <div className="font-mono text-xs text-[#38BDF8]">
                {lat.toFixed(5)}, {lng.toFixed(5)}
              </div>
            </div>
          ) : (
            <GoogleMap
              style={{ width: '100%', height: '100%' }}
              defaultCenter={{ lat, lng }}
              defaultZoom={15}
              mapId="DEMO_MAP_ID"
              gestureHandling="greedy"
              internalUsageAttributionIds={GMP_ATTRIBUTION_IDS}
            >
              <MapCameraSync lat={lat} lng={lng} />
              <AdvancedMarker
                ref={markerRef}
                position={{ lat, lng }}
                title={title}
                onClick={() => setInfoOpen((p) => !p)}
              >
                <Pin background="#FF5722" borderColor="#FFFFFF" glyphColor="#FFFFFF" scale={1.2} />
              </AdvancedMarker>
              {infoOpen && marker && (
                <InfoWindow anchor={marker} onCloseClick={() => setInfoOpen(false)}>
                  <div className="text-xs text-[#151B2B] p-1">
                    <div className="font-bold">{label || title}</div>
                    <div className="font-mono text-[10px] text-slate-500">
                      {lat.toFixed(5)}, {lng.toFixed(5)}
                    </div>
                  </div>
                </InfoWindow>
              )}
              {showRoute && (
                <ModernRoutesOverlay
                  origin={originCoords}
                  destination={{ lat, lng }}
                  travelMode={travelMode}
                  onRouteComputed={setRouteSummary}
                  onRouteError={setRouteError}
                />
              )}
            </GoogleMap>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 flex-wrap">
            {(['DRIVING', 'TWO_WHEELER', 'WALKING'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  setTravelMode(m);
                  if (!showRoute) startInAppDirections();
                }}
                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold ${
                  travelMode === m && showRoute
                    ? 'bg-[#2563EB] text-white'
                    : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A] dark:text-slate-300'
                }`}
              >
                {m === 'TWO_WHEELER' ? '2-Wheeler' : m}
              </button>
            ))}
            <button
              type="button"
              onClick={startInAppDirections}
              className="px-3.5 py-1.5 rounded-xl bg-[#FF5722] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
            >
              <RouteIcon className="w-3.5 h-3.5" /> Compute In-App Route
            </button>
          </div>

          <a
            href={`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`}
            target="_blank"
            rel="noreferrer"
            className="px-3 py-1.5 rounded-xl bg-[#0EA5E9] text-white text-xs font-bold flex items-center gap-1"
          >
            <Navigation className="w-3.5 h-3.5" /> Open Google Maps App
          </a>
        </div>

        {routeSummary && (
          <div className="p-2.5 rounded-xl bg-[#F0FDF4] dark:bg-emerald-950/30 border border-[#16A34A]/40 flex items-center gap-4 text-xs font-extrabold">
            <span className="text-[#16A34A]">
              🛣️ {(routeSummary.distanceMeters / 1000).toFixed(2)} km
            </span>
            <span className="text-[#2563EB]">
              ⏱️ {Math.max(1, Math.round(routeSummary.durationMillis / 60000))} mins (
              {routeSummary.travelMode})
            </span>
          </div>
        )}
        {routeError && (
          <div className="text-xs text-amber-600 dark:text-amber-300">{routeError}</div>
        )}
      </div>
    </div>
  );
};

