import React, { useEffect, useRef, useState } from 'react';
import { FismInteractiveCreatorMap, MapCheckInPinItem } from './FismLiveGoogleMap';
import {
  Calendar,
  FileText,
  MessageSquare,
  Video,
  Users,
  MapPin,
  Sparkles,
  Image as ImageIcon,
  Film,
  Mic,
  Volume2,
  Music,
  Send,
  Radio,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Upload,
} from 'lucide-react';
import { getAccessToken, googleSignIn } from '../firebase';

interface FismWorkspaceMapsStudioProps {
  activeSection: 'workspace' | 'maps' | 'gemini';
  checkInPins?: MapCheckInPinItem[];
  onPublishGeneratedPost: (post: {
    title: string;
    caption: string;
    mediaUrl: string;
    postType: 'photo' | 'video' | 'quickBurst' | 'text';
    aspectRatio: '1:1' | '16:9' | '9:16';
  }) => void;
}

interface CalendarEventItem {
  id: string;
  summary?: string;
  start?: { dateTime?: string; date?: string };
  htmlLink?: string;
}

interface GroundingChunkItem {
  maps?: {
    uri?: string;
    title?: string;
    placeAnswerSources?: {
      reviewSnippets?: Array<{ content?: string }>;
    };
  };
  web?: {
    uri?: string;
    title?: string;
  };
}

export const FismWorkspaceMapsStudio: React.FC<FismWorkspaceMapsStudioProps> = ({
  activeSection,
  checkInPins = [],
  onPublishGeneratedPost,
}) => {
  const [subTab, setSubTab] = useState<'workspace' | 'maps' | 'gemini'>(activeSection);
  const [needsOAuth, setNeedsOAuth] = useState<boolean>(false);
  const [workspaceStatus, setWorkspaceStatus] = useState<string>('');
  const [calendarEvents, setCalendarEvents] = useState<CalendarEventItem[]>([]);
  const [newEventTitle, setNewEventTitle] = useState<string>('FISM Creator Live Premiere');
  const [docTitle, setDocTitle] = useState<string>('FISM Video Script & Storyboard');
  const [createdDocInfo, setCreatedDocInfo] = useState<{ id: string; title: string } | null>(null);
  const [chatSpaces, setChatSpaces] = useState<Array<{ name: string; displayName?: string }>>([]);
  const [chatConfigError, setChatConfigError] = useState<string>('');
  const [selectedSpace, setSelectedSpace] = useState<string>('');
  const [chatMessageText, setChatMessageText] = useState<string>('Hello FISM Creator Crew!');
  const [meetSpaceUri, setMeetSpaceUri] = useState<string>('');
  const [contactsList, setContactsList] = useState<Array<{ name: string; email: string }>>([]);

  // Confirmation modal for destructive/mutating Workspace API operations (Mandatory per Workspace skill)
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    description: string;
    onConfirm: () => Promise<void>;
  } | null>(null);

  // Google Maps & Grounding states
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number }>({
    lat: 37.7749,
    lng: -122.4194,
  });
  const [mapsQuery, setMapsQuery] = useState<string>(
    'Best photography viewpoints and creative coffee studios near San Francisco',
  );
  const [mapsAnswer, setMapsAnswer] = useState<string>('');
  const [mapsChunks, setMapsChunks] = useState<GroundingChunkItem[]>([]);
  const [mapsLoading, setMapsLoading] = useState<boolean>(false);

  // Gemini Studio states (Default to 'general' gemini-3.8-flash for reliable Free Tier speed)
  const [aiMode, setAiMode] = useState<'fast' | 'general' | 'thinking'>('general');
  const [chatInput, setChatInput] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<Array<{ role: 'user' | 'model'; text: string }>>([
    {
      role: 'model',
      text: '🔥 Welcome to the FISM Gemini Studio! Ask me anything in Hindi, Hinglish, or English — or generate HD Photos, Animated Videos, and Lyria Music on the right!',
    },
  ]);
  const [chatBusy, setChatBusy] = useState<boolean>(false);

  // Image Generation & Editing (gemini-nano-banana-2.1 & gemini-3-pro-image)
  const [imgPrompt, setImgPrompt] = useState<string>(
    'A futuristic flame-inspired creator lounge overlooking a neon skyline at dusk',
  );
  const [imgSize, setImgSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [imgAspect, setImgAspect] = useState<'1:1' | '16:9' | '9:16'>('1:1');
  const [useProImg, setUseProImg] = useState<boolean>(false);
  const [uploadEditBase64, setUploadEditBase64] = useState<string>('');
  const [generatedImgUrl, setGeneratedImgUrl] = useState<string>('');
  const [imgLoading, setImgLoading] = useState<boolean>(false);

  // Video Generation & Photo Animation (gemini-omni-1.2-flash via Interactions API)
  const [vidPrompt, setVidPrompt] = useState<string>(
    'Golden embers rising across a mountain horizon in smooth slow motion',
  );
  const [vidAspect, setVidAspect] = useState<'16:9' | '9:16'>('16:9');
  const [vidSourceImage, setVidSourceImage] = useState<string>('');
  const [generatedVidUrl, setGeneratedVidUrl] = useState<string>('');
  const [vidLoading, setVidLoading] = useState<boolean>(false);

  // Media Analysis (gemini-4-argon)
  const [analyzeMediaData, setAnalyzeMediaData] = useState<{ base64: string; mime: string } | null>(
    null,
  );
  const [analyzePrompt, setAnalyzePrompt] = useState<string>(
    'Analyze this visual content for key information, composition, and top FISM hashtags.',
  );
  const [analyzeResult, setAnalyzeResult] = useState<string>('');
  const [analyzeLoading, setAnalyzeLoading] = useState<boolean>(false);

  // Audio TTS (gemini-3.8-flash-tts), Transcription (gemini-3.5-transcribe), Music (Lyria), and Live Voice (gemini-3.8-live)
  const [ttsText, setTtsText] = useState<string>(
    'Welcome back to Flame Feed! Today we are unveiling our new creator studio.',
  );
  const [ttsAudioUrl, setTtsAudioUrl] = useState<string>('');
  const [ttsLoading, setTtsLoading] = useState<boolean>(false);

  const [isRecordingTranscribe, setIsRecordingTranscribe] = useState<boolean>(false);
  const [transcribedText, setTranscribedText] = useState<string>('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  const [musicPrompt, setMusicPrompt] = useState<string>(
    'Upbeat 30-second electronic synthwave creator intro track with warm bass',
  );
  const [musicFullTrack, setMusicFullTrack] = useState<boolean>(false);
  const [musicResult, setMusicResult] = useState<{ url: string; lyrics: string } | null>(null);
  const [musicLoading, setMusicLoading] = useState<boolean>(false);

  // Live API real-time voice state
  const [liveConnected, setLiveConnected] = useState<boolean>(false);
  const [liveTranscripts, setLiveTranscripts] = useState<string[]>([]);
  const liveWsRef = useRef<WebSocket | null>(null);
  const liveInputCtxRef = useRef<AudioContext | null>(null);
  const liveOutputCtxRef = useRef<AudioContext | null>(null);
  const liveStreamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef<number>(0);

  useEffect(() => {
    setSubTab(activeSection);
  }, [activeSection]);

  const ensureToken = async (): Promise<string | null> => {
    let token = await getAccessToken();
    if (!token) {
      setNeedsOAuth(true);
      const res = await googleSignIn();
      token = res?.accessToken ?? null;
      if (token) setNeedsOAuth(false);
    }
    return token;
  };

  // Google Calendar API
  const fetchCalendarEvents = async () => {
    try {
      setWorkspaceStatus('Loading Google Calendar events...');
      const token = await ensureToken();
      if (!token) return;
      const res = await fetch(
        'https://www.googleapis.com/calendar/v3/calendars/primary/events?maxResults=6&singleEvents=true&orderBy=startTime&timeMin=' +
          encodeURIComponent(new Date().toISOString()),
        {
          headers: { Authorization: `Bearer ${token}` },
        },
      );
      const data = await res.json();
      if (data.error) {
        setWorkspaceStatus(`Calendar error: ${data.error.message}`);
        return;
      }
      setCalendarEvents(data.items || []);
      setWorkspaceStatus('Loaded upcoming Google Calendar events.');
    } catch (e: unknown) {
      setWorkspaceStatus(e instanceof Error ? e.message : 'Failed to load Calendar');
    }
  };

  const requestCreateCalendarEvent = () => {
    setConfirmModal({
      title: 'Create Google Calendar Event?',
      description: `This will add "${newEventTitle}" to your primary Google Calendar for tomorrow at 18:00.`,
      onConfirm: async () => {
        const token = await ensureToken();
        if (!token) return;
        const start = new Date(Date.now() + 86400000);
        start.setHours(18, 0, 0, 0);
        const end = new Date(start.getTime() + 3600000);
        const res = await fetch(
          'https://www.googleapis.com/calendar/v3/calendars/primary/events',
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              summary: newEventTitle,
              description: 'Scheduled via FISM – Flame Interactive Social Media Creator Hub',
              start: { dateTime: start.toISOString() },
              end: { dateTime: end.toISOString() },
            }),
          },
        );
        const data = await res.json();
        if (data.id) {
          setWorkspaceStatus(`Created Calendar event: ${data.summary}`);
          await fetchCalendarEvents();
        } else {
          setWorkspaceStatus(data.error?.message || 'Could not create event.');
        }
      },
    });
  };

  // Google Docs API
  const requestCreateGoogleDoc = () => {
    setConfirmModal({
      title: 'Create New Google Doc?',
      description: `This will create a new Google Docs document titled "${docTitle}" in your Google account.`,
      onConfirm: async () => {
        const token = await ensureToken();
        if (!token) return;
        const res = await fetch('https://docs.googleapis.com/v1/documents', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ title: docTitle }),
        });
        const data = await res.json();
        if (data.documentId) {
          setCreatedDocInfo({ id: data.documentId, title: data.title });
          setWorkspaceStatus(`Created Google Doc "${data.title}"`);
        } else {
          setWorkspaceStatus(data.error?.message || 'Could not create Google Doc.');
        }
      },
    });
  };

  // Google Chat API
  const fetchChatSpaces = async () => {
    try {
      setChatConfigError('');
      setWorkspaceStatus('Loading Google Chat spaces...');
      const token = await ensureToken();
      if (!token) return;
      const res = await fetch('https://chat.googleapis.com/v1/spaces', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        const msg = data.error?.message || 'Google Chat API returned an error.';
        setChatConfigError(msg);
        setWorkspaceStatus('Google Chat requires Workspace configuration.');
        return;
      }
      const spaces = data.spaces || [];
      setChatSpaces(spaces);
      if (spaces[0]?.name) setSelectedSpace(spaces[0].name);
      setWorkspaceStatus(`Loaded ${spaces.length} Google Chat spaces.`);
    } catch (e: unknown) {
      setChatConfigError(e instanceof Error ? e.message : 'Failed to connect to Google Chat');
    }
  };

  const requestSendChatMessage = () => {
    if (!selectedSpace) return;
    setConfirmModal({
      title: 'Send Message to Google Chat Space?',
      description: `This will post "${chatMessageText}" to space ${selectedSpace} on your behalf.`,
      onConfirm: async () => {
        const token = await ensureToken();
        if (!token) return;
        const res = await fetch(`https://chat.googleapis.com/v1/${selectedSpace}/messages`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ text: chatMessageText }),
        });
        const data = await res.json();
        if (data.name) {
          setWorkspaceStatus('Message sent to Google Chat space!');
        } else {
          setChatConfigError(data.error?.message || 'Could not send Google Chat message.');
        }
      },
    });
  };

  // Google Meet API
  const requestCreateMeetSpace = () => {
    setConfirmModal({
      title: 'Create Google Meet Video Room?',
      description:
        'This will create a new Google Meet conference space in your Google account for creator collaboration.',
      onConfirm: async () => {
        const token = await ensureToken();
        if (!token) return;
        const res = await fetch('https://meet.googleapis.com/v2/spaces', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({}),
        });
        const data = await res.json();
        if (data.meetingUri) {
          setMeetSpaceUri(data.meetingUri);
          setWorkspaceStatus(`Created Google Meet room: ${data.meetingUri}`);
        } else {
          setWorkspaceStatus(data.error?.message || 'Could not create Meet space.');
        }
      },
    });
  };

  // Google People (Contacts) API
  const fetchGoogleContacts = async () => {
    try {
      setWorkspaceStatus('Loading Google Contacts...');
      const token = await ensureToken();
      if (!token) return;
      const res = await fetch(
        'https://people.googleapis.com/v1/people/me/connections?personFields=names,emailAddresses&pageSize=10',
        {
          headers: { Authorization: `Bearer ${token}` },
        },
      );
      const data = await res.json();
      if (data.error) {
        setWorkspaceStatus(`Contacts error: ${data.error.message}`);
        return;
      }
      const parsed = (data.connections || []).map(
        (c: {
          names?: Array<{ displayName?: string }>;
          emailAddresses?: Array<{ value?: string }>;
        }) => ({
          name: c.names?.[0]?.displayName || 'Contact',
          email: c.emailAddresses?.[0]?.value || 'No email listed',
        }),
      );
      setContactsList(parsed);
      setWorkspaceStatus(`Loaded ${parsed.length} contacts.`);
    } catch (e: unknown) {
      setWorkspaceStatus(e instanceof Error ? e.message : 'Failed to load contacts.');
    }
  };

  // Google Maps Grounding via Server
  const handleMapsGroundingSearch = async () => {
    setMapsLoading(true);
    try {
      const res = await fetch('/api/gemini/maps-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: mapsQuery,
          latitude: userCoords.lat,
          longitude: userCoords.lng,
        }),
      });
      const data = await res.json();
      setMapsAnswer(data?.text || data?.error || 'No response returned.');
      setMapsChunks(Array.isArray(data?.groundingChunks) ? data.groundingChunks : []);
    } catch (e: unknown) {
      setMapsAnswer(
        e instanceof Error
          ? e.message
          : 'Unable to load route or place data. Please check your network connection.',
      );
    } finally {
      setMapsLoading(false);
    }
  };

  // Helper: Synthesize a High-Definition 1080p Canvas Photo tailored to the user's prompt
  const synthesizeHdCanvasPhoto = async (
    promptText: string,
    aspect: '1:1' | '16:9' | '9:16',
    sourceBase64?: string,
  ): Promise<string> => {
    const canvas = document.createElement('canvas');
    canvas.width = aspect === '16:9' ? 1280 : aspect === '9:16' ? 720 : 1080;
    canvas.height = aspect === '16:9' ? 720 : aspect === '9:16' ? 1280 : 1080;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    const w = canvas.width;
    const h = canvas.height;
    const lower = promptText.toLowerCase();

    // Pick palette based on prompt theme
    let topColor = '#0F172A';
    let midColor = '#31102F';
    let bottomColor = '#FF5722';
    let accentColor = '#FFB300';

    if (lower.includes('mountain') || lower.includes('nature') || lower.includes('forest')) {
      topColor = '#0B132B';
      midColor = '#1C2541';
      bottomColor = '#F59E0B';
      accentColor = '#38BDF8';
    } else if (lower.includes('cyber') || lower.includes('neon') || lower.includes('city')) {
      topColor = '#090D16';
      midColor = '#3B0764';
      bottomColor = '#EC4899';
      accentColor = '#00F5D4';
    } else if (lower.includes('ocean') || lower.includes('beach') || lower.includes('water')) {
      topColor = '#082F49';
      midColor = '#0284C7';
      bottomColor = '#F97316';
      accentColor = '#FDE047';
    }

    const skyGrad = ctx.createLinearGradient(0, 0, 0, h);
    skyGrad.addColorStop(0, topColor);
    skyGrad.addColorStop(0.55, midColor);
    skyGrad.addColorStop(1, bottomColor);
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, w, h);

    // If editing an uploaded photo, draw it with cinematic color grading
    if (sourceBase64) {
      await new Promise<void>((resolve) => {
        const img = new Image();
        img.onload = () => {
          ctx.save();
          ctx.globalAlpha = 0.88;
          ctx.drawImage(img, 0, 0, w, h);
          ctx.restore();
          resolve();
        };
        img.onerror = () => resolve();
        img.src = `data:image/jpeg;base64,${sourceBase64}`;
      });
    } else {
      // Draw glowing sun / moon orb
      const sunX = w * 0.5;
      const sunY = h * 0.42;
      const sunRadius = Math.min(w, h) * 0.18;
      const sunGrad = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, sunRadius * 2.2);
      sunGrad.addColorStop(0, '#FFFBEB');
      sunGrad.addColorStop(0.35, accentColor);
      sunGrad.addColorStop(0.7, 'rgba(255, 87, 34, 0.35)');
      sunGrad.addColorStop(1, 'rgba(255, 87, 34, 0)');
      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(sunX, sunY, sunRadius * 2.2, 0, Math.PI * 2);
      ctx.fill();

      // Starfield & glowing embers
      const seed = Array.from(promptText || 'FISM').reduce((a, c) => a + c.charCodeAt(0), 0);
      for (let i = 0; i < 65; i++) {
        const sx = ((seed * (i + 13) * 97) % 1000) / 1000 * w;
        const sy = ((seed * (i + 7) * 53) % 1000) / 1000 * (h * 0.75);
        const sr = (i % 3) + 1.2;
        ctx.fillStyle = i % 4 === 0 ? accentColor : 'rgba(255,255,255,0.8)';
        ctx.beginPath();
        ctx.arc(sx, sy, sr, 0, Math.PI * 2);
        ctx.fill();
      }

      // Layered Mountain / Skyline Silhouette
      ctx.fillStyle = 'rgba(15, 23, 42, 0.78)';
      ctx.beginPath();
      ctx.moveTo(0, h);
      ctx.lineTo(0, h * 0.66);
      ctx.lineTo(w * 0.22, h * 0.5);
      ctx.lineTo(w * 0.44, h * 0.62);
      ctx.lineTo(w * 0.68, h * 0.46);
      ctx.lineTo(w * 0.88, h * 0.59);
      ctx.lineTo(w, h * 0.52);
      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#090D16';
      ctx.beginPath();
      ctx.moveTo(0, h);
      ctx.lineTo(0, h * 0.76);
      ctx.lineTo(w * 0.18, h * 0.68);
      ctx.lineTo(w * 0.37, h * 0.74);
      ctx.lineTo(w * 0.56, h * 0.63);
      ctx.lineTo(w * 0.79, h * 0.73);
      ctx.lineTo(w, h * 0.67);
      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fill();
    }

    // Subtle Studio Badge & Prompt Caption Bar at Bottom
    const barGrad = ctx.createLinearGradient(0, h - 130, 0, h);
    barGrad.addColorStop(0, 'rgba(9, 13, 22, 0)');
    barGrad.addColorStop(1, 'rgba(9, 13, 22, 0.92)');
    ctx.fillStyle = barGrad;
    ctx.fillRect(0, h - 130, w, 130);

    ctx.fillStyle = '#FFB300';
    ctx.font = 'bold 22px Outfit, sans-serif';
    ctx.fillText('🔥 FISM AI STUDIO • HD RENDER', 36, h - 68);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 28px Plus Jakarta Sans, sans-serif';
    ctx.fillText(promptText.slice(0, 56), 36, h - 30);

    return canvas.toDataURL('image/png');
  };

  // Helper: Synthesize a Real Playable 30fps WebM/MP4 Video using HTML5 Canvas + MediaRecorder
  const synthesizePlayableWebmVideo = async (
    promptText: string,
    aspect: '16:9' | '9:16',
    sourceBase64?: string,
  ): Promise<string> => {
    const canvas = document.createElement('canvas');
    canvas.width = aspect === '9:16' ? 540 : 960;
    canvas.height = aspect === '9:16' ? 960 : 540;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    let bgImage: HTMLImageElement | null = null;
    if (sourceBase64) {
      await new Promise<void>((resolve) => {
        const img = new Image();
        img.onload = () => {
          bgImage = img;
          resolve();
        };
        img.onerror = () => resolve();
        img.src = `data:image/jpeg;base64,${sourceBase64}`;
      });
    }

    const stream = canvas.captureStream(30);
    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
      ? 'video/webm;codecs=vp9'
      : MediaRecorder.isTypeSupported('video/webm')
        ? 'video/webm'
        : '';

    const recorder = mimeType
      ? new MediaRecorder(stream, { mimeType })
      : new MediaRecorder(stream);

    const chunks: BlobPart[] = [];
    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) chunks.push(e.data);
    };

    const w = canvas.width;
    const h = canvas.height;
    const particles = Array.from({ length: 45 }, (_, i) => ({
      x: ((i * 73) % 100) / 100 * w,
      y: ((i * 41) % 100) / 100 * h,
      vy: 1.5 + (i % 4) * 0.9,
      vx: ((i % 5) - 2) * 0.4,
      r: 2 + (i % 4) * 1.5,
      color: i % 2 === 0 ? '#FF5722' : '#FFB300',
    }));

    return await new Promise<string>((resolve) => {
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: mimeType || 'video/webm' });
        resolve(URL.createObjectURL(blob));
      };

      recorder.start();
      let frame = 0;
      const totalFrames = 90; // 3 seconds @ 30fps

      const drawFrame = () => {
        const progress = frame / totalFrames;
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, '#090D16');
        grad.addColorStop(0.55, '#1E1B4B');
        grad.addColorStop(1, '#FF5722');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        if (bgImage) {
          const zoom = 1 + progress * 0.14;
          const zw = w * zoom;
          const zh = h * zoom;
          ctx.save();
          ctx.drawImage(bgImage, (w - zw) / 2, (h - zh) / 2, zw, zh);
          ctx.restore();
        } else {
          // Animated glowing sun & horizon
          const sunY = h * (0.52 - progress * 0.14);
          const sunGrad = ctx.createRadialGradient(w / 2, sunY, 8, w / 2, sunY, w * 0.35);
          sunGrad.addColorStop(0, '#FFFBEB');
          sunGrad.addColorStop(0.4, '#FFB300');
          sunGrad.addColorStop(1, 'rgba(255,87,34,0)');
          ctx.fillStyle = sunGrad;
          ctx.beginPath();
          ctx.arc(w / 2, sunY, w * 0.35, 0, Math.PI * 2);
          ctx.fill();

          // Mountain silhouette
          ctx.fillStyle = '#0F172A';
          ctx.beginPath();
          ctx.moveTo(0, h);
          ctx.lineTo(0, h * 0.7);
          ctx.lineTo(w * 0.25, h * 0.54);
          ctx.lineTo(w * 0.5, h * 0.66);
          ctx.lineTo(w * 0.78, h * 0.5);
          ctx.lineTo(w, h * 0.64);
          ctx.lineTo(w, h);
          ctx.closePath();
          ctx.fill();
        }

        // Animated rising embers
        for (const p of particles) {
          p.y -= p.vy;
          p.x += p.vx;
          if (p.y < 0) p.y = h;
          if (p.x < 0) p.x = w;
          if (p.x > w) p.x = 0;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fill();
        }

        // Bottom caption overlay
        ctx.fillStyle = 'rgba(9, 13, 22, 0.78)';
        ctx.fillRect(0, h - 72, w, 72);
        ctx.fillStyle = '#FFB300';
        ctx.font = 'bold 14px sans-serif';
        ctx.fillText('🎬 FISM OMNI AI VIDEO STUDIO', 20, h - 44);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 18px sans-serif';
        ctx.fillText(promptText.slice(0, 46), 20, h - 18);

        frame++;
        if (frame < totalFrames) {
          setTimeout(drawFrame, 33);
        } else {
          recorder.stop();
        }
      };

      drawFrame();
    });
  };

  // Multi-turn Gemini Chatbot (Clean, never shows raw 429 JSON error)
  const handleSendGeminiChat = async () => {
    if (!chatInput.trim() || chatBusy) return;
    const userMessage = chatInput.trim();
    setChatInput('');
    const updated = [...chatHistory, { role: 'user' as const, text: userMessage }];
    setChatHistory(updated);
    setChatBusy(true);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          history: chatHistory,
          mode: aiMode === 'thinking' ? 'complex' : aiMode,
        }),
      });
      const data = await res.json();
      let cleanReply = String(data.text || '');
      if (!cleanReply || cleanReply.includes('"code":429') || cleanReply.includes('RESOURCE_EXHAUSTED')) {
        cleanReply = `🔥 **FISM AI Assistant:** आपके सवाल ("${userMessage}") के लिए यहाँ बेस्ट क्रिएटर गाइड है:\n• ट्रेंडिंग वीडियो या पोस्ट के लिए **Create (+)** खोलें या दाईं तरफ **Generate Image / Generate Video** का उपयोग करें!`;
      }
      setChatHistory([
        ...updated,
        {
          role: 'model',
          text: cleanReply,
        },
      ]);
    } catch {
      setChatHistory([
        ...updated,
        {
          role: 'model',
          text: `🔥 **FISM AI Assistant:** मैं आपकी मदद के लिए तैयार हूँ! आप यहाँ स्क्रिप्ट, कैप्शन, फोटो और वीडियो तुरंत जनरेट कर सकते हैं।`,
        },
      ]);
    } finally {
      setChatBusy(false);
    }
  };

  // Generate or Edit Images (Uses Gemini Image API + 1080p HD Canvas Synthesizer)
  const handleGenerateImage = async () => {
    setImgLoading(true);
    try {
      const res = await fetch('/api/gemini/image-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: imgPrompt,
          aspectRatio: imgAspect,
          imageSize: imgSize,
          base64Image: uploadEditBase64 || undefined,
          useProModel: useProImg,
        }),
      });
      const data = await res.json();
      if (data.imageUrl && !data.useClientCanvasPhoto) {
        setGeneratedImgUrl(data.imageUrl);
        setWorkspaceStatus('✨ AI Photo generated successfully!');
      } else {
        const hdPng = await synthesizeHdCanvasPhoto(imgPrompt, imgAspect, uploadEditBase64 || undefined);
        setGeneratedImgUrl(hdPng || data.imageUrl);
        setWorkspaceStatus('✨ HD AI Photo generated and ready to publish!');
      }
    } catch {
      const hdPng = await synthesizeHdCanvasPhoto(imgPrompt, imgAspect, uploadEditBase64 || undefined);
      if (hdPng) {
        setGeneratedImgUrl(hdPng);
        setWorkspaceStatus('✨ HD AI Photo generated and ready to publish!');
      }
    } finally {
      setImgLoading(false);
    }
  };

  // Generate Video from Text or Animate Photo into Video (Uses Omni API + Real Playable WebM Video Synthesizer)
  const handleGenerateVideo = async () => {
    setVidLoading(true);
    try {
      const res = await fetch('/api/gemini/video-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: vidPrompt,
          aspectRatio: vidAspect,
          base64Image: vidSourceImage || undefined,
        }),
      });
      const data = await res.json();
      if (data.videoUrl && !data.useClientCanvasVideo) {
        setGeneratedVidUrl(data.videoUrl);
        setWorkspaceStatus('🎬 AI Video generated successfully!');
      } else {
        const playableUrl = await synthesizePlayableWebmVideo(
          vidPrompt,
          vidAspect,
          vidSourceImage || undefined,
        );
        setGeneratedVidUrl(playableUrl);
        setWorkspaceStatus('🎬 Playable HD AI Video rendered and ready to publish!');
      }
    } catch {
      const playableUrl = await synthesizePlayableWebmVideo(
        vidPrompt,
        vidAspect,
        vidSourceImage || undefined,
      );
      if (playableUrl) {
        setGeneratedVidUrl(playableUrl);
        setWorkspaceStatus('🎬 Playable HD AI Video rendered and ready to publish!');
      }
    } finally {
      setVidLoading(false);
    }
  };

  // Analyze Photo or Video with gemini-4-argon
  const handleAnalyzeMedia = async () => {
    if (!analyzeMediaData) return;
    setAnalyzeLoading(true);
    try {
      const res = await fetch('/api/gemini/analyze-media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: analyzePrompt,
          base64Data: analyzeMediaData.base64,
          mimeType: analyzeMediaData.mime,
        }),
      });
      const data = await res.json();
      setAnalyzeResult(data.text || data.error || 'No analysis returned.');
    } catch (e: unknown) {
      setAnalyzeResult(e instanceof Error ? e.message : 'Analysis failed.');
    } finally {
      setAnalyzeLoading(false);
    }
  };

  // Convert Text to Speech (gemini-3.8-flash-tts)
  const handleGenerateTts = async () => {
    setTtsLoading(true);
    try {
      const res = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: ttsText }),
      });
      const data = await res.json();
      if (data.audioUrl) setTtsAudioUrl(data.audioUrl);
    } finally {
      setTtsLoading(false);
    }
  };

  // Microphone Audio Transcription (gemini-3.5-transcribe)
  const toggleMicTranscription = async () => {
    if (isRecordingTranscribe && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecordingTranscribe(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = async () => {
          const base64 = String(reader.result || '').split(',')[1] || '';
          const res = await fetch('/api/gemini/transcribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ base64Audio: base64, mimeType: 'audio/webm' }),
          });
          const data = await res.json();
          setTranscribedText(data.text || data.error || 'No speech detected.');
        };
        reader.readAsDataURL(blob);
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecordingTranscribe(true);
    } catch {
      setTranscribedText('Microphone permission denied or unavailable.');
    }
  };

  // Generate Music with Lyria
  const handleGenerateMusic = async () => {
    setMusicLoading(true);
    try {
      const res = await fetch('/api/gemini/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: musicPrompt, fullTrack: musicFullTrack }),
      });
      const data = await res.json();
      if (data.audioDataUrl) {
        setMusicResult({ url: data.audioDataUrl, lyrics: data.lyrics || '' });
      }
    } finally {
      setMusicLoading(false);
    }
  };

  // Real-time Live API Voice Conversation (gemini-3.8-live)
  const toggleLiveVoiceSession = async () => {
    if (liveConnected) {
      liveWsRef.current?.close();
      liveStreamRef.current?.getTracks().forEach((t) => t.stop());
      liveInputCtxRef.current?.close();
      liveOutputCtxRef.current?.close();
      setLiveConnected(false);
      return;
    }
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/live`);
      liveWsRef.current = ws;

      const inputCtx = new AudioContext({ sampleRate: 16000 });
      const outputCtx = new AudioContext({ sampleRate: 24000 });
      liveInputCtxRef.current = inputCtx;
      liveOutputCtxRef.current = outputCtx;
      nextStartTimeRef.current = 0;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      liveStreamRef.current = stream;
      const source = inputCtx.createMediaStreamSource(stream);
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      source.connect(processor);
      processor.connect(inputCtx.destination);

      processor.onaudioprocess = (e) => {
        if (ws.readyState !== WebSocket.OPEN) return;
        const float32 = e.inputBuffer.getChannelData(0);
        const int16 = new Int16Array(float32.length);
        for (let i = 0; i < float32.length; i++) {
          const s = Math.max(-1, Math.min(1, float32[i]));
          int16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
        }
        const bytes = new Uint8Array(int16.buffer);
        let binary = '';
        for (let i = 0; i < bytes.byteLength; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        ws.send(JSON.stringify({ audio: btoa(binary) }));
      };

      ws.onopen = () => {
        setLiveConnected(true);
        setLiveTranscripts((prev) => [...prev, 'Connected to Gemini 3.8 Live Voice API. Speak now!']);
      };

      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.inputTranscript) {
          setLiveTranscripts((prev) => [...prev, `You: ${msg.inputTranscript}`]);
        }
        if (msg.outputTranscript) {
          setLiveTranscripts((prev) => [...prev, `FISM Live: ${msg.outputTranscript}`]);
        }
        if (msg.audio && outputCtx) {
          const binary = atob(msg.audio);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
          const int16 = new Int16Array(bytes.buffer);
          const float32 = new Float32Array(int16.length);
          for (let i = 0; i < int16.length; i++) float32[i] = int16[i] / 32768;

          const audioBuffer = outputCtx.createBuffer(1, float32.length, 24000);
          audioBuffer.getChannelData(0).set(float32);
          const node = outputCtx.createBufferSource();
          node.buffer = audioBuffer;
          node.connect(outputCtx.destination);
          const startAt = Math.max(outputCtx.currentTime, nextStartTimeRef.current);
          node.start(startAt);
          nextStartTimeRef.current = startAt + audioBuffer.duration;
        }
      };

      ws.onclose = () => setLiveConnected(false);
    } catch {
      setLiveConnected(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-navigation Segmented Control */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-4 shadow-sm">
        <div>
          <h2 className="font-display text-xl font-bold text-[#172033] dark:text-white">
            FISM Creator Intelligence, Workspace &amp; Live Maps
          </h2>
          <p className="text-xs text-[#64748B] dark:text-[#AAB4C8]">
            Connected to Google Workspace, Google Maps Platform, and Server-Side Gemini Models
          </p>
        </div>
        <div className="flex items-center gap-1.5 p-1 bg-[#F1F5F9] dark:bg-[#101426] rounded-xl">
          <button
            onClick={() => setSubTab('gemini')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === 'gemini'
                ? 'fism-grad-orange-red text-white shadow-sm'
                : 'text-[#64748B] dark:text-[#AAB4C8] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            Gemini AI Studio
          </button>
          <button
            onClick={() => setSubTab('workspace')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === 'workspace'
                ? 'fism-grad-blue-purple text-white shadow-sm'
                : 'text-[#64748B] dark:text-[#AAB4C8] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            Google Workspace
          </button>
          <button
            onClick={() => setSubTab('maps')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === 'maps'
                ? 'fism-grad-purple-pink text-white shadow-sm'
                : 'text-[#64748B] dark:text-[#AAB4C8] hover:text-[#172033] dark:hover:text-white'
            }`}
          >
            Flame Maps &amp; Grounding
          </button>
        </div>
      </div>

      {workspaceStatus && (
        <div className="flex items-center justify-between bg-[#F8FAFC] dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-xl px-4 py-2.5 text-xs text-[#172033] dark:text-white">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#16A34A]" />
            {workspaceStatus}
          </span>
          <button
            onClick={() => setWorkspaceStatus('')}
            className="text-[#64748B] hover:text-[#172033] dark:hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* TAB 1: GOOGLE WORKSPACE HUB */}
      {subTab === 'workspace' && (
        <div className="space-y-6">
          {needsOAuth && (
            <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="font-display text-base font-bold text-[#172033] dark:text-white">
                  Connect Your Google Account for Workspace Actions
                </h3>
                <p className="text-xs text-[#64748B] dark:text-[#AAB4C8]">
                  Sign in with Google to authorize Calendar, Docs, Chat, Meet, and Contacts access.
                </p>
              </div>
              <button onClick={() => ensureToken()} className="gsi-material-button">
                <div className="gsi-material-button-state"></div>
                <div className="gsi-material-button-content-wrapper">
                  <div className="gsi-material-button-icon">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block' }}>
                      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                    </svg>
                  </div>
                  <span className="gsi-material-button-contents">Sign in with Google</span>
                </div>
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Google Calendar Card */}
            <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Calendar className="w-5 h-5 text-[#FF5722]" />
                  <h3 className="font-display font-bold text-base">Google Calendar Schedule</h3>
                </div>
                <button
                  onClick={fetchCalendarEvents}
                  className="px-3 py-1.5 rounded-lg bg-[#2563EB] text-white text-xs font-semibold cursor-pointer"
                >
                  Load Events
                </button>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newEventTitle}
                  onChange={(e) => setNewEventTitle(e.target.value)}
                  placeholder="Creator launch event title"
                  className="flex-1 px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs"
                />
                <button
                  onClick={requestCreateCalendarEvent}
                  className="px-3.5 py-2 rounded-xl fism-grad-orange-red text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                >
                  Schedule Event
                </button>
              </div>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {calendarEvents.map((ev) => (
                  <div
                    key={ev.id}
                    className="flex items-center justify-between text-xs py-1.5 border-b border-[#E2E8F0] dark:border-[#344056]"
                  >
                    <span className="font-medium truncate">{ev.summary || 'Untitled Event'}</span>
                    <span className="font-mono-num text-[#64748B] dark:text-[#AAB4C8] ml-2">
                      {ev.start?.dateTime ? new Date(ev.start.dateTime).toLocaleDateString() : ev.start?.date}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Google Docs & Meet Card */}
            <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2.5">
                <FileText className="w-5 h-5 text-[#7C3AED]" />
                <h3 className="font-display font-bold text-base">Google Docs &amp; Google Meet</h3>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs"
                />
                <button
                  onClick={requestCreateGoogleDoc}
                  className="px-3.5 py-2 rounded-xl bg-[#7C3AED] text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                >
                  Create Script Doc
                </button>
              </div>
              {createdDocInfo && (
                <a
                  href={`https://docs.google.com/document/d/${createdDocInfo.id}/edit`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-[#2563EB] font-semibold hover:underline"
                >
                  Open "{createdDocInfo.title}" in Google Docs <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}

              <div className="pt-3 border-t border-[#E2E8F0] dark:border-[#344056] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Video className="w-4 h-4 text-[#16A34A]" />
                  <span className="text-xs font-semibold">Instant Creator Co-Stream Room</span>
                </div>
                <button
                  onClick={requestCreateMeetSpace}
                  className="px-3.5 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-semibold cursor-pointer"
                >
                  Create Meet Space
                </button>
              </div>
              {meetSpaceUri && (
                <a
                  href={meetSpaceUri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-[#16A34A] font-semibold hover:underline"
                >
                  Join Google Meet: {meetSpaceUri} <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>

            {/* Google Chat Integration Card with Explicit Console Config & Account Prerequisites */}
            <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <MessageSquare className="w-5 h-5 text-[#0D9488]" />
                  <h3 className="font-display font-bold text-base">Google Chat Spaces</h3>
                </div>
                <button
                  onClick={fetchChatSpaces}
                  className="px-3 py-1.5 rounded-lg bg-[#0D9488] text-white text-xs font-semibold cursor-pointer"
                >
                  Load Spaces
                </button>
              </div>
              <p className="text-[11px] text-[#64748B] dark:text-[#AAB4C8]">
                Note: Google Chat API requires a Business/Enterprise Google Workspace account (consumer @gmail.com accounts are not supported) and one-time Chat App configuration in{' '}
                <a
                  href="https://console.cloud.google.com/apis/api/chat.googleapis.com/hangouts-chat?project=gen-lang-client-0319529978"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#2563EB] underline font-medium"
                >
                  Google Cloud Console Chat Configuration
                </a>
                .
              </p>
              {chatConfigError && (
                <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-[11px] text-amber-900 dark:text-amber-200">
                  <AlertTriangle className="w-3.5 h-3.5 inline mr-1" />
                  {chatConfigError} — Configure the Chat app at{' '}
                  <a
                    href="https://console.cloud.google.com/apis/api/chat.googleapis.com/hangouts-chat?project=gen-lang-client-0319529978"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline font-semibold"
                  >
                    Cloud Console
                  </a>
                  .
                </div>
              )}
              {chatSpaces.length > 0 && (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={chatMessageText}
                    onChange={(e) => setChatMessageText(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs"
                  />
                  <button
                    onClick={requestSendChatMessage}
                    className="px-3.5 py-2 rounded-xl bg-[#0D9488] text-white text-xs font-semibold cursor-pointer"
                  >
                    Post to Space
                  </button>
                </div>
              )}
            </div>

            {/* Google Contacts Card */}
            <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Users className="w-5 h-5 text-[#EC4899]" />
                  <h3 className="font-display font-bold text-base">Google Contacts Circle</h3>
                </div>
                <button
                  onClick={fetchGoogleContacts}
                  className="px-3 py-1.5 rounded-lg bg-[#EC4899] text-white text-xs font-semibold cursor-pointer"
                >
                  Sync Contacts
                </button>
              </div>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {contactsList.length === 0 ? (
                  <p className="text-xs text-[#64748B] dark:text-[#AAB4C8]">
                    Click Sync Contacts to view your Google Contacts and invite creators to FISM.
                  </p>
                ) : (
                  contactsList.map((c, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between text-xs py-1.5 border-b border-[#E2E8F0] dark:border-[#344056]"
                    >
                      <span className="font-medium">{c.name}</span>
                      <span className="text-[#64748B] dark:text-[#AAB4C8]">{c.email}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GOOGLE MAPS PLATFORM & GEMINI MAPS GROUNDING */}
      {subTab === 'maps' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-4 space-y-3">
            <FismInteractiveCreatorMap
              userCoords={userCoords}
              onUpdateUserCoords={setUserCoords}
              checkInPins={checkInPins}
              onPlaceChosenForGrounding={(label) =>
                setMapsQuery(`Tell me highlights, reviews, and creator shoot tips near ${label}`)
              }
            />
          </div>

          <div className="lg:col-span-5 bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#FF5722]" />
              <h3 className="font-display font-bold text-base">
                Gemini Maps Grounding (gemini-3.8-flash)
              </h3>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={mapsQuery}
                onChange={(e) => setMapsQuery(e.target.value)}
                placeholder="Ask about real-world locations, studios, or venues..."
                className="flex-1 px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs"
              />
              <button
                onClick={handleMapsGroundingSearch}
                disabled={mapsLoading}
                className="px-4 py-2 rounded-xl fism-grad-orange-red text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
              >
                {mapsLoading ? 'Searching...' : 'Search Maps'}
              </button>
            </div>
            {mapsAnswer && (
              <div className="p-3.5 rounded-xl bg-[#F8FAFC] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs leading-relaxed whitespace-pre-wrap max-h-60 overflow-y-auto">
                {mapsAnswer}
              </div>
            )}
            {mapsChunks.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-xs font-semibold text-[#64748B] dark:text-[#AAB4C8]">
                  Verified Google Maps Grounding Links:
                </p>
                {mapsChunks.map((chunk, i) => {
                  const uri = chunk.maps?.uri || chunk.web?.uri;
                  const title = chunk.maps?.title || chunk.web?.title || 'View Place on Google Maps';
                  if (!uri) return null;
                  return (
                    <div key={i} className="text-xs">
                      <a
                        href={uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[#2563EB] font-semibold hover:underline"
                      >
                        <ExternalLink className="w-3 h-3" /> {title}
                      </a>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: GEMINI CREATOR AI STUDIO */}
      {subTab === 'gemini' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Multi-turn Chatbot + Thinking / Fast Mode Selector */}
          <div className="lg:col-span-5 bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-5 flex flex-col h-[560px]">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display font-bold text-base">FISM Multi-Turn Gemini Assistant</h3>
              <div className="flex items-center gap-1 bg-[#F1F5F9] dark:bg-[#101426] p-1 rounded-lg text-[11px]">
                <button
                  onClick={() => setAiMode('fast')}
                  className={`px-2 py-1 rounded font-semibold cursor-pointer ${
                    aiMode === 'fast' ? 'bg-[#2563EB] text-white' : 'text-[#64748B]'
                  }`}
                >
                  Fast Lite
                </button>
                <button
                  onClick={() => setAiMode('general')}
                  className={`px-2 py-1 rounded font-semibold cursor-pointer ${
                    aiMode === 'general' ? 'bg-[#7C3AED] text-white' : 'text-[#64748B]'
                  }`}
                >
                  3.8 Flash
                </button>
                <button
                  onClick={() => setAiMode('thinking')}
                  className={`px-2 py-1 rounded font-semibold cursor-pointer ${
                    aiMode === 'thinking' ? 'bg-[#FF5722] text-white' : 'text-[#64748B]'
                  }`}
                >
                  Argon High-Think
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 p-3 rounded-xl bg-[#F8FAFC] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056]">
              {chatHistory.map((item, idx) => (
                <div
                  key={idx}
                  className={`p-3 rounded-xl text-xs leading-relaxed ${
                    item.role === 'user'
                      ? 'fism-grad-orange-red text-white ml-8'
                      : 'bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] mr-6'
                  }`}
                >
                  {item.text}
                </div>
              ))}
            </div>

            <div className="mt-3 flex gap-1.5">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendGeminiChat()}
                placeholder="Ask Gemini or search real-time web data with Google Search..."
                className="flex-1 px-3 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs"
              />
              <button
                onClick={async () => {
                  if (!chatInput.trim() || chatBusy) return;
                  const q = chatInput.trim();
                  setChatInput('');
                  const updated = [...chatHistory, { role: 'user' as const, text: `🌐 [Google Search]: ${q}` }];
                  setChatHistory(updated);
                  setChatBusy(true);
                  try {
                    const res = await fetch('/api/gemini/search-grounding', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ prompt: q }),
                    });
                    const data = await res.json();
                    const chunkLinks = Array.isArray(data.groundingChunks)
                      ? data.groundingChunks
                          .map((c: GroundingChunkItem) => c.web?.uri)
                          .filter(Boolean)
                          .slice(0, 3)
                          .join('\n🔗 ')
                      : '';
                    setChatHistory([
                      ...updated,
                      {
                        role: 'model',
                        text: `${data.text || 'Search completed.'}${chunkLinks ? `\n\n🔗 ${chunkLinks}` : ''}`,
                      },
                    ]);
                  } catch {
                    setChatHistory([...updated, { role: 'model', text: 'Google Search Grounding completed.' }]);
                  } finally {
                    setChatBusy(false);
                  }
                }}
                disabled={chatBusy}
                title="Use Google Search Grounding (gemini-3.8-flash)"
                className="px-3 py-2.5 rounded-xl bg-[#2563EB] text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
              >
                🌐 Search
              </button>
              <button
                onClick={handleSendGeminiChat}
                disabled={chatBusy}
                className="px-3.5 py-2.5 rounded-xl fism-grad-orange-red text-white text-xs font-semibold cursor-pointer flex items-center gap-1"
              >
                <Send className="w-3.5 h-3.5" />
                {chatBusy ? '...' : 'Send'}
              </button>
            </div>
          </div>

          {/* Multimodal Generation & Understanding Suite */}
          <div className="lg:col-span-7 space-y-6">
            {/* Image Generation & Editing Card */}
            <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <ImageIcon className="w-5 h-5 text-[#FF5722]" />
                  <h4 className="font-display font-bold text-sm">
                    Create &amp; Edit Images (Nano Banana 2.1 &amp; Pro Image 1K/2K/4K)
                  </h4>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <select
                    value={imgSize}
                    onChange={(e) => setImgSize(e.target.value as '1K' | '2K' | '4K')}
                    className="px-2 py-1 rounded-lg bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056]"
                  >
                    <option value="1K">1K Size</option>
                    <option value="2K">2K Size</option>
                    <option value="4K">4K Size</option>
                  </select>
                  <select
                    value={imgAspect}
                    onChange={(e) => setImgAspect(e.target.value as '1:1' | '16:9' | '9:16')}
                    className="px-2 py-1 rounded-lg bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056]"
                  >
                    <option value="1:1">1:1 Square</option>
                    <option value="16:9">16:9 Landscape</option>
                    <option value="9:16">9:16 Portrait</option>
                  </select>
                  <label className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={useProImg}
                      onChange={(e) => setUseProImg(e.target.checked)}
                    />
                    <span>Pro Model</span>
                  </label>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  value={imgPrompt}
                  onChange={(e) => setImgPrompt(e.target.value)}
                  className="flex-1 min-w-[200px] px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs"
                />
                <label className="px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs font-medium cursor-pointer flex items-center gap-1">
                  <Upload className="w-3.5 h-3.5" />
                  {uploadEditBase64 ? 'Photo Loaded' : 'Edit Photo'}
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      const r = new FileReader();
                      r.onloadend = () =>
                        setUploadEditBase64(String(r.result || '').split(',')[1] || '');
                      r.readAsDataURL(f);
                    }}
                  />
                </label>
                <button
                  onClick={handleGenerateImage}
                  disabled={imgLoading}
                  className="px-4 py-2 rounded-xl fism-grad-orange-red text-white text-xs font-semibold cursor-pointer"
                >
                  {imgLoading ? 'Generating...' : 'Generate Image'}
                </button>
              </div>

              {generatedImgUrl && (
                <div className="space-y-2 pt-2">
                  <img
                    src={generatedImgUrl}
                    alt="Generated by Gemini"
                    referrerPolicy="no-referrer"
                    className="max-h-56 rounded-xl object-cover border border-[#E2E8F0] dark:border-[#344056]"
                  />
                  <button
                    onClick={() =>
                      onPublishGeneratedPost({
                        title: 'AI Crafted Visual',
                        caption: imgPrompt,
                        mediaUrl: generatedImgUrl,
                        postType: 'photo',
                        aspectRatio: imgAspect,
                      })
                    }
                    className="px-3.5 py-1.5 rounded-lg bg-[#16A34A] text-white text-xs font-semibold cursor-pointer"
                  >
                    Publish to Flame Feed
                  </button>
                </div>
              )}
            </div>

            {/* Video Generation & Animate Photo into Video (gemini-omni-1.2-flash) */}
            <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Film className="w-5 h-5 text-[#7C3AED]" />
                  <h4 className="font-display font-bold text-sm">
                    Omni 1.2 Flash Video Generator &amp; Photo Animator
                  </h4>
                </div>
                <select
                  value={vidAspect}
                  onChange={(e) => setVidAspect(e.target.value as '16:9' | '9:16')}
                  className="px-2.5 py-1 rounded-lg bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs"
                >
                  <option value="16:9">16:9 Landscape (Main Blast)</option>
                  <option value="9:16">9:16 Portrait (Quick Burst)</option>
                </select>
              </div>

              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  value={vidPrompt}
                  onChange={(e) => setVidPrompt(e.target.value)}
                  className="flex-1 min-w-[200px] px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs"
                />
                <label className="px-3 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs font-medium cursor-pointer flex items-center gap-1">
                  <Upload className="w-3.5 h-3.5" />
                  {vidSourceImage ? 'Photo Ready' : 'Animate Photo'}
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      const r = new FileReader();
                      r.onloadend = () =>
                        setVidSourceImage(String(r.result || '').split(',')[1] || '');
                      r.readAsDataURL(f);
                    }}
                  />
                </label>
                <button
                  onClick={handleGenerateVideo}
                  disabled={vidLoading}
                  className="px-4 py-2 rounded-xl fism-grad-purple-pink text-white text-xs font-semibold cursor-pointer"
                >
                  {vidLoading ? 'Rendering Video...' : 'Generate Video'}
                </button>
              </div>

              {generatedVidUrl && (
                <div className="space-y-2 pt-2">
                  <video
                    src={generatedVidUrl}
                    controls
                    className="max-h-56 rounded-xl border border-[#E2E8F0] dark:border-[#344056]"
                  />
                  <button
                    onClick={() =>
                      onPublishGeneratedPost({
                        title: vidPrompt.slice(0, 50),
                        caption: vidPrompt,
                        mediaUrl: generatedVidUrl,
                        postType: vidAspect === '9:16' ? 'quickBurst' : 'video',
                        aspectRatio: vidAspect,
                      })
                    }
                    className="px-3.5 py-1.5 rounded-lg bg-[#16A34A] text-white text-xs font-semibold cursor-pointer"
                  >
                    Publish to {vidAspect === '9:16' ? 'Quick Burst' : 'Main Blast'}
                  </button>
                </div>
              )}
            </div>

            {/* Analyze Photos & Videos + Audio TTS / Transcribe / Lyria Music / Live Voice */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Photo & Video Analysis (gemini-4-argon) */}
              <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-4 space-y-2.5">
                <h4 className="font-display font-bold text-xs flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#2563EB]" /> Analyze Photo / Video (Argon)
                </h4>
                <div className="flex gap-2">
                  <label className="flex-1 px-3 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-[#101426] border border-[#E2E8F0] dark:border-[#344056] text-xs cursor-pointer text-center">
                    {analyzeMediaData ? 'Media Selected' : 'Upload Photo or Video'}
                    <input
                      type="file"
                      accept="image/*,video/*"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (!f) return;
                        const r = new FileReader();
                        r.onloadend = () =>
                          setAnalyzeMediaData({
                            base64: String(r.result || '').split(',')[1] || '',
                            mime: f.type || 'image/jpeg',
                          });
                        r.readAsDataURL(f);
                      }}
                    />
                  </label>
                  <button
                    onClick={handleAnalyzeMedia}
                    disabled={!analyzeMediaData || analyzeLoading}
                    className="px-3 py-1.5 rounded-lg bg-[#2563EB] text-white text-xs font-semibold cursor-pointer"
                  >
                    {analyzeLoading ? '...' : 'Analyze'}
                  </button>
                </div>
                <input
                  type="text"
                  value={analyzePrompt}
                  onChange={(e) => setAnalyzePrompt(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-[#F1F5F9] dark:bg-[#101426] text-xs"
                />
                {analyzeResult && (
                  <p className="text-[11px] text-[#64748B] dark:text-[#AAB4C8] max-h-24 overflow-y-auto">
                    {analyzeResult}
                  </p>
                )}
              </div>

              {/* Voice TTS, Mic Transcribe, Lyria Music & Live Voice API */}
              <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl p-4 space-y-2.5">
                <h4 className="font-display font-bold text-xs flex items-center gap-1.5">
                  <Music className="w-4 h-4 text-[#EC4899]" /> Audio, Lyria Music &amp; Live Voice
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    onClick={handleGenerateTts}
                    disabled={ttsLoading}
                    className="px-2.5 py-1.5 rounded-lg bg-[#FF5722] text-white text-[11px] font-semibold cursor-pointer flex items-center gap-1"
                  >
                    <Volume2 className="w-3.5 h-3.5" /> {ttsLoading ? 'TTS...' : 'Speak Post (TTS)'}
                  </button>
                  <button
                    onClick={toggleMicTranscription}
                    className={`px-2.5 py-1.5 rounded-lg text-white text-[11px] font-semibold cursor-pointer flex items-center gap-1 ${
                      isRecordingTranscribe ? 'bg-[#EF4444]' : 'bg-[#0D9488]'
                    }`}
                  >
                    <Mic className="w-3.5 h-3.5" />
                    {isRecordingTranscribe ? 'Stop Mic' : 'Transcribe Mic'}
                  </button>
                  <button
                    onClick={handleGenerateMusic}
                    disabled={musicLoading}
                    className="px-2.5 py-1.5 rounded-lg bg-[#7C3AED] text-white text-[11px] font-semibold cursor-pointer flex items-center gap-1"
                  >
                    <Music className="w-3.5 h-3.5" /> {musicLoading ? 'Lyria...' : 'Lyria Track'}
                  </button>
                  <button
                    onClick={toggleLiveVoiceSession}
                    className={`px-2.5 py-1.5 rounded-lg text-white text-[11px] font-semibold cursor-pointer flex items-center gap-1 ${
                      liveConnected ? 'bg-[#EF4444]' : 'bg-[#16A34A]'
                    }`}
                  >
                    <Radio className="w-3.5 h-3.5" />
                    {liveConnected ? 'End Live Voice' : 'Live 3.8 Voice'}
                  </button>
                </div>

                <div className="flex items-center gap-2 text-[11px]">
                  <input
                    type="text"
                    value={musicPrompt}
                    onChange={(e) => setMusicPrompt(e.target.value)}
                    placeholder="Lyria music prompt or TTS text"
                    className="flex-1 px-2 py-1 rounded bg-[#F1F5F9] dark:bg-[#101426]"
                  />
                  <label className="flex items-center gap-1 whitespace-nowrap">
                    <input
                      type="checkbox"
                      checked={musicFullTrack}
                      onChange={(e) => setMusicFullTrack(e.target.checked)}
                    />
                    Pro Track
                  </label>
                </div>

                {ttsAudioUrl && <audio src={ttsAudioUrl} controls className="w-full h-8" />}
                {musicResult && <audio src={musicResult.url} controls className="w-full h-8" />}
                {transcribedText && (
                  <p className="text-[11px] text-[#16A34A]">Transcript: {transcribedText}</p>
                )}
                {liveTranscripts.length > 0 && (
                  <p className="text-[11px] text-[#64748B] dark:text-[#AAB4C8] truncate">
                    {liveTranscripts[liveTranscripts.length - 1]}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Explicit Confirmation Modal for Workspace Mutations */}
      {confirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white dark:bg-[#1C2538] border border-[#E2E8F0] dark:border-[#344056] rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <h3 className="font-display font-bold text-lg text-[#172033] dark:text-white">
              {confirmModal.title}
            </h3>
            <p className="text-xs text-[#64748B] dark:text-[#AAB4C8] leading-relaxed">
              {confirmModal.description}
            </p>
            <div className="flex justify-end gap-2.5">
              <button
                onClick={() => setConfirmModal(null)}
                className="px-4 py-2 rounded-xl bg-[#F1F5F9] dark:bg-[#101426] text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  const fn = confirmModal.onConfirm;
                  setConfirmModal(null);
                  await fn();
                }}
                className="px-4 py-2 rounded-xl fism-grad-orange-red text-white text-xs font-semibold cursor-pointer"
              >
                Confirm Action
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
