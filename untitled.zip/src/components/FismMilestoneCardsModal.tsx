import React, { useEffect, useMemo, useState } from 'react';
import {
  Award,
  Calendar as CalendarIcon,
  Camera,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  Crown,
  Flame,
  Gift,
  Lock,
  MapPin,
  MessageCircle,
  Package,
  Share2,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  X,
} from 'lucide-react';
import {
  FISM_MILESTONE_ROADMAP,
  FismFounderGiftClaim,
  FismMilestoneTier,
  FismMilestoneTierConfig,
  FismProfileFrameId,
  FismUserMilestoneState,
  computeExactMilestoneSchedule,
  computeTenureStats,
  isLeapYear,
} from '../types';
import { buildFismShareUrl, shareFismLink } from '../utils/fismDeepLinks';

export interface FismRedMilestoneTickProps {
  onClick?: (e: React.MouseEvent) => void;
  size?: 'sm' | 'md' | 'lg';
  title?: string;
}

export const FismRedMilestoneTick: React.FC<FismRedMilestoneTickProps> = ({
  onClick,
  size = 'sm',
  title = '1+ Year FISM Veteran — Click to view Achievement Card & Journey',
}) => {
  const iconDims =
    size === 'lg' ? 'w-6 h-6' : size === 'md' ? 'w-5 h-5' : 'w-4 h-4';
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onClick?.(e);
      }}
      title={title}
      aria-label={title}
      className="inline-flex items-center justify-center rounded-full p-0.5 transition-transform hover:scale-110 active:scale-95 focus:outline-none focus:ring-2 focus:ring-[#EF4444] shrink-0"
    >
      <span
        className={`${iconDims} rounded-full bg-gradient-to-br from-[#FF3B30] via-[#DC2626] to-[#7F1D1D] text-white inline-flex items-center justify-center shadow-[0_0_10px_rgba(239,68,68,0.65)] ring-1 ring-red-300/70`}
      >
        <Check className={size === 'lg' ? 'w-3.5 h-3.5 stroke-[3]' : 'w-2.5 h-2.5 stroke-[3.2]'} />
      </span>
    </button>
  );
};

export function getProfileFrameClasses(frameId?: FismProfileFrameId): string {
  switch (frameId) {
    case 'first_year_bronze':
      return 'ring-4 ring-[#CD7F32] shadow-[0_0_18px_rgba(205,127,50,0.6)]';
    case 'silver_glass':
      return 'ring-4 ring-slate-300 shadow-[0_0_20px_rgba(203,213,225,0.75)]';
    case 'platinum_aura':
      return 'ring-4 ring-cyan-200 shadow-[0_0_22px_rgba(165,243,252,0.75)]';
    case 'gold_vip':
      return 'ring-4 ring-[#FACC15] shadow-[0_0_24px_rgba(250,204,21,0.8)]';
    case 'red_cyberpunk':
      return 'ring-4 ring-[#EF4444] shadow-[0_0_26px_rgba(239,68,68,0.9)]';
    default:
      return '';
  }
}

export const FismVipGoldChatBadge: React.FC<{ label?: string }> = ({ label = 'VIP GOLD' }) => (
  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-gradient-to-r from-[#B45309] via-[#FACC15] to-[#D97706] text-[#101426] text-[9px] font-black uppercase tracking-wider shadow-[0_0_10px_rgba(250,204,21,0.55)] border border-yellow-200 shrink-0">
    <Crown className="w-2.5 h-2.5 fill-[#101426]" />
    {label}
  </span>
);

function getCardVisualPalette(tier: Exclude<FismMilestoneTier, 'none'>) {
  switch (tier) {
    case 'bronze':
      return {
        wrapper:
          'bg-gradient-to-br from-[#43230C] via-[#9C5221] to-[#D9822B] text-white border-[#F6AD55]/70',
        pill: 'bg-black/35 text-[#FDE68A] border-[#F6AD55]/45',
        accentHex: '#F6AD55',
        glowStyle: '0 20px 45px rgba(180,83,9,0.45)',
      };
    case 'silver':
      return {
        wrapper:
          'bg-gradient-to-br from-[#1E293B] via-[#64748B] to-[#CBD5E1] text-white border-white/60 backdrop-blur-xl',
        pill: 'bg-slate-900/60 text-slate-100 border-white/40',
        accentHex: '#E2E8F0',
        glowStyle: '0 20px 45px rgba(148,163,184,0.45)',
      };
    case 'platinum':
      return {
        wrapper:
          'bg-gradient-to-br from-[#0F172A] via-[#334155] to-[#94A3B8] text-white border-cyan-200/70',
        pill: 'bg-cyan-950/75 text-cyan-200 border-cyan-300/45',
        accentHex: '#A5F3FC',
        glowStyle: '0 20px 50px rgba(34,211,238,0.35)',
      };
    case 'gold':
      return {
        wrapper:
          'bg-gradient-to-br from-[#422006] via-[#B45309] to-[#FACC15] text-white border-[#FEF08A]/85 fism-diamond-dust',
        pill: 'bg-black/45 text-[#FEF08A] border-[#FEF08A]/60',
        accentHex: '#FEF08A',
        glowStyle: '0 20px 50px rgba(250,204,21,0.48)',
      };
    case 'red':
      return {
        wrapper:
          'bg-gradient-to-br from-[#080204] via-[#450A0A] to-[#DC2626] text-white border-[#FF2E4C]/90',
        pill: 'bg-black/65 text-[#FCA5A5] border-[#EF4444]/70',
        accentHex: '#FF2E4C',
        glowStyle: '0 22px 60px rgba(220,38,38,0.65)',
      };
  }
}

export interface FismMilestoneCardVisualProps {
  tier: Exclude<FismMilestoneTier, 'none'>;
  displayName: string;
  username: string;
  avatarUrl: string;
  tenureYears: number;
  tenureDays: number;
  joinedAtIso: string;
  compact?: boolean;
}

export const FismMilestoneCardVisual: React.FC<FismMilestoneCardVisualProps> = ({
  tier,
  displayName,
  username,
  avatarUrl,
  tenureYears,
  tenureDays,
  joinedAtIso,
  compact = false,
}) => {
  const cfg = FISM_MILESTONE_ROADMAP.find((r) => r.tier === tier) || FISM_MILESTONE_ROADMAP[0];
  const palette = getCardVisualPalette(tier);
  const joinedLabel = joinedAtIso ? joinedAtIso.slice(0, 10) : '2025-01-01';

  return (
    <div
      style={{ boxShadow: palette.glowStyle }}
      className={`relative overflow-hidden rounded-3xl border-2 ${palette.wrapper} ${
        compact ? 'p-4' : 'p-5 sm:p-6'
      }`}
    >
      {/* Subtle geometric shine */}
      <div className="pointer-events-none absolute -top-16 -right-16 w-48 h-48 rounded-full bg-white/15 blur-2xl" />
      <div className="pointer-events-none absolute -bottom-16 -left-12 w-40 h-40 rounded-full bg-black/25 blur-xl" />

      <div className="relative z-10 flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-black/45 border border-white/30 flex items-center justify-center shadow">
            <Flame className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="text-[10px] font-black uppercase tracking-[0.2em] opacity-85">
              FISM MILESTONE EDITION
            </div>
            <div className="text-sm sm:text-base font-black tracking-tight">{cfg.cardName}</div>
          </div>
        </div>
        <span
          className={`px-3 py-1 rounded-full text-[11px] font-black border uppercase tracking-wider ${palette.pill}`}
        >
          {cfg.badgeTitle}
        </span>
      </div>

      <div className="relative z-10 mt-5 flex items-center gap-3.5">
        <img
          src={avatarUrl}
          alt={displayName}
          className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl object-cover shrink-0 ${getProfileFrameClasses(
            cfg.frameId,
          )}`}
        />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="font-black text-base sm:text-lg truncate">{displayName}</span>
            <span className="w-5 h-5 rounded-full bg-[#DC2626] text-white inline-flex items-center justify-center ring-1 ring-white/70">
              <Check className="w-3 h-3 stroke-[3]" />
            </span>
          </div>
          <div className="text-xs font-bold opacity-90 truncate">@{username}</div>
          <div className="mt-1.5 flex items-center gap-2 text-[11px] font-extrabold opacity-90 tabular-nums flex-wrap">
            <span>Member since {joinedLabel}</span>
            <span>•</span>
            <span>
              {tenureYears.toFixed(1)} yrs ({tenureDays.toLocaleString()} days)
            </span>
          </div>
        </div>
      </div>

      {!compact && (
        <div className="relative z-10 mt-5 pt-3.5 border-t border-white/25 flex items-center justify-between gap-2 flex-wrap text-xs font-extrabold">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4" /> +{cfg.spReward.toLocaleString()} SP Coins Tier
          </span>
          <span className="opacity-90">{cfg.yearLabel} Official FISM Card</span>
        </div>
      )}
    </div>
  );
};

export async function generateMilestoneFlexPng(opts: {
  tier: Exclude<FismMilestoneTier, 'none'>;
  displayName: string;
  username: string;
  tenureYears: number;
  tenureDays: number;
}): Promise<{ dataUrl: string; blob: Blob | null }> {
  const cfg = FISM_MILESTONE_ROADMAP.find((r) => r.tier === opts.tier) || FISM_MILESTONE_ROADMAP[0];
  const canvas = document.createElement('canvas');
  canvas.width = 900;
  canvas.height = 1125;
  const ctx = canvas.getContext('2d');
  if (!ctx) return { dataUrl: '', blob: null };

  const paletteMap: Record<Exclude<FismMilestoneTier, 'none'>, [string, string, string]> = {
    bronze: ['#2A1205', '#8C4315', '#D9822B'],
    silver: ['#0F172A', '#475569', '#94A3B8'],
    platinum: ['#090D16', '#1E293B', '#38BDF8'],
    gold: ['#2A1802', '#A16207', '#FACC15'],
    red: ['#080204', '#450A0A', '#EF4444'],
  };
  const [c1, c2, c3] = paletteMap[opts.tier];

  const bgGrad = ctx.createLinearGradient(0, 0, 900, 1125);
  bgGrad.addColorStop(0, c1);
  bgGrad.addColorStop(0.55, c2);
  bgGrad.addColorStop(1, c3);
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, 900, 1125);

  ctx.strokeStyle = 'rgba(255,255,255,0.45)';
  ctx.lineWidth = 6;
  ctx.strokeRect(42, 42, 816, 1041);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 34px system-ui, sans-serif';
  ctx.fillText('FISM OFFICIAL ACHIEVEMENT CARD', 84, 130);

  ctx.fillStyle = 'rgba(255,255,255,0.88)';
  ctx.font = 'bold 62px system-ui, sans-serif';
  ctx.fillText(cfg.cardName.toUpperCase(), 84, 240);

  ctx.fillStyle = '#EF4444';
  ctx.beginPath();
  ctx.roundRect(84, 285, 340, 56, 28);
  ctx.fill();
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 28px system-ui, sans-serif';
  ctx.fillText(`✓ ${cfg.badgeTitle.toUpperCase()}`, 110, 323);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 52px system-ui, sans-serif';
  ctx.fillText(opts.displayName.slice(0, 26), 84, 520);

  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.font = '600 34px system-ui, sans-serif';
  ctx.fillText(`@${opts.username}`, 84, 578);

  ctx.fillStyle = 'rgba(0,0,0,0.38)';
  ctx.beginPath();
  ctx.roundRect(84, 650, 732, 220, 28);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 32px system-ui, sans-serif';
  ctx.fillText(
    `Journey Tenure: ${opts.tenureYears.toFixed(1)} Years (${opts.tenureDays} Days)`,
    120,
    720,
  );
  ctx.font = '600 26px system-ui, sans-serif';
  ctx.fillText(`Reward Tier: +${cfg.spReward.toLocaleString()} SP Coins`, 120, 775);
  ctx.fillText('Verified by FISM Red Milestone Crest', 120, 825);

  ctx.fillStyle = 'rgba(255,255,255,0.75)';
  ctx.font = 'bold 26px system-ui, sans-serif';
  ctx.fillText(
    `Look at my ${Math.max(1, Math.floor(opts.tenureYears))}-Year ${cfg.cardName} on FISM!`,
    84,
    1005,
  );

  const dataUrl = canvas.toDataURL('image/png');
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob((b) => resolve(b), 'image/png'),
  );
  return { dataUrl, blob };
}

export interface MilestoneModalTarget {
  accountId: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  joinedAtIso: string;
  milestoneTier?: FismMilestoneTier;
  vipGoldBadgeUnlocked?: boolean;
  equippedFrame?: FismProfileFrameId;
  isOwn: boolean;
}

interface FismMilestoneJourneyModalProps {
  open: boolean;
  target: MilestoneModalTarget | null;
  ownMilestone: FismUserMilestoneState;
  founderGiftClaims: FismFounderGiftClaim[];
  onClose: () => void;
  onDailyCheckInLocate: () => Promise<void> | void;
  onOpenMapsTab?: () => void;
  onClaimTier: (tier: Exclude<FismMilestoneTier, 'none'>) => Promise<void> | void;
  onSelectFrame: (frameId: FismProfileFrameId) => Promise<void> | void;
  onToggleCyberpunkMode: (enabled: boolean) => Promise<void> | void;
  onSubmitFounderGift: (giftItem: string, shippingNote: string) => Promise<void> | void;
  onFlexToFismStory: (opts: {
    tier: Exclude<FismMilestoneTier, 'none'>;
    imageDataUrl: string;
    caption: string;
  }) => Promise<void> | void;
  onTriggerToast: (msg: string) => void;
}

function formatCountdownMs(ms: number): string {
  const totalSec = Math.max(0, Math.ceil(ms / 1000));
  const hrs = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export const FismMilestoneJourneyModal: React.FC<FismMilestoneJourneyModalProps> = ({
  open,
  target,
  ownMilestone,
  founderGiftClaims,
  onClose,
  onDailyCheckInLocate,
  onOpenMapsTab,
  onClaimTier,
  onSelectFrame,
  onToggleCyberpunkMode,
  onSubmitFounderGift,
  onFlexToFismStory,
  onTriggerToast,
}) => {
  const [busyTier, setBusyTier] = useState<string | null>(null);
  const [checkingIn, setCheckingIn] = useState(false);
  const [inspectedYear, setInspectedYear] = useState<1 | 2 | 3 | 4 | 5>(1);
  const [calendarCursor, setCalendarCursor] = useState<Date>(() => new Date());
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const [giftItem, setGiftItem] = useState<string>('Limited FISM Obsidian Red Hoodie');
  const [shippingNote, setShippingNote] = useState<string>('');
  const [submittingGift, setSubmittingGift] = useState(false);
  const [flexingStory, setFlexingStory] = useState(false);
  const [copiedFlex, setCopiedFlex] = useState(false);

  useEffect(() => {
    if (!open) return;
    setNowMs(Date.now());
    const id = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [open]);

  const computed = useMemo(() => {
    if (!target) return null;
    if (target.isOwn) {
      return {
        tenureYears: ownMilestone.tenureYears,
        tenureDays: ownMilestone.tenureDays,
        verifiedCheckInDays: ownMilestone.verifiedCheckInDays ?? ownMilestone.tenureDays ?? 1,
        dailyStreakCount: ownMilestone.dailyStreakCount ?? ownMilestone.tenureDays ?? 1,
        currentTier: ownMilestone.currentTier,
        hasRedTick: ownMilestone.hasRedMilestoneTick,
        joinedAtIso: ownMilestone.joinedAtIso,
        claimedTiers: ownMilestone.claimedTiers,
        equippedFrame: ownMilestone.equippedFrame,
      };
    }
    const stats = computeTenureStats(target.joinedAtIso);
    const effectiveTier =
      target.milestoneTier && target.milestoneTier !== 'none'
        ? target.milestoneTier
        : stats.tier;
    return {
      tenureYears: Math.max(stats.tenureYears, effectiveTier === 'red' ? 5 : 0),
      tenureDays: stats.tenureDays,
      verifiedCheckInDays: stats.tenureDays,
      dailyStreakCount: stats.tenureDays,
      currentTier: effectiveTier,
      hasRedTick: stats.hasRedMilestoneTick || effectiveTier !== 'none',
      joinedAtIso: target.joinedAtIso || new Date().toISOString(),
      claimedTiers: effectiveTier === 'none' ? [] : [effectiveTier],
      equippedFrame: target.equippedFrame || 'none',
    };
  }, [target, ownMilestone]);

  const scheduleSummary = useMemo(() => {
    if (!computed) return null;
    return computeExactMilestoneSchedule(computed.joinedAtIso, computed.verifiedCheckInDays);
  }, [computed]);

  if (!open || !target || !computed || !scheduleSummary) return null;

  const activeVisualTier: Exclude<FismMilestoneTier, 'none'> =
    computed.currentTier === 'none' ? 'bronze' : computed.currentTier;
  const activeTierConfig =
    FISM_MILESTONE_ROADMAP.find((c) => c.tier === activeVisualTier) || FISM_MILESTONE_ROADMAP[0];
  const flexYears = Math.max(1, Math.floor(computed.tenureYears || 1));
  const profileShareUrl = buildFismShareUrl('user', target.username, { tier: activeVisualTier });
  const flexMessage = `Look at my ${flexYears}-Year ${activeTierConfig.cardName} on FISM! 🔥 #FISMMilestone ${profileShareUrl}`;
  const whatsappHref = `https://api.whatsapp.com/send?text=${encodeURIComponent(flexMessage)}`;

  const nextUnlockAtMs =
    target.isOwn && ownMilestone.nextCheckinUnlockAtIso
      ? Date.parse(ownMilestone.nextCheckinUnlockAtIso)
      : 0;
  const remainingCooldownMs =
    nextUnlockAtMs && !Number.isNaN(nextUnlockAtMs) ? Math.max(0, nextUnlockAtMs - nowMs) : 0;
  const canCheckInNow = remainingCooldownMs === 0;
  const inspectedSchedule =
    scheduleSummary.schedule.find((s) => s.yearNumber === inspectedYear) ||
    scheduleSummary.schedule[0];
  const year1TotalDays = scheduleSummary.schedule[0]?.cumulativeDaysRequired || 365;
  const checkInDateSet = new Set((ownMilestone.checkInHistory || []).map((c) => c.dateIso));
  const unlockDateMap = new Map(
    scheduleSummary.schedule.map((s) => [s.unlockDateIso, s]),
  );

  // Calendar grid values for currently selected month
  const calYear = calendarCursor.getUTCFullYear();
  const calMonth = calendarCursor.getUTCMonth();
  const firstDayOfMonth = new Date(Date.UTC(calYear, calMonth, 1));
  const startWeekday = (firstDayOfMonth.getUTCDay() + 6) % 7; // Mon = 0 .. Sun = 6
  const daysInMonth = new Date(Date.UTC(calYear, calMonth + 1, 0)).getUTCDate();
  const calMonthLabel = firstDayOfMonth.toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  });

  const handleInstagramExport = async () => {
    try {
      const { dataUrl, blob } = await generateMilestoneFlexPng({
        tier: activeVisualTier,
        displayName: target.displayName,
        username: target.username,
        tenureYears: computed.tenureYears,
        tenureDays: computed.tenureDays,
      });
      await navigator.clipboard?.writeText(flexMessage).catch(() => {});
      if (blob && navigator.share) {
        const file = new File([blob], `fism_${activeVisualTier}_card.png`, { type: 'image/png' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({
            title: `My ${activeTierConfig.cardName} on FISM`,
            text: flexMessage,
            url: profileShareUrl,
            files: [file],
          });
          onTriggerToast('Shared card PNG + FISM App Link!');
          return;
        }
      }
      if (dataUrl) {
        const a = document.createElement('a');
        a.href = dataUrl;
        a.download = `FISM_${activeVisualTier}_Card_${target.username}.png`;
        a.click();
        setCopiedFlex(true);
        setTimeout(() => setCopiedFlex(false), 2500);
        onTriggerToast('Card PNG downloaded & Instagram Story caption copied!');
      }
    } catch {
      onTriggerToast('Card caption copied to clipboard — ready for Instagram Story!');
    }
  };

  const handleStoryFlex = async () => {
    if (flexingStory) return;
    setFlexingStory(true);
    try {
      const { dataUrl } = await generateMilestoneFlexPng({
        tier: activeVisualTier,
        displayName: target.displayName,
        username: target.username,
        tenureYears: computed.tenureYears,
        tenureDays: computed.tenureDays,
      });
      await onFlexToFismStory({
        tier: activeVisualTier,
        imageDataUrl: dataUrl,
        caption: flexMessage,
      });
    } finally {
      setFlexingStory(false);
    }
  };

  const handleSubmitGift = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submittingGift) return;
    setSubmittingGift(true);
    try {
      await onSubmitFounderGift(giftItem, shippingNote.trim());
      setShippingNote('');
    } finally {
      setSubmittingGift(false);
    }
  };

  const ownGiftClaims = founderGiftClaims.filter(
    (c) => c.userId === target.accountId || c.username === target.username,
  );

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl max-h-[92vh] overflow-y-auto rounded-3xl bg-white dark:bg-[#0B0E17] text-[#111827] dark:text-[#F8FAFC] border border-[#D8E1F0] dark:border-slate-700 shadow-2xl p-4 sm:p-6 space-y-6"
      >
        {/* Modal Header */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#EF4444] to-[#991B1B] text-white flex items-center justify-center shadow-lg shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg sm:text-xl font-black truncate">
                  {target.displayName}&apos;s FISM Milestone Journey
                </h2>
                {computed.hasRedTick && <FismRedMilestoneTick size="md" />}
              </div>
              <p className="text-xs text-[#52607A] dark:text-slate-400 tabular-nums">
                @{target.username} • Active since {computed.joinedAtIso.slice(0, 10)} •{' '}
                {computed.tenureYears.toFixed(2)} Years ({computed.tenureDays.toLocaleString()} Days)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Milestone Journey Modal"
            className="min-w-[44px] min-h-[44px] rounded-2xl bg-[#F3F6FC] dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Active Card Showcase (or Locked Year 0 Preview) */}
        {computed.currentTier === 'none' ? (
          <div className="rounded-3xl p-5 bg-[#F3F6FC] dark:bg-slate-900 border-2 border-dashed border-[#D8E1F0] dark:border-slate-700 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2 font-black text-sm">
                <Lock className="w-4 h-4 text-[#FF5722]" />
                Year 1 Red Milestone Tick Unlocks at {year1TotalDays} Real-Time Days
              </div>
              <span className="px-3 py-1 rounded-full bg-[#FF5722]/15 text-[#FF5722] text-xs font-black tabular-nums">
                {computed.verifiedCheckInDays} / {year1TotalDays} Days
              </span>
            </div>
            <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#FF5722] to-[#EF4444]"
                style={{
                  width: `${Math.min(100, Math.round((computed.verifiedCheckInDays / year1TotalDays) * 100))}%`,
                }}
              />
            </div>
            <p className="text-xs text-[#52607A] dark:text-slate-400">
              Earn 1 real-time streak day every <strong>24 hours</strong> (cycles reset at{' '}
              <strong>6:00 AM</strong>). Year 1 unlocks on{' '}
              <strong>{scheduleSummary.schedule[0]?.unlockDateIso}</strong> ({year1TotalDays} days)
              and Year 5 Ultimate Red Card unlocks at{' '}
              <strong>{scheduleSummary.totalFiveYearDays.toLocaleString()} days</strong> (365 / 366
              leap-year exact calendar).
            </p>
          </div>
        ) : (
          <FismMilestoneCardVisual
            tier={activeVisualTier}
            displayName={target.displayName}
            username={target.username}
            avatarUrl={target.avatarUrl}
            tenureYears={computed.tenureYears}
            tenureDays={computed.tenureDays}
            joinedAtIso={computed.joinedAtIso}
          />
        )}

        {/* Social Flex Share Strip */}
        {computed.currentTier !== 'none' && (
          <div className="rounded-2xl p-4 bg-[#F3F6FC] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
                <Share2 className="w-4 h-4 text-[#EF4444]" /> Flex Your {activeTierConfig.cardName}
              </div>
              <button
                type="button"
                onClick={() =>
                  void shareFismLink({
                    title: `${target.displayName}'s FISM Milestone Card`,
                    text: flexMessage,
                    url: profileShareUrl,
                    triggerToast: onTriggerToast,
                  })
                }
                className="text-[11px] font-bold text-[#2563EB] hover:underline truncate max-w-full"
              >
                {profileShareUrl}
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={handleInstagramExport}
                className="min-h-[44px] px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-[#E1306C] via-[#F77737] to-[#FCAF45] text-white text-xs font-black flex items-center justify-center gap-2 shadow whitespace-nowrap shrink-0"
              >
                {copiedFlex ? <Check className="w-4 h-4" /> : <Camera className="w-4 h-4" />}
                {copiedFlex ? 'PNG Saved & Copied!' : 'Instagram Story PNG'}
              </button>
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="min-h-[44px] px-3.5 py-2.5 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white text-xs font-black flex items-center justify-center gap-2 shadow whitespace-nowrap shrink-0"
              >
                <MessageCircle className="w-4 h-4" /> Share on WhatsApp
              </a>
              <button
                type="button"
                disabled={flexingStory}
                onClick={handleStoryFlex}
                className="min-h-[44px] px-3.5 py-2.5 rounded-xl bg-[#0F172A] dark:bg-slate-800 hover:opacity-90 text-white text-xs font-black flex items-center justify-center gap-2 border border-white/15 shadow whitespace-nowrap shrink-0"
              >
                <Sparkles className="w-4 h-4 text-[#FACC15]" />
                {flexingStory ? 'Posting...' : 'Flex to FISM Stories'}
              </button>
            </div>
          </div>
        )}

        {/* REAL-TIME 24-HOUR CHECK-IN + 6:00 AM DAILY LOCATE & EXACT LEAP-YEAR SCHEDULE INSPECTOR */}
        <div className="rounded-2xl p-4 sm:p-5 bg-gradient-to-br from-[#0F172A] via-[#172554] to-[#1E1B4B] text-white border border-white/15 space-y-4">
          {target.isOwn && (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3.5 border-b border-white/15">
              <div className="space-y-1">
                <div className="text-xs font-black flex items-center gap-1.5 text-[#38BDF8]">
                  <Clock className="w-4 h-4 text-[#FACC15]" />
                  Real-Time 24-Hour Check-In &amp; 6:00 AM Daily Cycle
                </div>
                <div className="text-xs text-slate-200 tabular-nums">
                  Verified Active Days: <strong className="text-white">{computed.verifiedCheckInDays}</strong>{' '}
                  • Streak: <strong className="text-[#4ADE80]">{computed.dailyStreakCount} Days</strong>
                </div>
                {ownMilestone.lastCheckinLocationLabel && (
                  <div className="text-[11px] text-slate-300 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#4ADE80] shrink-0" />
                    Last Locate: {ownMilestone.lastCheckinLocationLabel}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  disabled={!canCheckInNow || checkingIn}
                  onClick={async () => {
                    if (!canCheckInNow || checkingIn) return;
                    setCheckingIn(true);
                    try {
                      await onDailyCheckInLocate();
                    } finally {
                      setCheckingIn(false);
                    }
                  }}
                  className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 shadow transition-all ${
                    canCheckInNow
                      ? 'bg-gradient-to-r from-[#16A34A] to-[#22C55E] text-white hover:brightness-110 cursor-pointer'
                      : 'bg-white/10 text-amber-300 border border-amber-400/40 cursor-not-allowed tabular-nums'
                  }`}
                >
                  <MapPin className="w-4 h-4" />
                  {checkingIn
                    ? 'Locating & Claiming...'
                    : canCheckInNow
                      ? 'Claim Daily Check-In & Locate'
                      : `Next Check-In in ${formatCountdownMs(remainingCooldownMs)}`}
                </button>
                {onOpenMapsTab && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenMapsTab();
                    }}
                    className="min-h-[44px] px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold"
                  >
                    View Locate Pins on Map
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Read-Only Year 1-5 Exact Card Schedule Inspector (Zero Cheat Simulation) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="text-xs font-black flex items-center gap-1.5">
                <CalendarIcon className="w-4 h-4 text-[#FACC15]" />
                Year 1–5 Card Schedule Inspector (Kaun Sa Card Kab Milega • 365 / 366 Leap Year)
              </div>
              <span className="text-[11px] font-bold text-slate-300 tabular-nums">
                5-Year Total: {scheduleSummary.totalFiveYearDays.toLocaleString()} Days
              </span>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {scheduleSummary.schedule.map((item) => {
                const isInspected = inspectedYear === item.yearNumber;
                return (
                  <button
                    key={item.yearNumber}
                    type="button"
                    onClick={() => setInspectedYear(item.yearNumber)}
                    className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-black transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
                      isInspected
                        ? 'bg-[#EF4444] text-white ring-2 ring-white shadow-lg'
                        : item.unlocked
                          ? 'bg-[#16A34A]/25 text-[#4ADE80] border border-[#16A34A]/50'
                          : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                  >
                    {item.unlocked ? <Check className="w-3.5 h-3.5" /> : <Lock className="w-3 h-3" />}
                    {item.yearLabel} ({item.cumulativeDaysRequired}d)
                  </button>
                );
              })}
            </div>

            <div className="p-3.5 rounded-xl bg-black/35 border border-white/15 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <div className="text-[10px] uppercase text-slate-400 font-bold">Target Card</div>
                <div className="font-black text-white mt-0.5">{inspectedSchedule.cardName}</div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-slate-400 font-bold">
                  Required Days (Exact)
                </div>
                <div className="font-black text-[#38BDF8] tabular-nums mt-0.5">
                  {inspectedSchedule.cumulativeDaysRequired.toLocaleString()} Days
                  <span className="block text-[10px] font-normal text-slate-300">
                    +{inspectedSchedule.daysInThatYear}d in Year {inspectedSchedule.yearNumber}
                    {inspectedSchedule.isLeapYearIncluded && inspectedSchedule.leapYearDateIso
                      ? ` (Leap ${inspectedSchedule.leapYearDateIso})`
                      : ''}
                  </span>
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-slate-400 font-bold">
                  Unlock Calendar Date
                </div>
                <div className="font-black text-[#FACC15] tabular-nums mt-0.5">
                  {inspectedSchedule.unlockDateIso}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-slate-400 font-bold">Real-Time Status</div>
                <div className="font-black mt-0.5 tabular-nums">
                  {inspectedSchedule.unlocked ? (
                    <span className="text-[#4ADE80]">Unlocked ✓</span>
                  ) : (
                    <span className="text-amber-300">
                      {inspectedSchedule.daysRemaining.toLocaleString()} Days Left
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Monthly & 5-Year Leap-Year Calendar */}
          <div className="pt-3 border-t border-white/15 space-y-2.5">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setCalendarCursor(new Date(Date.UTC(calYear, calMonth - 1, 1)))
                  }
                  aria-label="Previous calendar month"
                  className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-xs font-black min-w-[130px] text-center">
                  {calMonthLabel}
                </span>
                <button
                  type="button"
                  onClick={() =>
                    setCalendarCursor(new Date(Date.UTC(calYear, calMonth + 1, 1)))
                  }
                  aria-label="Next calendar month"
                  className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap text-[10px]">
                <button
                  type="button"
                  onClick={() => setCalendarCursor(new Date())}
                  className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 font-bold"
                >
                  Today
                </button>
                <button
                  type="button"
                  onClick={() => setCalendarCursor(new Date(Date.UTC(2028, 1, 1)))}
                  className="px-2 py-1 rounded bg-[#7C3AED]/50 hover:bg-[#7C3AED] font-bold"
                >
                  Leap 2028-02-29
                </button>
                {scheduleSummary.schedule.map((s) => (
                  <button
                    key={`jump-${s.yearNumber}`}
                    type="button"
                    onClick={() => {
                      const d = new Date(`${s.unlockDateIso}T00:00:00Z`);
                      if (!Number.isNaN(d.getTime())) setCalendarCursor(d);
                    }}
                    className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 font-bold"
                  >
                    Y{s.yearNumber} ({s.unlockDateIso.slice(0, 7)})
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-slate-400">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((wd) => (
                <div key={wd}>{wd}</div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {Array.from({ length: startWeekday }).map((_, idx) => (
                <div key={`pad-${idx}`} className="h-8" />
              ))}
              {Array.from({ length: daysInMonth }).map((_, idx) => {
                const dayNum = idx + 1;
                const iso = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
                const isCheckedIn = checkInDateSet.has(iso);
                const isLeapDay = calMonth === 1 && dayNum === 29 && isLeapYear(calYear);
                const unlockMatch = unlockDateMap.get(iso);
                return (
                  <div
                    key={iso}
                    title={
                      unlockMatch
                        ? `${unlockMatch.yearLabel} ${unlockMatch.cardName} Unlock Date (${unlockMatch.cumulativeDaysRequired} days)`
                        : isLeapDay
                          ? 'Leap Year Day (366-Day Year)'
                          : isCheckedIn
                            ? 'Verified Daily Check-In & Locate'
                            : iso
                    }
                    className={`h-8 rounded-lg flex flex-col items-center justify-center text-[11px] font-bold tabular-nums border ${
                      unlockMatch
                        ? 'bg-[#EF4444] border-white text-white shadow'
                        : isLeapDay
                          ? 'bg-[#7C3AED] border-purple-300 text-white'
                          : isCheckedIn
                            ? 'bg-[#16A34A] border-emerald-300 text-white'
                            : 'bg-white/5 border-white/10 text-slate-200'
                    }`}
                  >
                    <span>{dayNum}</span>
                    {unlockMatch && (
                      <span className="text-[8px] leading-none font-black">
                        Y{unlockMatch.yearNumber}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-between flex-wrap gap-2 text-[10px] text-slate-300">
              <div className="flex items-center gap-3 flex-wrap">
                <span className="inline-flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded bg-[#16A34A] inline-block" /> Checked-In
                </span>
                <span className="inline-flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded bg-[#7C3AED] inline-block" /> Leap Day (366d)
                </span>
                <span className="inline-flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded bg-[#EF4444] inline-block" /> Year 1–5 Unlock
                </span>
              </div>
              <span className="font-bold text-[#38BDF8]">
                {computed.verifiedCheckInDays >=
                (scheduleSummary.schedule[2]?.cumulativeDaysRequired || 1096)
                  ? '✓ Year 3 Full Calendar Access Active'
                  : `Year 3 Full Calendar Access unlocks at ${(scheduleSummary.schedule[2]?.cumulativeDaysRequired || 1096).toLocaleString()} days`}
              </span>
            </div>
          </div>
        </div>

        {/* Secret Red Cyberpunk Easter Egg + Founder Gift Form (Own Profile, Year 5+ Red Card) */}
        {target.isOwn && ownMilestone.currentTier === 'red' && (
          <div className="rounded-3xl p-5 bg-gradient-to-br from-[#160508] via-[#2B0910] to-[#080204] text-white border-2 border-[#EF4444] space-y-4 shadow-[0_0_30px_rgba(239,68,68,0.35)]">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div>
                <div className="text-[10px] font-black uppercase tracking-widest text-[#FCA5A5]">
                  YEAR 5+ ULTIMATE RED CARD PERKS
                </div>
                <h3 className="text-base font-black flex items-center gap-2 mt-0.5">
                  <Sparkles className="w-4 h-4 text-[#FF2E4C]" /> Secret Easter Egg: Red Cyberpunk
                  Theme Mode
                </h3>
                <p className="text-xs text-red-100/80 mt-0.5">
                  Transform the entire FISM platform into the exclusive obsidian-crimson VIP theme.
                </p>
              </div>
              <button
                type="button"
                onClick={() => void onToggleCyberpunkMode(!ownMilestone.redCyberpunkMode)}
                className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-black transition-all whitespace-nowrap shrink-0 ${
                  ownMilestone.redCyberpunkMode
                    ? 'bg-[#EF4444] text-white ring-2 ring-white shadow-lg'
                    : 'bg-white/15 hover:bg-white/25 text-white border border-red-400/50'
                }`}
              >
                {ownMilestone.redCyberpunkMode
                  ? '✓ Red Cyberpunk Mode ON'
                  : 'Activate Red Cyberpunk Mode'}
              </button>
            </div>

            <form
              onSubmit={handleSubmitGift}
              className="pt-4 border-t border-red-500/30 space-y-3"
            >
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h4 className="text-sm font-black flex items-center gap-1.5 text-[#FCA5A5]">
                  <Gift className="w-4 h-4 text-[#FF2E4C]" /> Claim Founder &amp; Admin Surprise
                  Gift / Exclusive Merch
                </h4>
                {ownGiftClaims.length > 0 && (
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[11px] font-black">
                    {ownGiftClaims[0].status.toUpperCase()} • {ownGiftClaims[0].giftItem}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <select
                  value={giftItem}
                  onChange={(e) => setGiftItem(e.target.value)}
                  className="min-h-[44px] px-3 py-2 rounded-xl bg-black/60 border border-red-500/40 text-xs font-bold text-white"
                >
                  <option value="Limited FISM Obsidian Red Hoodie">
                    Limited FISM Obsidian Red Hoodie
                  </option>
                  <option value="Engraved Red Metal Legend Plaque">
                    Engraved Red Metal Legend Plaque
                  </option>
                  <option value="FISM Pro Creator Studio Kit Box">
                    FISM Pro Creator Studio Kit Box
                  </option>
                  <option value="Mystery Founder Direct Surprise Pack">
                    Mystery Founder Direct Surprise Pack
                  </option>
                </select>
                <input
                  type="text"
                  value={shippingNote}
                  onChange={(e) => setShippingNote(e.target.value)}
                  placeholder="Size / City / Handle note for Founder..."
                  className="min-h-[44px] px-3 py-2 rounded-xl bg-black/60 border border-red-500/40 text-xs text-white placeholder:text-red-200/50"
                />
              </div>
              <button
                type="submit"
                disabled={submittingGift}
                className="min-h-[44px] w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#DC2626] to-[#991B1B] hover:opacity-95 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg"
              >
                <Package className="w-4 h-4" />
                {submittingGift
                  ? 'Sending Claim...'
                  : 'Request Founder Surprise Gift & Merch'}
              </button>
            </form>
          </div>
        )}

        {/* Year-by-Year Milestone Cards & Perks Roadmap */}
        <div className="space-y-3">
          <h3 className="text-sm font-black uppercase tracking-wider flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#FF5722]" /> Year 1–5+ Collectible Roadmap &amp;
            Rewards
          </h3>

          <div className="space-y-3">
            {FISM_MILESTONE_ROADMAP.map((item: FismMilestoneTierConfig) => {
              const schedItem = scheduleSummary.schedule.find((s) => s.tier === item.tier);
              const requiredDays = schedItem?.cumulativeDaysRequired ?? item.minYears * 365;
              const unlocked = computed.verifiedCheckInDays >= requiredDays;
              const claimed = computed.claimedTiers.includes(item.tier);
              const frameEquipped = computed.equippedFrame === item.frameId;
              const palette = getCardVisualPalette(item.tier);

              return (
                <div
                  key={item.tier}
                  className={`rounded-2xl p-4 border transition-all ${
                    unlocked
                      ? 'bg-[#F8FAFC] dark:bg-slate-900 border-[#D8E1F0] dark:border-slate-700'
                      : 'bg-[#F3F6FC]/60 dark:bg-slate-900/50 border-[#D8E1F0]/70 dark:border-slate-800 opacity-85'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[11px] font-black border ${palette.wrapper}`}
                        >
                          {item.yearLabel}
                        </span>
                        <span className="font-black text-sm sm:text-base">{item.cardName}</span>
                        <span className="text-xs font-extrabold text-[#FF5722] tabular-nums">
                          +{item.spReward.toLocaleString()} SP Coins
                        </span>
                        {schedItem && (
                          <span className="px-2 py-0.5 rounded-full bg-slate-200/80 dark:bg-slate-800 text-[10px] font-extrabold tabular-nums">
                            {schedItem.cumulativeDaysRequired.toLocaleString()} Days • Unlocks{' '}
                            {schedItem.unlockDateIso}
                          </span>
                        )}
                        {claimed && (
                          <span className="px-2 py-0.5 rounded-full bg-[#16A34A]/15 text-[#16A34A] text-[10px] font-black flex items-center gap-1">
                            <Check className="w-3 h-3" /> Claimed
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] font-semibold text-[#52607A] dark:text-slate-400">
                        {item.aestheticSummary}
                      </p>
                      <ul className="mt-2 space-y-1 text-xs text-[#172033] dark:text-slate-200">
                        {item.perks.map((perk) => (
                          <li key={perk} className="flex items-center gap-1.5">
                            <ShieldCheck className="w-3.5 h-3.5 text-[#EF4444] shrink-0" />
                            <span>{perk}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {target.isOwn && (
                      <div className="flex items-center gap-2 flex-wrap shrink-0">
                        {!claimed ? (
                          <button
                            type="button"
                            disabled={!unlocked || busyTier === item.tier}
                            onClick={async () => {
                              setBusyTier(item.tier);
                              try {
                                await onClaimTier(item.tier);
                              } finally {
                                setBusyTier(null);
                              }
                            }}
                            className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-black whitespace-nowrap shrink-0 ${
                              unlocked
                                ? 'bg-gradient-to-r from-[#FF5722] to-[#EF4444] text-white shadow hover:opacity-95'
                                : 'bg-slate-200 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                            }`}
                          >
                            {busyTier === item.tier
                              ? 'Claiming...'
                              : unlocked
                                ? `Claim +${item.spReward} SP`
                                : `Locked (${requiredDays.toLocaleString()}d)`}
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              void onSelectFrame(frameEquipped ? 'none' : item.frameId)
                            }
                            className={`min-h-[44px] px-3.5 py-2 rounded-xl text-xs font-black border whitespace-nowrap shrink-0 ${
                              frameEquipped
                                ? 'bg-[#16A34A] text-white border-[#16A34A]'
                                : 'bg-white dark:bg-slate-800 text-[#111827] dark:text-white border-[#D8E1F0] dark:border-slate-700'
                            }`}
                          >
                            {frameEquipped ? '✓ Frame Equipped' : 'Equip Frame'}
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
