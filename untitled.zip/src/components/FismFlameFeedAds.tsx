import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ExternalLink, RefreshCw, Settings, ShieldCheck } from 'lucide-react';
import {
  FismAdsterraConfig,
  FismBannerOriginalSize,
  FismSmartAdItem,
} from '../types';

export function parseBannerDimensions(size?: FismBannerOriginalSize): {
  width: number;
  height: number;
} {
  switch (size) {
    case '468x60':
      return { width: 468, height: 60 };
    case '728x90':
      return { width: 728, height: 90 };
    case '300x250':
      return { width: 300, height: 250 };
    case '320x50':
    default:
      return { width: 320, height: 50 };
  }
}

export function extractAdsterraBannerFromSnippet(rawHtml: string): {
  key?: string;
  host?: string;
  scriptUrl?: string;
  size?: FismBannerOriginalSize;
} {
  const srcMatch = rawHtml.match(/<script[^>]*src\s*=\s*["']([^"']+)["']/i);
  const scriptUrl = srcMatch?.[1]?.trim();

  const keyMatch =
    rawHtml.match(/['"]?key['"]?\s*[:=]\s*['"]([a-zA-Z0-9_-]{8,64})['"]/i) ||
    rawHtml.match(/https?:\/\/[^/"']+\/(?:[a-zA-Z0-9_-]+\/)?([a-zA-Z0-9_-]{16,64})(?:\/invoke\.js)?/i);

  const hostMatch = (scriptUrl || rawHtml).match(/https?:\/\/([^/"'\s]+)/i);
  const wMatch = rawHtml.match(/['"]?width['"]?\s*:\s*(\d{2,4})/i);
  const hMatch = rawHtml.match(/['"]?height['"]?\s*:\s*(\d{2,4})/i);

  let size: FismBannerOriginalSize | undefined;
  if (wMatch && hMatch) {
    const candidate = `${wMatch[1]}x${hMatch[1]}`;
    if (
      candidate === '320x50' ||
      candidate === '468x60' ||
      candidate === '728x90' ||
      candidate === '300x250'
    ) {
      size = candidate;
    }
  }
  return {
    key: keyMatch?.[1],
    host: hostMatch?.[1],
    scriptUrl,
    size,
  };
}

export function extractAdsterraNativeFromSnippet(rawHtml: string): {
  scriptUrl?: string;
  containerId?: string;
} {
  const srcMatch = rawHtml.match(/<script[^>]*src\s*=\s*["']([^"']+)["']/i);
  const divMatch = rawHtml.match(/id\s*=\s*["'](container-[a-zA-Z0-9_-]+)["']/i);
  return {
    scriptUrl: srcMatch?.[1]?.trim(),
    containerId: divMatch?.[1]?.trim(),
  };
}

function buildAdsterraBannerSrcDoc(params: {
  width: number;
  height: number;
  key: string;
  host?: string;
  scriptUrl?: string;
  rawHtml?: string;
}): string {
  const { width, height, key, host, scriptUrl, rawHtml } = params;
  const safeKey = (key || '').replace(/'/g, '');
  const resolvedHost = (host || 'bicea.org').replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
  const resolvedScriptUrl =
    scriptUrl?.trim() || `https://${resolvedHost}/${safeKey}/invoke.js`;

  const rawBody = rawHtml?.trim()
    ? rawHtml.trim()
    : `<script type="text/javascript">
  atOptions = {
    'key' : '${safeKey}',
    'format' : 'iframe',
    'height' : ${height},
    'width' : ${width},
    'params' : {}
  };
</script>
<script type="text/javascript" src="${resolvedScriptUrl.replace(/"/g, '&quot;')}"></script>`;

  return `<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <base target="_blank" />
    <style>
      * { box-sizing: border-box; }
      html, body {
        margin: 0;
        padding: 0;
        width: ${width}px;
        height: ${height}px;
        overflow: hidden;
        background: transparent;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      iframe, img, a {
        max-width: ${width}px;
        max-height: ${height}px;
      }
    </style>
  </head>
  <body>${rawBody}</body>
</html>`;
}

function buildAdsterraNativeSrcDoc(cfg: FismAdsterraConfig, frameToken: string): string {
  const rawBody = cfg.nativeRawHtml?.trim()
    ? cfg.nativeRawHtml.trim()
    : `<script async="async" data-cfasync="false" src="${cfg.nativeScriptUrl.replace(/"/g, '&quot;')}"></script>
<div id="${cfg.nativeContainerId.replace(/"/g, '')}"></div>`;

  return `<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <base target="_blank" />
    <style>
      * { box-sizing: border-box; }
      html, body {
        margin: 0;
        padding: 0;
        width: 100%;
        height: auto;
        background: transparent;
        overflow: hidden;
        font-family: system-ui, -apple-system, sans-serif;
      }
      #fism-native-root {
        width: 100%;
        display: block;
      }
      #fism-native-root img {
        max-width: 100%;
        height: auto;
      }
    </style>
  </head>
  <body>
    <div id="fism-native-root">${rawBody}</div>
    <script>
      (function() {
        var token = ${JSON.stringify(frameToken)};
        var root = document.getElementById('fism-native-root');
        function reportHeight() {
          if (!root) return;
          var rectH = Math.ceil(root.getBoundingClientRect().height || 0);
          var scrollH = Math.ceil(root.scrollHeight || 0);
          var bodyH = Math.ceil(document.body.scrollHeight || 0);
          var h = Math.max(rectH, scrollH, bodyH, 100);
          try {
            window.parent.postMessage({ type: 'fism-native-ad-height', token: token, height: h }, '*');
          } catch (e) {}
        }
        if (typeof ResizeObserver !== 'undefined' && root) {
          var ro = new ResizeObserver(reportHeight);
          ro.observe(root);
        }
        if (typeof MutationObserver !== 'undefined' && root) {
          var mo = new MutationObserver(function() {
            var imgs = root.querySelectorAll('img');
            for (var i = 0; i < imgs.length; i++) {
              imgs[i].addEventListener('load', reportHeight, { once: true });
            }
            reportHeight();
          });
          mo.observe(root, { childList: true, subtree: true, attributes: true });
        }
        window.addEventListener('load', reportHeight);
        window.addEventListener('resize', reportHeight);
        setTimeout(reportHeight, 150);
        setTimeout(reportHeight, 600);
        setTimeout(reportHeight, 1400);
        setTimeout(reportHeight, 3000);
      })();
    </script>
  </body>
</html>`;
}

interface FismBannerAdProps {
  adsterraConfig?: FismAdsterraConfig | null;
  officialBannerAds?: FismSmartAdItem[];
  isAdmin?: boolean;
  onOpenAdConfig?: () => void;
  onTrackAdClick?: (adId: string) => void;
}

/**
 * Exact-Size AdsTerra Mobile / IAB Banner Ad (Default 320x50 Mobile Banner).
 * Centered unclipped iframe matching exact width x height without stretching or distortion.
 */
export const FismBanner320x50Ad: React.FC<FismBannerAdProps> = ({
  adsterraConfig,
  officialBannerAds = [],
  isAdmin = false,
  onOpenAdConfig,
  onTrackAdClick,
}) => {
  const [refreshCycle, setRefreshCycle] = useState<number>(0);
  const [secondsLeft, setSecondsLeft] = useState<number>(30);

  const hasLiveAdsterraBanner = Boolean(
    adsterraConfig &&
      adsterraConfig.enabled !== false &&
      adsterraConfig.bannerEnabled !== false &&
      (adsterraConfig.bannerKey?.trim() ||
        adsterraConfig.bannerScriptUrl?.trim() ||
        adsterraConfig.bannerRawHtml?.trim()),
  );

  const dims = parseBannerDimensions(adsterraConfig?.bannerSize || '320x50');

  useEffect(() => {
    if (!hasLiveAdsterraBanner) return;
    const timer = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          setRefreshCycle((c) => c + 1);
          return 30;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [hasLiveAdsterraBanner]);

  const bannerSrcDoc = useMemo(() => {
    if (!hasLiveAdsterraBanner || !adsterraConfig) return '';
    return buildAdsterraBannerSrcDoc({
      width: dims.width,
      height: dims.height,
      key: adsterraConfig.bannerKey,
      host: adsterraConfig.bannerHost,
      scriptUrl: adsterraConfig.bannerScriptUrl,
      rawHtml: adsterraConfig.bannerRawHtml,
    });
  }, [hasLiveAdsterraBanner, adsterraConfig, dims.width, dims.height, refreshCycle]);

  const activeOfficialBanner = officialBannerAds.find(
    (ad) => ad.isActive && ad.placement === 'banner' && ad.productLinkUrl,
  );

  return (
    <div
      className="fism-card mb-5 px-2 py-2.5 flex flex-col items-center justify-center border border-[#D8E1F0] dark:border-slate-700 bg-white dark:bg-[#101426]"
      aria-label={`AdsTerra Original ${dims.width}x${dims.height} Banner Ad`}
    >
      <div className="w-full flex items-center justify-between mb-1.5 px-1 text-[10px]">
        <span className="font-extrabold uppercase tracking-wider text-[#52607A] dark:text-slate-400 flex items-center gap-1">
          <ShieldCheck className="w-3 h-3 text-[#16A34A]" />
          {hasLiveAdsterraBanner
            ? `Sponsored Banner • ${dims.width}×${dims.height}`
            : `Sponsored Banner Slot • ${dims.width}×${dims.height}`}
        </span>
        <div className="flex items-center gap-2">
          {hasLiveAdsterraBanner && (
            <span className="text-amber-500 font-extrabold flex items-center gap-1">
              <RefreshCw className="w-2.5 h-2.5" /> {secondsLeft}s
            </span>
          )}
          {isAdmin && onOpenAdConfig && (
            <button
              type="button"
              onClick={onOpenAdConfig}
              className="px-2 py-0.5 rounded bg-[#FF5722]/15 text-[#FF5722] font-extrabold hover:bg-[#FF5722] hover:text-white transition-colors inline-flex items-center gap-1"
            >
              <Settings className="w-2.5 h-2.5" /> Ad Settings
            </button>
          )}
        </div>
      </div>

      {hasLiveAdsterraBanner ? (
        <div className="w-full overflow-x-auto flex justify-center">
          <div
            style={{
              width: `${dims.width}px`,
              height: `${dims.height}px`,
              minWidth: `${dims.width}px`,
              minHeight: `${dims.height}px`,
            }}
            className="rounded-lg overflow-hidden bg-[#F8FAFC] dark:bg-slate-900/70 flex items-center justify-center"
          >
            <iframe
              key={`adsterra-banner-${refreshCycle}-${adsterraConfig?.bannerKey}-${adsterraConfig?.bannerSize}`}
              title={`AdsTerra ${dims.width}x${dims.height} Banner`}
              srcDoc={bannerSrcDoc}
              width={dims.width}
              height={dims.height}
              scrolling="no"
              sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation allow-forms"
              style={{
                width: `${dims.width}px`,
                height: `${dims.height}px`,
                border: 0,
                display: 'block',
              }}
            />
          </div>
        </div>
      ) : activeOfficialBanner ? (
        <a
          href={activeOfficialBanner.productLinkUrl}
          target="_blank"
          rel="noreferrer"
          onClick={() => onTrackAdClick?.(activeOfficialBanner.id)}
          style={{ width: `${dims.width}px`, height: `${dims.height}px` }}
          className="max-w-full rounded-lg bg-gradient-to-r from-[#0F172A] to-[#1E293B] border border-[#FF5722]/40 px-3 flex items-center justify-between gap-2 text-white"
        >
          <div className="min-w-0">
            <div className="text-[11px] font-extrabold truncate">{activeOfficialBanner.title}</div>
            <div className="text-[9px] text-slate-300 truncate">
              {activeOfficialBanner.storePlatform} • {activeOfficialBanner.description}
            </div>
          </div>
          <span className="px-2 py-1 rounded bg-[#FF5722] text-white text-[9px] font-black shrink-0 inline-flex items-center gap-1">
            {activeOfficialBanner.ctaLabel} <ExternalLink className="w-2.5 h-2.5" />
          </span>
        </a>
      ) : (
        <div
          style={{ width: `${dims.width}px`, height: `${dims.height}px` }}
          className="max-w-full rounded-lg border border-dashed border-[#CBD5E1] dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-900/80 px-2.5 flex items-center justify-between gap-2 text-[10px] text-[#52607A] dark:text-slate-400"
        >
          <span className="truncate font-semibold">
            AdsTerra {dims.width}×{dims.height} Zone Ready — Paste Banner Key in Admin
          </span>
          {isAdmin && onOpenAdConfig && (
            <button
              type="button"
              onClick={onOpenAdConfig}
              className="px-2 py-1 rounded bg-[#FF5722] text-white text-[9px] font-black shrink-0"
            >
              Add Tag
            </button>
          )}
        </div>
      )}
    </div>
  );
};

/**
 * Exact-Size 300x250 Medium Rectangle Banner Ad.
 * Renders at strict 300x250 px without clipping or distortion.
 */
export const FismBanner300x250Ad: React.FC<FismBannerAdProps> = ({
  adsterraConfig,
  officialBannerAds = [],
  isAdmin = false,
  onOpenAdConfig,
  onTrackAdClick,
}) => {
  const [refreshCycle, setRefreshCycle] = useState<number>(0);

  const hasLiveRectBanner = Boolean(
    adsterraConfig &&
      adsterraConfig.enabled !== false &&
      adsterraConfig.rectBannerEnabled !== false &&
      (adsterraConfig.rectBannerKey?.trim() ||
        adsterraConfig.rectBannerScriptUrl?.trim() ||
        adsterraConfig.rectBannerRawHtml?.trim()),
  );

  useEffect(() => {
    if (!hasLiveRectBanner) return;
    const timer = window.setInterval(() => {
      setRefreshCycle((c) => c + 1);
    }, 45000);
    return () => window.clearInterval(timer);
  }, [hasLiveRectBanner]);

  const rectSrcDoc = useMemo(() => {
    if (!hasLiveRectBanner || !adsterraConfig) return '';
    return buildAdsterraBannerSrcDoc({
      width: 300,
      height: 250,
      key: adsterraConfig.rectBannerKey || '',
      host: adsterraConfig.bannerHost || 'bicea.org',
      scriptUrl: adsterraConfig.rectBannerScriptUrl,
      rawHtml: adsterraConfig.rectBannerRawHtml,
    });
  }, [hasLiveRectBanner, adsterraConfig, refreshCycle]);

  const activeOfficialBanner = officialBannerAds.find(
    (ad) => ad.isActive && ad.placement === 'banner' && ad.productLinkUrl,
  );

  if (!hasLiveRectBanner && !activeOfficialBanner && !isAdmin) {
    return null;
  }

  return (
    <div
      className="fism-card p-2.5 flex flex-col items-center justify-center border border-[#D8E1F0] dark:border-slate-700 bg-white dark:bg-[#101426]"
      aria-label="AdsTerra Original 300x250 Medium Rectangle Banner Ad"
    >
      <div className="w-full flex items-center justify-between mb-1.5 px-1 text-[10px]">
        <span className="font-extrabold uppercase tracking-wider text-[#52607A] dark:text-slate-400 flex items-center gap-1">
          <ShieldCheck className="w-3 h-3 text-[#16A34A]" />
          Sponsored • 300×250
        </span>
        {isAdmin && onOpenAdConfig && (
          <button
            type="button"
            onClick={onOpenAdConfig}
            className="px-2 py-0.5 rounded bg-[#FF5722]/15 text-[#FF5722] font-extrabold hover:bg-[#FF5722] hover:text-white transition-colors inline-flex items-center gap-1"
          >
            <Settings className="w-2.5 h-2.5" /> Ad Settings
          </button>
        )}
      </div>

      {hasLiveRectBanner ? (
        <div className="w-full overflow-x-auto flex justify-center">
          <div
            style={{ width: '300px', height: '250px', minWidth: '300px', minHeight: '250px' }}
            className="rounded-xl overflow-hidden bg-[#F8FAFC] dark:bg-slate-900/70 flex items-center justify-center"
          >
            <iframe
              key={`adsterra-rect-300x250-${refreshCycle}-${adsterraConfig?.rectBannerKey}`}
              title="AdsTerra 300x250 Medium Rectangle Banner"
              srcDoc={rectSrcDoc}
              width={300}
              height={250}
              scrolling="no"
              sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation allow-forms"
              style={{
                width: '300px',
                height: '250px',
                border: 0,
                display: 'block',
              }}
            />
          </div>
        </div>
      ) : activeOfficialBanner ? (
        <a
          href={activeOfficialBanner.productLinkUrl}
          target="_blank"
          rel="noreferrer"
          onClick={() => onTrackAdClick?.(activeOfficialBanner.id)}
          style={{ width: '300px', height: '250px' }}
          className="max-w-full rounded-xl bg-gradient-to-br from-[#0F172A] to-[#1E293B] border border-[#FF5722]/40 p-4 flex flex-col justify-between text-white"
        >
          <div className="text-[10px] font-bold uppercase text-[#FF5722]">
            {activeOfficialBanner.storePlatform}
          </div>
          <div>
            <div className="text-sm font-extrabold line-clamp-2">{activeOfficialBanner.title}</div>
            <p className="text-xs text-slate-300 mt-1 line-clamp-3">
              {activeOfficialBanner.description}
            </p>
          </div>
          <span className="px-3 py-2 rounded-lg bg-[#FF5722] text-white text-xs font-black text-center inline-flex items-center justify-center gap-1">
            {activeOfficialBanner.ctaLabel} <ExternalLink className="w-3 h-3" />
          </span>
        </a>
      ) : (
        <div
          style={{ width: '300px', height: '250px' }}
          className="max-w-full rounded-xl border border-dashed border-[#CBD5E1] dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-900/80 p-3 flex flex-col items-center justify-center text-center gap-2 text-[11px] text-[#52607A] dark:text-slate-400"
        >
          <span>300×250 Medium Rectangle Ready</span>
          {isAdmin && onOpenAdConfig && (
            <button
              type="button"
              onClick={onOpenAdConfig}
              className="px-3 py-1.5 rounded-lg bg-[#FF5722] text-white text-[10px] font-black"
            >
              Add 300×250 Tag
            </button>
          )}
        </div>
      )}
    </div>
  );
};

/**
 * AdsTerra Native Banner Ad — Responsive 100% width with true dynamic content auto-height via ResizeObserver + MutationObserver.
 */
export const FismNativeBannerAd: React.FC<{
  slotIndex?: number;
  adsterraConfig?: FismAdsterraConfig | null;
  officialBannerAds?: FismSmartAdItem[];
  isAdmin?: boolean;
  onOpenAdConfig?: () => void;
  onTrackAdClick?: (adId: string) => void;
}> = ({
  slotIndex = 1,
  adsterraConfig,
  officialBannerAds = [],
  isAdmin = false,
  onOpenAdConfig,
  onTrackAdClick,
}) => {
  const [nativeHeight, setNativeHeight] = useState<number>(180);
  const frameTokenRef = useRef<string>(
    `fism_native_${slotIndex}_${Math.random().toString(36).slice(2, 8)}`,
  );

  const hasLiveNativeAd = Boolean(
    adsterraConfig &&
      adsterraConfig.enabled !== false &&
      adsterraConfig.nativeEnabled !== false &&
      ((adsterraConfig.nativeScriptUrl?.trim() && adsterraConfig.nativeContainerId?.trim()) ||
        adsterraConfig.nativeRawHtml?.trim()),
  );

  useEffect(() => {
    const onMessage = (e: MessageEvent) => {
      const data = e.data;
      if (
        data &&
        typeof data === 'object' &&
        data.type === 'fism-native-ad-height' &&
        data.token === frameTokenRef.current &&
        typeof data.height === 'number'
      ) {
        const clamped = Math.max(100, Math.min(900, Math.ceil(data.height)));
        setNativeHeight(clamped);
      }
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, []);

  const nativeSrcDoc = useMemo(() => {
    if (!hasLiveNativeAd || !adsterraConfig) return '';
    return buildAdsterraNativeSrcDoc(adsterraConfig, frameTokenRef.current);
  }, [hasLiveNativeAd, adsterraConfig]);

  const activeOfficialBanner = officialBannerAds.find(
    (ad) => ad.isActive && ad.placement === 'banner' && ad.productLinkUrl,
  );

  return (
    <article
      className="fism-card mb-5 border border-[#D8E1F0] dark:border-slate-700 bg-white dark:bg-[#101426] p-3"
      aria-label={`AdsTerra Native Banner Slot #${slotIndex}`}
    >
      <div className="pb-2 mb-2 border-b border-[#E2E8F0] dark:border-slate-800 flex items-center justify-between gap-2 text-[10px]">
        <span className="font-extrabold uppercase tracking-wider text-[#52607A] dark:text-slate-400 flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-[#16A34A]" />
          {hasLiveNativeAd
            ? `Sponsored Native • Auto-Responsive (Slot #${slotIndex})`
            : `Native Ad Slot #${slotIndex}`}
        </span>
        {isAdmin && onOpenAdConfig && (
          <button
            type="button"
            onClick={onOpenAdConfig}
            className="px-2 py-0.5 rounded bg-[#FF5722]/15 text-[#FF5722] font-extrabold hover:bg-[#FF5722] hover:text-white transition-colors inline-flex items-center gap-1"
          >
            <Settings className="w-2.5 h-2.5" /> Configure Native
          </button>
        )}
      </div>

      {hasLiveNativeAd ? (
        <div className="w-full">
          <iframe
            key={`adsterra-native-${slotIndex}-${adsterraConfig?.nativeContainerId}-${adsterraConfig?.nativeScriptUrl}`}
            title={`AdsTerra Native Banner Slot #${slotIndex}`}
            srcDoc={nativeSrcDoc}
            scrolling="no"
            sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation allow-forms"
            style={{
              width: '100%',
              height: `${nativeHeight}px`,
              border: 0,
              display: 'block',
            }}
          />
        </div>
      ) : activeOfficialBanner ? (
        <a
          href={activeOfficialBanner.productLinkUrl}
          target="_blank"
          rel="noreferrer"
          onClick={() => onTrackAdClick?.(activeOfficialBanner.id)}
          className="w-full min-h-[120px] rounded-xl bg-gradient-to-r from-[#0F172A] to-[#1E293B] border border-[#FF5722]/40 p-4 flex items-center justify-between gap-3 text-white"
        >
          <div className="min-w-0">
            <div className="text-sm font-extrabold truncate">{activeOfficialBanner.title}</div>
            <div className="text-xs text-slate-300 mt-1 truncate">
              {activeOfficialBanner.storePlatform} • {activeOfficialBanner.description}
            </div>
          </div>
          <span className="px-3.5 py-2 rounded-xl bg-[#FF5722] text-white text-xs font-black uppercase shrink-0 inline-flex items-center gap-1">
            {activeOfficialBanner.ctaLabel} <ExternalLink className="w-3.5 h-3.5" />
          </span>
        </a>
      ) : (
        <div className="w-full min-h-[120px] rounded-xl border border-dashed border-[#CBD5E1] dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-900/70 p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#52607A] dark:text-slate-300">
          <div>
            <div className="font-extrabold text-[#172033] dark:text-white">
              AdsTerra Native Banner Ready (Full Responsive Auto-Height)
            </div>
            <p className="text-[11px] mt-0.5">
              Paste your AdsTerra Native Banner snippet in Admin → Official Ads.
            </p>
          </div>
          {isAdmin && onOpenAdConfig && (
            <button
              type="button"
              onClick={onOpenAdConfig}
              className="px-3.5 py-2 rounded-xl bg-[#FF5722] text-white text-xs font-black shrink-0"
            >
              Setup Native Script
            </button>
          )}
        </div>
      )}
    </article>
  );
};
