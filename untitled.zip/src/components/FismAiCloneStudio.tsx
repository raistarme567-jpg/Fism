import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  CheckCircle2,
  Download,
  Film,
  Image as ImageIcon,
  Mic,
  Pause,
  Play,
  RefreshCw,
  Send,
  Sparkles,
  Square,
  Sun,
  Type as TypeIcon,
  Upload,
  UserCheck,
  Video,
  Volume2,
  Wand2,
} from 'lucide-react';
import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import { auth, db, storage } from '../firebase';
import { FismAiCloneAvatarProfile, FismAiCloneRenderedVideo } from '../types';

export interface AiCloneStudioProps {
  currentUserId: string;
  currentUsername: string;
  currentDisplayName: string;
  avatars: FismAiCloneAvatarProfile[];
  onSaveAvatar: (avatar: FismAiCloneAvatarProfile) => void;
  onPublishToFismFeed: (payload: {
    title: string;
    caption: string;
    videoUrl: string;
    thumbnailUrl: string;
    durationSec: number;
    targetMode: 'mainBlast' | 'quickBurst';
    avatarName: string;
  }) => Promise<void> | void;
  onTriggerToast: (msg: string) => void;
}

const VIRTUAL_BACKGROUNDS = [
  {
    id: 'cyber_arena',
    name: 'Cyber Flame Studio',
    topColor: '#0F172A',
    bottomColor: '#31102F',
    glowColor: '#FF5722',
  },
  {
    id: 'editorial_light',
    name: 'Minimal Daylight Desk',
    topColor: '#E2E8F0',
    bottomColor: '#CBD5E1',
    glowColor: '#2563EB',
  },
  {
    id: 'podcast_loft',
    name: 'Neon Podcast Loft',
    topColor: '#1E1B4B',
    bottomColor: '#090D16',
    glowColor: '#7C3AED',
  },
  {
    id: 'golden_sunset',
    name: 'Golden Hour Terrace',
    topColor: '#7C2D12',
    bottomColor: '#1E293B',
    glowColor: '#F59E0B',
  },
  {
    id: 'emerald_lab',
    name: 'Creator Tech Lab',
    topColor: '#064E3B',
    bottomColor: '#0F172A',
    glowColor: '#10B981',
  },
];

const LIGHTING_PRESETS = [
  { id: 'ring', name: 'Soft Ring Light', tint: 'rgba(255,255,255,0.14)', rim: '#FFFFFF' },
  { id: 'golden', name: 'Warm Golden Key', tint: 'rgba(251,191,36,0.16)', rim: '#FBBF24' },
  { id: 'cyber', name: 'Cyber Rim Neon', tint: 'rgba(124,58,237,0.20)', rim: '#38BDF8' },
  { id: 'contrast', name: 'Studio High-Contrast', tint: 'rgba(255,87,34,0.14)', rim: '#FF5722' },
];

const OVERLAY_TEMPLATES = [
  { id: 'lower_third', name: 'Lower-Third Nameplate' },
  { id: 'breaking', name: 'Breaking Creator News' },
  { id: 'hook_banner', name: 'Top Viral Hook Banner' },
  { id: 'bold_captions', name: 'Centered Bold Captions' },
  { id: 'none', name: 'Clean Full Frame' },
];

const STARTER_AVATAR: FismAiCloneAvatarProfile = {
  id: 'clone_starter_flame',
  ownerId: 'starter',
  name: 'Arian Studio Digital Clone',
  voicePersona: 'Kore',
  language: 'English / Hinglish',
  referenceVideoUrl: '',
  skinTone: '#E8B89A',
  hairColor: '#1E293B',
  outfitColor: '#7C3AED',
  accentColor: '#FF5722',
  pitchHz: 145,
  speakingRate: 1.0,
  facialLandmarksSummary: '68-point facial mesh, natural head-tilt physics & lip-sync viseme rig.',
  createdAt: 'Studio Preset',
};

export const FismAiCloneStudio: React.FC<AiCloneStudioProps> = ({
  currentUserId,
  currentUsername,
  currentDisplayName,
  avatars,
  onSaveAvatar,
  onPublishToFismFeed,
  onTriggerToast,
}) => {
  const [studioStep, setStudioStep] = useState<'train' | 'generate'>(
    avatars.length > 0 ? 'generate' : 'train',
  );

  // Step 1: Avatar Training & Capture State
  const [avatarName, setAvatarName] = useState(`${currentDisplayName} AI Clone`);
  const [avatarLanguage, setAvatarLanguage] = useState('English / Hinglish');
  const [avatarVoice, setAvatarVoice] = useState<'Kore' | 'Zephyr' | 'Puck' | 'Charon' | 'Fenrir'>(
    'Kore',
  );
  const [webcamActive, setWebcamActive] = useState(false);
  const [isRecordingRef, setIsRecordingRef] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [refVideoBlob, setRefVideoBlob] = useState<Blob | null>(null);
  const [refVideoUrl, setRefVideoUrl] = useState<string>('');
  const [refThumbBase64, setRefThumbBase64] = useState<string>('');
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isTraining, setIsTraining] = useState(false);

  const webcamVideoRef = useRef<HTMLVideoElement | null>(null);
  const webcamStreamRef = useRef<MediaStream | null>(null);
  const refRecorderRef = useRef<MediaRecorder | null>(null);
  const refChunksRef = useRef<BlobPart[]>([]);
  const refTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Step 2 & 3: Generator, Customization, Lip-Sync & Export State
  const availableAvatars = avatars.length > 0 ? avatars : [STARTER_AVATAR];
  const [selectedAvatarId, setSelectedAvatarId] = useState<string>(availableAvatars[0].id);
  const activeAvatar =
    availableAvatars.find((a) => a.id === selectedAvatarId) || availableAvatars[0];

  const [scriptTopic, setScriptTopic] = useState('');
  const [scriptText, setScriptText] = useState(
    'Hey FISM family! This is my trained AI Digital Clone speaking in real time with synced lip movement, custom studio lighting, and instant feed publishing.',
  );
  const [isWritingScript, setIsWritingScript] = useState(false);
  const [voiceMode, setVoiceMode] = useState<'ai_tts' | 'mic_voiceover'>('ai_tts');
  const [isRecordingVoiceOver, setIsRecordingVoiceOver] = useState(false);
  const [customVoiceOverUrl, setCustomVoiceOverUrl] = useState<string>('');
  const voiceOverRecorderRef = useRef<MediaRecorder | null>(null);
  const voiceOverChunksRef = useRef<BlobPart[]>([]);

  const [aspectMode, setAspectMode] = useState<'16:9' | '9:16'>('16:9');
  const [selectedBgId, setSelectedBgId] = useState(VIRTUAL_BACKGROUNDS[0].id);
  const [customBgImageUrl, setCustomBgImageUrl] = useState<string>('');
  const customBgImgRef = useRef<HTMLImageElement | null>(null);
  const [selectedLightingId, setSelectedLightingId] = useState(LIGHTING_PRESETS[0].id);
  const [selectedOverlayId, setSelectedOverlayId] = useState(OVERLAY_TEMPLATES[0].id);
  const [overlayHeadline, setOverlayHeadline] = useState('AI CLONE STUDIO LIVE UPDATE');
  const [videoTitle, setVideoTitle] = useState('My AI Clone Broadcast on FISM');

  // Audio + Lip-Sync Animation & Export State
  const [isGeneratingSpeech, setIsGeneratingSpeech] = useState(false);
  const [generatedAudioUrl, setGeneratedAudioUrl] = useState<string>('');
  const [audioDurationSec, setAudioDurationSec] = useState<number>(8);
  const [isPreviewPlaying, setIsPreviewPlaying] = useState(false);
  const [isRenderingExport, setIsRenderingExport] = useState(false);
  const [renderProgressPct, setRenderProgressPct] = useState(0);
  const [exportedVideoUrl, setExportedVideoUrl] = useState<string>('');
  const [renderedHistory, setRenderedHistory] = useState<FismAiCloneRenderedVideo[]>([]);
  const [publishMode, setPublishMode] = useState<'mainBlast' | 'quickBurst'>('mainBlast');
  const [isPublishing, setIsPublishing] = useState(false);

  const stageCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioSourceConnectedRef = useRef<boolean>(false);
  const mouthEnergyRef = useRef<number>(0);

  // Stop webcam on unmount
  const stopWebcam = () => {
    if (refTimerRef.current) {
      clearInterval(refTimerRef.current);
      refTimerRef.current = null;
    }
    if (webcamStreamRef.current) {
      webcamStreamRef.current.getTracks().forEach((t) => t.stop());
      webcamStreamRef.current = null;
    }
    setWebcamActive(false);
    setIsRecordingRef(false);
  };

  useEffect(() => {
    return () => {
      stopWebcam();
      if (audioCtxRef.current && audioCtxRef.current.state !== 'closed') {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, []);

  useEffect(() => {
    if (!customBgImageUrl) {
      customBgImgRef.current = null;
      return;
    }
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      customBgImgRef.current = img;
    };
    img.src = customBgImageUrl;
  }, [customBgImageUrl]);

  const startWebcam = async () => {
    try {
      stopWebcam();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
        audio: true,
      });
      webcamStreamRef.current = stream;
      setWebcamActive(true);
      setTimeout(() => {
        if (webcamVideoRef.current) {
          webcamVideoRef.current.srcObject = stream;
          webcamVideoRef.current.play().catch(() => {});
        }
      }, 60);
    } catch {
      onTriggerToast(
        'Camera/mic permission denied or unavailable. Upload a 10–15s speaking video file instead.',
      );
    }
  };

  const captureThumbnailFromVideoEl = (videoEl: HTMLVideoElement | null) => {
    if (!videoEl || videoEl.videoWidth === 0) return '';
    const temp = document.createElement('canvas');
    temp.width = 240;
    temp.height = 180;
    const ctx = temp.getContext('2d');
    if (!ctx) return '';
    ctx.drawImage(videoEl, 0, 0, 240, 180);
    return temp.toDataURL('image/jpeg', 0.72);
  };

  const startRecordingReference = () => {
    if (!webcamStreamRef.current) {
      onTriggerToast('Start your camera first or upload a speaking video file.');
      return;
    }
    refChunksRef.current = [];
    setRecordSeconds(0);
    const recorder = new MediaRecorder(webcamStreamRef.current);
    refRecorderRef.current = recorder;

    recorder.ondataavailable = (ev) => {
      if (ev.data.size > 0) refChunksRef.current.push(ev.data);
    };
    recorder.onstop = () => {
      const blob = new Blob(refChunksRef.current, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      setRefVideoBlob(blob);
      setRefVideoUrl(url);
      const snap = captureThumbnailFromVideoEl(webcamVideoRef.current);
      if (snap) setRefThumbBase64(snap);
      setIsRecordingRef(false);
      onTriggerToast('Speaking sample recorded! Click "Train AI Clone Avatar" to calibrate.');
    };

    recorder.start(250);
    setIsRecordingRef(true);
    const snap = captureThumbnailFromVideoEl(webcamVideoRef.current);
    if (snap) setRefThumbBase64(snap);

    refTimerRef.current = setInterval(() => {
      setRecordSeconds((prev) => {
        if (prev + 1 >= 15) {
          if (refTimerRef.current) clearInterval(refTimerRef.current);
          if (refRecorderRef.current?.state === 'recording') {
            refRecorderRef.current.stop();
          }
          return 15;
        }
        return prev + 1;
      });
    }, 1000);
  };

  const stopRecordingReference = () => {
    if (refTimerRef.current) {
      clearInterval(refTimerRef.current);
      refTimerRef.current = null;
    }
    if (refRecorderRef.current?.state === 'recording') {
      refRecorderRef.current.stop();
    }
  };

  const handleUploadReferenceFile = (file: File) => {
    const url = URL.createObjectURL(file);
    setRefVideoBlob(file);
    setRefVideoUrl(url);
    onTriggerToast(`Loaded "${file.name}" as Avatar training reference.`);
  };

  const uploadBlobToFirebaseStorage = async (
    blob: Blob,
    folder: string,
    fileName: string,
  ): Promise<string | null> => {
    try {
      const storageRef = ref(storage, `${folder}/${currentUserId}/${Date.now()}_${fileName}`);
      const task = uploadBytesResumable(storageRef, blob);
      const downloadUrl = await new Promise<string>((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error('Storage upload timeout')), 12000);
        task.on(
          'state_changed',
          (snap) => {
            const pct = Math.round((snap.bytesTransferred / Math.max(1, snap.totalBytes)) * 100);
            setUploadProgress(pct);
          },
          (err) => {
            clearTimeout(timeout);
            reject(err);
          },
          async () => {
            clearTimeout(timeout);
            try {
              const url = await getDownloadURL(task.snapshot.ref);
              resolve(url);
            } catch (e) {
              reject(e);
            }
          },
        );
      });
      return downloadUrl;
    } catch {
      return null;
    }
  };

  const handleTrainAvatar = async () => {
    if (!avatarName.trim()) {
      onTriggerToast('Please enter a name for your AI Clone Avatar.');
      return;
    }
    setIsTraining(true);
    setUploadProgress(15);

    let cloudRefUrl = refVideoUrl;
    if (refVideoBlob && auth.currentUser) {
      const uploaded = await uploadBlobToFirebaseStorage(
        refVideoBlob,
        'ai-clone-training',
        'reference.webm',
      );
      if (uploaded) {
        cloudRefUrl = uploaded;
      }
    }
    setUploadProgress(65);

    let calibration = {
      skinTone: '#E8B89A',
      hairColor: '#1E293B',
      outfitColor: '#7C3AED',
      accentColor: '#FF5722',
      facialLandmarksSummary: '68-point facial mesh & synchronized lip-sync rig calibrated.',
    };

    try {
      const res = await fetch('/api/ai-clone/train-avatar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: avatarName.trim(),
          voicePersona: avatarVoice,
          language: avatarLanguage,
          thumbnailBase64: refThumbBase64,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        calibration = {
          skinTone: data.skinTone || calibration.skinTone,
          hairColor: data.hairColor || calibration.hairColor,
          outfitColor: data.outfitColor || calibration.outfitColor,
          accentColor: data.accentColor || calibration.accentColor,
          facialLandmarksSummary: data.facialLandmarksSummary || calibration.facialLandmarksSummary,
        };
      }
    } catch {
      // keep safe calibrated defaults
    }

    const avatarId = `avatar_${Date.now()}`;
    const newAvatar: FismAiCloneAvatarProfile = {
      id: avatarId,
      ownerId: currentUserId,
      name: avatarName.trim(),
      voicePersona: avatarVoice,
      language: avatarLanguage,
      referenceVideoUrl: cloudRefUrl || '',
      skinTone: calibration.skinTone,
      hairColor: calibration.hairColor,
      outfitColor: calibration.outfitColor,
      accentColor: calibration.accentColor,
      pitchHz: avatarVoice === 'Charon' || avatarVoice === 'Fenrir' ? 115 : 168,
      speakingRate: 1.0,
      facialLandmarksSummary: calibration.facialLandmarksSummary,
      createdAt: new Date().toLocaleTimeString(),
    };

    if (auth.currentUser?.emailVerified) {
      try {
        await setDoc(doc(db, 'aiCloneAvatars', avatarId), {
          ownerId: auth.currentUser.uid,
          name: newAvatar.name.slice(0, 80),
          voicePersona: newAvatar.voicePersona.slice(0, 80),
          referenceVideoUrl: newAvatar.referenceVideoUrl.startsWith('blob:')
            ? ''
            : newAvatar.referenceVideoUrl.slice(0, 2048),
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Firestore aiCloneAvatars sync skipped:', err);
      }
    }

    setUploadProgress(100);
    setIsTraining(false);
    stopWebcam();
    onSaveAvatar(newAvatar);
    setSelectedAvatarId(newAvatar.id);
    setStudioStep('generate');
    onTriggerToast(`AI Clone Avatar "${newAvatar.name}" trained & ready for lip-sync video!`);
  };

  const handleEnhanceScript = async () => {
    setIsWritingScript(true);
    try {
      const res = await fetch('/api/ai-clone/enhance-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: scriptTopic.trim() || videoTitle,
          language: activeAvatar.language || avatarLanguage,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.script) {
          setScriptText(data.script);
          onTriggerToast('AI generated a crisp speaking script for your Clone!');
        }
      }
    } catch {
      onTriggerToast('Could not reach script generator — edit your script manually.');
    } finally {
      setIsWritingScript(false);
    }
  };

  const toggleVoiceOverRecording = async () => {
    if (isRecordingVoiceOver) {
      voiceOverRecorderRef.current?.stop();
      setIsRecordingVoiceOver(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      voiceOverChunksRef.current = [];
      const rec = new MediaRecorder(stream);
      voiceOverRecorderRef.current = rec;
      rec.ondataavailable = (ev) => {
        if (ev.data.size > 0) voiceOverChunksRef.current.push(ev.data);
      };
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(voiceOverChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setCustomVoiceOverUrl(url);
        setGeneratedAudioUrl(url);
        setAudioDurationSec(6);
        onTriggerToast('Custom voice-over recorded! Ready to animate lip-sync & render.');
      };
      rec.start(200);
      setIsRecordingVoiceOver(true);
    } catch {
      onTriggerToast('Microphone permission required to record custom voice-over.');
    }
  };

  const ensureAudioAnalyserConnected = () => {
    const audioEl = audioElRef.current;
    if (!audioEl) return;
    if (!audioCtxRef.current) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtxRef.current = new AudioCtx();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume().catch(() => {});
    }
    if (!audioSourceConnectedRef.current && audioCtxRef.current) {
      const src = audioCtxRef.current.createMediaElementSource(audioEl);
      const analyser = audioCtxRef.current.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      analyser.connect(audioCtxRef.current.destination);
      analyserRef.current = analyser;
      audioSourceConnectedRef.current = true;
    }
  };

  const handleGenerateSpeechAndPreview = async () => {
    if (voiceMode === 'mic_voiceover') {
      if (!customVoiceOverUrl) {
        onTriggerToast('Record a custom mic voice-over first, or switch to AI Neural TTS.');
        return;
      }
      setGeneratedAudioUrl(customVoiceOverUrl);
      setTimeout(() => {
        ensureAudioAnalyserConnected();
        audioElRef.current?.play().catch(() => {});
        setIsPreviewPlaying(true);
      }, 60);
      return;
    }

    if (!scriptText.trim()) {
      onTriggerToast('Enter a script for your AI Clone to speak.');
      return;
    }

    setIsGeneratingSpeech(true);
    try {
      const res = await fetch('/api/ai-clone/generate-speech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          script: scriptText.trim(),
          voiceName: avatarVoice || activeAvatar.voicePersona,
        }),
      });
      const data = await res.json();
      if (data?.audioUrl) {
        setGeneratedAudioUrl(data.audioUrl);
        setAudioDurationSec(Number(data.durationSec || 6));
        setTimeout(() => {
          ensureAudioAnalyserConnected();
          if (audioElRef.current) {
            audioElRef.current.currentTime = 0;
            audioElRef.current.play().catch(() => {});
            setIsPreviewPlaying(true);
          }
        }, 80);
        onTriggerToast(`AI Speech ready (${data.engine}) — playing synced lip-sync preview!`);
      }
    } catch {
      onTriggerToast('Speech synthesis failed. Please try again.');
    } finally {
      setIsGeneratingSpeech(false);
    }
  };

  // Real-time Animated Digital Avatar & Studio Canvas Loop (30fps+ Lip-Sync)
  useEffect(() => {
    if (studioStep !== 'generate') return;
    let rafId = 0;
    const freqBins = new Uint8Array(64);
    const startMs = performance.now();

    const drawStage = (now: number) => {
      const canvas = stageCanvasRef.current;
      if (!canvas) {
        rafId = requestAnimationFrame(drawStage);
        return;
      }
      const w = aspectMode === '16:9' ? 1280 : 720;
      const h = aspectMode === '16:9' ? 720 : 1280;
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Measure real-time audio energy for accurate lip-sync viseme open/close
      let energy = 0;
      if (analyserRef.current && isPreviewPlaying) {
        analyserRef.current.getByteFrequencyData(freqBins);
        let sum = 0;
        for (let i = 2; i < 26; i++) sum += freqBins[i];
        energy = Math.min(1, sum / (24 * 120));
      } else if (isPreviewPlaying) {
        const elapsed = (now - startMs) / 1000;
        energy = 0.3 + Math.abs(Math.sin(elapsed * 11)) * 0.55;
      }
      mouthEnergyRef.current = mouthEnergyRef.current * 0.6 + energy * 0.4;
      const talk = mouthEnergyRef.current;
      const t = (now - startMs) / 1000;

      // 1. Virtual Studio Background
      const bg = VIRTUAL_BACKGROUNDS.find((b) => b.id === selectedBgId) || VIRTUAL_BACKGROUNDS[0];
      if (customBgImgRef.current) {
        ctx.drawImage(customBgImgRef.current, 0, 0, w, h);
        ctx.fillStyle = 'rgba(10, 14, 28, 0.32)';
        ctx.fillRect(0, 0, w, h);
      } else {
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, bg.topColor);
        grad.addColorStop(1, bg.bottomColor);
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        // Ambient studio backlights
        const glow = ctx.createRadialGradient(w * 0.5, h * 0.42, 40, w * 0.5, h * 0.42, w * 0.55);
        glow.addColorStop(0, `${bg.glowColor}55`);
        glow.addColorStop(1, 'transparent');
        ctx.fillStyle = glow;
        ctx.fillRect(0, 0, w, h);
      }

      // 2. Subtle grid & acoustic waveform rings behind avatar
      const cx = w * 0.5;
      const cy = h * (aspectMode === '16:9' ? 0.54 : 0.48);
      const baseScale = aspectMode === '16:9' ? 1.0 : 0.92;

      ctx.save();
      ctx.strokeStyle = activeAvatar.accentColor;
      ctx.globalAlpha = 0.28 + talk * 0.45;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(cx, cy - 35 * baseScale, (175 + talk * 34) * baseScale, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // 3. Natural Head Movement & Breathing Sway
      const swayX = Math.sin(t * 1.4) * 5;
      const swayY = Math.sin(t * 2.1) * 4 - talk * 5;
      const headTilt = Math.sin(t * 1.1) * 0.03 + (talk > 0.25 ? Math.sin(t * 5.2) * 0.025 : 0);

      ctx.save();
      ctx.translate(cx + swayX, cy + swayY);
      ctx.scale(baseScale, baseScale);

      // Shoulders & Outfit
      ctx.fillStyle = activeAvatar.outfitColor;
      ctx.beginPath();
      ctx.moveTo(-220, 320);
      ctx.quadraticCurveTo(-190, 120, -60, 105);
      ctx.lineTo(60, 105);
      ctx.quadraticCurveTo(190, 120, 220, 320);
      ctx.closePath();
      ctx.fill();

      // Collar / Jacket lapel accent
      ctx.fillStyle = activeAvatar.accentColor;
      ctx.beginPath();
      ctx.moveTo(-58, 105);
      ctx.lineTo(0, 195);
      ctx.lineTo(58, 105);
      ctx.lineTo(36, 105);
      ctx.lineTo(0, 162);
      ctx.lineTo(-36, 105);
      ctx.closePath();
      ctx.fill();

      // Neck
      ctx.fillStyle = activeAvatar.skinTone;
      ctx.fillRect(-36, 38, 72, 82);

      // Head group (rotates smoothly with speech cadence)
      ctx.save();
      ctx.rotate(headTilt);

      // Hair Back
      ctx.fillStyle = activeAvatar.hairColor;
      ctx.beginPath();
      ctx.ellipse(0, -68, 114, 126, 0, 0, Math.PI * 2);
      ctx.fill();

      // Ears
      ctx.fillStyle = activeAvatar.skinTone;
      ctx.beginPath();
      ctx.ellipse(-102, -45, 16, 28, -0.1, 0, Math.PI * 2);
      ctx.ellipse(102, -45, 16, 28, 0.1, 0, Math.PI * 2);
      ctx.fill();

      // Face / Jawline
      ctx.fillStyle = activeAvatar.skinTone;
      ctx.beginPath();
      ctx.moveTo(-98, -85);
      ctx.quadraticCurveTo(-100, 36, 0, 62 + talk * 9);
      ctx.quadraticCurveTo(100, 36, 98, -85);
      ctx.quadraticCurveTo(96, -172, 0, -174);
      ctx.quadraticCurveTo(-96, -172, -98, -85);
      ctx.closePath();
      ctx.fill();

      // Styled Hair Fringe
      ctx.fillStyle = activeAvatar.hairColor;
      ctx.beginPath();
      ctx.moveTo(-104, -84);
      ctx.quadraticCurveTo(-95, -186, 8, -188);
      ctx.quadraticCurveTo(108, -182, 104, -82);
      ctx.quadraticCurveTo(54, -135, 6, -118);
      ctx.quadraticCurveTo(-48, -104, -104, -84);
      ctx.closePath();
      ctx.fill();

      // Eyes + Natural Blink every ~3.4s
      const blinkCycle = t % 3.4;
      const eyeOpen = blinkCycle > 3.24 ? 0.12 : 1.0;

      // Eyebrows (expressive lift while speaking)
      const browLift = talk * 6;
      ctx.strokeStyle = activeAvatar.hairColor;
      ctx.lineWidth = 7;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(-64, -82 - browLift);
      ctx.quadraticCurveTo(-42, -92 - browLift, -20, -82 - browLift);
      ctx.moveTo(20, -82 - browLift);
      ctx.quadraticCurveTo(42, -92 - browLift, 64, -82 - browLift);
      ctx.stroke();

      // Left & Right Eyes
      for (const ex of [-42, 42]) {
        ctx.save();
        ctx.translate(ex, -54);
        ctx.scale(1, eyeOpen);
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.ellipse(0, 0, 18, 12, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#1E293B';
        ctx.beginPath();
        ctx.arc(Math.sin(t * 0.7) * 2.5, 0, 8, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(3, -3, 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Nose bridge shadow
      ctx.strokeStyle = 'rgba(0,0,0,0.16)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, -52);
      ctx.lineTo(-4, -12);
      ctx.quadraticCurveTo(0, -6, 6, -12);
      ctx.stroke();

      // Synchronized Lip-Sync Mouth (Audio Viseme Openness & Shape)
      const mouthOpenH = 4 + talk * 24;
      const mouthWidth = 28 - talk * 4 + Math.sin(t * 14) * talk * 5;

      ctx.fillStyle = '#581C24';
      ctx.beginPath();
      ctx.ellipse(0, 18 + talk * 4, Math.max(14, mouthWidth), mouthOpenH, 0, 0, Math.PI * 2);
      ctx.fill();

      // Upper teeth flash on open visemes
      if (mouthOpenH > 10) {
        ctx.fillStyle = '#F8FAFC';
        ctx.beginPath();
        ctx.ellipse(0, 12 + talk * 2, mouthWidth * 0.68, 4.5, 0, 0, Math.PI);
        ctx.fill();
      }

      // Outer lips
      ctx.strokeStyle = '#B9535E';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.ellipse(0, 18 + talk * 4, Math.max(14, mouthWidth), mouthOpenH, 0, 0, Math.PI * 2);
      ctx.stroke();

      ctx.restore(); // end head group
      ctx.restore(); // end avatar root

      // 4. Studio Lighting Preset Pass
      const light =
        LIGHTING_PRESETS.find((l) => l.id === selectedLightingId) || LIGHTING_PRESETS[0];
      const lightGrad = ctx.createRadialGradient(w * 0.5, h * 0.35, 60, w * 0.5, h * 0.5, w * 0.72);
      lightGrad.addColorStop(0, light.tint);
      lightGrad.addColorStop(1, 'rgba(0,0,0,0.28)');
      ctx.fillStyle = lightGrad;
      ctx.fillRect(0, 0, w, h);

      // 5. Overlay Text Template Layer
      if (selectedOverlayId === 'lower_third') {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.86)';
        ctx.fillRect(42, h - 128, w - 84, 86);
        ctx.fillStyle = activeAvatar.accentColor;
        ctx.fillRect(42, h - 128, 12, 86);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 28px Inter, system-ui, sans-serif';
        ctx.fillText(overlayHeadline || activeAvatar.name, 74, h - 88);
        ctx.fillStyle = '#CBD5E1';
        ctx.font = '600 18px Inter, system-ui, sans-serif';
        ctx.fillText(`@${currentUsername} • FISM AI Clone Studio`, 74, h - 56);
      } else if (selectedOverlayId === 'breaking') {
        ctx.fillStyle = '#DC2626';
        ctx.fillRect(0, h - 110, w, 72);
        ctx.fillStyle = '#FACC15';
        ctx.fillRect(0, h - 118, w, 8);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = '900 28px Inter, system-ui, sans-serif';
        ctx.fillText(`LIVE AI CLONE: ${overlayHeadline}`, 36, h - 64);
      } else if (selectedOverlayId === 'hook_banner') {
        ctx.fillStyle = 'rgba(255, 87, 34, 0.94)';
        ctx.fillRect(48, 36, w - 96, 74);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = '800 28px Inter, system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(overlayHeadline || 'WATCH UNTIL THE END', w / 2, 83);
        ctx.textAlign = 'left';
      } else if (selectedOverlayId === 'bold_captions') {
        const snippet = scriptText.slice(0, 62) + (scriptText.length > 62 ? '...' : '');
        ctx.fillStyle = 'rgba(0, 0, 0, 0.72)';
        ctx.fillRect(48, h - 120, w - 96, 72);
        ctx.fillStyle = '#FDE047';
        ctx.font = '800 24px Inter, system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(snippet, w / 2, h - 75);
        ctx.textAlign = 'left';
      }

      // Live Badge Watermark
      ctx.fillStyle = 'rgba(15, 23, 42, 0.72)';
      ctx.fillRect(26, 26, 175, 34);
      ctx.fillStyle = '#FF5722';
      ctx.beginPath();
      ctx.arc(46, 43, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '700 14px Inter, system-ui, sans-serif';
      ctx.fillText('FISM AI CLONE', 60, 48);

      rafId = requestAnimationFrame(drawStage);
    };

    rafId = requestAnimationFrame(drawStage);
    return () => cancelAnimationFrame(rafId);
  }, [
    studioStep,
    aspectMode,
    selectedBgId,
    selectedLightingId,
    selectedOverlayId,
    overlayHeadline,
    scriptText,
    activeAvatar,
    currentUsername,
    isPreviewPlaying,
  ]);

  const handleRenderAndExport = async () => {
    const canvas = stageCanvasRef.current;
    if (!canvas) return;

    if (!generatedAudioUrl) {
      onTriggerToast('Generate AI Voice or record voice-over first before rendering!');
      return;
    }

    setIsRenderingExport(true);
    setRenderProgressPct(5);
    setExportedVideoUrl('');

    try {
      ensureAudioAnalyserConnected();
      const canvasStream = canvas.captureStream(30);
      const combinedTracks: MediaStreamTrack[] = [...canvasStream.getVideoTracks()];

      // Attach audio track from Web Audio API destination if available
      if (audioCtxRef.current && analyserRef.current) {
        const dest = audioCtxRef.current.createMediaStreamDestination();
        analyserRef.current.connect(dest);
        dest.stream.getAudioTracks().forEach((t) => combinedTracks.push(t));
      }

      const combinedStream = new MediaStream(combinedTracks);
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')
        ? 'video/webm;codecs=vp8,opus'
        : 'video/webm';
      const recorder = new MediaRecorder(combinedStream, { mimeType });
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };

      const renderMs = Math.min(18000, Math.max(3500, audioDurationSec * 1000));
      const startTime = Date.now();
      const progressTimer = setInterval(() => {
        const pct = Math.min(96, Math.round(((Date.now() - startTime) / renderMs) * 100));
        setRenderProgressPct(pct);
      }, 200);

      const finalBlob = await new Promise<Blob>((resolve) => {
        recorder.onstop = () => {
          clearInterval(progressTimer);
          resolve(new Blob(chunks, { type: 'video/webm' }));
        };
        recorder.start(250);

        if (audioElRef.current) {
          audioElRef.current.currentTime = 0;
          audioElRef.current.play().catch(() => {});
          setIsPreviewPlaying(true);
        }

        setTimeout(() => {
          setIsPreviewPlaying(false);
          audioElRef.current?.pause();
          if (recorder.state === 'recording') {
            recorder.stop();
          }
        }, renderMs);
      });

      let finalUrl = URL.createObjectURL(finalBlob);
      if (auth.currentUser) {
        const cloudUrl = await uploadBlobToFirebaseStorage(
          finalBlob,
          'ai-clone-exports',
          'ai_clone_video.webm',
        );
        if (cloudUrl) {
          finalUrl = cloudUrl;
        }
      }

      setRenderProgressPct(100);
      setExportedVideoUrl(finalUrl);
      setRenderedHistory((prev) => [
        {
          id: `render_${Date.now()}`,
          avatarId: activeAvatar.id,
          avatarName: activeAvatar.name,
          title: videoTitle.trim() || 'AI Clone Video',
          scriptText,
          backgroundId: selectedBgId,
          lightingId: selectedLightingId,
          overlayTemplateId: selectedOverlayId,
          overlayHeadline,
          videoUrl: finalUrl,
          audioUrl: generatedAudioUrl,
          durationSec: Math.round(renderMs / 1000),
          createdAt: new Date().toLocaleTimeString(),
        },
        ...prev,
      ]);
      onTriggerToast('Video rendered! Preview, Download, or Publish directly to FISM Feed.');
    } catch {
      onTriggerToast('Render interrupted — check browser media permissions and retry.');
    } finally {
      setIsRenderingExport(false);
    }
  };

  const handlePublishExport = async () => {
    const thumb = stageCanvasRef.current?.toDataURL('image/jpeg', 0.8) || '';
    const finalVideoUrl = exportedVideoUrl;
    if (!finalVideoUrl) {
      onTriggerToast('Click "Render & Export Video" first so a playable video file is generated.');
      return;
    }
    setIsPublishing(true);
    try {
      await onPublishToFismFeed({
        title: videoTitle.trim() || `${activeAvatar.name} AI Broadcast`,
        caption: `${scriptText}\n\n🤖 Created with FISM AI Clone Studio • Avatar: ${activeAvatar.name}`,
        videoUrl: finalVideoUrl,
        thumbnailUrl: thumb,
        durationSec: audioDurationSec,
        targetMode: publishMode,
        avatarName: activeAvatar.name,
      });
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      {/* Header Banner */}
      <div className="fism-card p-5 bg-gradient-to-r from-[#0F172A] via-[#1E1B4B] to-[#31102F] text-white border-2 border-[#7C3AED] flex items-center justify-between flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2.5 py-0.5 rounded bg-[#FF5722] text-white text-[10px] font-black uppercase">
              AI Clone Studio
            </span>
            <span className="px-2.5 py-0.5 rounded bg-[#16A34A] text-white text-[10px] font-black uppercase">
              Lip-Sync &amp; Neural Voice
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold mt-1 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-[#FFB300]" /> AI Clone &amp; Digital Avatar Video Studio
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Train your personal Digital Clone from a 10–15s speaking clip, customize lighting &amp;
            virtual backgrounds, animate real-time lip-sync speech, and publish directly to FISM.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-white/10 p-1.5 rounded-xl">
          <button
            type="button"
            onClick={() => setStudioStep('train')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold flex items-center gap-1.5 ${
              studioStep === 'train' ? 'bg-[#FF5722] text-white shadow' : 'text-slate-200'
            }`}
          >
            <Camera className="w-4 h-4" /> 1. Train Avatar ({availableAvatars.length})
          </button>
          <button
            type="button"
            onClick={() => setStudioStep('generate')}
            className={`px-3.5 py-2 rounded-lg text-xs font-extrabold flex items-center gap-1.5 ${
              studioStep === 'generate' ? 'bg-[#7C3AED] text-white shadow' : 'text-slate-200'
            }`}
          >
            <Film className="w-4 h-4" /> 2. Create AI Video
          </button>
        </div>
      </div>

      {/* STEP 1: AVATAR TRAINING & UPLOAD PIPELINE */}
      {studioStep === 'train' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7 fism-card p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h2 className="text-base font-extrabold flex items-center gap-2">
                <Video className="w-5 h-5 text-[#FF5722]" /> Record 10–15s Speaking Sample or Upload
                Video
              </h2>
              {isRecordingRef && (
                <span className="px-3 py-1 rounded-full bg-[#DC2626] text-white text-xs font-black animate-pulse">
                  ● REC {recordSeconds}s / 15s
                </span>
              )}
            </div>

            <div className="relative aspect-video rounded-2xl overflow-hidden bg-[#0F172A] border border-slate-700 flex items-center justify-center">
              {webcamActive ? (
                <video
                  ref={webcamVideoRef}
                  muted
                  playsInline
                  autoPlay
                  className="w-full h-full object-cover"
                />
              ) : refVideoUrl ? (
                <video
                  src={refVideoUrl}
                  controls
                  playsInline
                  className="w-full h-full object-contain bg-black"
                />
              ) : (
                <div className="text-center p-6 space-y-2 text-slate-300">
                  <Camera className="w-10 h-10 mx-auto text-[#FF5722]" />
                  <p className="text-sm font-bold">
                    Record a 10–15 second clear speaking clip looking at the camera
                  </p>
                  <p className="text-xs text-slate-400">
                    Or upload an MP4/WebM reference video file from your device.
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2.5 flex-wrap">
              {!webcamActive ? (
                <button
                  type="button"
                  onClick={startWebcam}
                  className="px-4 py-2.5 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
                >
                  <Camera className="w-4 h-4" /> Open Webcam &amp; Mic
                </button>
              ) : !isRecordingRef ? (
                <>
                  <button
                    type="button"
                    onClick={startRecordingReference}
                    className="px-4 py-2.5 rounded-xl bg-[#DC2626] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
                  >
                    <Play className="w-4 h-4 fill-white" /> Start 15s Recording
                  </button>
                  <button
                    type="button"
                    onClick={stopWebcam}
                    className="px-3.5 py-2.5 rounded-xl bg-slate-700 text-white text-xs font-bold"
                  >
                    Close Camera
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={stopRecordingReference}
                  className="px-4 py-2.5 rounded-xl bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1.5 shadow"
                >
                  <Square className="w-4 h-4 fill-white" /> Stop &amp; Save Clip ({recordSeconds}s)
                </button>
              )}

              <label className="px-4 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-extrabold flex items-center gap-1.5 cursor-pointer hover:border-[#FF5722]">
                <Upload className="w-4 h-4 text-[#FF5722]" /> Upload Reference Video File
                <input
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleUploadReferenceFile(file);
                    e.target.value = '';
                  }}
                />
              </label>
            </div>
          </div>

          <div className="lg:col-span-5 fism-card p-5 space-y-4">
            <h2 className="text-base font-extrabold flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-[#7C3AED]" /> Avatar Calibration Profile
            </h2>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-extrabold mb-1">Digital Clone Name</label>
                <input
                  type="text"
                  value={avatarName}
                  onChange={(e) => setAvatarName(e.target.value)}
                  placeholder="e.g., My Studio Twin"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-extrabold mb-1">Voice Persona</label>
                  <select
                    value={avatarVoice}
                    onChange={(e) =>
                      setAvatarVoice(
                        e.target.value as 'Kore' | 'Zephyr' | 'Puck' | 'Charon' | 'Fenrir',
                      )
                    }
                    className="w-full px-3 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                  >
                    <option value="Kore">Kore (Balanced Studio)</option>
                    <option value="Zephyr">Zephyr (Bright Creator)</option>
                    <option value="Puck">Puck (Energetic Youth)</option>
                    <option value="Charon">Charon (Deep Documentary)</option>
                    <option value="Fenrir">Fenrir (Bold Anchor)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-extrabold mb-1">Primary Language</label>
                  <select
                    value={avatarLanguage}
                    onChange={(e) => setAvatarLanguage(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                  >
                    <option value="English / Hinglish">English / Hinglish</option>
                    <option value="Hindi">Hindi</option>
                    <option value="English">English</option>
                    <option value="Spanish">Spanish</option>
                  </select>
                </div>
              </div>

              {isTraining && (
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] font-bold text-[#7C3AED]">
                    <span>Calibrating facial mesh &amp; uploading reference...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#FF5722] to-[#7C3AED] transition-all"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}

              <button
                type="button"
                onClick={handleTrainAvatar}
                disabled={isTraining}
                className="w-full fism-btn-primary py-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 shadow-lg"
              >
                <Sparkles className="w-4 h-4" />
                {isTraining ? 'Training AI Clone...' : 'Train & Save AI Clone Avatar →'}
              </button>

              <button
                type="button"
                onClick={() => setStudioStep('generate')}
                className="w-full py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-xs font-bold text-[#52607A] hover:text-[#FF5722]"
              >
                Use Existing Studio Clone ({activeAvatar.name}) →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2 & 3: VIDEO GENERATOR, CUSTOMIZATION, LIP-SYNC PREVIEW & EXPORT */}
      {studioStep === 'generate' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left Controls Column */}
          <div className="lg:col-span-5 space-y-4">
            {/* Avatar Selector */}
            <div className="fism-card p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase text-[#52607A]">
                  Trained AI Clone Avatar
                </span>
                <button
                  type="button"
                  onClick={() => setStudioStep('train')}
                  className="text-xs font-extrabold text-[#FF5722] hover:underline"
                >
                  + Train New Clone
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {availableAvatars.map((av) => (
                  <button
                    key={av.id}
                    type="button"
                    onClick={() => setSelectedAvatarId(av.id)}
                    className={`p-2.5 rounded-xl border text-left transition-all flex items-center gap-2.5 ${
                      av.id === activeAvatar.id
                        ? 'border-[#7C3AED] bg-[#7C3AED]/10'
                        : 'border-[#D8E1F0] dark:border-slate-800'
                    }`}
                  >
                    <span
                      className="w-8 h-8 rounded-full shrink-0 border-2 border-white shadow"
                      style={{ backgroundColor: av.outfitColor }}
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-extrabold truncate">{av.name}</div>
                      <div className="text-[10px] text-[#52607A] truncate">
                        {av.voicePersona} • {av.language}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
              <div className="text-[11px] text-[#16A34A] font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{activeAvatar.facialLandmarksSummary}</span>
              </div>
            </div>

            {/* Script & Voice Mode */}
            <div className="fism-card p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-extrabold uppercase text-[#52607A]">
                  Dialogue Script &amp; Audio
                </span>
                <div className="flex items-center gap-1 bg-[#F1F5F9] dark:bg-slate-800 p-1 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setVoiceMode('ai_tts')}
                    className={`px-2 py-1 rounded text-[10px] font-extrabold ${
                      voiceMode === 'ai_tts' ? 'bg-[#7C3AED] text-white' : 'text-[#52607A]'
                    }`}
                  >
                    AI TTS
                  </button>
                  <button
                    type="button"
                    onClick={() => setVoiceMode('mic_voiceover')}
                    className={`px-2 py-1 rounded text-[10px] font-extrabold ${
                      voiceMode === 'mic_voiceover' ? 'bg-[#FF5722] text-white' : 'text-[#52607A]'
                    }`}
                  >
                    Mic Voice-Over
                  </button>
                </div>
              </div>

              <input
                type="text"
                value={videoTitle}
                onChange={(e) => setVideoTitle(e.target.value)}
                placeholder="Video title..."
                className="w-full px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
              />

              {voiceMode === 'ai_tts' ? (
                <>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={scriptTopic}
                      onChange={(e) => setScriptTopic(e.target.value)}
                      placeholder="Topic for AI script writer (optional)..."
                      className="flex-1 px-3 py-2 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs"
                    />
                    <button
                      type="button"
                      onClick={handleEnhanceScript}
                      disabled={isWritingScript}
                      className="px-3 py-2 rounded-xl bg-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-1 shrink-0"
                    >
                      <Wand2 className="w-3.5 h-3.5" />
                      {isWritingScript ? 'Writing...' : 'AI Write'}
                    </button>
                  </div>

                  <textarea
                    rows={3}
                    value={scriptText}
                    onChange={(e) => setScriptText(e.target.value)}
                    placeholder="Type what your AI Clone should speak..."
                    className="w-full p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs leading-relaxed"
                  />

                  <div className="flex items-center justify-between gap-2">
                    <label className="text-xs font-bold text-[#52607A]">Voice:</label>
                    <select
                      value={avatarVoice}
                      onChange={(e) =>
                        setAvatarVoice(
                          e.target.value as 'Kore' | 'Zephyr' | 'Puck' | 'Charon' | 'Fenrir',
                        )
                      }
                      className="flex-1 px-3 py-1.5 rounded-lg bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                    >
                      <option value="Kore">Kore — Warm Creator</option>
                      <option value="Zephyr">Zephyr — Energetic Studio</option>
                      <option value="Puck">Puck — Fast Shorts Host</option>
                      <option value="Charon">Charon — Deep Narrator</option>
                      <option value="Fenrir">Fenrir — Bold Broadcast</option>
                    </select>
                  </div>
                </>
              ) : (
                <div className="p-3 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 space-y-2">
                  <p className="text-xs text-[#52607A]">
                    Record your own voice directly to drive your Digital Avatar&apos;s lip-sync!
                  </p>
                  <button
                    type="button"
                    onClick={toggleVoiceOverRecording}
                    className={`w-full py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 ${
                      isRecordingVoiceOver
                        ? 'bg-[#DC2626] text-white animate-pulse'
                        : 'bg-[#FF5722] text-white'
                    }`}
                  >
                    <Mic className="w-4 h-4" />
                    {isRecordingVoiceOver ? 'Stop Recording Voice-Over' : 'Record Mic Voice-Over'}
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={handleGenerateSpeechAndPreview}
                disabled={isGeneratingSpeech}
                className="w-full fism-btn-primary py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 shadow"
              >
                <Volume2 className="w-4 h-4" />
                {isGeneratingSpeech
                  ? 'Synthesizing Neural Speech...'
                  : 'Generate Voice & Preview Lip-Sync'}
              </button>
            </div>

            {/* Studio Customization: Background, Lighting & Text Overlays */}
            <div className="fism-card p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase text-[#52607A]">
                  Studio Customization
                </span>
                <div className="flex items-center gap-1">
                  {(['16:9', '9:16'] as const).map((ratio) => (
                    <button
                      key={ratio}
                      type="button"
                      onClick={() => setAspectMode(ratio)}
                      className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                        aspectMode === ratio
                          ? 'bg-[#FF5722] text-white'
                          : 'bg-[#F1F5F9] dark:bg-slate-800 text-[#52607A]'
                      }`}
                    >
                      {ratio}
                    </button>
                  ))}
                </div>
              </div>

              {/* Virtual Backgrounds */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-bold flex items-center gap-1">
                    <ImageIcon className="w-3.5 h-3.5 text-[#7C3AED]" /> Virtual Background
                  </span>
                  <label className="text-[11px] font-extrabold text-[#2563EB] cursor-pointer hover:underline">
                    Upload Image
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        setCustomBgImageUrl(URL.createObjectURL(file));
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>
                <div className="grid grid-cols-5 gap-1.5">
                  {VIRTUAL_BACKGROUNDS.map((bg) => (
                    <button
                      key={bg.id}
                      type="button"
                      onClick={() => {
                        setCustomBgImageUrl('');
                        setSelectedBgId(bg.id);
                      }}
                      title={bg.name}
                      style={{
                        background: `linear-gradient(135deg, ${bg.topColor}, ${bg.glowColor})`,
                      }}
                      className={`h-8 rounded-lg border-2 transition-all ${
                        selectedBgId === bg.id && !customBgImageUrl
                          ? 'border-[#FF5722] scale-105'
                          : 'border-transparent'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Lighting Presets */}
              <div>
                <span className="text-[11px] font-bold flex items-center gap-1 mb-1">
                  <Sun className="w-3.5 h-3.5 text-[#F59E0B]" /> Studio Lighting
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  {LIGHTING_PRESETS.map((l) => (
                    <button
                      key={l.id}
                      type="button"
                      onClick={() => setSelectedLightingId(l.id)}
                      className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold border text-left ${
                        selectedLightingId === l.id
                          ? 'border-[#F59E0B] bg-amber-500/10 text-[#F59E0B]'
                          : 'border-[#D8E1F0] dark:border-slate-800'
                      }`}
                    >
                      {l.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Overlay Templates */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold flex items-center gap-1">
                  <TypeIcon className="w-3.5 h-3.5 text-[#2563EB]" /> Overlay Text Template
                </span>
                <select
                  value={selectedOverlayId}
                  onChange={(e) => setSelectedOverlayId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                >
                  {OVERLAY_TEMPLATES.map((tpl) => (
                    <option key={tpl.id} value={tpl.id}>
                      {tpl.name}
                    </option>
                  ))}
                </select>
                {selectedOverlayId !== 'none' && (
                  <input
                    type="text"
                    value={overlayHeadline}
                    onChange={(e) => setOverlayHeadline(e.target.value)}
                    placeholder="Headline text overlay..."
                    className="w-full px-3 py-1.5 rounded-lg bg-[#F3F6FC] dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-semibold"
                  />
                )}
              </div>
            </div>
          </div>

          {/* Right Live Stage, Render & Publish Column */}
          <div className="lg:col-span-7 space-y-4">
            <div className="fism-card p-4 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h2 className="text-sm font-extrabold flex items-center gap-2">
                  <Film className="w-4 h-4 text-[#FF5722]" /> Real-Time Lip-Sync Stage Preview (
                  {aspectMode})
                </h2>
                {generatedAudioUrl && (
                  <button
                    type="button"
                    onClick={() => {
                      const el = audioElRef.current;
                      if (!el) return;
                      ensureAudioAnalyserConnected();
                      if (isPreviewPlaying) {
                        el.pause();
                        setIsPreviewPlaying(false);
                      } else {
                        el.play().catch(() => {});
                        setIsPreviewPlaying(true);
                      }
                    }}
                    className="px-3 py-1.5 rounded-lg bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1"
                  >
                    {isPreviewPlaying ? (
                      <>
                        <Pause className="w-3.5 h-3.5" /> Pause Preview
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" /> Play Lip-Sync
                      </>
                    )}
                  </button>
                )}
              </div>

              <div
                className={`mx-auto rounded-2xl overflow-hidden bg-black border-2 border-[#7C3AED] shadow-xl ${
                  aspectMode === '9:16' ? 'max-w-[340px] aspect-[9/16]' : 'w-full aspect-video'
                }`}
              >
                <canvas ref={stageCanvasRef} className="w-full h-full object-contain" />
              </div>

              <audio
                ref={audioElRef}
                src={generatedAudioUrl || undefined}
                onPlay={() => setIsPreviewPlaying(true)}
                onPause={() => setIsPreviewPlaying(false)}
                onEnded={() => setIsPreviewPlaying(false)}
                className="w-full h-9"
                controls
              />

              {/* Render & Export Controls */}
              <div className="p-3.5 rounded-xl bg-[#F8FAFE] dark:bg-slate-900 border border-[#D8E1F0] dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <div className="text-xs font-extrabold">
                      Render &amp; Export Final AI Clone Video (.webm)
                    </div>
                    <div className="text-[11px] text-[#52607A]">
                      Combines canvas lip-sync, lighting, overlays &amp; synchronized neural voice.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleRenderAndExport}
                    disabled={isRenderingExport}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FF5722] to-[#7C3AED] text-white text-xs font-extrabold flex items-center gap-1.5 shadow-lg"
                  >
                    {isRenderingExport ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" /> Rendering {renderProgressPct}%
                      </>
                    ) : (
                      <>
                        <Film className="w-4 h-4" /> Render &amp; Export Video
                      </>
                    )}
                  </button>
                </div>

                {isRenderingExport && (
                  <div className="h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#FF5722] to-[#16A34A] transition-all"
                      style={{ width: `${renderProgressPct}%` }}
                    />
                  </div>
                )}

                {exportedVideoUrl && (
                  <div className="pt-2 border-t border-[#D8E1F0] dark:border-slate-800 space-y-3">
                    <div className="text-xs font-extrabold text-[#16A34A] flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" /> Exported AI Clone Video Ready!
                    </div>
                    <video
                      src={exportedVideoUrl}
                      controls
                      playsInline
                      className="w-full max-h-60 rounded-xl bg-black"
                    />
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <a
                        href={exportedVideoUrl}
                        download={`${(videoTitle || 'fism_ai_clone').replace(/\s+/g, '_')}.webm`}
                        className="px-4 py-2 rounded-xl bg-[#2563EB] text-white text-xs font-extrabold flex items-center gap-1.5"
                      >
                        <Download className="w-4 h-4" /> Download Video
                      </a>

                      <div className="flex items-center gap-2">
                        <select
                          value={publishMode}
                          onChange={(e) =>
                            setPublishMode(e.target.value as 'mainBlast' | 'quickBurst')
                          }
                          className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-[#D8E1F0] dark:border-slate-700 text-xs font-bold"
                        >
                          <option value="mainBlast">Main Blast (Feed)</option>
                          <option value="quickBurst">Quick Burst (Shorts)</option>
                        </select>
                        <button
                          type="button"
                          onClick={handlePublishExport}
                          disabled={isPublishing}
                          className="fism-btn-primary px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow"
                        >
                          <Send className="w-4 h-4" />
                          {isPublishing ? 'Scanning & Publishing...' : 'Publish to FISM Feed'}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {renderedHistory.length > 0 && (
              <div className="fism-card p-4 space-y-2">
                <div className="text-xs font-extrabold uppercase text-[#52607A]">
                  Recent Studio Exports ({renderedHistory.length})
                </div>
                <div className="space-y-2">
                  {renderedHistory.map((item) => (
                    <div
                      key={item.id}
                      className="p-2.5 rounded-xl bg-[#F3F6FC] dark:bg-slate-800 flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0">
                        <div className="font-extrabold truncate">{item.title}</div>
                        <div className="text-[10px] text-[#52607A]">
                          {item.avatarName} • {item.durationSec}s • {item.createdAt}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setExportedVideoUrl(item.videoUrl)}
                        className="px-2.5 py-1 rounded-lg bg-[#7C3AED] text-white text-[11px] font-bold shrink-0"
                      >
                        Load
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
