export type FismScreen =
  | 'flameFeed'
  | 'mainBlast'
  | 'quickBurst'
  | 'musicHub'
  | 'circleFeed'
  | 'findFlame'
  | 'emberChat'
  | 'warmSparks'
  | 'myHearth'
  | 'ashStash'
  | 'onFire'
  | 'fuelUp'
  | 'earningHub'
  | 'shoppingSection'
  | 'gameHub'
  | 'controlCore'
  | 'adminPanel'
  | 'adminFileVault'
  | 'flame3DArena'
  | 'aiWorkspaceHub'
  | 'aiCloneStudio'
  | 'communityChat'
  | 'liveCreatorChat'
  | 'coinLeaderboard'
  | 'flameMaps'
  | 'installApp'
  | 'helpSupport'
  | 'aboutFism'
  | 'privacyPolicy'
  | 'termsConditions';

export type FismBannerOriginalSize = '320x50' | '468x60' | '728x90' | '300x250';

export interface FismAdsterraConfig {
  enabled: boolean;
  bannerEnabled: boolean;
  bannerKey: string;
  bannerHost: string;
  bannerScriptUrl?: string;
  bannerSize: FismBannerOriginalSize;
  bannerRawHtml: string;
  rectBannerEnabled?: boolean;
  rectBannerKey?: string;
  rectBannerScriptUrl?: string;
  rectBannerRawHtml?: string;
  nativeEnabled: boolean;
  nativeContainerId: string;
  nativeScriptUrl: string;
  nativeRawHtml: string;
  updatedAt: string;
}

export const DEFAULT_LIVE_ADSTERRA_CONFIG: FismAdsterraConfig = {
  enabled: true,
  bannerEnabled: true,
  bannerKey: 'f2836e32972c4e847257ab5b0a99454b',
  bannerHost: 'bicea.org',
  bannerScriptUrl: 'https://bicea.org/22/f2836e32972c4e847257ab5b0a99454b',
  bannerSize: '320x50',
  bannerRawHtml: `<script>
  atOptions = {
    'key' : 'f2836e32972c4e847257ab5b0a99454b',
    'format' : 'iframe',
    'height' : 50,
    'width' : 320,
    'params' : {}
  };
</script>
<script src="https://bicea.org/22/f2836e32972c4e847257ab5b0a99454b"></script>`,
  rectBannerEnabled: true,
  rectBannerKey: 'd18c8733cba0076961f3a96779511f03',
  rectBannerScriptUrl: 'https://bicea.org/22/d18c8733cba0076961f3a96779511f03',
  rectBannerRawHtml: `<script>
  atOptions = {
    'key' : 'd18c8733cba0076961f3a96779511f03',
    'format' : 'iframe',
    'height' : 250,
    'width' : 300,
    'params' : {}
  };
</script>
<script src="https://bicea.org/22/d18c8733cba0076961f3a96779511f03"></script>`,
  nativeEnabled: true,
  nativeContainerId: 'container-dae1bd5172914b3167ca53a3a0dfdd75',
  nativeScriptUrl: 'https://bicea.org/21/dae1bd5172914b3167ca53a3a0dfdd75',
  nativeRawHtml: `<script async="async" data-cfasync="false" src="https://bicea.org/21/dae1bd5172914b3167ca53a3a0dfdd75"></script>
<div id="container-dae1bd5172914b3167ca53a3a0dfdd75"></div>`,
  updatedAt: '2026-11-20T00:00:00.000Z',
};

export interface FismApkReleaseInfo {
  id: string;
  appName: string;
  version: string;
  details: string;
  fileName: string;
  sizeBytes: number;
  downloadUrl: string;
  packageName: string;
  uploadedBy: string;
  uploadedAt: string;
}

export interface FismMusicTrack {
  id: string;
  title: string;
  artist: string;
  uploaderUsername: string;
  audioUrl: string;
  coverUrl: string;
  duration: string;
  genre: string;
  usesCount: number;
  createdAt: string;
}

export interface FismGameItem {
  id: string;
  name: string;
  title: string;
  description: string;
  category: string;
  folderName: string;
  filesCount: number;
  uploadedByAdmin: boolean;
  createdAt: string;
  engineType:
    | 'flameRunner2D'
    | 'brickBreaker2D'
    | 'cyberSnake2D'
    | 'redBallDefense2D'
    | 'customAdmin2D';
  isGreenScreenGame?: boolean;
  chromaColor?: string;
  chromaSensitivity?: number;
  overlayMediaUrl?: string;
  overlayMediaType?: 'image' | 'video' | 'engine';
  gameFilesSummary?: string[];
}


export interface FismShoppingProduct {
  id: string;
  title: string;
  description: string;
  price: string;
  photos: string[]; // Min 2, Max 15
  imageUrl?: string;
  videoUrl: string; // Min 1, Max 1
  videoTitle: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  phoneNumber: string;
  email: string;
  locationLabel: string;
  lat: number;
  lng: number;
  createdAt: string;
}

export interface FismWatchHistoryEntry {
  videoTitle: string;
  watchedAtDate: string;
  watchedAtTime: string;
  durationWatched: string;
}

export interface FismAdminUserDossier {
  uid: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  email: string;
  passwordRecord: string;
  phoneNumber: string;
  bio: string;
  isBanned: boolean;
  liveStatusText: string;
  videosUploadedCount: number;
  sparksFollowersCount: number;
  flamesFollowingCount: number;
  whatUsedSummary: string;
  whyUsedSummary: string;
  watchHistory: FismWatchHistoryEntry[];
  ipAddress?: string;
  categories?: string[];
  liveActivities?: { action: string; reason: string; timestamp: string }[];
}

export interface FismSurveyQuestion {
  id: string;
  questionText: string;
  options: string[]; // Admin-created options (starts with 3, can add 15-20+ via + button); "More / Other" is always appended automatically
}

export interface FismSurveyCampaign {
  id: string;
  title: string;
  questions: FismSurveyQuestion[];
  isActive: boolean;
  createdAt: string;
}

export interface FismSurveySubmission {
  id: string;
  surveyId: string;
  userId: string;
  username: string;
  displayName: string;
  userEmail: string;
  ipAddress: string;
  submittedAt: string;
  answers: {
    questionId: string;
    questionText: string;
    selectedOption: string;
    customMoreText?: string;
  }[];
}

export interface FismUpiConfig {
  upiId: string;
  merchantName: string;
  qrCodeUrl: string;
  updatedAt: string;
}

export interface FismUpiPaymentRequest {
  id: string;
  userId: string;
  username: string;
  displayName: string;
  userAvatar: string;
  userEmail: string;
  senderUpiId: string;
  utrTransactionId: string;
  payerName: string;
  amountLabel: string;
  planName: string;
  creatorId?: string;
  creatorName?: string;
  status: 'pending' | 'accepted' | 'declined';
  requestType?: 'premium' | 'sp_coin_pack';
  spCoinsAmount?: number;
  submittedAt: string;
  reviewedAt?: string;
}

export interface FismWithdrawalRequest {
  id: string;
  userId: string;
  userFullName: string;
  profileId: string;
  username: string;
  profileName: string;
  userAvatar: string;
  amountUsd: number;
  convertedAmountLabel: string;
  currencyCode: string;
  countryName: string;
  paymentMethodCategory: 'international_card' | 'upi' | 'other_wallet';
  paymentMethodLabel: string;
  paymentAccountDetails: string;
  cardNumber?: string;
  cardExpiry?: string;
  cardHolderName?: string;
  bankSwiftCode?: string;
  upiId?: string;
  walletProvider?: string;
  walletId?: string;
  status: 'pending' | 'accepted' | 'declined';
  submittedAt: string;
  reviewedAt?: string;
}

export const FISM_PROFILE_CATEGORIES: string[] = [
  'Web Development & Full-Stack',
  'Sarkari Naukri (Government Jobs)',
  'Light & Electrical Engineering',
  'UPSC / IAS / IPS Civil Services',
  'SSC / Railway / Banking Jobs',
  'Army / Police / Defence Jobs',
  'App & Software Engineering',
  'AI, Machine Learning & Data Science',
  'Cyber Security & Ethical Hacking',
  'Gaming & Esports Live Streamer',
  'Teaching, Coaching & Education',
  'Medical, Nursing & Healthcare Jobs',
  'Digital Marketing, SEO & E-Commerce',
  'Video Editing, VFX & Filmmaking',
  'Graphic Design & 3D Animation',
  'Music, Singing & Audio Production',
  'Business, Startup & Entrepreneurship',
  'Finance, Stock Market & Accounting',
  'Civil, Mechanical & Automobile Work',
  'Law, Judiciary & Legal Services',
  'Agriculture & Rural Development',
  'Fitness, Sports & Athletics',
  'Comedy, Vlogging & Entertainment',
  'Photography & Journalism',
];

export type FismAccountPrivacyMode = 'public' | 'private';

export interface FismSubAccount {
  id: string;
  masterUid?: string;
  isMaster?: boolean;
  email: string;
  username: string;
  displayName: string;
  bio?: string;
  avatarUrl: string;
  coverUrl?: string;
  location?: string;
  website?: string;
  categories?: string[];
  privacyMode?: FismAccountPrivacyMode;
  isPrivate?: boolean;
  isAgeVerified?: boolean;
  verifiedAge?: number;
  verifiedDocumentType?: string;
  ageVerifiedAt?: string;
  ageVerificationStatus?: 'unverified' | 'verified' | 'rejected';
  ageVerificationNote?: string;
  publicPublishingRestricted?: boolean;
  hasPassword?: boolean;
  sparksCount?: number;
  flamesCount?: number;
  fuelersCount?: number;
  monthlyPrice?: number;
  connectedCreatorUids?: string[];
  approvedFollowerUids?: string[];
  phoneVerified: boolean;
  phoneNumber: string;
  createdAt: string;
  joinedAtIso?: string;
  milestoneTier?: FismMilestoneTier;
  hasRedMilestoneTick?: boolean;
  equippedFrame?: FismProfileFrameId;
  vipGoldBadgeUnlocked?: boolean;
}

export interface FismPrivateFollowRequest {
  id: string;
  requesterUid: string;
  requesterUsername: string;
  requesterDisplayName: string;
  requesterAvatar: string;
  targetUid: string;
  targetUsername: string;
  targetDisplayName: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: string;
  respondedAt?: string;
}

export interface FismAgeVerificationResult {
  accountId: string;
  is_age_verified: boolean;
  status: 'verified' | 'rejected';
  calculatedAge?: number;
  documentType: string;
  reason: string;
  verifiedAt: string;
  privacyLockedToPrivate: boolean;
  publicPublishingRestricted: boolean;
}

export interface FismCreator {
  uid: string;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string;
  coverUrl: string;
  location: string;
  website: string;
  isVerified: boolean;
  isPrivate: boolean;
  isAgeVerified?: boolean;
  sparksCount: number; // Sparks
  flamesCount: number; // Flames
  fuelersCount: number; // Fuelers
  monthlyPrice: number;
  categories?: string[]; // Up to 4 chosen categories
  isConnected?: boolean;
  isFuelledUp?: boolean;
  isMuted?: boolean;
  isBlocked?: boolean;
  joinedAtIso?: string;
  milestoneTier?: FismMilestoneTier;
  hasRedMilestoneTick?: boolean;
  equippedFrame?: FismProfileFrameId;
  vipGoldBadgeUnlocked?: boolean;
  algorithmBoostTier?: FismMilestoneTier;
}

export interface FismCommentItem {
  id: string;
  postId: string;
  authorId: string;
  authorUsername: string;
  authorAvatar: string;
  text: string;
  createdAt: string;
  isAutoBotReply?: boolean;
  productLinkUrl?: string;
  productTitle?: string;
  productStoreName?: string;
  authorHasRedTick?: boolean;
  authorVipGoldBadge?: boolean;
  authorMilestoneTier?: FismMilestoneTier;
}

export interface FismPostItem {
  id: string;
  authorId: string;
  authorUsername: string;
  authorDisplayName: string;
  authorAvatar: string;
  authorVerified: boolean;
  postType: 'photo' | 'video' | 'quickBurst' | 'text' | 'story' | 'live';
  title: string;
  caption: string;
  mediaUrl: string;
  thumbnailUrl: string;
  aspectRatio: '1:1' | '4:5' | '16:9' | '9:16';
  duration?: string;
  audioTrack?: string;
  hashtags: string[];
  location: string;
  visibility: 'public' | 'subscribers' | 'private';
  allowComments: boolean;
  sparkCount: number;
  chatterCount: number;
  spreadCount: number;
  viewsCount: number;
  isSparked?: boolean;
  isStashed?: boolean;
  stashCollection?: string;
  createdAt: string;
  comments: FismCommentItem[];
  isRealVideo?: boolean;
  transcriptText?: string;
  translatedVoiceText?: string;
  translatedVoiceLang?: string;
  generatedMusicUrl?: string;
  remixCount?: number;
  isPremiumCreator?: boolean;
  algorithmBoostTier?: FismMilestoneTier;
  authorHasRedTick?: boolean;
  authorVipGoldBadge?: boolean;
  remixedFromId?: string;
  remixedFromAuthor?: string;
  greenScreenBgUrl?: string;
  shoppingLinkUrl?: string;
  shoppingProductTitle?: string;
  shoppingProductImage?: string;
  shoppingStoreName?: string;
  affiliateKeywords?: string[];
  autoBotRepliesCount?: number;
  giftDropId?: string;
  giftDrop?: FismGiftDropConfig;
  has_gift_drop?: boolean;
  is3DVrVideo?: boolean;
  connectedVideo?: FismConnectedVideoRef;
  taggedCollaborators?: FismTaggedCollaborator[];
  copyrightStatus?: 'CLEAN' | 'RESTRICTED_COPYRIGHT' | 'BLOCKED' | 'APPEAL_PENDING';
  copyrightReason?: string;
  matchedAssetTitle?: string;
  videoFingerprint?: string;
  audioFingerprint?: string;
  copyrightAppeal?: {
    status: 'pending' | 'approved' | 'rejected';
    reason: string;
    proofText: string;
    proofFileName?: string;
    submittedAt: string;
    reviewedAt?: string;
  };
}

export interface FismConnectedVideoRef {
  id: string;
  title: string;
  thumbnailUrl: string;
  postType: 'photo' | 'video' | 'quickBurst' | 'text' | 'story' | 'live';
  authorUsername?: string;
}

export interface FismTaggedCollaborator {
  uid: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  status: 'pending' | 'accepted';
}

export interface FismCopyrightAssetRecord {
  id: string;
  title: string;
  rightsHolder: string;
  videoHashPrefix: string;
  audioHashPrefix: string;
  keywords: string[];
  action: 'RESTRICTED_COPYRIGHT' | 'BLOCKED';
  createdAt: string;
}

export interface FismCopyrightViolationRecord {
  id: string;
  postId: string;
  uploaderId: string;
  uploaderUsername: string;
  videoTitle: string;
  status: 'RESTRICTED_COPYRIGHT' | 'BLOCKED' | 'APPEAL_PENDING' | 'RESTORED';
  reason: string;
  matchedAssetTitle: string;
  confidence: number;
  videoFingerprint: string;
  audioFingerprint: string;
  viewsBlockedAt: number;
  appealProofText?: string;
  appealProofFileName?: string;
  appealSubmittedAt?: string;
  createdAt: string;
}

export interface FismAiCloneAvatarProfile {
  id: string;
  ownerId: string;
  name: string;
  voicePersona: string;
  language: string;
  referenceVideoUrl: string;
  skinTone: string;
  hairColor: string;
  outfitColor: string;
  accentColor: string;
  pitchHz: number;
  speakingRate: number;
  facialLandmarksSummary: string;
  createdAt: string;
}

export interface FismAiCloneRenderedVideo {
  id: string;
  avatarId: string;
  avatarName: string;
  title: string;
  scriptText: string;
  backgroundId: string;
  lightingId: string;
  overlayTemplateId: string;
  overlayHeadline: string;
  videoUrl: string;
  audioUrl?: string;
  durationSec: number;
  createdAt: string;
}

export interface FismCommunityRoom {
  id: string;
  name: string;
  description: string;
  privacy: 'public' | 'private';
  roomType: 'community' | 'live_creator';
  creatorId: string;
  creatorUsername: string;
  creatorDisplayName: string;
  creatorAvatar: string;
  memberIds: string[];
  mutualFollowerIds: string[];
  createdAt: string;
}

export interface FismCommunityMessage {
  id: string;
  roomId: string;
  senderId: string;
  senderUsername: string;
  senderDisplayName: string;
  senderAvatar: string;
  text: string;
  messageType: 'text' | 'call_event';
  createdAt: string;
}

export interface FismGroupCallParticipant {
  uid: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  hasVideo: boolean;
  hasAudio: boolean;
  joinedAt: string;
}

export interface FismActiveGroupCall {
  callId: string;
  roomId: string;
  roomName: string;
  roomType: 'community' | 'live_creator';
  mode: 'audio' | 'video';
  initiatorId: string;
  initiatorName: string;
  initiatorAvatar: string;
  participants: FismGroupCallParticipant[];
  startedAt: string;
}

export interface FismLiveCreatorPermissionRecord {
  uid: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  canAccessLiveCreatorChat: boolean;
  grantedBy?: string;
  grantedAt?: string;
}

export interface FismAutoReplyRule {
  id: string;
  triggerText: string;
  replyText: string;
  enabled: boolean;
  createdAt: string;
}

export interface FismStoryItem {
  id: string;
  authorId: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  mediaUrl: string;
  caption: string;
  createdAt: string;
  viewed: boolean;
  sparked: boolean;
}

export interface FismChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  recipientId: string;
  text: string;
  encryptedPayload?: string;
  isAutoReply?: boolean;
  pendingManualReply?: boolean;
  awaitingManualReply?: boolean;
  mediaUrl?: string;
  messageType: 'text' | 'image' | 'video' | 'voice' | 'file' | 'location';
  reactions: string[];
  replyToText?: string;
  isRead: boolean;
  delivered: boolean;
  createdAt: string;
  lat?: number;
  lng?: number;
  accuracyMeters?: number;
  liveShareId?: string;
  liveSharingActive?: boolean;
  isSecret?: boolean;
  expiresAtMs?: number;
}

export interface FismConversation {
  userId: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  online: boolean;
  typing?: boolean;
  unreadCount: number;
  messages: FismChatMessage[];
  isSecretChat?: boolean;
  disappearAfterSeconds?: number;
}

export type FismArFilterOverlayType =
  | 'cyberpunk_sunglasses'
  | 'neon_halo'
  | 'flame_crown'
  | 'laser_visor'
  | 'cat_ears'
  | 'angel_wings'
  | 'spark_hud'
  | 'prism_glasses'
  | 'custom_mask';

export interface FismArFilterAsset {
  id: string;
  name: string;
  prompt: string;
  overlayType: FismArFilterOverlayType;
  cssFilter: string;
  primaryColor: string;
  secondaryColor: string;
  eyeOffsetX: number;
  eyeOffsetY: number;
  scale: number;
  glowIntensity: number;
  badgeText: string;
  thumbnailColor: string;
  publishedToUsers: boolean;
  createdBy: string;
  createdAt: string;
}

export type FismStudioSmartFilterMode =
  | 'off'
  | 'photo_bg'
  | 'camera_chroma'
  | 'game_chroma';

export interface FismCameraChromaPlacement {
  x: number; // Normalized 0..1 center X
  y: number; // Normalized 0..1 center Y
  scale: number; // 0.2..2.5
  rotationDeg: number; // -180..180
  locked: boolean;
}

export interface FismSavedStudioFilter {
  id: string;
  name: string;
  mode: Exclude<FismStudioSmartFilterMode, 'off'>;
  createdAt: string;
  // Photo Filter fields
  photoBgUrl?: string;
  segSensitivity?: number;
  // Camera Chroma Element fields
  elementUrl?: string;
  elementType?: 'image' | 'video';
  elementName?: string;
  chromaColor?: string;
  chromaSensitivity?: number;
  chromaSmoothness?: number;
  placement?: FismCameraChromaPlacement;
  // Game Filter fields
  gameId?: string;
  gameEngineType?: FismGameItem['engineType'];
  gameAssetUrl?: string;
  gameAssetType?: 'image' | 'video' | 'engine';
  gameFolderName?: string;
}

export interface FismLiveLocationState {
  shareId: string;
  senderId: string;
  senderName: string;
  recipientId: string;
  lat: number;
  lng: number;
  accuracyMeters: number;
  isSharing: boolean;
  updatedAt: string;
}

export interface FismPremiumProfileStyle {
  themeColorHex: string;
  customDarkAccent: boolean;
  usernameFontId: 'geometric' | 'editorial' | 'mono' | 'condensed';
  usernameEffectId: 'classic' | 'flameGradient' | 'goldShimmer' | 'royalOutline';
}

export interface FismNotificationItem {
  id: string;
  actorId: string;
  actorName: string;
  actorAvatar: string;
  notificationType:
    | 'spark'
    | 'chatter'
    | 'connect'
    | 'spread'
    | 'fuelUp'
    | 'message'
    | 'live'
    | 'mention'
    | 'upload'
    | 'collab_tag'
    | 'follow_request'
    | 'follow_accepted'
    | 'age_verified'
    | 'age_rejected';
  message: string;
  isRead: boolean;
  createdAt: string;
  targetScreen?: FismScreen;
  targetPostId?: string;
  targetUid?: string;
  collabStatus?: 'pending' | 'accepted';
  followRequestId?: string;
  followRequestStatus?: 'pending' | 'accepted' | 'declined';
}

export interface FismReportItem {
  id: string;
  reporterId: string;
  reporterName: string;
  targetId: string;
  targetLabel: string;
  targetType: 'post' | 'video' | 'comment' | 'message' | 'profile' | 'live';
  reason:
    | 'Spam'
    | 'Harassment'
    | 'Hate Speech'
    | 'Violence'
    | 'Impersonation'
    | 'Inappropriate Content'
    | 'Other';
  details: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
}

export const GENERATED_ASSETS = {
  heroCover: '/src/assets/images/fism_hero_cover_1794263961928.jpg',
  mountainPost: '/src/assets/images/fism_post_photography_1794263961714.jpg',
  studioThumb: '/src/assets/images/fism_video_thumbnail_1794263962490.jpg',
  shopHeadset: '/src/assets/images/fism_video_thumbnail_1794263962490.jpg',
  avatar1: '/src/assets/images/fism_creator_avatar_1_1794263962158.jpg',
  avatar2: '/src/assets/images/fism_creator_avatar_2_1794263963864.jpg',
};

export const INITIAL_MUSIC_TRACKS: FismMusicTrack[] = [
  {
    id: 'music_1',
    title: 'Booyah Kord Phonk Beat (Official Free Fire Sound)',
    artist: 'SRMINT482',
    uploaderUsername: 'SRMINT482',
    audioUrl: '',
    coverUrl: GENERATED_ASSETS.studioThumb,
    duration: '00:30',
    genre: 'Gaming Phonk / Bass',
    usesCount: 47200,
    createdAt: 'Trending #1 on FISM',
  },
  {
    id: 'music_2',
    title: 'Ember Pulse – Midnight Cyber Synthwave',
    artist: 'Arian Vance',
    uploaderUsername: 'arian_vance',
    audioUrl: '',
    coverUrl: GENERATED_ASSETS.heroCover,
    duration: '00:45',
    genre: 'Electronic / Synth',
    usesCount: 18400,
    createdAt: '2 hours ago',
  },
  {
    id: 'music_3',
    title: 'Alpine Wind & Cinematic Strings (4K HDR Score)',
    artist: 'Elena Rostova',
    uploaderUsername: 'elena_rostova',
    audioUrl: '',
    coverUrl: GENERATED_ASSETS.mountainPost,
    duration: '00:38',
    genre: 'Cinematic / Ambient',
    usesCount: 12900,
    createdAt: '5 hours ago',
  },
  {
    id: 'music_4',
    title: 'Desi Flute Trap x Neon Bass Drop',
    artist: 'Kael Ignite Studio',
    uploaderUsername: 'kael_ignite',
    audioUrl: '',
    coverUrl: GENERATED_ASSETS.avatar1,
    duration: '00:28',
    genre: 'Hip-Hop / Desi Trap',
    usesCount: 31500,
    createdAt: '1 day ago',
  },
];

export const INITIAL_CREATORS: FismCreator[] = [
  {
    uid: 'creator_srmint',
    username: 'SRMINT482',
    displayName: 'SR OM SAMAR (@SRMINT482)',
    bio: 'Pro Esports & Free Fire Booyah Creator 🔥 Kord Clutch Specialist & Quick Burst Viral Star.',
    avatarUrl: GENERATED_ASSETS.avatar1,
    coverUrl: GENERATED_ASSETS.studioThumb,
    location: 'Mumbai, India',
    website: 'https://fism.social/@SRMINT482',
    isVerified: true,
    isPrivate: false,
    sparksCount: 482000,
    flamesCount: 120,
    fuelersCount: 9420,
    monthlyPrice: 4.99,
    isConnected: false,
    isFuelledUp: true,
    joinedAtIso: '2021-06-15T10:00:00.000Z',
    milestoneTier: 'red',
    hasRedMilestoneTick: true,
    equippedFrame: 'red_cyberpunk',
    vipGoldBadgeUnlocked: true,
    algorithmBoostTier: 'red',
  },
  {
    uid: 'creator_arian',
    username: 'arian_vance',
    displayName: 'Arian Vance',
    bio: 'Visual Director & Synth Architect. Capturing golden-hour cinema and modular soundscapes on FISM.',
    avatarUrl: GENERATED_ASSETS.avatar1,
    coverUrl: GENERATED_ASSETS.heroCover,
    location: 'San Francisco, CA',
    website: 'https://fism.social/@arian_vance',
    isVerified: true,
    isPrivate: false,
    sparksCount: 148200,
    flamesCount: 412,
    fuelersCount: 3890,
    monthlyPrice: 4.99,
    isConnected: true,
    isFuelledUp: true,
    joinedAtIso: '2023-09-10T10:00:00.000Z',
    milestoneTier: 'platinum',
    hasRedMilestoneTick: true,
    equippedFrame: 'platinum_aura',
    vipGoldBadgeUnlocked: false,
    algorithmBoostTier: 'platinum',
  },
  {
    uid: 'creator_elena',
    username: 'elena_rostova',
    displayName: 'Elena Rostova',
    bio: 'Alpine documentary photographer, expedition filmmaker & spatial creator. Sharing raw moments.',
    avatarUrl: GENERATED_ASSETS.avatar2,
    coverUrl: GENERATED_ASSETS.mountainPost,
    location: 'Zurich, Switzerland',
    website: 'https://fism.social/@elena_rostova',
    isVerified: true,
    isPrivate: false,
    sparksCount: 294500,
    flamesCount: 285,
    fuelersCount: 6410,
    monthlyPrice: 6.99,
    isConnected: true,
    isFuelledUp: false,
    joinedAtIso: '2022-08-20T10:00:00.000Z',
    milestoneTier: 'gold',
    hasRedMilestoneTick: true,
    equippedFrame: 'gold_vip',
    vipGoldBadgeUnlocked: true,
    algorithmBoostTier: 'gold',
  },
  {
    uid: 'creator_kael',
    username: 'kael_ignite',
    displayName: 'Kael Ignite Studio',
    bio: 'Next-gen 3D motion graphics, spatial computing & live electronic sets.',
    avatarUrl: GENERATED_ASSETS.avatar1,
    coverUrl: GENERATED_ASSETS.studioThumb,
    location: 'Tokyo, Japan',
    website: 'https://fism.social/@kael_ignite',
    isVerified: true,
    isPrivate: false,
    sparksCount: 92400,
    flamesCount: 190,
    fuelersCount: 1920,
    monthlyPrice: 5.99,
    isConnected: false,
    isFuelledUp: false,
    joinedAtIso: '2025-05-01T10:00:00.000Z',
    milestoneTier: 'bronze',
    hasRedMilestoneTick: true,
    equippedFrame: 'first_year_bronze',
    vipGoldBadgeUnlocked: false,
    algorithmBoostTier: 'bronze',
  },
  {
    uid: 'creator_zara',
    username: 'zara_private',
    displayName: 'Zara Ember (Private Vault)',
    bio: 'Private Backstage Creator Vault 🔒 Request to Follow so you can unlock my exclusive Sparks, Main Blast reels & Quick Bursts.',
    avatarUrl: GENERATED_ASSETS.avatar2,
    coverUrl: GENERATED_ASSETS.studioThumb,
    location: 'Bengaluru, India',
    website: 'https://fism.social/@zara_private',
    isVerified: true,
    isPrivate: true,
    isAgeVerified: true,
    sparksCount: 18400,
    flamesCount: 74,
    fuelersCount: 620,
    monthlyPrice: 4.99,
    isConnected: false,
    isFuelledUp: false,
    joinedAtIso: '2026-06-15T10:00:00.000Z',
    milestoneTier: 'none',
    hasRedMilestoneTick: false,
    equippedFrame: 'none',
    vipGoldBadgeUnlocked: false,
    algorithmBoostTier: 'none',
  },
];

export const INITIAL_STORIES: FismStoryItem[] = [
  {
    id: 'story_1',
    authorId: 'creator_elena',
    username: 'elena_rostova',
    displayName: 'Elena Rostova',
    avatarUrl: GENERATED_ASSETS.avatar2,
    mediaUrl: GENERATED_ASSETS.mountainPost,
    caption: 'Sunrise at 3,800m above the Chamonix cloud sea. Zero filters needed.',
    createdAt: '18m ago',
    viewed: false,
    sparked: false,
  },
  {
    id: 'story_2',
    authorId: 'creator_arian',
    username: 'arian_vance',
    displayName: 'Arian Vance',
    avatarUrl: GENERATED_ASSETS.avatar1,
    mediaUrl: GENERATED_ASSETS.heroCover,
    caption: 'Dialing in the new cinema camera rig for tonight’s Main Blast premiere!',
    createdAt: '42m ago',
    viewed: false,
    sparked: true,
  },
  {
    id: 'story_3',
    authorId: 'creator_kael',
    username: 'kael_ignite',
    displayName: 'Kael Ignite Studio',
    avatarUrl: GENERATED_ASSETS.avatar1,
    mediaUrl: GENERATED_ASSETS.studioThumb,
    caption: 'Live modular synth patch ready for Quick Burst.',
    createdAt: '1h ago',
    viewed: true,
    sparked: false,
  },
];

export const INITIAL_POSTS: FismPostItem[] = [
  {
    id: 'post_srmint_booyah',
    authorId: 'creator_srmint',
    authorUsername: 'SRMINT482',
    authorDisplayName: 'SR OM SAMAR',
    authorAvatar: GENERATED_ASSETS.avatar1,
    authorVerified: true,
    postType: 'quickBurst',
    title: 'Booyah with kord 😜 #freefire #funny #shorts',
    caption: 'Booyah with kord 😜 #freefire #funny #shorts #booyah #gaming',
    mediaUrl: '',
    thumbnailUrl: GENERATED_ASSETS.studioThumb,
    aspectRatio: '9:16',
    duration: '00:15',
    audioTrack: 'Booyah Kord Phonk Beat – @SRMINT482',
    hashtags: ['#freefire', '#funny', '#shorts', '#booyah'],
    location: 'Mumbai, India',
    visibility: 'public',
    allowComments: true,
    sparkCount: 82000,
    chatterCount: 240,
    spreadCount: 4120,
    viewsCount: 1480000,
    remixCount: 47,
    isPremiumCreator: true,
    has_gift_drop: true,
    isSparked: false,
    isStashed: false,
    createdAt: '1 hour ago',
    comments: [
      {
        id: 'c_sr1',
        postId: 'post_srmint_booyah',
        authorId: 'creator_arian',
        authorUsername: 'arian_vance',
        authorAvatar: GENERATED_ASSETS.avatar1,
        text: 'Insane Kord gloo-wall clutch! 🔥🔥 1.4M+ views well deserved!',
        createdAt: '12m ago',
      },
    ],
  },
  {
    id: 'post_1',
    authorId: 'creator_elena',
    authorUsername: 'elena_rostova',
    authorDisplayName: 'Elena Rostova',
    authorAvatar: GENERATED_ASSETS.avatar2,
    authorVerified: true,
    postType: 'photo',
    title: 'Above the Golden Cloud Sea',
    caption:
      'Climbed through freezing pre-dawn winds to catch the first warm ember rays hitting the ridge. When the clouds ignite like liquid gold, every step is worth it.',
    mediaUrl: GENERATED_ASSETS.mountainPost,
    thumbnailUrl: GENERATED_ASSETS.mountainPost,
    aspectRatio: '16:9',
    hashtags: ['#AlpineFlame', '#GoldenHour', '#Documentary', '#FISMPhotography'],
    location: 'Mont Blanc Massif, Alps',
    visibility: 'public',
    allowComments: true,
    sparkCount: 94829,
    chatterCount: 1142,
    spreadCount: 3318,
    viewsCount: 1280400,
    remixCount: 19,
    isPremiumCreator: true,
    isSparked: true,
    isStashed: false,
    createdAt: '25 minutes ago',
    comments: [
      {
        id: 'c_1',
        postId: 'post_1',
        authorId: 'creator_arian',
        authorUsername: 'arian_vance',
        authorAvatar: GENERATED_ASSETS.avatar1,
        text: 'The dynamic range on those cloud highlights is extraordinary!',
        createdAt: '19m ago',
      },
    ],
  },
  {
    id: 'post_2',
    authorId: 'creator_arian',
    authorUsername: 'arian_vance',
    authorDisplayName: 'Arian Vance',
    authorAvatar: GENERATED_ASSETS.avatar1,
    authorVerified: true,
    postType: 'video',
    title: 'Inside the Flame Creative Studio: 8K Cinema Rig & Synth Architecture',
    caption:
      'Full breakdown of our hybrid analog-digital studio setup, dual-color key lighting, and how we score real-time visuals for Main Blast.',
    mediaUrl: '',
    thumbnailUrl: GENERATED_ASSETS.heroCover,
    aspectRatio: '16:9',
    duration: '12:45',
    audioTrack: 'Original Studio Master – Arian Vance',
    hashtags: ['#MainBlast', '#StudioTour', '#Filmmaking', '#FISMCreators'],
    location: 'San Francisco, CA',
    visibility: 'public',
    allowComments: true,
    sparkCount: 119340,
    chatterCount: 2418,
    spreadCount: 5812,
    viewsCount: 1640200,
    remixCount: 84,
    isPremiumCreator: true,
    shoppingLinkUrl: 'https://fism.social/shop/prod_1-8k-cinema-rig',
    shoppingProductTitle: '8K Cinema Camera Cage & Dual-Color RGB Studio Light Kit',
    shoppingProductImage: GENERATED_ASSETS.heroCover,
    shoppingStoreName: 'FISM Verified Creator Store',
    has_gift_drop: true,
    isSparked: false,
    isStashed: true,
    stashCollection: 'Studio Inspiration',
    createdAt: '2 hours ago',
    comments: [
      {
        id: 'c_2',
        postId: 'post_2',
        authorId: 'creator_elena',
        authorUsername: 'elena_rostova',
        authorAvatar: GENERATED_ASSETS.avatar2,
        text: 'That softbox + purple rim light combination looks incredible on camera.',
        createdAt: '1h ago',
      },
    ],
  },
  {
    id: 'post_3',
    authorId: 'creator_kael',
    authorUsername: 'kael_ignite',
    authorDisplayName: 'Kael Ignite Studio',
    authorAvatar: GENERATED_ASSETS.avatar1,
    authorVerified: true,
    postType: 'video',
    title: 'Future Beats Live Session: Analog Polysynth & Spatial Visuals',
    caption:
      'Recorded live in one take at midnight. Put on studio headphones and experience the full bass response.',
    mediaUrl: '',
    thumbnailUrl: GENERATED_ASSETS.studioThumb,
    aspectRatio: '16:9',
    duration: '08:19',
    audioTrack: 'Future Beats 8K Session – Kael Ignite',
    hashtags: ['#FutureBeats', '#Synthwave', '#MainBlast', '#LiveSession'],
    location: 'Shibuya, Tokyo',
    visibility: 'subscribers',
    allowComments: true,
    sparkCount: 61500,
    chatterCount: 289,
    spreadCount: 540,
    viewsCount: 1189300,
    remixCount: 12,
    isPremiumCreator: true,
    isSparked: false,
    isStashed: false,
    createdAt: '4 hours ago',
    comments: [],
  },
  {
    id: 'post_4',
    authorId: 'creator_arian',
    authorUsername: 'arian_vance',
    authorDisplayName: 'Arian Vance',
    authorAvatar: GENERATED_ASSETS.avatar1,
    authorVerified: true,
    postType: 'quickBurst',
    title: '60-Second Lighting Transformation',
    caption: 'How two LED tubes + a warm key light transform a flat room into a cinematic set in 60 seconds.',
    mediaUrl: '',
    thumbnailUrl: GENERATED_ASSETS.heroCover,
    aspectRatio: '9:16',
    duration: '00:45',
    audioTrack: 'Ember Pulse (Original Audio) – arian_vance',
    hashtags: ['#QuickBurst', '#LightingHacks', '#Cinematography'],
    location: 'San Francisco, CA',
    visibility: 'public',
    allowComments: true,
    sparkCount: 18400,
    chatterCount: 612,
    spreadCount: 1490,
    viewsCount: 1120500,
    remixCount: 31,
    isPremiumCreator: true,
    shoppingLinkUrl: 'https://fism.social/shop/prod_1-rgb-light-kit',
    shoppingProductTitle: '8K Cinema Camera Cage & Dual-Color RGB Studio Light Kit',
    shoppingProductImage: GENERATED_ASSETS.heroCover,
    shoppingStoreName: 'FISM Verified Creator Store',
    isSparked: true,
    isStashed: false,
    createdAt: '5 hours ago',
    comments: [],
  },
  {
    id: 'post_5',
    authorId: 'creator_elena',
    authorUsername: 'elena_rostova',
    authorDisplayName: 'Elena Rostova',
    authorAvatar: GENERATED_ASSETS.avatar2,
    authorVerified: true,
    postType: 'quickBurst',
    title: 'Ridge Walk Above the Clouds',
    caption: 'Vertical POV walking the summit ridge as the sun breaks over the horizon.',
    mediaUrl: '',
    thumbnailUrl: GENERATED_ASSETS.mountainPost,
    aspectRatio: '9:16',
    duration: '00:38',
    audioTrack: 'Alpine Wind & Strings – elena_rostova',
    hashtags: ['#QuickBurst', '#MountainPOV', '#Adventure'],
    location: 'Chamonix, France',
    visibility: 'public',
    allowComments: true,
    sparkCount: 24900,
    chatterCount: 834,
    spreadCount: 2100,
    viewsCount: 1390100,
    remixCount: 26,
    isPremiumCreator: true,
    isSparked: false,
    isStashed: true,
    stashCollection: 'Travel & Peaks',
    createdAt: '7 hours ago',
    comments: [],
  },
  {
    id: 'post_zara_private_1',
    authorId: 'creator_zara',
    authorUsername: 'zara_private',
    authorDisplayName: 'Zara Ember (Private Vault)',
    authorAvatar: GENERATED_ASSETS.avatar2,
    authorVerified: true,
    postType: 'photo',
    title: 'Private Vault: Backstage Neon Light Rig & Unreleased Setlist',
    caption: 'Exclusive backstage photo post visible ONLY to approved followers of @zara_private.',
    mediaUrl: GENERATED_ASSETS.studioThumb,
    thumbnailUrl: GENERATED_ASSETS.studioThumb,
    aspectRatio: '16:9',
    hashtags: ['#PrivateVault', '#FollowersOnly', '#FISMExclusive'],
    location: 'Bengaluru, India',
    visibility: 'private',
    allowComments: true,
    sparkCount: 4120,
    chatterCount: 184,
    spreadCount: 0,
    viewsCount: 1040000,
    isPremiumCreator: true,
    isSparked: false,
    isStashed: false,
    createdAt: '32 mins ago',
    comments: [],
  },
];

export const INITIAL_SHOPPING_PRODUCTS: FismShoppingProduct[] = [
  {
    id: 'prod_1',
    title: '8K Cinema Camera Cage & Dual-Color RGB Studio Light Kit',
    description:
      'Complete creator production bundle with 3x RGB tube lights, carbon tripod, and wireless mic receiver. Tested on Main Blast studio shoots.',
    price: '₹42,999 ($510)',
    photos: [
      GENERATED_ASSETS.heroCover,
      GENERATED_ASSETS.studioThumb,
      GENERATED_ASSETS.mountainPost,
    ],
    videoUrl: GENERATED_ASSETS.heroCover,
    videoTitle: 'Full 60s Lighting & Camera Rig Demo Video (1080p)',
    sellerId: 'creator_arian',
    sellerName: 'Arian Vance',
    sellerAvatar: GENERATED_ASSETS.avatar1,
    phoneNumber: '+91 98765 43210',
    email: 'arian.studio@fism.social',
    locationLabel: 'Cyber Hub Studio, Gurugram / San Francisco',
    lat: 28.495,
    lng: 77.089,
    createdAt: '14 mins ago',
  },
  {
    id: 'prod_2',
    title: 'Alpine Carbon Drone 4K + Waterproof Action Gimbal Pack',
    description:
      'Ultra-light foldable expedition drone with 45-min flight battery, ND filter set, and 1-inch sensor. Ready for immediate pickup or delivery.',
    price: '₹64,500 ($769)',
    photos: [
      GENERATED_ASSETS.mountainPost,
      GENERATED_ASSETS.heroCover,
    ],
    videoUrl: GENERATED_ASSETS.mountainPost,
    videoTitle: 'Chamonix Summit Flight Test Video (4K 60fps)',
    sellerId: 'creator_elena',
    sellerName: 'Elena Rostova',
    sellerAvatar: GENERATED_ASSETS.avatar2,
    phoneNumber: '+91 91234 56789',
    email: 'elena.expedition@fism.social',
    locationLabel: 'Connaught Place Creator Hub, New Delhi',
    lat: 28.6315,
    lng: 77.2167,
    createdAt: '1 hour ago',
  },
];

export const INITIAL_ADMIN_USER_DOSSIERS: FismAdminUserDossier[] = [
  {
    uid: 'creator_arian',
    username: 'arian_vance',
    displayName: 'Arian Vance',
    avatarUrl: GENERATED_ASSETS.avatar1,
    email: 'arian.vance@fism.social',
    passwordRecord: 'FISM-HASH#av9928$FlameKey',
    phoneNumber: '+91 98765 43210',
    bio: 'Visual Director & Synth Architect. Capturing golden-hour cinema and modular soundscapes on FISM.',
    isBanned: false,
    liveStatusText: 'ONLINE • Browsing Main Blast & Shopping',
    videosUploadedCount: 38,
    sparksFollowersCount: 148200,
    flamesFollowingCount: 412,
    whatUsedSummary: 'Main Blast 8K Video Player, Gemini AI Studio, Shopping Seller Listing, Ember Chat Video Call',
    whyUsedSummary: 'Uploaded studio lighting tutorial, listed RGB camera rig in Shopping, and hosted live Q&A.',
    watchHistory: [
      {
        videoTitle: 'Inside the Flame Creative Studio: 8K Cinema Rig',
        watchedAtDate: '2026-11-09',
        watchedAtTime: '14:42:18 IST',
        durationWatched: '12m 45s (100%)',
      },
      {
        videoTitle: 'Ridge Walk Above the Clouds (Quick Burst)',
        watchedAtDate: '2026-11-09',
        watchedAtTime: '13:15:04 IST',
        durationWatched: '00m 38s (100%)',
      },
      {
        videoTitle: 'Future Beats Live Session: Analog Polysynth',
        watchedAtDate: '2026-11-08',
        watchedAtTime: '22:09:51 IST',
        durationWatched: '07m 12s (88%)',
      },
    ],
  },
  {
    uid: 'creator_elena',
    username: 'elena_rostova',
    displayName: 'Elena Rostova',
    avatarUrl: GENERATED_ASSETS.avatar2,
    email: 'elena.rostova@fism.social',
    passwordRecord: 'FISM-HASH#er7741$AlpineKey',
    phoneNumber: '+91 91234 56789',
    bio: 'Alpine documentary photographer, expedition filmmaker & spatial creator. Sharing raw moments.',
    isBanned: false,
    liveStatusText: 'ONLINE • Active in Ember Chat & Emoji Blast Game',
    videosUploadedCount: 64,
    sparksFollowersCount: 294500,
    flamesFollowingCount: 285,
    whatUsedSummary: 'Quick Burst Vertical Feed, Ember Chat Emoji Blast Game, Google Maps Grounding, Ash Stash',
    whyUsedSummary: 'Scouted alpine photography locations on Maps and chatted with followers in Ember Chat.',
    watchHistory: [
      {
        videoTitle: '60-Second Lighting Transformation',
        watchedAtDate: '2026-11-09',
        watchedAtTime: '15:05:30 IST',
        durationWatched: '00m 45s (100%)',
      },
      {
        videoTitle: 'Above the Golden Cloud Sea Documentary',
        watchedAtDate: '2026-11-09',
        watchedAtTime: '11:20:10 IST',
        durationWatched: '18m 10s (95%)',
      },
    ],
  },
  {
    uid: 'creator_kael',
    username: 'kael_ignite',
    displayName: 'Kael Ignite Studio',
    avatarUrl: GENERATED_ASSETS.avatar1,
    email: 'kael.ignite@fism.social',
    passwordRecord: 'FISM-HASH#ki5503$SynthKey',
    phoneNumber: '+91 99887 76655',
    bio: 'Next-gen 3D motion graphics, spatial computing & live electronic sets.',
    isBanned: true,
    liveStatusText: 'RESTRICTED • Flagged for automated spam link test',
    videosUploadedCount: 19,
    sparksFollowersCount: 92400,
    flamesFollowingCount: 190,
    whatUsedSummary: '3D & XR Spatial Arena, On Fire Live Broadcast, Fuel Up Subscriptions',
    whyUsedSummary: 'Streamed live modular synth session and tested 3D Ember Cruiser arena.',
    watchHistory: [
      {
        videoTitle: 'Future Beats Live Session: Analog Polysynth',
        watchedAtDate: '2026-11-09',
        watchedAtTime: '10:02:44 IST',
        durationWatched: '08m 19s (100%)',
      },
    ],
  },
];

export const INITIAL_GAMES: FismGameItem[] = [
  {
    id: 'game_flame_runner_2d',
    name: 'Flame Runner 2D',
    title: 'Flame Runner 2D: Cyber Rooftop Dash & Fireball Blaster',
    description:
      'High-speed 2D side-scrolling arcade action! Jump over laser drones, shoot plasma fireballs, and collect glowing Flame Orbs.',
    category: '2D Action Platformer',
    folderName: '/games/flame-runner-2d',
    filesCount: 14,
    uploadedByAdmin: true,
    createdAt: 'Official 2D Build',
    engineType: 'flameRunner2D',
  },
  {
    id: 'game_brick_breaker_2d',
    name: 'Ember Brick Breaker 2D',
    title: 'Ember Brick Breaker 2D: Neon Arcade Reactor Smash',
    description:
      'Classic 2D physics paddle & ball brick-smashing arcade with combo multipliers, explosive ember blocks, and 3 lives.',
    category: '2D Physics Arcade',
    folderName: '/games/ember-brick-breaker-2d',
    filesCount: 11,
    uploadedByAdmin: true,
    createdAt: 'Official 2D Build',
    engineType: 'brickBreaker2D',
  },
  {
    id: 'game_cyber_snake_2d',
    name: 'Neon Flame Snake 2D',
    title: 'Neon Flame Snake 2D: Hyper-Grid Arena',
    description:
      'Navigate the glowing 2D cyber grid, absorb energy cores, grow your flame trail, and set a new high score without crashing!',
    category: '2D Classic Grid Arcade',
    folderName: '/games/neon-flame-snake-2d',
    filesCount: 9,
    uploadedByAdmin: true,
    createdAt: 'Official 2D Build',
    engineType: 'cyberSnake2D',
  },
  {
    id: 'game_red_ball_2d',
    name: 'Red Ball Defense 2D',
    title: 'Red Ball (लाल गेंद) 2D Emoji Blast Defense',
    description:
      'Protect the center Red Ball from waves of incoming emojis! 3 lives, rapid combo blasts, and arcade sound effects.',
    category: '2D Reflex Defense',
    folderName: '/games/red-ball-defense-2d',
    filesCount: 8,
    uploadedByAdmin: true,
    createdAt: 'Official 2D Build',
    engineType: 'redBallDefense2D',
  },
];

export const INITIAL_PUBLISHED_AR_FILTERS: FismArFilterAsset[] = [
  {
    id: 'ar_cyber_shades_01',
    name: 'Cyberpunk Shades',
    prompt: 'Add glowing cyberpunk sunglasses on the face',
    overlayType: 'cyberpunk_sunglasses',
    cssFilter: 'contrast(1.18) saturate(1.45)',
    primaryColor: '#00F5D4',
    secondaryColor: '#FF2A85',
    eyeOffsetX: 0,
    eyeOffsetY: -6,
    scale: 1.0,
    glowIntensity: 20,
    badgeText: 'CYBER AR',
    thumbnailColor: '#00F5D4',
    publishedToUsers: true,
    createdBy: 'FISM Official AI Studio',
    createdAt: 'Official AR Pack',
  },
  {
    id: 'ar_flame_crown_02',
    name: 'Inferno Crown',
    prompt: 'Glowing orange flame halo crown with ember particles',
    overlayType: 'flame_crown',
    cssFilter: 'saturate(1.35) brightness(1.06)',
    primaryColor: '#FF5722',
    secondaryColor: '#FFB300',
    eyeOffsetX: 0,
    eyeOffsetY: -8,
    scale: 1.0,
    glowIntensity: 22,
    badgeText: 'FLAME VIP',
    thumbnailColor: '#FF5722',
    publishedToUsers: true,
    createdBy: 'FISM Official AI Studio',
    createdAt: 'Official AR Pack',
  },
];

export type FismSmartAdPlacement = 'longVideo' | 'quickBurst' | 'banner';

export interface FismSmartAdItem {
  id: string;
  source: 'official' | 'creator';
  placement: FismSmartAdPlacement;
  title: string;
  description: string;
  mediaUrl: string;
  isVideo: boolean;
  productLinkUrl: string;
  ctaLabel: string;
  storePlatform: 'Amazon' | 'Flipkart' | 'Meesho' | 'FISM Store' | 'Official';
  categoryTags: string[];
  creatorId: string;
  creatorUsername: string;
  creatorDisplayName: string;
  creatorAvatar: string;
  isActive: boolean;
  impressions: number;
  clicks: number;
  likes: number;
  isLiked?: boolean;
  createdAt: string;
}

export interface FismAffiliateStoreConfig {
  userId: string;
  amazonAffiliateUrl: string;
  amazonTag: string;
  flipkartAffiliateUrl: string;
  flipkartId: string;
  meeshoAffiliateUrl: string;
  meeshoCode: string;
  updatedAt: string;
}

export interface FismUserBehaviorProfile {
  watchTimeByCategory: Record<string, number>;
  likedTags: Record<string, number>;
  gameInterests: Record<string, number>;
  searchTags: string[];
  engagedPostIds: string[];
}

export const INITIAL_SMART_ADS: FismSmartAdItem[] = [
  {
    id: 'ad_official_gaming_long_1',
    source: 'official',
    placement: 'longVideo',
    title: '🎮 Pro RGB Gaming Headset & Zero-Lag Controller Kit',
    description:
      'Matched to your Gaming & Esports interests! Spatial 7.1 sound + creator discount bundle.',
    mediaUrl:
      'https://assets.mixkit.co/videos/preview/mixkit-gamer-playing-on-a-console-43527-large.mp4',
    isVideo: true,
    productLinkUrl: 'https://www.amazon.in/s?k=gaming+headset',
    ctaLabel: 'Shop Gaming Gear',
    storePlatform: 'Amazon',
    categoryTags: ['gaming', 'esports', 'tech', 'headset'],
    creatorId: 'fism_official',
    creatorUsername: 'fism_official',
    creatorDisplayName: 'FISM Official Ads',
    creatorAvatar: GENERATED_ASSETS.avatar1,
    isActive: true,
    impressions: 1420,
    clicks: 184,
    likes: 92,
    createdAt: 'Official Campaign',
  },
  {
    id: 'ad_creator_tech_long_2',
    source: 'creator',
    placement: 'longVideo',
    title: '🎥 Arian Creator 4K Streaming Mic & RGB Ring Light',
    description:
      'Creator Sponsored Pick • Built for crystal-clear Main Blast & On Fire Live streams.',
    mediaUrl: GENERATED_ASSETS.shopHeadset,
    isVideo: false,
    productLinkUrl: 'https://www.flipkart.com/search?q=streaming+microphone',
    ctaLabel: 'Buy on Flipkart',
    storePlatform: 'Flipkart',
    categoryTags: ['tech', 'creator', 'audio', 'music'],
    creatorId: 'creator_arian',
    creatorUsername: 'arian_flame',
    creatorDisplayName: 'Arian Flame',
    creatorAvatar: GENERATED_ASSETS.avatar1,
    isActive: true,
    impressions: 980,
    clicks: 112,
    likes: 64,
    createdAt: 'Creator Campaign',
  },
  {
    id: 'ad_official_quickburst_gaming_1',
    source: 'official',
    placement: 'quickBurst',
    title: '⚡ Ultra-Fast Mobile Cooling Trigger & Esports Thumb Sleeves',
    description:
      'Keep 120FPS smooth during Free Fire & Battle Royale sessions. Tap to grab creator bundle!',
    mediaUrl:
      'https://assets.mixkit.co/videos/preview/mixkit-young-man-playing-video-games-in-a-dark-room-42388-large.mp4',
    isVideo: true,
    productLinkUrl: 'https://www.meesho.com/search?q=mobile+gaming+cooler',
    ctaLabel: 'Shop on Meesho →',
    storePlatform: 'Meesho',
    categoryTags: ['gaming', 'freefire', 'esports', 'shorts'],
    creatorId: 'fism_official',
    creatorUsername: 'fism_official',
    creatorDisplayName: 'FISM Official Gaming Ad',
    creatorAvatar: GENERATED_ASSETS.avatar2,
    isActive: true,
    impressions: 2450,
    clicks: 318,
    likes: 210,
    createdAt: 'Official Short Ad',
  },
  {
    id: 'ad_creator_quickburst_gear_2',
    source: 'creator',
    placement: 'quickBurst',
    title: '🎧 Neon Wireless Earbuds — Ultra Low Latency Mode',
    description:
      'Creator Affiliate Spotlight • Zero audio delay for Quick Burst Shorts & Music creators.',
    mediaUrl: GENERATED_ASSETS.shopHeadset,
    isVideo: false,
    productLinkUrl: 'https://www.amazon.in/s?k=wireless+gaming+earbuds',
    ctaLabel: 'Order on Amazon →',
    storePlatform: 'Amazon',
    categoryTags: ['music', 'gaming', 'tech', 'shorts'],
    creatorId: 'creator_arian',
    creatorUsername: 'arian_flame',
    creatorDisplayName: 'Arian Flame Partner',
    creatorAvatar: GENERATED_ASSETS.avatar1,
    isActive: true,
    impressions: 1620,
    clicks: 204,
    likes: 147,
    createdAt: 'Creator Short Ad',
  },
  {
    id: 'ad_official_banner_1',
    source: 'official',
    placement: 'banner',
    title: '🔥 Official FISM Partner Deal: Creator Studio RGB & VR Kit (Up to 40% Off)',
    description: 'Verified Official Banner • Instant affiliate store checkout on Amazon & Flipkart',
    mediaUrl: GENERATED_ASSETS.studioThumb,
    isVideo: false,
    productLinkUrl: 'https://www.amazon.in/s?k=creator+studio+kit',
    ctaLabel: 'Explore Deal',
    storePlatform: 'Official',
    categoryTags: ['gaming', 'tech', 'vr', 'creator'],
    creatorId: 'fism_official',
    creatorUsername: 'fism_official',
    creatorDisplayName: 'FISM Official',
    creatorAvatar: GENERATED_ASSETS.avatar1,
    isActive: true,
    impressions: 3100,
    clicks: 290,
    likes: 88,
    createdAt: 'Official Banner',
  },
];

export type FismGiftDropRewardType = 'coins' | 'photo' | 'secret_text' | 'redeem_code';

export interface FismGiftDropConfig {
  id: string;
  postId: string;
  creatorId: string;
  creatorUsername: string;
  creatorDisplayName: string;
  rewardType: FismGiftDropRewardType;
  rewardTitle: string;
  rewardValue: string; // Photo URL, Secret Text, Redeem Code, or Coin note
  coinsPerWinner: number;
  winnerLimit: number;
  claimedCount: number;
  claimedByUids: string[];
  totalCoinsDeducted: number;
  status: 'active' | 'exhausted';
  createdAt: string;
}

export interface FismCoinWallet {
  uid: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  coinBalance: number;
  totalEarnedCoins: number;
  totalDroppedCoins: number;
  premiumExpiresAt: string;
  claimedRewardIds: string[];
  updatedAt: string;
}

export interface FismClaimedGiftReceipt {
  id: string;
  dropId: string;
  postId: string;
  creatorUsername: string;
  rewardType: FismGiftDropRewardType;
  rewardTitle: string;
  rewardValue: string;
  coinsAwarded: number;
  claimedAt: string;
}

export const PREMIUM_COIN_PACK_BONUS = 10_000;
export const FREE_PREMIUM_COIN_COST = 100_000;

export const INITIAL_GIFT_DROPS: FismGiftDropConfig[] = [
  {
    id: 'drop_seed_booyah_1',
    postId: 'post_srmint_booyah',
    creatorId: 'creator_srmint',
    creatorUsername: 'SRMINT482',
    creatorDisplayName: 'SR OM SAMAR (@SRMINT482)',
    rewardType: 'coins',
    rewardTitle: 'Booyah 100 Coins First-10 Drop',
    rewardValue: 'Instant 100 FISM Wallet Coins for first 10 viewers!',
    coinsPerWinner: 100,
    winnerLimit: 10,
    claimedCount: 3,
    claimedByUids: ['seed_u1', 'seed_u2', 'seed_u3'],
    totalCoinsDeducted: 1000,
    status: 'active',
    createdAt: 'Active Drop',
  },
  {
    id: 'drop_seed_studio_2',
    postId: 'post_2',
    creatorId: 'creator_arian',
    creatorUsername: 'arian_vance',
    creatorDisplayName: 'Arian Vance',
    rewardType: 'redeem_code',
    rewardTitle: 'Creator Secret Pro Preset Redeem Code',
    rewardValue: 'FISM-PRO-8K-GIFT2026',
    coinsPerWinner: 50,
    winnerLimit: 5,
    claimedCount: 1,
    claimedByUids: ['seed_u4'],
    totalCoinsDeducted: 250,
    status: 'active',
    createdAt: 'Active Drop',
  },
];

export const INITIAL_COIN_WALLETS: FismCoinWallet[] = [
  {
    uid: 'creator_srmint',
    username: 'SRMINT482',
    displayName: 'SR OM SAMAR (@SRMINT482)',
    avatarUrl: GENERATED_ASSETS.avatar1,
    coinBalance: 142500,
    totalEarnedCoins: 165000,
    totalDroppedCoins: 22500,
    premiumExpiresAt: '2027-01-15',
    claimedRewardIds: [],
    updatedAt: 'Live Rank #1',
  },
  {
    uid: 'creator_elena',
    username: 'elena_rostova',
    displayName: 'Elena Rostova',
    avatarUrl: GENERATED_ASSETS.avatar2,
    coinBalance: 98400,
    totalEarnedCoins: 104000,
    totalDroppedCoins: 5600,
    premiumExpiresAt: '2026-12-30',
    claimedRewardIds: [],
    updatedAt: 'Live Rank #2',
  },
  {
    uid: 'creator_arian',
    username: 'arian_vance',
    displayName: 'Arian Vance',
    avatarUrl: GENERATED_ASSETS.avatar1,
    coinBalance: 64200,
    totalEarnedCoins: 72000,
    totalDroppedCoins: 7800,
    premiumExpiresAt: '2026-12-20',
    claimedRewardIds: [],
    updatedAt: 'Live Rank #3',
  },
  {
    uid: 'creator_kael',
    username: 'kael_ignite',
    displayName: 'Kael Ignite Studio',
    avatarUrl: GENERATED_ASSETS.avatar1,
    coinBalance: 38900,
    totalEarnedCoins: 42000,
    totalDroppedCoins: 3100,
    premiumExpiresAt: '',
    claimedRewardIds: [],
    updatedAt: 'Live Rank #4',
  },
];

export const PREMIUM_SP_COIN_BONUS = 500;
export const SP_SUPER_CHAT_COST = 50;
export const CHANNEL_MEMBERSHIP_SP_COST = 500;

export interface FismSpCoinBuyPack {
  id: string;
  spCoins: number;
  priceInr: number;
  label: string;
  badge: string;
}

export const SP_COIN_BUY_PACKS: FismSpCoinBuyPack[] = [
  { id: 'sp_500', spCoins: 500, priceInr: 100, label: '500 SP Coins', badge: 'Starter Pack' },
  { id: 'sp_1000', spCoins: 1000, priceInr: 190, label: '1,000 SP Coins', badge: 'Save ₹10' },
  { id: 'sp_2000', spCoins: 2000, priceInr: 360, label: '2,000 SP Coins', badge: 'Popular' },
  { id: 'sp_5000', spCoins: 5000, priceInr: 850, label: '5,000 SP Coins', badge: 'Creator Value' },
  { id: 'sp_10000', spCoins: 10000, priceInr: 1600, label: '10,000 SP Coins', badge: 'VIP Pro Pack' },
];

export type FismSuperChatBoxStyle =
  | 'amber_flame'
  | 'royal_violet'
  | 'emerald_surge'
  | 'crimson_nova';

export interface FismSuperChatBoxTier {
  id: FismSuperChatBoxStyle;
  label: string;
  cardClass: string;
  badgeBg: string;
}

export const SUPER_CHAT_BOX_TIERS: FismSuperChatBoxTier[] = [
  {
    id: 'amber_flame',
    label: 'Amber Flame',
    cardClass: 'bg-gradient-to-r from-[#FF5722] to-[#F59E0B] text-white border-[#FDE047]',
    badgeBg: 'bg-black/35 text-[#FDE047]',
  },
  {
    id: 'royal_violet',
    label: 'Royal Violet',
    cardClass: 'bg-gradient-to-r from-[#7C3AED] to-[#EC4899] text-white border-[#F9A8D4]',
    badgeBg: 'bg-black/35 text-pink-200',
  },
  {
    id: 'emerald_surge',
    label: 'Emerald Surge',
    cardClass: 'bg-gradient-to-r from-[#059669] to-[#0EA5E9] text-white border-[#6EE7B7]',
    badgeBg: 'bg-black/35 text-emerald-200',
  },
  {
    id: 'crimson_nova',
    label: 'Crimson Nova',
    cardClass: 'bg-gradient-to-r from-[#DC2626] to-[#9333EA] text-white border-[#FCA5A5]',
    badgeBg: 'bg-black/35 text-amber-200',
  },
];

export interface FismSuperStickerOption {
  id: string;
  label: string;
  emoji: string;
  cardGradient: string;
}

export const SUPER_STICKER_OPTIONS: FismSuperStickerOption[] = [
  { id: 'stk_crown', label: 'Inferno Crown', emoji: '👑', cardGradient: 'from-[#F59E0B] to-[#FF5722]' },
  { id: 'stk_booyah', label: 'Booyah Clutch', emoji: '🔥', cardGradient: 'from-[#E53935] to-[#EC4899]' },
  { id: 'stk_diamond', label: 'Diamond Drop', emoji: '💎', cardGradient: 'from-[#06B6D4] to-[#2563EB]' },
  { id: 'stk_rocket', label: 'Rocket Fuel', emoji: '🚀', cardGradient: 'from-[#7C3AED] to-[#4F46E5]' },
  { id: 'stk_vip', label: 'VIP Respect', emoji: '⚡', cardGradient: 'from-[#10B981] to-[#059669]' },
  { id: 'stk_mvp', label: 'Pro MVP', emoji: '🏆', cardGradient: 'from-[#D97706] to-[#B45309]' },
];

export interface FismSuperChatMessage {
  id: string;
  streamId: string;
  senderUid: string;
  senderUsername: string;
  senderDisplayName: string;
  senderAvatar: string;
  text: string;
  kind: 'superchat' | 'sticker';
  boxStyle: FismSuperChatBoxStyle;
  stickerId?: string;
  stickerLabel?: string;
  stickerEmoji?: string;
  spCost: number;
  createdAt: string;
}

export interface FismChannelMembership {
  id: string;
  memberUid: string;
  memberUsername: string;
  memberDisplayName: string;
  memberAvatar: string;
  creatorUid: string;
  creatorUsername: string;
  creatorDisplayName: string;
  creatorAvatar: string;
  spCost: number;
  joinedAt: string;
}

export interface FismSpCoinWallet {
  uid: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  spCoins: number;
  totalSpPurchased: number;
  totalSpSpent: number;
  updatedAt: string;
}

export type FismMilestoneTier = 'none' | 'bronze' | 'silver' | 'platinum' | 'gold' | 'red';

export type FismProfileFrameId =
  | 'none'
  | 'first_year_bronze'
  | 'silver_glass'
  | 'platinum_aura'
  | 'gold_vip'
  | 'red_cyberpunk';

export interface FismMilestoneTierConfig {
  tier: Exclude<FismMilestoneTier, 'none'>;
  minYears: number;
  yearLabel: string;
  cardName: string;
  badgeTitle: string;
  spReward: number;
  frameId: Exclude<FismProfileFrameId, 'none'>;
  algorithmBoostPoints: number;
  aestheticSummary: string;
  perks: string[];
}

export interface FismFounderGiftClaim {
  id: string;
  userId: string;
  username: string;
  displayName: string;
  giftItem: string;
  shippingNote: string;
  status: 'pending' | 'approved' | 'shipped';
  claimedAt: string;
  adminNote?: string;
}

export interface FismDailyCheckInRecord {
  dayNumber: number;
  dateIso: string;
  checkedInAtIso: string;
  lat: number;
  lng: number;
  locationLabel: string;
  cycleRefreshHour: number;
}

export interface FismMilestoneYearScheduleItem {
  yearNumber: 1 | 2 | 3 | 4 | 5;
  tier: Exclude<FismMilestoneTier, 'none'>;
  yearLabel: string;
  cardName: string;
  daysInThatYear: 365 | 366;
  isLeapYearIncluded: boolean;
  leapYearDateIso?: string;
  cumulativeDaysRequired: number;
  unlockDateIso: string;
  daysCompleted: number;
  daysRemaining: number;
  progressPct: number;
  unlocked: boolean;
}

export interface FismUserMilestoneState {
  accountId: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  joinedAtIso: string;
  tenureYears: number;
  tenureDays: number;
  verifiedCheckInDays?: number;
  dailyStreakCount?: number;
  firstCheckinAtIso?: string;
  lastCheckinAtIso?: string;
  nextCheckinUnlockAtIso?: string;
  lastCheckinLocationLabel?: string;
  lastCheckinLat?: number;
  lastCheckinLng?: number;
  dailyRefreshHourLocal?: number;
  checkInHistory?: FismDailyCheckInRecord[];
  currentTier: FismMilestoneTier;
  hasRedMilestoneTick: boolean;
  claimedTiers: Exclude<FismMilestoneTier, 'none'>[];
  equippedFrame: FismProfileFrameId;
  vipGoldBadgeUnlocked: boolean;
  aiBoostActive: boolean;
  topAlgorithmBoost: boolean;
  freePremiumMonthClaimed: boolean;
  premiumBonusExpiresAt?: string;
  redCyberpunkMode: boolean;
  founderGiftClaimed: boolean;
  updatedAt: string;
}

export const FISM_MILESTONE_ROADMAP: FismMilestoneTierConfig[] = [
  {
    tier: 'bronze',
    minYears: 1,
    yearLabel: 'Year 1',
    cardName: 'Bronze Card',
    badgeTitle: '1-Year Veteran',
    spReward: 100,
    frameId: 'first_year_bronze',
    algorithmBoostPoints: 0,
    aestheticSummary: 'Premium Metallic Bronze Finish · Engraved FISM Mark · Red Milestone Tick',
    perks: [
      'Special Red Milestone Tick unlocked on Profile, Posts & Comments',
      '100 SP Coins credited to wallet',
      "Exclusive 'First Year' Metallic Bronze Profile Frame",
    ],
  },
  {
    tier: 'silver',
    minYears: 2,
    yearLabel: 'Year 2',
    cardName: 'Silver Card',
    badgeTitle: '2-Year Legend',
    spReward: 250,
    frameId: 'silver_glass',
    algorithmBoostPoints: 0,
    aestheticSummary: 'Luminous Silver-Glass Frosted Finish · Prismatic Specular Rim',
    perks: [
      '250 SP Coins credited to wallet',
      '1 Month Free Access to FISM Premium Features',
      "Exclusive 'Silver-Glass' Profile Frame",
    ],
  },
  {
    tier: 'platinum',
    minYears: 3,
    yearLabel: 'Year 3',
    cardName: 'Platinum Card',
    badgeTitle: '3-Year Platinum',
    spReward: 500,
    frameId: 'platinum_aura',
    algorithmBoostPoints: 24,
    aestheticSummary: 'Sleek Luxury Platinum-Glow Finish · Liquid Chrome Surface',
    perks: [
      '500 SP Coins credited to wallet',
      'AI Algorithm Boost active on all Posts, Main Blast & Quick Burst videos',
      'Luxury Platinum Profile Aura Frame',
    ],
  },
  {
    tier: 'gold',
    minYears: 4,
    yearLabel: 'Year 4',
    cardName: 'Gold Card',
    badgeTitle: '4-Year Sovereign',
    spReward: 1000,
    frameId: 'gold_vip',
    algorithmBoostPoints: 35,
    aestheticSummary: 'Royal Gold Finish · Animated Diamond-Dust Sparkle Texture',
    perks: [
      '1,000 SP Coins credited to wallet',
      "Special 'VIP Gold Badge' shining in Chatter Comments & Community Chat",
      'Royal Gold Diamond-Dust Frame + +35 AI Reach Boost',
    ],
  },
  {
    tier: 'red',
    minYears: 5,
    yearLabel: 'Year 5+',
    cardName: 'Ultimate Red Card (Masterpiece)',
    badgeTitle: '5+ Year Red Legend',
    spReward: 2500,
    frameId: 'red_cyberpunk',
    algorithmBoostPoints: 80,
    aestheticSummary: 'Blood-Red Neon Glow · Dark Obsidian Cyberpunk Masterpiece Finish',
    perks: [
      'Highest FISM Platform Status + Top Algorithm Priority Boost on Videos & Sparks',
      '2,500 SP Coins credited to wallet',
      'Direct Founder & Admin Surprise Gifts / Exclusive Merchandise Access',
      'Secret Easter Egg: Full-App Red Cyberpunk VIP Theme Mode',
    ],
  },
];

export function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

function addCalendarYearsUtc(date: Date, years: number): Date {
  const y = date.getUTCFullYear() + years;
  const m = date.getUTCMonth();
  const d = date.getUTCDate();
  if (m === 1 && d === 29 && !isLeapYear(y)) {
    return new Date(Date.UTC(y, 1, 28, date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds()));
  }
  return new Date(Date.UTC(y, m, d, date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds()));
}

function findLeapDayBetween(startMs: number, endMs: number): string | undefined {
  const startYear = new Date(startMs).getUTCFullYear();
  const endYear = new Date(endMs).getUTCFullYear();
  for (let y = startYear; y <= endYear; y++) {
    if (!isLeapYear(y)) continue;
    const feb29Ms = Date.UTC(y, 1, 29, 0, 0, 0);
    if (feb29Ms >= startMs && feb29Ms < endMs) {
      return `${y}-02-29`;
    }
  }
  return undefined;
}

export function computeExactMilestoneSchedule(
  joinedAtIso?: string,
  effectiveDaysOverride?: number,
): {
  joinedAtIso: string;
  effectiveDays: number;
  calendarElapsedDays: number;
  totalFiveYearDays: number;
  schedule: FismMilestoneYearScheduleItem[];
} {
  const parsedMs = joinedAtIso ? Date.parse(joinedAtIso) : Date.now();
  const safeStartMs = Number.isNaN(parsedMs) ? Date.now() : parsedMs;
  const startDate = new Date(safeStartMs);
  const calendarElapsedDays = Math.floor(Math.max(0, Date.now() - safeStartMs) / 86_400_000);
  const effectiveDays =
    typeof effectiveDaysOverride === 'number' && !Number.isNaN(effectiveDaysOverride)
      ? Math.max(0, Math.floor(effectiveDaysOverride))
      : calendarElapsedDays;

  const tierByYear: Record<1 | 2 | 3 | 4 | 5, { tier: Exclude<FismMilestoneTier, 'none'>; cardName: string }> = {
    1: { tier: 'bronze', cardName: 'Bronze Card' },
    2: { tier: 'silver', cardName: 'Silver Card' },
    3: { tier: 'platinum', cardName: 'Platinum Card' },
    4: { tier: 'gold', cardName: 'Gold Card' },
    5: { tier: 'red', cardName: 'Ultimate Red Card (Masterpiece)' },
  };

  let cumulative = 0;
  let prevBoundary = startDate;
  const schedule: FismMilestoneYearScheduleItem[] = [];

  for (const yr of [1, 2, 3, 4, 5] as const) {
    const nextBoundary = addCalendarYearsUtc(startDate, yr);
    const spanDaysRaw = Math.round((nextBoundary.getTime() - prevBoundary.getTime()) / 86_400_000);
    const daysInThatYear: 365 | 366 = spanDaysRaw >= 366 ? 366 : 365;
    const leapDate = findLeapDayBetween(prevBoundary.getTime(), nextBoundary.getTime());
    cumulative += daysInThatYear;
    const daysCompleted = Math.min(cumulative, effectiveDays);
    const daysRemaining = Math.max(0, cumulative - effectiveDays);
    const progressPct = Math.min(100, Math.round((daysCompleted / cumulative) * 100));
    schedule.push({
      yearNumber: yr,
      tier: tierByYear[yr].tier,
      yearLabel: yr === 5 ? 'Year 5+' : `Year ${yr}`,
      cardName: tierByYear[yr].cardName,
      daysInThatYear,
      isLeapYearIncluded: daysInThatYear === 366 || Boolean(leapDate),
      leapYearDateIso: leapDate,
      cumulativeDaysRequired: cumulative,
      unlockDateIso: nextBoundary.toISOString().slice(0, 10),
      daysCompleted,
      daysRemaining,
      progressPct,
      unlocked: effectiveDays >= cumulative,
    });
    prevBoundary = nextBoundary;
  }

  return {
    joinedAtIso: startDate.toISOString(),
    effectiveDays,
    calendarElapsedDays,
    totalFiveYearDays: cumulative,
    schedule,
  };
}

export function getMilestoneTierFromYears(tenureYears: number): FismMilestoneTier {
  if (tenureYears >= 5) return 'red';
  if (tenureYears >= 4) return 'gold';
  if (tenureYears >= 3) return 'platinum';
  if (tenureYears >= 2) return 'silver';
  if (tenureYears >= 1) return 'bronze';
  return 'none';
}

export function computeTenureStats(
  joinedAtIso?: string,
  verifiedCheckInDays?: number,
): {
  tenureYears: number;
  tenureDays: number;
  tier: FismMilestoneTier;
  hasRedMilestoneTick: boolean;
} {
  const sched = computeExactMilestoneSchedule(joinedAtIso, verifiedCheckInDays);
  const effectiveDays =
    typeof verifiedCheckInDays === 'number'
      ? Math.min(sched.calendarElapsedDays > 0 ? Math.max(verifiedCheckInDays, sched.calendarElapsedDays) : verifiedCheckInDays, verifiedCheckInDays)
      : sched.calendarElapsedDays;

  let tier: FismMilestoneTier = 'none';
  for (const item of sched.schedule) {
    if (effectiveDays >= item.cumulativeDaysRequired) {
      tier = item.tier;
    }
  }
  const year1Days = sched.schedule[0]?.cumulativeDaysRequired || 365;
  const tenureYears = Number((effectiveDays / (sched.totalFiveYearDays / 5 || 365.2)).toFixed(2));
  return {
    tenureYears,
    tenureDays: effectiveDays,
    tier,
    hasRedMilestoneTick: effectiveDays >= year1Days,
  };
}
export interface FismTrackedVideoEngagement {
  postId: string;
  videoTitle: string;
  category?: string;
  watchedAt: string;
  watchSeconds: number;
  durationSeconds: number;
  completionPct: number;
  liked: boolean;
  likedAt?: string;
  commented: boolean;
  commentText?: string;
  commentedAt?: string;
  saved: boolean;
  savedAt?: string;
  downloaded: boolean;
  downloadedAt?: string;
}

export interface FismBrandedDownloadRecord {
  downloadId: string;
  postId: string;
  videoTitle: string;
  filename: string;
  watermarkLabel: string;
  downloadedAt: string;
  sizeBytes: number;
  ffmpegEngine: string;
}

export interface FismEncryptedIdVaultDoc {
  docId: string;
  docType: string;
  status: 'verified' | 'rejected' | 'pending';
  calculatedAge?: number;
  extractedDob?: string;
  mimeType: string;
  encryptionAlgorithm: 'AES-256-GCM';
  ciphertextHash: string;
  ivHex: string;
  uploadedAt: string;
  uploaderIp: string;
  deviceName: string;
  note?: string;
}

export interface FismAdminUserFolder {
  uid: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  email: string;
  phoneNumber: string;
  ipAddress: string;
  deviceName: string;
  platformOs: string;
  isBanned: boolean;
  accountAgeLabel: string;
  milestoneTier: FismMilestoneTier;
  walletCoins: number;
  spCoins: number;
  followersCount: number;
  followingCount: number;
  followersList: string[];
  followingList: string[];
  totalWatchSeconds: number;
  watchLogs: FismTrackedVideoEngagement[];
  likedCount: number;
  unlikedWatchedCount: number;
  commentedCount: number;
  uncommentedWatchedCount: number;
  savedCount: number;
  downloadedVideos: FismBrandedDownloadRecord[];
  encryptedIdDocuments: FismEncryptedIdVaultDoc[];
  lastActiveAt: string;
  recentEvents: { action: string; detail: string; timestamp: string }[];
}

export interface FismBackupManifestFile {
  relativePath: string;
  content: string;
}

export interface FismDefenseLayerTier {
  tierId: string;
  tierName: string;
  layerStart: number;
  layerEnd: number;
  layerCount: number;
  status: 'ENFORCING' | 'ACTIVE_PATROL';
  highlights: string[];
}

export interface FismSecurityRedAlert {
  alertId: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  threatType: string;
  layerTriggered: string;
  attackerIp: string;
  deviceFingerprint: string;
  deviceName: string;
  platformOs: string;
  attemptedVector: string;
  timestamp: string;
  actionTaken: 'AUTO_EJECT_AND_BLACKHOLE' | 'SANITIZED_SELF_HEALED' | 'RATE_THROTTLED_EJECTED';
  blackholed: boolean;
  encryptedEvidenceHash: string;
  encryptedEvidenceCiphertext?: string;
  encryptedEvidenceIvHex?: string;
  selfHealPatch: string;
}

export interface FismBlackholedEntity {
  id: string;
  ipAddress: string;
  deviceFingerprint: string;
  deviceName: string;
  reason: string;
  threatType: string;
  blockedAt: string;
  blockedRequestsCount: number;
}

export interface FismSelfHealLogEntry {
  healId: string;
  vulnerabilitySignature: string;
  patchApplied: string;
  targetModule: string;
  healedAt: string;
  verificationStatus: 'VERIFIED_INTACT';
}

export interface FismSecurityGridState {
  totalDefenseLayers: number;
  encryptionStandard: string;
  zeroTrustEnabled: boolean;
  autoEjectEnabled: boolean;
  selfHealingEnabled: boolean;
  blockedAttacksTotal: number;
  packetsInspectedTotal: number;
  defenseTiers: FismDefenseLayerTier[];
  blackholedEntities: FismBlackholedEntity[];
  redAlerts: FismSecurityRedAlert[];
  selfHealLogs: FismSelfHealLogEntry[];
}

